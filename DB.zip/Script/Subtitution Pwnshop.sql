--select * from xxx_Pawnshop;
--select distinct trdate from xxx_Pawnshop;
--select distinct ENTITY from xxx_Pawnshop;

-----Asset------
With PwnAssetA as (
			select sum(AMTPESO) as AssetA , ENTITY, TRDATE from xxx_Pawnshop	
			where RECNO in ('10','20','30','47','48','50','51','110','121','151','152','153','154','155','163','181','184')
			--and TRDATE = '2018-12-31 00:00:00.000'
			and SCHNO = 'BS'
			group by ENTITY, TRDATE 
)

, PwnAssetB as ( 
			select sum(AMTPESO) as AssetB , ENTITY, TRDATE from xxx_Pawnshop where
			RECNO in ('157','164','182','187')
			and SCHNO = 'BS'
			group by ENTITY, TRDATE  				
)

,	PwnAsset as (		select sum(A.AssetA) - sum(B.AssetB) as AssetAMTPESO, A.trdate, A.ENTITY  from PwnAssetA A join PwnAssetB B
		on A.ENTITY = B.ENTITY and A.TRDATE = B.TRDATE
		group by A.trdate, A.ENTITY
)

-----Liabilities------
,	PwnLiab as (	
			Select sum(AMTPESO) as LiabAMTPESO , ENTITY, TRDATE from xxx_Pawnshop 
			where RECNO in ('203','230','310','329','328')
			and SCHNO = 'BS'
			group by ENTITY, TRDATE
	)

-----Equity------
,	PwnEquityA as (	
			Select sum(AMTPESO) as EquityA , ENTITY, TRDATE from xxx_Pawnshop 
			where RECNO in ('340','343','359','360')
			and SCHNO = 'BS'
			group by ENTITY, TRDATE
	)

,	PwnEquityB as (	
			Select sum(AMTPESO) as EquityB , ENTITY, TRDATE from xxx_Pawnshop 
			where RECNO in ('345')
			and SCHNO = 'BS'
			group by ENTITY, TRDATE
	)

,	PwnEquity as (		
		select sum(A.EquityA) - sum(B.EquityB) as EquityAMTPESO, A.trdate, A.ENTITY  from PwnEquityA A join PwnEquityB B
		on A.ENTITY = B.ENTITY and A.TRDATE = B.TRDATE
		group by A.trdate, A.ENTITY
		)

-----Capital------
,	PwnCapitalA as (	
			Select sum(AMTPESO) as CapitalA , ENTITY, TRDATE from xxx_Pawnshop 
			where RECNO in ('398','399','415')
			and SCHNO = 'BS'
			group by ENTITY, TRDATE
	)

,	PwnCapitalB as (	
			Select sum(AMTPESO) as CapitalB , ENTITY, TRDATE from xxx_Pawnshop 
			where RECNO in ('410')
			and SCHNO = 'BS'
			group by ENTITY, TRDATE
	)


,PwnCapital as (		
		Select sum(A.CapitalA) - sum(B.CapitalB) as CapitalAMTPESO, A.trdate, A.ENTITY  from PwnCapitalA A join PwnCapitalB B
		on A.ENTITY = B.ENTITY and A.TRDATE = B.TRDATE
		group by A.trdate, A.ENTITY
	)

,PwnLECAMTPESO as (		
				Select CapitalAMTPESO + EquityAMTPESO + LiabAMTPESO as LECAMTPESO, A.trdate, A.ENTITY  
				from PwnLiab A join PwnEquity B 
					on A.ENTITY = B.ENTITY 
					and A.TRDATE = B.TRDATE
				join PwnCapital C
					on A.ENTITY = C.ENTITY
					and A.TRDATE = C.TRDATE
				--group by A.trdate, A.ENTITY
			)

,PwnAMTPESOCH as (	
		Select  A.AssetAMTPESO - b.LECAMTPESO PwnAMTPESOCheck, A.ENTITY, A.TRDATE  
		,TAG = Case
				when A.ENTITY = '310798' and  A.TRDATE = '2018-12-31 00:00:00.000' Then 0
				else 1
			END

		from PwnAsset A join PwnLECAMTPESO B
		on A.ENTITY = B.ENTITY
		and A.TRDATE = B.TRDATE
	)

	Select PwnAMTPESOCheck,ENTITY, TRDATE,
	TAG = 
	CASE 
		WHEN PwnAMTPESOCheck = 0 and TAG <> 0 then 1
		else 0
		END
	from PwnAMTPESOCH
