-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_LOAD_MFSG_CSOC_PAWNSHOP_v2
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert into Staging Fact table
	INSERT INTO S_FACT_MFSG_CSOC_PAWNSHOP
	SELECT C.Time_Idx 
			,A.BNKIND 
			,A.RECNO	
			,A.SCHNO	
			,A.AMOUNT
			,A.[TABLE]
	FROM [vw_PAWNSHOP] A 
	JOIN [vw_PAWNSHOP_BALANCING] B
	ON A.ENTITY = B.ENTITY 
	AND A.TRDATE = B.TRDATE
	JOIN DES.dbo.Dim_Time C
	ON A.TRDATE = C.Date_Code
	WHERE AMOUNT IS NOT NULL and RECNO <> 0
	AND B.TAG = 1

-----Update Record for recno 410------
UPDATE S_FACT_MFSG_CSOC_PAWNSHOP 
SET  amount = amount * -1
where recno = 410
----------------------------

-----DELETE OLD RECORD------
	Delete from [DES].[dbo].[FACT_CSOC_NBFI_PAWNSHOP]
	WHERE Time_Idx IN (SELECT DISTINCT TRDATE from [S_FACT_MFSG_CSOC_PAWNSHOP]) OR Time_Idx = -1;

INSERT INTO [des].[dbo].[FACT_CSOC_NBFI_PAWNSHOP]
	SELECT  DISTINCT
	C.Time_Idx
	,D.[BNKIND_Idx]
	,B.[RecNo_Idx]
	--,A.RECNO
	--,[SCHNO]
	,[AMOUNT] 
	,[TABLE]
	FROM [S_FACT_MFSG_CSOC_PAWNSHOP] A
		LEFT JOIN [DES].[dbo].[Dim_MFSG_NBFI] B
	ON A.[RECNO] = B. [RecNo_Code]
	LEFT JOIN (
        SELECT 
            MAX(Time_Idx) Time_Idx,
            Quarter_Name
        FROM [DES].dbo.Dim_Time
        GROUP BY Quarter_Name
    )C
	ON  A.TRDATE = C.Time_Idx
	JOIN DES.[dbo].[Dim_INS_INDUSTRY] D
	ON A.BNKIND =  D.[BNKIND]
		WHERE B.INDUSTRY_GROUP = 'PAWNSHOP' 


END
GO
