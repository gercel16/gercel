select * from xxx_Pawnshop
;

With PwnAsset AS (
				select * from  xxx_Pawnshop			
				)
	
select * from PwnAsset