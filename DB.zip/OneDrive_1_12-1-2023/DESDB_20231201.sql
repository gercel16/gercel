USE [master]
GO
/****** Object:  Database [DES]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE DATABASE [DES]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'EDW', FILENAME = N'D:\DATA\DES.MDF' , SIZE = 27247936KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'EDW_log', FILENAME = N'E:\Logs\DES_Log.ldf' , SIZE = 80839616KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [DES] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [DES].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [DES] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [DES] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [DES] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [DES] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [DES] SET ARITHABORT OFF 
GO
ALTER DATABASE [DES] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [DES] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [DES] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [DES] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [DES] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [DES] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [DES] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [DES] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [DES] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [DES] SET  DISABLE_BROKER 
GO
ALTER DATABASE [DES] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [DES] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [DES] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [DES] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [DES] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [DES] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [DES] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [DES] SET RECOVERY FULL 
GO
ALTER DATABASE [DES] SET  MULTI_USER 
GO
ALTER DATABASE [DES] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [DES] SET DB_CHAINING OFF 
GO
ALTER DATABASE [DES] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [DES] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [DES] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [DES] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
EXEC sys.sp_db_vardecimal_storage_format N'DES', N'ON'
GO
ALTER DATABASE [DES] SET QUERY_STORE = OFF
GO
USE [DES]
GO
/****** Object:  User [SXV01EDWDB1D\Administrator]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [SXV01EDWDB1D\Administrator] FOR LOGIN [SXV01EDWDB1D\Administrator] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [NTTDeveloper]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [NTTDeveloper] WITHOUT LOGIN WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [ITSMDnooraaj]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [ITSMDnooraaj] WITHOUT LOGIN WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [ITSMDmartyfb]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [ITSMDmartyfb] WITHOUT LOGIN WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [ITSMDdelimaab]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [ITSMDdelimaab] WITHOUT LOGIN WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [ITSMDcastilloca]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [ITSMDcastilloca] WITHOUT LOGIN WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [ETLADMIN]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [ETLADMIN] WITHOUT LOGIN WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [BSP\TDEDWHCIQS1_ADM]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [BSP\TDEDWHCIQS1_ADM] FOR LOGIN [BSP\TDEDWHCIQS1_ADM] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [BSP\PDEDWPCDEV5_ADM]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [BSP\PDEDWPCDEV5_ADM] FOR LOGIN [BSP\PDEDWPCDEV5_ADM] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [BSP\PDEDWPCDEV4_ADM]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [BSP\PDEDWPCDEV4_ADM] FOR LOGIN [BSP\PDEDWPCDEV4_ADM] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [BSP\PDEDWPCDEV3_ADM]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [BSP\PDEDWPCDEV3_ADM] FOR LOGIN [BSP\PDEDWPCDEV3_ADM] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [BSP\PDEDWPCDEV2_ADM]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [BSP\PDEDWPCDEV2_ADM] FOR LOGIN [BSP\PDEDWPCDEV2_ADM] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [BSP\PDEDWPCDEV1_ADM]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [BSP\PDEDWPCDEV1_ADM] FOR LOGIN [BSP\PDEDWPCDEV1_ADM] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [BSP\GarciaDC]    Script Date: 12/1/2023 3:41:31 PM ******/
CREATE USER [BSP\GarciaDC] FOR LOGIN [BSP\GarciaDC] WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [SXV01EDWDB1D\Administrator]
GO
ALTER ROLE [db_owner] ADD MEMBER [NTTDeveloper]
GO
ALTER ROLE [db_datareader] ADD MEMBER [ITSMDnooraaj]
GO
ALTER ROLE [db_datareader] ADD MEMBER [ITSMDmartyfb]
GO
ALTER ROLE [db_datareader] ADD MEMBER [ITSMDdelimaab]
GO
ALTER ROLE [db_datareader] ADD MEMBER [ITSMDcastilloca]
GO
ALTER ROLE [db_datareader] ADD MEMBER [ETLADMIN]
GO
ALTER ROLE [db_datawriter] ADD MEMBER [ETLADMIN]
GO
ALTER ROLE [db_owner] ADD MEMBER [BSP\TDEDWHCIQS1_ADM]
GO
ALTER ROLE [db_owner] ADD MEMBER [BSP\PDEDWPCDEV5_ADM]
GO
ALTER ROLE [db_owner] ADD MEMBER [BSP\PDEDWPCDEV4_ADM]
GO
ALTER ROLE [db_owner] ADD MEMBER [BSP\PDEDWPCDEV3_ADM]
GO
ALTER ROLE [db_owner] ADD MEMBER [BSP\PDEDWPCDEV2_ADM]
GO
ALTER ROLE [db_owner] ADD MEMBER [BSP\PDEDWPCDEV1_ADM]
GO
ALTER ROLE [db_owner] ADD MEMBER [BSP\GarciaDC]
GO
GRANT CONNECT TO [BSP\GarciaDC] AS [dbo]
GO
GRANT CONNECT TO [BSP\PDEDWPCDEV1_ADM] AS [dbo]
GO
GRANT CONNECT TO [BSP\PDEDWPCDEV2_ADM] AS [dbo]
GO
GRANT CONNECT TO [BSP\PDEDWPCDEV3_ADM] AS [dbo]
GO
GRANT CONNECT TO [BSP\PDEDWPCDEV4_ADM] AS [dbo]
GO
GRANT CONNECT TO [BSP\PDEDWPCDEV5_ADM] AS [dbo]
GO
GRANT CONNECT TO [BSP\TDEDWHCIQS1_ADM] AS [dbo]
GO
GRANT CONNECT TO [ETLADMIN] AS [dbo]
GO
GRANT CONNECT TO [ITSMDcastilloca] AS [dbo]
GO
GRANT CONNECT TO [ITSMDdelimaab] AS [dbo]
GO
GRANT CONNECT TO [ITSMDmartyfb] AS [dbo]
GO
GRANT CONNECT TO [ITSMDnooraaj] AS [dbo]
GO
GRANT CONNECT TO [NTTDeveloper] AS [dbo]
GO
GRANT VIEW ANY COLUMN ENCRYPTION KEY DEFINITION TO [public] AS [dbo]
GO
GRANT VIEW ANY COLUMN MASTER KEY DEFINITION TO [public] AS [dbo]
GO
GRANT CONNECT TO [SXV01EDWDB1D\Administrator] AS [dbo]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_month_name_to_number]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Dola Garcia
-- =============================================
CREATE FUNCTION [dbo].[fn_month_name_to_number]
(
	-- Add the parameters for the function here
@monthname varchar(25)

)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
declare @monthno as int;

	-- Add the T-SQL statements to compute the return value here
select @monthno =
case @monthname
when 'Jan' then 1
when 'Feb' then 2
when 'Mar' then 3
when 'Apr' then 4
when 'May' then 5
when 'Jun' then 6
when 'Jul' then 7
when 'Aug' then 8
when 'Sep' then 9
when 'Oct' then 10
when 'Nov' then 11
when 'Dec' then 12
end

	-- Return the result of the function
return @monthno

END
GO
/****** Object:  UserDefinedFunction [dbo].[InitialCap]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[InitialCap](@String VARCHAR(8000))
                  RETURNS VARCHAR(8000)
                 AS
 BEGIN 

                   DECLARE @Position INT;

					SELECT @String   = STUFF(LOWER(@String),1,1,UPPER(LEFT(@String,1))) COLLATE Latin1_General_Bin,
                    @Position = PATINDEX('%[^A-Za-z''][a-z]%',@String COLLATE Latin1_General_Bin);

                    WHILE @Position > 0
                    SELECT @String   = STUFF(@String,@Position,2,UPPER(SUBSTRING(@String,@Position,2))) COLLATE Latin1_General_Bin,
                    @Position = PATINDEX('%[^A-Za-z''][a-z]%',@String COLLATE Latin1_General_Bin);

                     RETURN @String;

  END ;
GO
/****** Object:  Table [dbo].[Fact_ESLIG_SWCP_MonthlyPrice]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_SWCP_MonthlyPrice](
	[Time_Idx] [int] NOT NULL,
	[CommodityType_Idx] [int] NOT NULL,
	[SWCP_Type] [varchar](100) NOT NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FACT_SWCP_PAGE2]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[vw_FACT_SWCP_PAGE2]
AS

--	U.S DOLLAR PER TROY OUNCE
--U.S. CENT PER POUND
--U.S. DOLLAR PER METRIC TON
		SELECT * FROM (

		   SELECT [Time_Idx]
		  ,[CommodityType_Idx]
		  ,[SWCP_Type] = 'U.S DOLLAR PER TROY OUNCE'
		  ,[Value] 
		  FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] where CommodityType_Idx in ('34')

		  UNION ALL

		   SELECT  [Time_Idx]
		  ,[CommodityType_Idx]
		  ,[SWCP_Type] = 'U.S. CENT PER POUND'
		  ,[Value] = ([Value]/ 2204.62262 ) * 100
		  FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] where CommodityType_Idx in ('20','58','3')


		  UNION ALL
		   SELECT [Time_Idx]
		  ,[CommodityType_Idx]
		  ,[SWCP_Type] = 'U.S. DOLLAR PER METRIC TON'
		  ,[Value] 
		  FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] where CommodityType_Idx in ('20','58','3')

		
		) A
GO
/****** Object:  Table [dbo].[Dim_SWCP_CommodityType]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SWCP_CommodityType](
	[CommodityType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[CommodityType_Code] [nvarchar](max) NOT NULL,
	[CommodityType_Name] [nvarchar](max) NOT NULL,
	[CommodityType_Label] [nvarchar](max) NULL,
	[CommodityType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_CommodityType] PRIMARY KEY CLUSTERED 
(
	[CommodityType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FACT_SWCP_PAGE3]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[vw_FACT_SWCP_PAGE3]
AS

--	U.S DOLLAR PER TROY OUNCE
--U.S. CENT PER POUND
--U.S. DOLLAR PER METRIC TON
		SELECT * FROM (

		  -- SELECT [Time_Idx]
		  --,[CommodityType_Idx]
		  --,[SWCP_Type] = 'U.S DOLLAR PER TROY OUNCE'
		  --,[Value] 
		  --FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] where CommodityType_Idx in ('34')

		  --UNION ALL

		
		   SELECT [Time_Idx]
		  ,A.[CommodityType_Idx]
		  ,[SWCP_Type] = 'U.S. CENT PER POUND' 
		  ,[Value] = 
			CASE 
				WHEN B.CommodityType_Label = '($/mt)' THEN CONVERT(DECIMAL(18,2),(([Value] / 2204.62262 ) * 100 ))
				WHEN B.CommodityType_Label = '($/kg)' THEN CONVERT(DECIMAL(18,2),(([Value] / 2204.62262 ) * 100 ) * 1000)
			ELSE CONVERT(DECIMAL,[Value]  * 1000) 
			END
		  FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice]  A LEFT JOIN [Dim_SWCP_CommodityType] B 
		  ON A.[CommodityType_Idx]  = B.CommodityType_Idx 
		  where A.[CommodityType_Idx] is not null 



		  UNION ALL

		   SELECT [Time_Idx]
		  ,A.[CommodityType_Idx]
		  ,[SWCP_Type] = 'U.S. DOLLAR PER METRIC TON' 
		  ,[Value] = 
			CASE WHEN B.CommodityType_Label = '($/mt)' THEN [Value]
			ELSE CONVERT(DECIMAL,[Value]  * 1000) 
			END
		  FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice]  A LEFT JOIN [Dim_SWCP_CommodityType] B 
		  ON A.[CommodityType_Idx]  = B.CommodityType_Idx 
		  where A.[CommodityType_Idx] is not null 
		) A
GO
/****** Object:  View [dbo].[vw_FACT_SWCP_PAGE4]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[vw_FACT_SWCP_PAGE4]
AS

--	U.S DOLLAR PER TROY OUNCE
--U.S. CENT PER POUND
--U.S. DOLLAR PER METRIC TON
		SELECT * FROM (

		  -- SELECT [Time_Idx]
		  --,[CommodityType_Idx]
		  --,[SWCP_Type] = 'U.S DOLLAR PER TROY OUNCE'
		  --,[Value] 
		  --FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] where CommodityType_Idx in ('34')

		  --UNION ALL

		   SELECT  [Time_Idx]
		  ,[CommodityType] = 'C R U D E  O I L / U.S. DOLLAR/BARREL'
		  ,[SWCP_Type] = CASE WHEN CommodityType_Idx = 25 THEN 'BRENT CRUDE' ELSE 'DUBAI' END
		  ,[Value] = [Value] 
		  FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] where CommodityType_Idx in ('25','26')


		  UNION ALL

		  
		   SELECT  [Time_Idx]
		  ,[CommodityType] = 'Cotton'
		  ,[SWCP_Type] = 'U.S. CENT PER POUND'
		  ,[Value] = CONVERT(decimal(18,2),(([Value]/ 2204.62262 ) * 100 ) * 1000)
		  FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] where CommodityType_Idx in ('22') 

		  UNION ALL

		   SELECT [Time_Idx]
		  ,[CommodityType] = 'Cotton'
		  ,[SWCP_Type] = 'U.S. DOLLAR PER METRIC TON'
		  ,CONVERT(decimal,[Value] * 1000)
		  FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] where CommodityType_Idx in ('22') 

		) A


		
GO
/****** Object:  Table [dbo].[Dim_NUMFIN_RegulatedFI]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_NUMFIN_RegulatedFI](
	[RegulatedFI_Idx] [int] NOT NULL,
	[RegulatedFI_Code] [varchar](100) NOT NULL,
	[RegulatedFI_Name] [varchar](100) NOT NULL,
	[RegulatedFI_Label] [varchar](100) NOT NULL,
	[RegulatedFI_Sort] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_NUMFIN_BankType]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_NUMFIN_BankType](
	[BankType_Idx] [int] NOT NULL,
	[BankType_Code] [varchar](100) NOT NULL,
	[BankType_Name] [varchar](100) NOT NULL,
	[BankType_Label] [varchar](100) NOT NULL,
	[BankType_Sort] [int] NOT NULL,
	[RegulatedFI_Idx] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_NUMFIN_BankSubType]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_NUMFIN_BankSubType](
	[BankSubType_Idx] [int] NOT NULL,
	[BankSubType_Code] [varchar](100) NOT NULL,
	[BankSubType_Name] [varchar](100) NOT NULL,
	[BankSubType_Label] [varchar](100) NOT NULL,
	[BankSubType_Sort] [int] NOT NULL,
	[BankType_Idx] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_NUMFIN_Category]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_NUMFIN_Category](
	[Category_Idx] [int] NOT NULL,
	[Category_Code] [varchar](100) NOT NULL,
	[Category_Name] [varchar](100) NOT NULL,
	[Category_Label] [varchar](100) NOT NULL,
	[Category_Sort] [int] NOT NULL,
	[BankSubType_Idx] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_Dim_NUMFIN_FI]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_Dim_NUMFIN_FI]
AS
select 
a.RegulatedFI_Idx
,a.RegulatedFI_Code
,a.RegulatedFI_Name
,a.RegulatedFI_Label
,a.RegulatedFI_Sort
,b.BankType_Idx
,b.BankType_Code
,b.BankType_Name
,b.BankType_Label
,b.BankType_Sort
,c.BankSubType_Idx
,c.BankSubType_Code
,c.BankSubType_Name
,c.BankSubType_Label
,c.BankSubType_Sort
,d.Category_Idx
,d.Category_Code
,d.Category_Name
,d.Category_Label
,d.Category_Sort
from Dim_NUMFIN_RegulatedFI a
join Dim_NUMFIN_BankType b on a.RegulatedFI_Idx = b.RegulatedFI_Idx
join Dim_NUMFIN_BankSubType c on b.BankType_Idx = c.BankType_Idx
join Dim_NUMFIN_Category d on c.BankSubType_Idx = d.BankSubType_Idx
GO
/****** Object:  Table [dbo].[Dim_Company]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Company](
	[Company_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Company_Code] [nvarchar](150) NULL,
	[Company_Name] [nvarchar](150) NOT NULL,
	[Company_Label] [nvarchar](150) NULL,
	[Company_Sort] [int] NULL,
	[Industry_Idx] [int] NULL,
	[Type_Idx] [int] NULL,
	[Sector_Idx] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_Company] PRIMARY KEY CLUSTERED 
(
	[Company_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SOCF_Bonds]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SOCF_Bonds](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Sector_Idx] [int] NULL,
	[Group_Idx] [int] NULL,
	[Company_Idx] [int] NOT NULL,
	[Currency_Code] [nvarchar](50) NULL,
	[Maturity_Code] [nvarchar](50) NULL,
	[Matref_Type] [nvarchar](50) NULL,
	[AmountIssued] [numeric](18, 2) NULL,
	[RealER] [numeric](18, 2) NULL,
	[InPeso] [numeric](18, 2) NULL,
	[Rank] [int] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Time]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Time](
	[Time_Idx] [int] NOT NULL,
	[Date_Code] [nvarchar](50) NOT NULL,
	[Date_Name] [nvarchar](150) NULL,
	[Date_Label] [nvarchar](150) NULL,
	[Date_Sort] [int] NULL,
	[Week_Code] [nvarchar](50) NULL,
	[Week_Name] [nvarchar](150) NULL,
	[Week_Sort] [int] NULL,
	[Period_Code] [nvarchar](50) NULL,
	[Period_Name] [nvarchar](150) NULL,
	[Period_Sort] [int] NULL,
	[Quarter_Code] [nvarchar](50) NULL,
	[Quarter_Name] [nvarchar](150) NULL,
	[Quarter_Sort] [int] NULL,
	[Semester_Code] [nvarchar](50) NULL,
	[Semester_Name] [nvarchar](150) NOT NULL,
	[Semester_Sort] [int] NULL,
	[Year_Code] [nvarchar](50) NULL,
	[Year_Name] [nvarchar](150) NULL,
	[Year_Sort] [int] NULL,
	[Month_Name] [nvarchar](50) NULL,
	[YearToDate_Name] [nvarchar](150) NULL,
	[Month_SName] [nvarchar](50) NULL,
	[YearToDate_SName] [nvarchar](50) NULL,
	[Month_Sort] [int] NULL,
	[ActualDate] [datetime] NOT NULL,
	[Year] [int] NOT NULL,
	[Quarter] [int] NOT NULL,
	[Month] [int] NOT NULL,
	[Week] [int] NOT NULL,
	[DayofYear] [int] NOT NULL,
	[DayofMonth] [int] NOT NULL,
	[DayofWeek] [int] NOT NULL,
	[IsWeekend] [bit] NOT NULL,
	[IsHoliday] [bit] NULL,
	[BusinessYearWeek] [int] NOT NULL,
	[LeapYear] [tinyint] NOT NULL,
	[Month_YTDSname] [nvarchar](50) NULL,
	[IsWeekDay] [bit] NULL,
	[IsWorkDay] [bit] NULL,
	[WorkStart_Date] [int] NULL,
	[WorkDate_Range] [nvarchar](100) NULL,
 CONSTRAINT [PK_Dim_Time_1] PRIMARY KEY CLUSTERED 
(
	[Time_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FACT_SOC_Equity_Annual]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_FACT_SOC_Equity_Annual] AS
SELECT
	ROW_NUMBER() OVER(PARTITION BY Year_Name ORDER BY InPEso DESC) AS Rank,
	Year_Name,
	Company_Name,
	InPeso
FROM(
	SELECT
		C.Company_Name,
		B.Year_Name,
		SUM(A.InPeso) AS InPeso
	FROM DES.dbo.Fact_SOCF_Bonds A
	JOIN DES.dbo.Dim_Time B
	ON A.Time_Idx = B.Time_Idx
	JOIN DES.dbo.Dim_Company C
	ON A.Company_Idx = C.Company_Idx
	GROUP BY Company_Name,B.Date_Name,Month_Name,Year_Name
)A
GO
/****** Object:  View [dbo].[vw_FACT_SOC_Equity_Monthly]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[vw_FACT_SOC_Equity_Monthly] AS
SELECT
	ROW_NUMBER() OVER(PARTITION BY Month_Name, Year_Name ORDER BY InPEso DESC) AS Rank,
	Company_Name,
	Date_Listed,
	InPeso
FROM(
	SELECT
		C.Company_Name,
		B.Month_Name,
		B.Year_Name,
		B.Date_Name AS Date_Listed,
		SUM(A.InPeso) AS InPeso
	FROM DES.dbo.Fact_SOCF_Bonds A
	JOIN DES.dbo.Dim_Time B
	ON A.Time_Idx = B.Time_Idx
	JOIN DES.dbo.Dim_Company C
	ON A.Company_Idx = C.Company_Idx
	GROUP BY Company_Name,B.Date_Name,Month_Name,Year_Name
)A
GO
/****** Object:  Table [dbo].[Fact_BES_ConsolidatedRespondents]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_ConsolidatedRespondents](
	[Time_Idx] [int] NULL,
	[Company_Name] [nvarchar](255) NULL,
	[Sector_Code] [nvarchar](255) NULL,
	[Subsector_Code] [nvarchar](255) NULL,
	[Region_Code] [nvarchar](255) NULL,
	[ProductLine] [nvarchar](255) NULL,
	[ContactPerson] [nvarchar](255) NULL,
	[Designation] [nvarchar](255) NULL,
	[Email] [nvarchar](255) NULL,
	[Address1] [nvarchar](255) NULL,
	[Address2] [nvarchar](255) NULL,
	[TelephoneNumber] [nvarchar](255) NULL,
	[FaxNumber] [nvarchar](255) NULL,
	[DateReceive ] [date] NULL,
	[InputtedSector] [nvarchar](255) NULL,
	[InputtedSubsector] [nvarchar](255) NULL,
	[BusinessOutlookCQ] [nvarchar](255) NULL,
	[BusinessOutlookNQ] [nvarchar](255) NULL,
	[BusinessOutlookN12M] [nvarchar](255) NULL,
	[CQReasonBusinessOutlook] [nvarchar](max) NULL,
	[NQReasonBusinessOutlook] [nvarchar](max) NULL,
	[N12MReasonBusinessOutlook] [nvarchar](max) NULL,
	[CQVolumeofBusinessActivity] [nvarchar](255) NULL,
	[NQVolumeofBusinessActivity] [nvarchar](255) NULL,
	[CQVolumeofTotalOrderBook] [nvarchar](255) NULL,
	[NQVolumeofTotalOrderBook] [nvarchar](255) NULL,
	[CQVolumeofImportOrderBook] [nvarchar](255) NULL,
	[NQVolumeofImportOrderBook] [nvarchar](255) NULL,
	[CQAverageSellingPricePriceofServices] [nvarchar](255) NULL,
	[NQAverageSellingPricePriceofServices] [nvarchar](255) NULL,
	[CQVolumeofExportOrderBook] [nvarchar](255) NULL,
	[NQVolumeofExportOrderBook] [nvarchar](255) NULL,
	[CQCapitalExpenditure] [nvarchar](255) NULL,
	[NQCapitalExpenditure] [nvarchar](255) NULL,
	[CQVolumeofStocks] [nvarchar](255) NULL,
	[NQVolumeofStocks] [nvarchar](255) NULL,
	[CQInventoryofRawMaterials] [nvarchar](255) NULL,
	[NQInventoryofRawMaterials] [nvarchar](255) NULL,
	[CQFinishedGoodsforSale] [nvarchar](255) NULL,
	[NQFinishedGoodsforSale] [nvarchar](255) NULL,
	[CQNetIncome] [nvarchar](255) NULL,
	[NQNetIncome] [nvarchar](255) NULL,
	[CQBusinessConditions] [nvarchar](255) NULL,
	[NQBusinessConditions] [nvarchar](255) NULL,
	[NumberofEmployees] [int] NULL,
	[NQNumberofEmployees] [nvarchar](255) NULL,
	[NQExpansionPlans] [nvarchar](255) NULL,
	[CQFinancialConditions] [nvarchar](255) NULL,
	[NQFinancialConditions] [nvarchar](255) NULL,
	[Reason CQ] [nvarchar](max) NULL,
	[Reason NQ] [nvarchar](max) NULL,
	[CQAccesstoCredit] [nvarchar](255) NULL,
	[NQAccesstoCredit] [nvarchar](255) NULL,
	[Reason_A_CQ] [nvarchar](max) NULL,
	[Reason_A_NQ] [nvarchar](max) NULL,
	[CurrentPercentLevelofCapacityUtilization] [numeric](18, 2) NULL,
	[PresentTechnicalCapacity] [nvarchar](255) NULL,
	[None] [nvarchar](255) NULL,
	[Highinterestrate] [nvarchar](255) NULL,
	[Financialproblems] [nvarchar](255) NULL,
	[Insufficientdemand] [nvarchar](255) NULL,
	[Accesstocredit] [nvarchar](255) NULL,
	[Lackofequipment] [nvarchar](255) NULL,
	[Lackofmaterialinput] [nvarchar](255) NULL,
	[Uncleareconomiclaws] [nvarchar](255) NULL,
	[Foreigncompetition] [nvarchar](255) NULL,
	[Domesticcompetition] [nvarchar](255) NULL,
	[Laborproblems] [nvarchar](255) NULL,
	[Others] [nvarchar](255) NULL,
	[OthersSpecify] [nvarchar](255) NULL,
	[LimitingFactor1] [nvarchar](255) NULL,
	[LFReason1] [nvarchar](max) NULL,
	[LimitingFactor2] [nvarchar](255) NULL,
	[LFReason2] [nvarchar](max) NULL,
	[LimitingFactor3] [nvarchar](255) NULL,
	[LFReason3] [nvarchar](max) NULL,
	[N12MVolumeofBusinessActivity] [nvarchar](255) NULL,
	[N12MVolumeofExportOrderBook] [nvarchar](255) NULL,
	[N12MVolumeofImportOrderBook] [nvarchar](255) NULL,
	[N12MBusinessConditions] [nvarchar](255) NULL,
	[N12MAverageSellingPrice] [nvarchar](255) NULL,
	[N12MNumberofEmployees] [nvarchar](255) NULL,
	[N12MExpansionPlans] [nvarchar](255) NULL,
	[CQAveragePesoBorrowingRate] [nvarchar](255) NULL,
	[NQAveragePesoBorrowingRate] [nvarchar](255) NULL,
	[N12MAveragePesoBorrowingRate] [nvarchar](255) NULL,
	[CQAverageP$ExchangeRate] [nvarchar](255) NULL,
	[NQAverageP$ExchangeRate] [nvarchar](255) NULL,
	[N12MAverageP$ExchangeRate] [nvarchar](255) NULL,
	[CQInflationRate] [nvarchar](255) NULL,
	[NQInflationRate] [nvarchar](255) NULL,
	[N12MInflationRate] [nvarchar](255) NULL,
	[CQReasonInflationRateOutlook] [nvarchar](max) NULL,
	[NQReasonInflationRateOutlook] [nvarchar](max) NULL,
	[N12MReasonInflationOutlook] [nvarchar](max) NULL,
	[CQInflationRate_Value] [nvarchar](255) NULL,
	[NQInflationRate_Value] [nvarchar](255) NULL,
	[N12MInflationRate_Value] [nvarchar](255) NULL,
	[CQExchangeRate_Value] [numeric](18, 2) NULL,
	[NQExchangeRate_Value] [numeric](18, 2) NULL,
	[N12MExchangeRate_Value] [numeric](18, 2) NULL,
	[ImporterExporter] [nvarchar](255) NULL,
	[RegisteredName] [nvarchar](255) NULL,
	[SourceFile] [nvarchar](255) NULL,
	[Branch] [nvarchar](255) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_BES_EncodingTemplate]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/****** Script for SelectTopNRows command from SSMS  ******/

CREATE VIEW  [dbo].[vw_BES_EncodingTemplate]
AS
SELECT 
      [Company_Name]
      ,[Sector] = [Sector_Code]
      ,[Subsector] =[Subsector_Code]
      ,[Region] = [Region_Code]
      ,[ProductLine]
      ,[ContactPerson]
      ,[Designation]
      ,[Email]
      ,[Address1]
      ,[Address2]
      ,[TelephoneNumber]
      ,[FaxNumber]
      ,[DateReceive ]
      ,[InputtedSector]
      ,[InputtedSubsector]
      ,[BusinessOutlookCQ]
      ,[BusinessOutlookNQ]
      ,[BusinessOutlookN12M]
      ,[CQReasonBusinessOutlook]
      ,[NQReasonBusinessOutlook]
      ,[N12MReasonBusinessOutlook]
      ,[CQVolumeofBusinessActivity]
      ,[NQVolumeofBusinessActivity]
      ,[CQVolumeofTotalOrderBook]
      ,[NQVolumeofTotalOrderBook]
      ,[CQVolumeofImportOrderBook]
      ,[NQVolumeofImportOrderBook]
      ,[CQAverageSellingPricePriceofServices]
      ,[NQAverageSellingPricePriceofServices]
      ,[CQVolumeofExportOrderBook]
      ,[NQVolumeofExportOrderBook]
      ,[CQCapitalExpenditure]
      ,[NQCapitalExpenditure]
      ,[CQVolumeofStocks]
      ,[NQVolumeofStocks]
      ,[CQInventoryofRawMaterials]
      ,[NQInventoryofRawMaterials]
      ,[CQFinishedGoodsforSale]
      ,[NQFinishedGoodsforSale]
      ,[CQNetIncome]
      ,[NQNetIncome]
      ,[CQBusinessConditions]
      ,[NQBusinessConditions]
      ,[NumberofEmployees]
      ,[NQNumberofEmployees]
      ,[NQExpansionPlans]
      ,[CQFinancialConditions]
      ,[NQFinancialConditions]
      ,[Reason CQ]
      ,[Reason NQ]
      ,[CQAccesstoCredit]
      ,[NQAccesstoCredit]
      ,[Reason_A_CQ]
      ,[Reason_A_NQ]
      ,[CurrentPercentLevelofCapacityUtilization]
      ,[PresentTechnicalCapacity]
      ,[None]
      ,[Highinterestrate]
      ,[Financialproblems]
      ,[Insufficientdemand]
      ,[Accesstocredit]
      ,[Lackofequipment]
      ,[Lackofmaterialinput]
      ,[Uncleareconomiclaws]
      ,[Foreigncompetition]
      ,[Domesticcompetition]
      ,[Laborproblems]
      ,[Others]
      ,[OthersSpecify]
      ,[LimitingFactor1]
      ,[LFReason1]
      ,[LimitingFactor2]
      ,[LFReason2]
      ,[LimitingFactor3]
      ,[LFReason3]
      ,[N12MVolumeofBusinessActivity]
      ,[N12MVolumeofExportOrderBook]
      ,[N12MVolumeofImportOrderBook]
      ,[N12MBusinessConditions]
      ,[N12MAverageSellingPrice]
      ,[N12MNumberofEmployees]
      ,[N12MExpansionPlans]
      ,[CQAveragePesoBorrowingRate]
      ,[NQAveragePesoBorrowingRate]
      ,[N12MAveragePesoBorrowingRate]
      ,[CQAverageP$ExchangeRate]
      ,[NQAverageP$ExchangeRate]
      ,[N12MAverageP$ExchangeRate]
      ,[CQInflationRate]
      ,[NQInflationRate]
      ,[N12MInflationRate]
      ,[CQReasonInflationRateOutlook]
      ,[NQReasonInflationRateOutlook]
      ,[N12MReasonInflationOutlook]
      ,[CQInflationRate_Value]
      ,[NQInflationRate_Value]
      ,[N12MInflationRate_Value]
      ,[CQExchangeRate_Value]
      ,[NQExchangeRate_Value]
      ,[N12MExchangeRate_Value]
      ,[ImporterExporter]
      ,[RegisteredName]
      ,[SourceFile]
      ,[Branch]
  FROM [DES].[dbo].[Fact_BES_ConsolidatedRespondents]
   WHERE LEFT([Time_Idx],6) = (SELECT  LEFT(MAX(Time_Idx),6) FROM  [DES].[dbo].[Fact_BES_ConsolidatedRespondents])
   AND Company_Name <> '0'
GO
/****** Object:  Table [dbo].[BSP_RATES]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BSP_RATES](
	[Time_Idx] [int] NULL,
	[Particulars] [nvarchar](255) NULL,
	[TENOR] [varchar](36) NULL,
	[BKCODE] [int] NULL,
	[BASIS] [varchar](6) NULL,
	[PART] [varchar](17) NULL,
	[ACCTCODE] [varchar](18) NULL,
	[TVNOTRAN] [numeric](19, 5) NULL,
	[TVAMOUNT] [numeric](19, 5) NULL,
	[IRLOWER] [numeric](19, 5) NULL,
	[IRUPPER] [numeric](19, 5) NULL,
	[EIRLOWER] [numeric](19, 5) NULL,
	[EIRUPPER] [numeric](19, 5) NULL,
	[WAIR] [numeric](19, 5) NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_BSP_RATES_LENDING]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[vw_BSP_RATES_LENDING]
AS
	
	SELECT distinct A.Time_Idx,A.TENOR,[Overall Amount],[Overall IRUPPER],[Overall IRLOWER],[Overall WAIR] 
	
	FROM 
	(
		--WAIR
		SELECT distinct Time_Idx,TENOR,
		SUM([Total Value]) over (Partition by Time_Idx,TENOR) [Overall Amount] ,
		SUM(Overall)over (Partition by Time_Idx,TENOR) / SUM([Total Value]) over (Partition by Time_Idx,TENOR) [Overall WAIR] 
	
		FROM 
		(
			SELECT distinct
				[Time_Idx],
				[Total_Amount],
				[Total Value],
				[Total Value] * (SUM(PRODUCT) over (partition by Time_Idx,BKCode,TENOR) / NULLIF(A.[Total Value],0)) as Overall,
				[BKCODE],
				[TENOR]
	
			FROM 
			(
				SELECT distinct Time_Idx,TENOR,BKCODE,ISNULL(A.TOTAL_AMOUNT * NULLIF(A.WAIR,0),0) [PRODUCT],
				SUM(A.TOTAL_AMOUNT) over (partition by Time_Idx,BKCODE,TENOR) [Total Value] ,
				SUM(A.TOTAL_AMOUNT) over (partition by Time_Idx,BKCODE) Total_Amount
				FROM 
				(

					SELECT Time_Idx,TENOR,BKCODE,TVAMOUNT as TOTAL_AMOUNT,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
					FROM BSP_RATES where Part = 'Form 1 Loans' 

				) A 
			) A 

		) A
	
	) A INNER JOIN 


	--- IR LOWER AND UPPER

	(		
		
		SELECT distinct Time_Idx,TENOR,AVG(A.[Overall IRLOWER]) over (partition by Time_Idx) as   [Overall IRLOWER] ,AVG(A.[Overall IRUPPER]) over (partition by Time_Idx) as [Overall IRUPPER] 
		FROM (
		SELECT distinct   Time_Idx,TENOR,B.INST,A.BKCODE,
		--CASE 
		--WHEN A.BKCODE = '445' THEN AVG(A.[Ave IRLOWER]) over (partition by A.BKCODE)  / 4
	 --   WHEN A.BKCODE = '65' THEN '1.14'
		--ELSE AVG(A.[AVE IRLOWER]) over (partition by A.BKCODE) END AS [Overall IRLOWER] ,
	    AVG(A.[Ave IRLOWER]) over (partition by Time_Idx,A.BKCODE) [Overall IRLOWER],
		AVG(A.[Ave IRUPPER]) over (partition by Time_Idx,A.BKCODE) [Overall IRUPPER] 
		FROM 
				(
					SELECT distinct Time_Idx,TENOR,Particulars,
					BKCODE,
					AVG(A.IRLOWER) over (partition by Time_Idx,BKCODE,[Particulars]) [Ave IRLOWER] ,
					AVG(A.IRUPPER) over (partition by Time_Idx,BKCODE,[Particulars]) [Ave IRUPPER] 
					FROM (

						select Time_Idx,TENOR,BKCODE,Particulars,TVAMOUNT as TOTAL_AMOUNT,IRLOWER * 100 as IRLOWER,IRUPPER * 100 as IRUPPER,EIRLOWER,EIRUPPER,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
						FROM BSP_Rates where  Part = 'Form 1 Loans' --and BKCODE = '50'
						and Particulars = 'AGRARIAN REFORM AND OTHER AGRICULTURAL LOANS'  and TENOR = 'Short-term (1 year and below)'
					

					) A

					UNION ALL

					SELECT distinct  Time_Idx,TENOR,Particulars,
					BKCODE,
					AVG(A.IRLOWER) over (partition by Time_Idx,BKCODE,[Particulars]) [Ave IRLOWER] ,
					AVG(A.IRUPPER) over (partition by Time_Idx,BKCODE,[Particulars]) [Ave IRUPPER] 
					FROM (

						select distinct Time_Idx,TENOR,BKCODE,Particulars,TVAMOUNT as TOTAL_AMOUNT,IRLOWER * 100 as IRLOWER,IRUPPER * 100 as IRUPPER ,EIRLOWER,EIRUPPER,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
						FROM BSP_Rates where  Part = 'Form 1 Loans' --and BKCODE = '50'
						and Particulars = 'LOANS TO INDIVIDUALS' and TENOR = 'Short-term (1 year and below)'
					

					) A

					UNION ALL

					SELECT distinct  Time_Idx,'Short-term (1 year and below)','LOANS TO PRIVATE CORPORATION TOTAL',
					BKCODE,
					AVG(A.IRLOWER) over (partition by Time_Idx,BKCODE,[Particulars]) [Ave IRLOWER],
					AVG(A.IRUPPER) over (partition by Time_Idx,BKCODE,[Particulars]) [Ave IRUPPER]  
					FROM (

						select Time_Idx,TENOR,BKCODE,Particulars,TVAMOUNT as TOTAL_AMOUNT,IRLOWER * 100 as IRLOWER,IRUPPER * 100 as IRUPPER,EIRLOWER,EIRUPPER,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
						FROM BSP_Rates where Part = 'Form 1 Loans'  --and BKCODE = '50'
						and Particulars = 'LOANS TO PRIVATE CORPORATION'
					

					) A

					UNION ALL

					SELECT distinct Time_Idx,TENOR,Particulars,
					BKCODE,
					AVG(A.IRLOWER) over (partition by Time_Idx,BKCODE,[Particulars]) [Ave IRLOWER] ,
					AVG(A.IRUPPER) over (partition by Time_Idx,BKCODE,[Particulars]) [Ave IRUPPER] 
					FROM (

						select Time_Idx,TENOR,BKCODE,Particulars,TVAMOUNT as TOTAL_AMOUNT,IRLOWER * 100 as IRLOWER,IRUPPER * 100 as IRUPPER,EIRLOWER,EIRUPPER,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
						FROM BSP_Rates where  Part = 'Form 1 Loans' --and BKCODE = '50'
						and Particulars = 'LOANS TO PRIVATE CORPORATION' and TENOR = 'Short-term (1 year and below)'
					

					) A

					UNION ALL

					SELECT distinct  Time_Idx,TENOR,Particulars,
					BKCODE,
					AVG(A.IRLOWER) over (partition by Time_Idx,BKCODE,[Particulars]) [Ave IRLOWER] ,
					AVG(A.IRUPPER) over (partition by Time_Idx,BKCODE,[Particulars]) [Ave IRUPPER] 
					FROM (

						select Time_Idx,TENOR,BKCODE,Particulars,TVAMOUNT as TOTAL_AMOUNT,IRLOWER * 100 as IRLOWER,IRUPPER * 100 as IRUPPER,EIRLOWER,EIRUPPER,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
						FROM BSP_Rates where  Part = 'Form 1 Loans' --and BKCODE = '50'
						and Particulars = 'SMALL AND MEDIUM ENTERPRISE LOANS' and TENOR = 'Short-term (1 year and below)'
					

					) A

		) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
		where A.BKCODE is not null
		and B.BNKTYP = 0 --and TENOR = 'Short-term (1 year and below)'
		) A --where BKCODE = '445'
				

		--order by 1 asc

		UNION ALL
		-- OVER ALL IRLOWER AND IRUPPER
		SELECT distinct Time_Idx,A.TENOR,
		AVG(A.[Overall IRLOWER]) over (partition by Time_Idx) [Overall IRLOWER], 
		AVG(A.[Overall IRUPPER]) over (partition by Time_Idx) [Overall IRUPPER] 
		FROM (
		SELECT distinct   Time_Idx,TENOR,B.INST,A.BKCODE,
		
		--AVG(A.[Ave IRLOWER]) over (partition by A.BKCODE,TENOR) [Overall IRLOWER] ,
		--AVG(A.[Ave IRUPPER]) over (partition by A.BKCODE,TENOR) [Overall IRUPPER] ,
		AVG(A.[Ave IRLOWER]) over (partition by Time_Idx,A.BKCODE) [Overall IRLOWER],
		AVG(A.[Ave IRUPPER]) over (partition by Time_Idx,A.BKCODE) [Overall IRUPPER] 
		FROM 
				(
					SELECT distinct  Time_Idx,TENOR,Particulars,BKCODE,
					AVG(A.IRLOWER) over (partition by Time_Idx,BKCODE,Particulars) [Ave IRLOWER] ,
					AVG(A.IRUPPER) over (partition by Time_Idx,BKCODE,Particulars) [Ave IRUPPER] 
					FROM (

						select Time_Idx,TENOR,BKCODE,Particulars,TVAMOUNT as TOTAL_AMOUNT,IRLOWER * 100 as IRLOWER,IRUPPER * 100 as IRUPPER,EIRLOWER,EIRUPPER,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
						FROM BSP_Rates where Part = 'Form 1 Loans' --and BKCODE = '80'
						AND  TENOR  IN ('Medium-term (over 1 year to 5 years)')
					

					) A

		) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0  
		--and B.BKCODE = '35'
		) A

		UNION ALL

		SELECT distinct Time_Idx,A.TENOR,
		AVG(A.[Overall IRLOWER]) over (partition by Time_Idx) [Overall IRLOWER], 
		AVG(A.[Overall IRUPPER]) over (partition by Time_Idx) [Overall IRUPPER] 
		FROM (
		SELECT distinct   Time_Idx,TENOR,B.INST,A.BKCODE,
		
		--AVG(A.[Ave IRLOWER]) over (partition by A.BKCODE,TENOR) [Overall IRLOWER] ,
		--AVG(A.[Ave IRUPPER]) over (partition by A.BKCODE,TENOR) [Overall IRUPPER] ,
		AVG(A.[Ave IRLOWER]) over (partition by Time_Idx,A.BKCODE) [Overall IRLOWER],
		AVG(A.[Ave IRUPPER]) over (partition by Time_Idx,A.BKCODE) [Overall IRUPPER] 
		FROM 
				(
					SELECT distinct  Time_Idx,TENOR,Particulars,BKCODE,
					AVG(A.IRLOWER) over (partition by Time_Idx,BKCODE,Particulars) [Ave IRLOWER] ,
					AVG(A.IRUPPER) over (partition by Time_Idx,BKCODE,Particulars) [Ave IRUPPER] 
					FROM (

						select Time_Idx,TENOR,BKCODE,Particulars,TVAMOUNT as TOTAL_AMOUNT,IRLOWER * 100 as IRLOWER,IRUPPER * 100 as IRUPPER,EIRLOWER,EIRUPPER,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
						FROM BSP_Rates where Part = 'Form 1 Loans' --and BKCODE = '80'
						AND  TENOR  IN ('Long-term (over 5 years)')
					

					) A

		) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0  
		--and B.BKCODE = '35'
		) A--and TENOR = 'Medium-term (over 1 year to 5 years)'
		
		) B 
		
		
		on A.TENOR = B.TENOR
		and A.Time_Idx=B.Time_Idx
		where A.TENOR <> 'CREDIT CARD' and A.TENOR not in ('over 6 months to 1 year','over 1 year','3 months and below','over 3 months to 6 months')


GO
/****** Object:  View [dbo].[vw_BSP_RATES_TOTAL_LENDING]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [dbo].[vw_BSP_RATES_TOTAL_LENDING]
AS
	SELECT distinct Time_Idx,Particulars,B.INST,A.BKCODE,
			SUM(AMOUNT) over (Partition by Time_Idx,A.BKCODE) Total_Amount,
			SUM([Total Value]) over (Partition by Time_Idx,A.BKCODE) / NULLIF([Total Amount],0) as [Overall_Loans]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,[LOANS TO INDIVIDUALS],TENOR,BKCODE,
				ISNULL(AMOUNT,0) AMOUNT,ISNULL(WAIR,0) WAIR,

				SUM(AMOUNT) over (Partition by Time_Idx,BKCODE) as [Total Amount],
				ISNULL(A.AMOUNT * NULLIF(A.WAIR,0),0) [Total Value] 
				FROM 
				(

					select Time_Idx,'LOANS TO INDIVIDUALS' as Particulars,
					CASE 
					WHEN ACCTCODE IN 
					('140150504510100002',
					'140150504510100004',
					'140150504510100006') THEN 'MOTOR VEHICLE LOANS'
					WHEN ACCTCODE IN 
					('140150504512100002',
					'140150504512100004',
					'140150504512100006') THEN 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
					WHEN ACCTCODE IN 
					('140150504000100002',
					'140150504000100004',
					'140150504000100006') THEN 'HOUSING LOANS'
					WHEN ACCTCODE IN 
					('140150504505100000') THEN 'CREDIT CARD'
					WHEN ACCTCODE IN 
					('140150504515100002',
					'140150504515100004',
					'140150504515100006') THEN 'OTHERS'
		
					ELSE 'CREDIT CARD'
					END AS 'LOANS TO INDIVIDUALS',
					TENOR,BKCODE,TVAMOUNT as AMOUNT,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars = 'LOANS TO INDIVIDUALS' --and BKCODE = '45'

					



					--and BKCODE = '210'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 
			
			
		UNION ALL
		--LOANS TO GOVERNMENT
		SELECT distinct Time_Idx,Particulars,INST,A.BKCODE,
			SUM(AMOUNT) over (Partition by Time_Idx,A.BKCODE,Particulars) Total_Amount,
			SUM([Total Value]) over (Partition by Time_Idx,A.BKCODE,Particulars) / NULLIF([Total Amount],0) as [Overall Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,TENOR,BKCODE,
				ISNULL(AMOUNT,0) AMOUNT,ISNULL(WAIR,0) WAIR,

				SUM(AMOUNT) over (Partition by BKCODE,Particulars) as [Total Amount],
				ISNULL(A.AMOUNT * NULLIF(A.WAIR,0),0) [Total Value] 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,TVAMOUNT as AMOUNT,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
					FROM BSP_RATES where  Part = 'Form 1 Loans' 
					and Particulars =  'LOANS TO GOVERNMENT' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 
		--
		UNION ALL
		--LOANS TO PRIVATE CORPORATION
		SELECT distinct Time_Idx,Particulars,INST,A.BKCODE,
			SUM(AMOUNT) over (Partition by Time_Idx,A.BKCODE,Particulars) Total_Amount,
			SUM([Total Value]) over (Partition by Time_Idx,A.BKCODE,Particulars) / NULLIF([Total Amount],0) as [Overall Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,TENOR,BKCODE,
				ISNULL(AMOUNT,0) AMOUNT,ISNULL(WAIR,0) WAIR,

				SUM(AMOUNT) over (Partition by Time_Idx,BKCODE,Particulars) as [Total Amount],
				ISNULL(A.AMOUNT * NULLIF(A.WAIR,0),0) [Total Value] 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,TVAMOUNT as AMOUNT,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
					FROM BSP_RATES where  Part = 'Form 1 Loans' 
					and Particulars =  'LOANS TO PRIVATE CORPORATION' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 
		UNION ALL
		-- CONTRACTS TO SELL
	

		SELECT distinct Time_Idx,Particulars,INST,A.BKCODE,
			SUM(AMOUNT) over (Partition by Time_Idx,A.BKCODE,Particulars) Total_Amount,
			SUM([Total Value]) over (Partition by Time_Idx,A.BKCODE,Particulars) / NULLIF([Total Amount],0) as [Overall Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,TENOR,BKCODE,
				ISNULL(AMOUNT,0) AMOUNT,ISNULL(WAIR,0) WAIR,

				SUM(AMOUNT) over (Partition by Time_Idx,BKCODE,Particulars) as [Total Amount],
				ISNULL(A.AMOUNT * NULLIF(A.WAIR,0),0) [Total Value] 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,TVAMOUNT as AMOUNT,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
					FROM BSP_RATES where  Part = 'Form 1 Loans' 
					and Particulars =  'CONTRACTS TO SELL' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 

		--MICROENTERPRISE LOANS
		UNION ALL

		SELECT distinct Time_Idx,Particulars,INST,A.BKCODE,
			SUM(AMOUNT) over (Partition by Time_Idx,A.BKCODE,Particulars) Total_Amount,
			SUM([Total Value]) over (Partition by Time_Idx,A.BKCODE,Particulars) / NULLIF([Total Amount],0) as [Overall Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,TENOR,BKCODE,
				ISNULL(AMOUNT,0) AMOUNT,ISNULL(WAIR,0) WAIR,

				SUM(AMOUNT) over (Partition by Time_Idx,BKCODE,Particulars) as [Total Amount],
				ISNULL(A.AMOUNT * NULLIF(A.WAIR,0),0) [Total Value] 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,TVAMOUNT as AMOUNT,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars =  'MICROENTERPRISE LOANS' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 

		UNION ALL
		
		SELECT distinct Time_Idx,Particulars,INST,A.BKCODE,
			SUM(AMOUNT) over (Partition by Time_Idx,A.BKCODE,Particulars) Total_Amount,
			SUM([Total Value]) over (Partition by Time_Idx,A.BKCODE,Particulars) / NULLIF([Total Amount],0) as [Overall Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,TENOR,BKCODE,
				ISNULL(AMOUNT,0) AMOUNT,ISNULL(WAIR,0) WAIR,

				SUM(AMOUNT) over (Partition by Time_Idx,BKCODE,Particulars) as [Total Amount],
				ISNULL(A.AMOUNT * NULLIF(A.WAIR,0),0) [Total Value] 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,TVAMOUNT as AMOUNT,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars =  'SMALL AND MEDIUM ENTERPRISE LOANS' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 

		UNION ALL
		--AGRARIAN REFORM AND OTHER AGRICULTURAL LOANS
		SELECT distinct Time_Idx,Particulars,INST,A.BKCODE,
			SUM(AMOUNT) over (Partition by Time_Idx,A.BKCODE,Particulars) Total_Amount,
			SUM([Total Value]) over (Partition by Time_Idx,A.BKCODE,Particulars) / NULLIF([Total Amount],0) as [Overall Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,TENOR,BKCODE,
				ISNULL(AMOUNT,0) AMOUNT,ISNULL(WAIR,0) WAIR,

				SUM(AMOUNT) over (Partition by Time_Idx,BKCODE,Particulars) as [Total Amount],
				ISNULL(A.AMOUNT * NULLIF(A.WAIR,0),0) [Total Value] 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,TVAMOUNT as AMOUNT,WAIR * 100 as WAIR, TVAMOUNT / NULLIF(WAIR,0) as PRODUCT 
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars =  'AGRARIAN REFORM AND OTHER AGRICULTURAL LOANS' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 

GO
/****** Object:  Table [dbo].[Dim_YieldCurve_Tenor]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_YieldCurve_Tenor](
	[Tenor_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Tenor_Code] [nvarchar](50) NOT NULL,
	[Tenor_Name] [nvarchar](150) NOT NULL,
	[Tenor_Label] [nvarchar](150) NOT NULL,
	[Tenor_Sort] [int] NOT NULL,
 CONSTRAINT [PK_Dim_YieldCurve_Tenor] PRIMARY KEY CLUSTERED 
(
	[Tenor_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_ITR_BSPRateType]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_ITR_BSPRateType](
	[BSPRateType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[BSPRateType_Code] [nvarchar](150) NOT NULL,
	[BSPRateType_Name] [nvarchar](150) NOT NULL,
	[BSPRateType_Label] [nvarchar](150) NULL,
	[BSPRateType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_ITR_BSPRateType] PRIMARY KEY CLUSTERED 
(
	[BSPRateType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_ITR_BSPRateSubType]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_ITR_BSPRateSubType](
	[BSPRateSubType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[BSPRateSubType_Code] [nvarchar](150) NOT NULL,
	[BSPRateSubType_Name] [nvarchar](150) NOT NULL,
	[BSPRateSubType_Label] [nvarchar](150) NULL,
	[BSPRateSubType_Sort] [int] NULL,
	[BSPRateType_Code] [int] NULL,
 CONSTRAINT [PK_Dim_ITR_BSPRateSubType] PRIMARY KEY CLUSTERED 
(
	[BSPRateSubType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_ITR_Tenors]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_ITR_Tenors](
	[Tenors_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Tenors_Code] [nvarchar](150) NOT NULL,
	[Tenors_Name] [nvarchar](150) NOT NULL,
	[Tenors_Label] [nvarchar](150) NULL,
	[Tenors_Sort] [int] NULL,
	[BSPRateSubType_Code] [nvarchar](150) NULL,
 CONSTRAINT [PK_Dim_ITR_Tenors] PRIMARY KEY CLUSTERED 
(
	[Tenors_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FACT_ESLIG_DimTable6]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO










CREATE VIEW [dbo].[vw_FACT_ESLIG_DimTable6]
AS
		
		select 

		Level1 = A.BSPRateType_Name,
		Level2 = B.BSPRateSubType_Name,
		Level3 =  CASE 
		WHEN C.Tenors_Name is null 	THEN BSPRateSubType_Name 
		 WHEN C.Tenors_Name = '7 Days' THEN '7-Day'
		 WHEN C.Tenors_Name = '2 Weeks' THEN '14-Day'
		 WHEN C.Tenors_Name = '28 Days' THEN '28-Day'
		 WHEN C.Tenors_Name = '28 Day' THEN '28-Day'
		ELSE C.Tenors_Name END ,
		
		SORT = CASE WHEN C.Tenors_Sort is null THEN  B.BSPRateSubType_Sort ELSE Tenors_Sort + 10 END,
		B.BSPRateSubType_Sort,
		Level1_Sort = a.BSPRateType_Sort

		from [dbo].[Dim_ITR_BSPRateType] A LEFT JOIN [dbo].[Dim_ITR_BSPRateSubType] B
		ON A.BSPRateType_Idx = B.BSPRateType_Code 
		LEFT JOIN [dbo].[Dim_ITR_Tenors] C
		on B.BSPRateSubType_Idx = c.BSPRateSubType_Code

		UNION ALL

		select 

		Level1 = 'Rate on Government Securities',
		Level2 = 'Government Securities in the Secondary Market',
		Level3 = Tenor_Label ,
		
		SORT =Tenor_Sort,
		SUB_SORT = 12,
		Level1_Sort =3
		from [dbo].[Dim_YieldCurve_Tenor]
		

GO
/****** Object:  View [dbo].[vw_BSP_RATES_OVERALL_LENDING]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [dbo].[vw_BSP_RATES_OVERALL_LENDING]
AS
	

	
	SELECT distinct A.Time_Idx,A.Overall_Amount,B.Overall_IRUPPER_Total,B.Overall_IRLOWER_Total,A.OVERALL_WAIR FROM (
	SELECT distinct Time_Idx,Overall_Amount,
	SUM(A.OVERALL_TOTAL) over (partition by Time_Idx) / NULLIF(Overall_Amount,0) as OVERALL_WAIR  
	FROM (
	SELECT Time_Idx,A.BKCODE,B.INST,Overall_Amount,Total_Amount,Overall_WAIR,Total_Amount * Overall_WAIR as OVERALL_TOTAL FROM (
	select distinct Time_Idx,BKCODE, 
	SUM(Total_Amount) over (Partition by Time_Idx,BKCODE) Total_Amount,
	SUM(Total_Amount ) over (partition by Time_Idx) Overall_Amount ,
	SUM(Total_Amount * [Overall_Loans]) over (partition by Time_Idx,BKCODE)  / SUM(NULLIF(Total_Amount,0)) over (partition by Time_Idx,BKCODE) as Overall_WAIR


	from [dbo].[vw_BSP_RATES_TOTAL_LENDING] 
	) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
			ON A.BKCODE = B.BKCODE
  
			where A.BKCODE is not null
			and B.BNKTYP = 0 
	) A 
	) A INNER JOIN 

	(
	
	SELECT distinct Time_Idx,
	 --BKCODE,INST,
		   AVG([Overall_IRLOWER_Total]) over (partition by Time_Idx) [Overall_IRLOWER_Total],
		   AVG([Overall_IRUPPER_Total]) over (partition by Time_Idx) [Overall_IRUPPER_Total] FROM (

	SELECT distinct Time_Idx,BKCODE,INST,AVG([Overall_IRLOWER_Total]) over (Partition by Time_Idx,A.BKCODE) [Overall_IRLOWER_Total],
		   AVG([Overall_IRUPPER_Total]) over (Partition by Time_Idx,A.BKCODE) [Overall_IRUPPER_Total] 
	FROM (
	        SELECT distinct Time_Idx,Particulars,B.INST,A.BKCODE,
			AVG(IRLOWER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRLOWER_Total],
			AVG(IRUPPER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRUPPER_Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,[LOANS TO INDIVIDUALS],BKCODE,
				IRLOWER_TOTAL = AVG(IRLOWER) over (Partition by Time_Idx,[LOANS TO INDIVIDUALS],BKCODE),
				IRUPPER_TOTAL = AVG(IRUPPER) over (Partition by Time_Idx,[LOANS TO INDIVIDUALS],BKCODE)
				FROM 
				(

					select Time_Idx,'LOANS TO INDIVIDUALS' as Particulars,
					CASE 
					WHEN ACCTCODE IN 
					('140150504510100002',
					'140150504510100004',
					'140150504510100006') THEN 'MOTOR VEHICLE LOANS'
					WHEN ACCTCODE IN 
					('140150504512100002',
					'140150504512100004',
					'140150504512100006') THEN 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
					WHEN ACCTCODE IN 
					('140150504000100002',
					'140150504000100004',
					'140150504000100006') THEN 'HOUSING LOANS'
					WHEN ACCTCODE IN 
					('140150504505100000') THEN 'CREDIT CARD'
					WHEN ACCTCODE IN 
					('140150504515100002',
					'140150504515100004',
					'140150504515100006') THEN 'OTHERS'
		
					ELSE 'CREDIT CARD'
					END AS 'LOANS TO INDIVIDUALS',
					TENOR,BKCODE,
					IRLOWER = IRLOWER * 100,
					IRUPPER = IRUPPER * 100 
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars = 'LOANS TO INDIVIDUALS'-- and BKCODE = '50'

				) A
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
		where A.BKCODE is not null
		and B.BNKTYP = 0 


			
		UNION ALL
		--MICROENTERPRISE LOANS
			SELECT distinct Time_Idx,Particulars,B.INST,A.BKCODE,
			AVG(IRLOWER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRLOWER_Total],
			AVG(IRUPPER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRUPPER_Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,BKCODE,
				IRLOWER_TOTAL = AVG(IRLOWER) over (Partition by Time_Idx,Particulars,BKCODE),
				IRUPPER_TOTAL = AVG(IRUPPER) over (Partition by Time_Idx,Particulars,BKCODE) 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,
					IRLOWER = IRLOWER * 100,
					IRUPPER = IRUPPER * 100  
					FROM BSP_RATES where  Part = 'Form 1 Loans' 
					and Particulars =  'MICROENTERPRISE LOANS' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 
			
		UNION ALL
		--LOANS TO GOVERNMENT

		SELECT distinct Time_Idx,Particulars,B.INST,A.BKCODE,
			AVG(IRLOWER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRLOWER_Total],
			AVG(IRUPPER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRUPPER_Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,BKCODE,
				IRLOWER_TOTAL = AVG(IRLOWER) over (Partition by Time_Idx,Particulars,BKCODE),
				IRUPPER_TOTAL = AVG(IRUPPER) over (Partition by Time_Idx,Particulars,BKCODE) 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,
					IRLOWER = IRLOWER * 100,
					IRUPPER = IRUPPER * 100  
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars =  'LOANS TO GOVERNMENT' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 
		
		--
		UNION ALL
		--LOANS TO PRIVATE CORPORATION
		SELECT distinct Time_Idx,Particulars,B.INST,A.BKCODE,
			AVG(IRLOWER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRLOWER_Total],
			AVG(IRUPPER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRUPPER_Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,BKCODE,
				IRLOWER_TOTAL = AVG(IRLOWER) over (Partition by Time_Idx,Particulars,BKCODE),
				IRUPPER_TOTAL = AVG(IRUPPER) over (Partition by Time_Idx,Particulars,BKCODE) 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,
					IRLOWER = IRLOWER * 100,
					IRUPPER = IRUPPER * 100  
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars =  'LOANS TO PRIVATE CORPORATION' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 

		
		UNION ALL
		-- CONTRACTS TO SELL
	
	    SELECT distinct Time_Idx,Particulars,B.INST,A.BKCODE,
			AVG(IRLOWER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRLOWER_Total],
			AVG(IRUPPER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRUPPER_Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,BKCODE,
				IRLOWER_TOTAL = AVG(IRLOWER) over (Partition by Time_Idx,Particulars,BKCODE),
				IRUPPER_TOTAL = AVG(IRUPPER) over (Partition by Time_Idx,Particulars,BKCODE) 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,
					IRLOWER = IRLOWER * 100,
					IRUPPER = IRUPPER * 100  
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars =  'CONTRACTS TO SELL' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 
		
		--MICROENTERPRISE LOANS
		UNION ALL
		SELECT distinct Time_Idx,Particulars,B.INST,A.BKCODE,
			AVG(IRLOWER_TOTAL) over (Partition by A.BKCODE) [Overall_IRLOWER_Total],
			AVG(IRUPPER_TOTAL) over (Partition by A.BKCODE) [Overall_IRUPPER_Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,BKCODE,
				IRLOWER_TOTAL = AVG(IRLOWER) over (Partition by Time_Idx,Particulars,BKCODE),
				IRUPPER_TOTAL = AVG(IRUPPER) over (Partition by Time_Idx,Particulars,BKCODE) 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,
					IRLOWER = IRLOWER * 100,
					IRUPPER = IRUPPER * 100  
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars =  'MICROENTERPRISE LOANS' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 

		

		UNION ALL
		--

		SELECT distinct Time_Idx,Particulars,B.INST,A.BKCODE,
			AVG(IRLOWER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRLOWER_Total],
			AVG(IRUPPER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRUPPER_Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,BKCODE,
				IRLOWER_TOTAL = AVG(IRLOWER) over (Partition by Time_Idx,Particulars,BKCODE),
				IRUPPER_TOTAL = AVG(IRUPPER) over (Partition by Time_Idx,Particulars,BKCODE) 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,
					IRLOWER = IRLOWER * 100,
					IRUPPER = IRUPPER * 100  
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars =  'SMALL AND MEDIUM ENTERPRISE LOANS' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 

		

		UNION ALL
		--AGRARIAN REFORM AND OTHER AGRICULTURAL LOANS
		SELECT distinct Time_Idx,Particulars,B.INST,A.BKCODE,
			AVG(IRLOWER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRLOWER_Total],
			AVG(IRUPPER_TOTAL) over (Partition by Time_Idx,A.BKCODE) [Overall_IRUPPER_Total]
			FROM 
			(
				SELECT distinct Time_Idx,Particulars,BKCODE,
				IRLOWER_TOTAL = AVG(IRLOWER) over (Partition by Time_Idx,Particulars,BKCODE),
				IRUPPER_TOTAL = AVG(IRUPPER) over (Partition by Time_Idx,Particulars,BKCODE) 
				FROM 
				(

					select 
					Time_Idx,Particulars,
					TENOR,BKCODE,
					IRLOWER = IRLOWER * 100,
					IRUPPER = IRUPPER * 100  
					FROM BSP_RATES where Part = 'Form 1 Loans' 
					and Particulars =  'AGRARIAN REFORM AND OTHER AGRICULTURAL LOANS' 
					--and BKCODE = '45'
				) A-- where [LOANS TO INDIVIDUALS] = 'SALARY-BASED GENERAL-PURPOSE CONSUMPTION LOANS'
			) A LEFT JOIN [FSS_EFILS].[dbo].[INSTLIB]  B 
		ON A.BKCODE = B.BKCODE
  
		where A.BKCODE is not null
		and B.BNKTYP = 0 

) A 
) A 
) B ON A.Time_Idx = B.Time_idx



GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_AFF]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_AFF](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NOT NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_AFF]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [dbo].[vw_AFF]
AS
	SELECT  [Time_Idx]
      ,[Type_Idx]
      ,[Prices]
      ,[Sector]
      ,[Value]
  FROM [DES].[dbo].[Fact_ESLIG_NAT_AFF]  where Type_Idx <> -1

GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_HFCE]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_HFCE](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_HFCE]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[vw_HFCE]
AS
	SELECT  [Time_Idx]
      ,[Type_Idx]
      ,[Prices]
      ,[Sector]
      ,[Value]
  FROM [DES].[dbo].[Fact_ESLIG_NAT_HFCE] where Type_Idx = 8

GO
/****** Object:  View [dbo].[vw_HFCE_DIM]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [dbo].[vw_HFCE_DIM]
AS

	select distinct [HFCE_Idx] = Time_Idx
      ,[HFCE_Code] = 'Share to GDP (in percent)'
      ,[HFCE_Name] =  'Share to GDP (in percent)'
      ,[HFCE_Label] = 'Share to GDP (in percent)'
      ,[HFCE_Sort] = 1 FROM [dbo].[Fact_ESLIG_NAT_HFCE]
	
		UNION ALL

		select distinct [HFCE_Idx] = Time_Idx
      ,[HFCE_Code] = 'Percentage point contribution to GDP growth'
      ,[HFCE_Name] =  'Percentage point contribution to GDP growth'
      ,[HFCE_Label] = 'Percentage point contribution to GDP growth'
      ,[HFCE_Sort] = 2 FROM [dbo].[Fact_ESLIG_NAT_HFCE]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_Import]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_Import](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_Import_Total]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [dbo].[vw_Import_Total]
AS
	SELECT distinct [Time_Idx]
      ,[Type_Idx]
      ,[Prices]
      ,[Sector]
      ,[Value]
  FROM [DES].[dbo].[Fact_ESLIG_NAT_Import] where Type_Idx <> -1


GO
/****** Object:  Table [dbo].[Dim_Nat_ExportType]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Nat_ExportType](
	[ExportType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[ExportType_Code] [nvarchar](150) NOT NULL,
	[ExportType_Name] [nvarchar](150) NOT NULL,
	[ExportType_Label] [nvarchar](150) NULL,
	[SubSectorType_Idx] [int] NULL,
	[ExportType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_ExportType] PRIMARY KEY CLUSTERED 
(
	[ExportType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_Export]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_Export](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Nat_ImportType]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Nat_ImportType](
	[ImportType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[ImportType_Code] [nvarchar](150) NOT NULL,
	[ImportType_Name] [nvarchar](150) NOT NULL,
	[ImportType_Label] [nvarchar](150) NULL,
	[SubSectorType_Idx] [int] NULL,
	[ImportType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_ImportType] PRIMARY KEY CLUSTERED 
(
	[ImportType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_ImportExport]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO








CREATE VIEW [dbo].[vw_ImportExport]
AS
	SELECT distinct [Time_Idx]
      ,B.ImportType_Name
      ,[Sector_Type] = 'Import'
	  ,[Prices]
      ,[Sector]
      ,[Value]
	FROM [DES].[dbo].[Fact_ESLIG_NAT_Import] A
	JOIN [DES].[dbo].[Dim_Nat_ImportType] B
	ON A.Type_Idx = B.ImportType_Idx
	where Type_Idx <> -1

	UNION ALL

	SELECT distinct [Time_Idx]
      ,B.ExportType_Name
	  ,[Sector_Type] = 'Export'
      ,[Prices]
      ,[Sector]
      ,[Value]
	FROM [DES].[dbo].[Fact_ESLIG_NAT_Export] A
	JOIN [DES].[dbo].[Dim_Nat_ExportType] B
	ON A.Type_Idx = B.ExportType_Idx
	where Type_Idx <> -1


GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_PoultryEggsVolume]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_PoultryEggsVolume](
	[Time_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[Animal_Idx] [int] NOT NULL,
	[Date] [date] NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_PalayCornVolume]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_PalayCornVolume](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Crop_Idx] [int] NOT NULL,
	[Date] [date] NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_OtherCropsVolume]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_OtherCropsVolume](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Crop_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_AnimalType]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_AnimalType](
	[AnimalType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[AnimalType_Code] [nvarchar](50) NOT NULL,
	[AnimalType_Name] [nvarchar](150) NOT NULL,
	[AnimalType_Label] [nvarchar](150) NULL,
	[AnimalType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_AnimalType] PRIMARY KEY CLUSTERED 
(
	[AnimalType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CropType]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CropType](
	[CropType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[CropType_Code] [nvarchar](150) NOT NULL,
	[CropType_Name] [nvarchar](150) NOT NULL,
	[CropType_Label] [nvarchar](150) NULL,
	[CropType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_CropType] PRIMARY KEY CLUSTERED 
(
	[CropType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_AquaCulture]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_AquaCulture](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Fish_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_CommercialFisheries]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_CommercialFisheries](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Fish_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_MajorForestProducts]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_MajorForestProducts](
	[Time_Idx] [int] NOT NULL,
	[Logs] [numeric](18, 2) NULL,
	[Lumber] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_Livestock]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_Livestock](
	[Time_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[Animal_Idx] [int] NOT NULL,
	[Date] [date] NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_MarineMunicipallFisheries]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_MarineMunicipallFisheries](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Fish_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FACT_Production]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [dbo].[vw_FACT_Production]
AS
		
		
		--CROPS
		SELECT  
		[Time_Idx],
		[Category] = 'Crops',
		[Sub_Category] = 
		
		CASE 
			WHEN [Crop_Idx] in (83,195) THEN 'Cereals'
			WHEN [Crop_Idx] in (1,25,46,47,50,60,74,75,101,169,211,222,238,265,283,287) THEN 'Major Crops'
			ELSE 'Other Crops'
		END ,
		[Type] = B.CropType_Name,
		[Value] 

		FROM [dbo].[Fact_ESLIG_ProInd_OtherCropsVolume] A LEFT JOIN Dim_CropType B on A.Crop_Idx = B.CropType_Idx
		where A.Crop_Idx is not null

		UNION

		SELECT  
		[Time_Idx],
		[Category] = 'Crops',
		[Sub_Category] = 'Cereals',
		[Type] = B.CropType_Name,
		[Value] FROM [dbo].[Fact_ESLIG_ProInd_PalayCornVolume] A LEFT JOIN Dim_CropType B on A.Crop_Idx = B.CropType_Idx
		where A.Crop_Idx is not null

		UNION
		-- LIVESTOCKS

		SELECT  DISTINCT
		[Time_Idx],
		[Category] = 'Livestocks' ,
		[Sub_Category] = 'Livestocks',
		[Type] = '',
		[Value] FROM [dbo].[Fact_ESLIG_ProInd_Livestock] A LEFT JOIN Dim_AnimalType B on A.Animal_Idx = B.AnimalType_Idx
		where A.Animal_Idx is not null
		
		UNION

		SELECT  DISTINCT
		[Time_Idx],
		[Category] = 'Livestocks' ,
		[Sub_Category] = 'Poultry',
		[Type] = '',
		[Value] FROM [dbo].[Fact_ESLIG_ProInd_PoultryEggsVolume] 
		
		UNION
		-- FISHERIES

		SELECT  DISTINCT
		[Time_Idx],
		[Category] = 'Fishery' ,
		[Sub_Category] = 'Commercial',
		[Type] = '',
		[Value] FROM [dbo].[Fact_ESLIG_ProInd_CommercialFisheries] 

		UNION

		SELECT  DISTINCT
		[Time_Idx],
		[Category] = 'Fishery' ,
		[Sub_Category] = 'Commercial',
		[Type] = '',
		[Value] FROM [dbo].[Fact_ESLIG_ProInd_CommercialFisheries] 		

		UNION

		SELECT  DISTINCT
		[Time_Idx],
		[Category] = 'Fishery' ,
		[Sub_Category] = 'Municipal',
		[Type] = '',
		[Value] FROM [dbo].[Fact_ESLIG_ProInd_MarineMunicipallFisheries] 	

		UNION

		SELECT  DISTINCT
		[Time_Idx],
		[Category] = 'Fishery' ,
		[Sub_Category] = 'Aqua Culture',
		[Type] = '',
		[Value] FROM [dbo].[Fact_ESLIG_ProInd_AquaCulture] 
		
			

		UNION

		SELECT  DISTINCT
		[Time_Idx],
		[Category] = 'Forestry' ,
		[Sub_Category] = 'Logging Operations',
		[Type] = 'Logs',
		[Logs] FROM [dbo].[Fact_ESLIG_ProInd_MajorForestProducts] 


GO
/****** Object:  View [dbo].[vw_ImportExport_Total]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[vw_ImportExport_Total]
AS
	

	SELECT distinct [Time_Idx]
      ,[Sector_Type] = 'Import'
	  ,[Prices]
      ,[Sector]
      ,[Value] = SUM([Value]) over (Partition by Time_Idx,Sector,Prices)
	FROM [DES].[dbo].[Fact_ESLIG_NAT_Import] A
	JOIN [DES].[dbo].[Dim_Nat_ImportType] B
	ON A.Type_Idx = B.ImportType_Idx
	where Type_Idx <> -1 
	and Type_Idx IN (34,42)
	  -- and Type_Idx not in (2,6,7,8,9,12,17,22,28) 

	UNION ALL
	SELECT distinct [Time_Idx]
      ,[Sector_Type] = 'Export'
	  ,[Prices]
      ,[Sector]
      ,[Value] = SUM([Value]) over (Partition by Time_Idx,Sector,Prices)
	FROM [DES].[dbo].[Fact_ESLIG_NAT_Export] A
	JOIN [DES].[dbo].[Dim_Nat_ExportType] B
	ON A.Type_Idx = B.ExportType_Idx
	where Type_Idx IN(17,18)
	

	/*SELECT distinct [Time_Idx]
      ,[Sector_Type] = 'Export'
	  ,[Prices]
      ,[Sector]
      ,[Value] = SUM([Value]) over (Partition by Time_Idx,Sector,Prices)
	FROM [DES].[dbo].[Fact_ESLIG_NAT_Export] A
	JOIN [DES].[dbo].[Dim_Nat_ExportType] B
	ON A.Type_Idx = B.ExportType_Idx
	where Type_Idx <> -1 
	and Type_Idx  in (1,2,6,7,16,19,21,23,27,31,32,34,42) 
    and Sector = 'Export of Goods'

	UNION ALL

	SELECT distinct [Time_Idx]
      ,[Sector_Type] = 'Export'
	  ,[Prices]
      ,[Sector]
      ,[Value] = SUM([Value]) over (Partition by Time_Idx,Sector,Prices)
	FROM [DES].[dbo].[Fact_ESLIG_NAT_Export] A
	JOIN [DES].[dbo].[Dim_Nat_ExportType] B
	ON A.Type_Idx = B.ExportType_Idx
	where Type_Idx <> -1 
	and Type_Idx  in (5,20,22,25,28,38,39,40) 
    and Sector = 'Export of Services'
	
	*/



	
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_PalayCornAreaHarvested]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_PalayCornAreaHarvested](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Crop_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_OtherCropsAreaHarvested]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_OtherCropsAreaHarvested](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Crop_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FACT_Production_LandUtilization]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[vw_FACT_Production_LandUtilization]
AS
		
		
		--CROPS
		SELECT  
		[Time_Idx],
		[Category] = 'Crops',
		[Sub_Category] = 
		
		CASE 
			WHEN [Crop_Idx] in (83,195) THEN 'Cereals'
			WHEN [Crop_Idx] in (1,25,46,47,50,60,74,75,101,169,211,222,238,265,283,287) THEN 'Major Crops'
			ELSE 'Other Crops'
		END ,
		[Type] = B.CropType_Name,
		[Value] 

		FROM [dbo].[Fact_ESLIG_ProInd_OtherCropsAreaHarvested] A LEFT JOIN Dim_CropType B on A.Crop_Idx = B.CropType_Idx
		where A.Crop_Idx is not null

		UNION

		SELECT  
		[Time_Idx],
		[Category] = 'Crops',
		[Sub_Category] = 'Cereals',
		[Type] = B.CropType_Name,
		[Value] FROM [dbo].[Fact_ESLIG_ProInd_PalayCornAreaHarvested] A LEFT JOIN Dim_CropType B on A.Crop_Idx = B.CropType_Idx
		where A.Crop_Idx is not null


GO
/****** Object:  Table [dbo].[Dim_STATBUL_PFSParticular]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_STATBUL_PFSParticular](
	[PFSParticular_Idx] [int] NOT NULL,
	[PFSParticularCode] [nvarchar](255) NULL,
	[PFSParticularName] [nvarchar](255) NULL,
	[PFSParticularDesc] [nvarchar](255) NULL,
	[PFSParticularLevel] [float] NULL,
	[PFSParticularGroup] [nvarchar](255) NULL,
	[PFSParticularSubGroup1] [nvarchar](255) NULL,
	[PFSParticularSubGroup2] [nvarchar](255) NULL,
	[PFSCode] [nvarchar](255) NULL,
	[PFSParticularSort] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_Dim_PFSParticular]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[vw_Dim_PFSParticular]
AS
SELECT        PFSParticular_Idx, PFSParticularCode, PFSParticularName, PFSParticularDesc, PFSParticularGroup
FROM            dbo.Dim_STATBUL_PFSParticular
WHERE        (PFSParticularDesc IN ('Central Bank', 'UKBs', 'TBs', 'RCBs', 'NBFIs'))
GO
/****** Object:  View [dbo].[vw_FACT_ESLIG_Table19]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO











CREATE VIEW [dbo].[vw_FACT_ESLIG_Table19]
AS
		
			SELECT * FROM (
			
			
			-- TREASURY BILLS
			SELECT 
			[Level1] = 'Treasury Bill Rates',
			Tenors_Label = Tenors_Label,
			SORT = '1',
			Tenors_Sort = Tenors_Sort
			from Dim_ITR_Tenors B where Tenors_Idx in (1025,1026,1027,1028,6)

			UNION ALL

			-- TIME DEPOSIT
			SELECT 
			[Level1] = 'Time Deposit Rates',
			Tenors_Label = Tenors_Label,
			SORT = '2',
			Tenors_Sort = Tenors_Sort
			from Dim_ITR_Tenors B where Tenors_Idx in (1029,16)
			
			UNION ALL

			-- SAVINGS DEPOSIT
			SELECT top 1
			[Level1] = 'Savings Deposit Rates',
			Tenors_Label = 'Savings Deposit Rates',
			SORT ='3',
			Tenors_Sort = '1'
			from Dim_ITR_Tenors

			UNION ALL

			--BANK AVERAGE LENDING RATES
			SELECT top 1
			[Level1] = 'Bank Average Lending Rates',
			Tenors_Label = 'Bank Average Lending Rates',
			SORT = '4',
			Tenors_Sort = '1'
			from Dim_ITR_Tenors
			
			UNION ALL

			--LENDING RATES
			SELECT 
			[Level1] = 'Lending Rates',
			Tenors_Label = Tenors_Label,
			SORT = '5',
			Tenors_Sort = Tenors_Sort
			from Dim_ITR_Tenors B where Tenors_Idx in (25,26)
			
		
			UNION ALL

			--Overnight Lending Facility (OLF) Rates
			SELECT top 1
			[Level1] = 'Overnight Lending Facility (OLF) Rates',
			Tenors_Label = 'Overnight Lending Facility (OLF) Rates',
			SORT = '7',
			Tenors_Sort = '1'
			from Dim_ITR_Tenors

			UNION ALL

			--Overnight Reverse Repurchase Rates (RRP)
			SELECT top 1
			[Level1] = 'Overnight Reverse Repurchase Rates (RRP)',
			Tenors_Label = 'Overnight Reverse Repurchase Rates (RRP)',
			SORT = '8',
			Tenors_Sort = '1'
			from Dim_ITR_Tenors
			UNION ALL

			--Overnight Deposit Facility (ODF) Rates
			SELECT top 1
			[Level1] = 'Overnight Deposit Facility (ODF) Rates',
			Tenors_Label ='Overnight Deposit Facility (ODF) Rates',
			SORT = '9',
			Tenors_Sort = '1'
			from Dim_ITR_Tenors
			UNION ALL

			--BSP Securities
			SELECT 
			[Level1] = 'BSP Securities',
			Tenors_Label = Tenors_Label,
			SORT = '10',
			Tenors_Sort = Tenors_Sort
			from Dim_ITR_Tenors where Tenors_Idx in (29,1030)
			
			
			UNION ALL

			--Term Deposit Facility (TDF) Rates
			SELECT 
			[Level1] = 'Term Deposit Facility (TDF) Rates',
			Tenors_Label = Tenors_Label,
			SORT = '11',
			Tenors_Sort = Tenors_Sort
			from Dim_ITR_Tenors where Tenors_Idx in (2,3,4)


			UNION ALL

			--Term Deposit Facility (TDF) Rates
			SELECT top 1
			[Level1] = 'Interbank Call Loan Rates',
			Tenors_Label = 'Interbank Call Loan Rates',
			SORT = '12',
			Tenors_Sort = '1'
			from Dim_ITR_Tenors 
			) A
GO
/****** Object:  View [dbo].[vw_FACT_ESLIG_Table7]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO















CREATE VIEW [dbo].[vw_FACT_ESLIG_Table7]
AS
		
		select 

		Level1 = CASE WHEN B.BSPRateSubType_Name IN ('Interbank Call Loans','Savings Deposit','Time Deposits (All Maturities)')   THEN 'Borrowing Rates of Banks'
		 WHEN  B.BSPRateSubType_Name = 'Lending Rates' THEN 'Lending Rates'
		 WHEN A.BSPRateType_Name ='Bangko Sentral Rates 4' THEN  'Borrowing Rates of Banks' 
		 WHEN  A.BSPRateType_Name ='Bank Interest Rates' THEN  'Bangko Sentral Rates' 
		 WHEN  A.BSPRateType_Name ='Rate on Government Securities' THEN  'Rate on Treasury Bills' 
		 ELSE A.BSPRateType_Name
		END ,
		Level2 = CASE WHEN  B.BSPRateSubType_Name ='Overnight RRP'THEN 'Reverse Repurchase (RRP) Facility'
				  WHEN BSPRateSubType_Name = 'BSP Securities 5' THEN 'BSP Securities (28-Day)'
				  WHEN BSPRateSubType_Name = 'Rediscounting by loan maturity' THEN 'Rediscounting'
				  WHEN BSPRateSubType_Name = 'Treasury Bills, All Maturities' THEN 'All Maturities'
		ELSE  B.BSPRateSubType_Name END,
		Level3 =  CASE WHEN C.Tenors_Name is null THEN 
		 CASE WHEN B.BSPRateSubType_Name ='Overnight RRP' THEN 'Reverse Repurchase (RRP) Facility'
		 WHEN BSPRateSubType_Name = 'Rediscounting by loan maturity' THEN 'Rediscounting'
		-- WHEN BSPRateSubType_Name = 'Treasury Bills, All Maturities' THEN 'All Maturities'
		 ELSE BSPRateSubType_Name END
		 WHEN C.Tenors_Name = '7 Days' THEN '7-Day'
		 WHEN C.Tenors_Name = '2 Weeks' THEN '14-Day'
		 WHEN C.Tenors_Name = '28 Days' THEN '28-Day'
		ELSE C.Tenors_Name END ,
		Level3_Sort = CASE WHEN C.Tenors_Name = 'All Maturities' THEN 1 
		WHEN C.Tenors_Sort is null THEN  B.BSPRateSubType_Sort + 1 ELSE Tenors_Sort + 11 END,
		Level2_Sort = B.BSPRateSubType_Sort,
		Level1_Sort = CASE  WHEN B.BSPRateSubType_Name IN ('Interbank Call Loans','Savings Deposit','Time Deposits (All Maturities)')  THEN 1
		  WHEN  B.BSPRateSubType_Name = 'Lending Rates' THEN '2'
		-- WHEN A.BSPRateType_Name ='Bangko Sentral Rates 4'  THEN  '1' 
		 WHEN  A.BSPRateType_Name ='Bank Interest Rates' OR A.BSPRateType_Name = 'Bangko Sentral Rates' THEN  '3' 
		 WHEN  A.BSPRateType_Name ='Rate on Government Securities' THEN  '4' 
		 
		END 


		from [dbo].[Dim_ITR_BSPRateType] A LEFT JOIN [dbo].[Dim_ITR_BSPRateSubType] B
		ON A.BSPRateType_Idx = B.BSPRateType_Code 
		LEFT JOIN [dbo].[Dim_ITR_Tenors] C
		on B.BSPRateSubType_Idx = c.BSPRateSubType_Code
		
		UNION ALL

		SELECT 
		[Level1] = 'Rate on Treasury Bills',
		[Level2] = REPLACE(Tenors_Label,' ',''),
	    [Level3] = REPLACE(Tenors_Label,' ',''),
		[Level3_Sort] = Tenors_Idx,
		[Level2_Sort] = Tenors_Idx,
		[Level1_Sort] = '4'
		from Dim_ITR_Tenors B where Tenors_Idx in (1025,1026,1027,1028)
		

GO
/****** Object:  View [dbo].[vw_FACT_ESLIG_WPR]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

















CREATE     VIEW [dbo].[vw_FACT_ESLIG_WPR]
AS
		

		
		SELECT 
		[Level1] = '09. Bank Lending Rates',
		[Level2] = 'Lending Rates',
		Tenors_Label = Tenors_Label,
		Level1_Sort = '1',
		Tenor_Sort=Tenors_Sort
		from Dim_ITR_Tenors B where Tenors_Idx in (25,26,27)

		UNION ALL

		SELECT 
		[Level1] = '09. Bank Lending Rates',
		[Level2] = '',
		Tenors_Label = '',
		Level1_Sort = '1',
		Tenor_Sort=''
		
		UNION ALL

		SELECT 
		[Level1] = '10. Peso Deposit Rates',
		[Level2] = 'Savings Deposits',
		Tenors_Label = Tenors_Label,
		SORT = '2',
		Tenor_Sort=Tenors_Sort
		from Dim_ITR_Tenors B where Tenors_Idx in (25,26)
		
		UNION ALL

		SELECT 
		[Level1] = '10. Peso Deposit Rates',
		[Level2] = '',
		Tenors_Label = '',
		Level1_Sort = '1',
		Tenor_Sort=''
		UNION ALL

		SELECT 
		[Level1] = '10. Peso Deposit Rates',
		[Level2] = 'Time Deposits',
		Tenors_Label = Tenors_Label,
		SORT = '3',
		Tenor_Sort= Tenors_Sort
		from Dim_ITR_Tenors B where Tenors_Idx in (14,17,18,15,22,24)

		UNION ALL

		SELECT 
		[Level1] = '11. Dollar Deposit Rates',
		[Level2] = 'Savings Deposits',
		Tenors_Label = 'Savings Deposits',
		SORT = '2',
		Tenor_Sort=0
		--from Dim_ITR_Tenors B where Tenors_Idx in (25,26)
		UNION ALL

		SELECT 
		[Level1] = '11. Dollar Deposit Rates',
		[Level2] = '',
		Tenors_Label = '',
		Level1_Sort = '1',
		Tenor_Sort=''
		UNION ALL

		SELECT 
		[Level1] = '11. Dollar Deposit Rates',
		[Level2] = 'Time Deposits',
		Tenors_Label = Tenors_Label,
		SORT = '3',
		Tenor_Sort=Tenors_Sort
		from Dim_ITR_Tenors B where Tenors_Idx in (14,17,18,15,22,24)
		
GO
/****** Object:  View [dbo].[Dim_LoadTime]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[Dim_LoadTime] AS
SELECT *
FROM Dim_Time
GO
/****** Object:  Table [dbo].[FACT_CSOC_NBFI_PAWNSHOP]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FACT_CSOC_NBFI_PAWNSHOP](
	[Time_Idx] [int] NOT NULL,
	[BNKIND_Idx] [int] NOT NULL,
	[PARTICULAR_Idx] [int] NULL,
	[AMOUNT] [numeric](38, 2) NULL,
	[INDUSTRY_GROUP] [varchar](8) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FACT_MFSG_NBFI_NSSLA]    Script Date: 12/1/2023 3:41:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FACT_MFSG_NBFI_NSSLA](
	[Time_Idx] [int] NOT NULL,
	[BNKIND_Idx] [int] NOT NULL,
	[ACCOUNT_Idx] [int] NULL,
	[AMOUNT] [numeric](38, 2) NULL,
	[INDUSTRY_GROUP] [varchar](8) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FACT_CSOC_NBFI_IH]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FACT_CSOC_NBFI_IH](
	[Time_Idx] [int] NOT NULL,
	[BNKIND_Idx] [int] NOT NULL,
	[PARTICULAR_Idx] [int] NULL,
	[AMOUNT] [float] NULL,
	[INDUSTRY_GROUP] [varchar](8) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FACT_CSOC_NBFI_FC]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FACT_CSOC_NBFI_FC](
	[Time_Idx] [int] NOT NULL,
	[BNKIND_Idx] [int] NOT NULL,
	[PARTICULAR_Idx] [int] NULL,
	[AMOUNT] [float] NULL,
	[INDUSTRY_GROUP] [varchar](8) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_NBFI_PICs]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_NBFI_PICs](
	[Time_Idx] [int] NOT NULL,
	[PARTICULAR_Idx] [int] NULL,
	[BNKIND_Idx] [int] NULL,
	[AMOUNT] [numeric](38, 3) NULL,
	[TABLE] [varchar](8) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_GSIS_SSS]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_GSIS_SSS](
	[Time_Idx] [int] NOT NULL,
	[Particular_Idx] [int] NOT NULL,
	[BNKIND_Idx] [int] NULL,
	[Amount] [float] NULL,
	[INDUSTRY_GROUP] [varchar](8) NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_MFSG_NBFI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[vw_MFSG_NBFI]
AS
	SELECT [Time_Idx]
      ,[BNKIND_Idx]
      , [PARTICULAR_Idx]  as RecNo_Idx
      ,[AMOUNT]
      ,INDUSTRY_GROUP 
	FROM [DES].[dbo].[FACT_CSOC_NBFI_FC] --FC
	
	UNION ALL

	SELECT [Time_Idx]
      ,[BNKIND_Idx]
      ,[PARTICULAR_Idx] as RecNo_Idx
      ,[AMOUNT]
      ,INDUSTRY_GROUP 
	FROM [DES].[dbo].[FACT_CSOC_NBFI_IH] -- IH
	
	UNION ALL

	SELECT [Time_Idx]
		  ,[BNKIND_Idx]
		  ,[PARTICULAR_Idx] as RecNo_Idx
		  ,[AMOUNT]
		  ,INDUSTRY_GROUP
	  FROM [DES].[dbo].[FACT_CSOC_NBFI_PAWNSHOP]

	UNION ALL

	SELECT [Time_Idx]
	,[BNKIND_Idx] 
      ,[PARTICULAR_Idx] as RecNo_Idx
      ,[AMOUNT]
      ,[TABLE]
	FROM [DES].[dbo].[Fact_MFSG_NBFI_PICs]

	UNION ALL

	SELECT [Time_Idx]
		  ,[BNKIND_Idx]
		  ,[ACCOUNT_Idx] as RecNo_Idx
		  ,[AMOUNT]
		  ,INDUSTRY_GROUP
	  FROM [DES].[dbo].[FACT_MFSG_NBFI_NSSLA]

	UNION ALL

	SELECT [Time_Idx]
      ,BNKIND_idx 
      ,[Particular_Idx] as RecNo_Idx
      ,[Amount]
	  ,INDUSTRY_GROUP 
	FROM des.[dbo].Fact_MFSG_GSIS_SSS

GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDWeekly]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDWeekly](
	[BKCODE] [int] NULL,
	[Time_Idx] [int] NULL,
	[BASIS] [varchar](6) NULL,
	[PART] [varchar](17) NULL,
	[ACCTCODE] [varchar](18) NULL,
	[TVNOTRAN] [float] NULL,
	[TVAMOUNT] [numeric](19, 5) NULL,
	[IRLOWER] [real] NULL,
	[IRUPPER] [real] NULL,
	[EIRLOWER] [real] NULL,
	[EIRUPPER] [real] NULL,
	[WAIR] [real] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_SecuritiesAuctionResult]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_SecuritiesAuctionResult](
	[Auction Date_Idx] [int] NOT NULL,
	[Settlement Date_Idx] [int] NOT NULL,
	[Tenor_Idx] [varchar](100) NOT NULL,
	[Amount offered] [decimal](18, 4) NULL,
	[Amount Tendered] [decimal](18, 4) NULL,
	[Amount Awarded] [decimal](18, 4) NULL,
	[Lowest accepted yield] [decimal](18, 4) NULL,
	[Highest accepted yield] [decimal](18, 4) NULL,
	[Weighted average accepted yield] [decimal](18, 4) NULL,
	[Bid Coverage Ratio] [decimal](18, 4) NULL,
	[Security Identifier] [varchar](100) NOT NULL,
	[Instrument] [varchar](100) NOT NULL,
	[Maturity Date_Idx] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_TDFAuctionResult]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_TDFAuctionResult](
	[Auction Date_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[Volume offered] [decimal](18, 4) NULL,
	[Amount Tendered] [decimal](18, 4) NULL,
	[Amount Awarded] [decimal](18, 4) NULL,
	[Weighted average accepted yield] [decimal](18, 4) NULL,
	[Lowest accepted yield] [decimal](18, 4) NULL,
	[Highest accepted yield] [decimal](18, 4) NULL,
	[Bid Coverage Ratio] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_TenorRates]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_TenorRates](
	[Time_Idx] [int] NULL,
	[Tenor_Idx] [varchar](100) NOT NULL,
	[Rate_Idx] [varchar](100) NOT NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IBCL]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IBCL](
	[Time_Idx] [int] NULL,
	[IBCLType_Idx] [int] NOT NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FACT_ESLIG_Table6]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[vw_FACT_ESLIG_Table6]
AS
		
		-- BANK INTEREST RATES
			--SAVING DEPOSIT 215100000000000000
			--TIME DEPOSIT 215150000000000000
			--IBCL WAIR
			SELECT A.Time_Idx,A.Level1,A.Level2,A.Level3,A.WAIR,ROW_NUMBER() over (order by SORT) as  Sort_By FROM (
			SELECT Time_Idx,
			[Level1] = 'Bank Interest Rates',
			[Level2] = 'Interbank Call Loans',
			[Level3] = '',
			WAIR = ISNULL([Value],0) ,
			SORT = '1'
			 FROM [dbo].[Fact_ESLIG_ITR_IBCL] where IBCLType_Idx = 1
			
			UNION


			SELECT Time_Idx,
			[Level1] = 'Bank Interest Rates',

				CASE 
					WHEN ACCTCODE = '215100000000000000' THEN 'Savings Deposit'
					WHEN ACCTCODE = '215150000000000000' THEN 'Time Deposits'
			END [Level2],
			[Level3] = '',
			WAIR = ISNULL(WAIR,0) ,
			SORT = '2'
		   FROM [dbo].[Fact_ESLIG_ITR_IRLDWeekly] where ACCTCODE in (215100000000000000,215150000000000000)

			UNION
			--BANGKO SENTRAL RATES

			SELECT Time_Idx,
			[Level1] = 'Bangko Sentral Rates 4',
			[Level2] = CASE 
					WHEN Rate_Idx = '4' THEN 'Overnight Lending Facility (OLF)'
					WHEN Rate_Idx = '3' THEN 'Overnight Deposit Facility (ODF)'
					WHEN Rate_Idx = '5' THEN 'Overnight RRP Facility'
					
			END ,
			[Level3] = '',
			WAIR = [Value]  ,
			SORT = '3'
			 FROM [dbo].[Fact_ESLIG_ITR_TenorRates] where Rate_Idx in (3,4,5) and Tenor_Idx  in (4)

			 UNION

			 SELECT [Auction Date_Idx],
			[Level1] = 'Bangko Sentral Rates 4',
			[Level2] = 'Term Deposit Facility (TDF)',
			[Level3] = B.Tenors_Code,
			WAIR = [Weighted average accepted yield]  ,
			SORT = '4'
			 FROM [dbo].[Fact_ESLIG_ITR_TDFAuctionResult]  A
			 LEFT JOIN [dbo].[Dim_ITR_Tenors] B on
			 A.Tenor_Idx = B.Tenors_Idx
			 where  A.Tenor_Idx  in (1,2,3)
			
			 UNION

			 SELECT [Auction Date_Idx],
			[Level1] = 'Bangko Sentral Rates 4',
			[Level2] = 'BSP Securities',
			[Level3] = B.Tenors_Code,
			WAIR = [Weighted average accepted yield] 
			 ,
			SORT = '5'
			 FROM [dbo].[Fact_ESLIG_ITR_SecuritiesAuctionResult]  A
			 LEFT JOIN [dbo].[Dim_ITR_Tenors] B on
			 A.Tenor_Idx = B.Tenors_Idx
			 where  A.Tenor_Idx  in (1,2,3)
			) A
GO
/****** Object:  Table [dbo].[Dim_MFSG_FC_RecNo]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MFSG_FC_RecNo](
	[RecNo_Idx] [int] IDENTITY(1,1) NOT NULL,
	[RecNo_Code] [nvarchar](150) NOT NULL,
	[RecNo_Name] [nvarchar](150) NOT NULL,
	[RecNo_Label] [nvarchar](150) NULL,
	[Group_Code] [nvarchar](150) NULL,
	[RecNo_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_MFSG_RecNo] PRIMARY KEY CLUSTERED 
(
	[RecNo_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MFSG_IH_RecNo]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MFSG_IH_RecNo](
	[RecNo_Idx] [int] IDENTITY(1,1) NOT NULL,
	[RecNo_Code] [nvarchar](150) NOT NULL,
	[RecNo_Name] [nvarchar](150) NOT NULL,
	[RecNo_Label] [nvarchar](150) NULL,
	[Group_Code] [nvarchar](150) NULL,
	[RecNo_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_MFSG_IH_RecNo] PRIMARY KEY CLUSTERED 
(
	[RecNo_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MFSG_GSISSSS]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MFSG_GSISSSS](
	[Acct_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Acct_Code] [nvarchar](150) NOT NULL,
	[Acct_Name] [nvarchar](150) NOT NULL,
	[Acct_Label] [nvarchar](150) NULL,
	[Acct_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_MFSG_Acct_GSISSSS] PRIMARY KEY CLUSTERED 
(
	[Acct_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MFSG_Pawnshop_RecNo]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MFSG_Pawnshop_RecNo](
	[RecNo_Idx] [int] IDENTITY(1,1) NOT NULL,
	[RecNo_Code] [nvarchar](150) NOT NULL,
	[RecNo_Name] [nvarchar](150) NOT NULL,
	[RecNo_Label] [nvarchar](150) NULL,
	[Group_Code] [nvarchar](150) NULL,
	[RecNo_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_MFSG_RecNo_pawnshop] PRIMARY KEY CLUSTERED 
(
	[RecNo_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MFSG_NSSLA_Acct]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MFSG_NSSLA_Acct](
	[Acct_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Acct_Code] [nvarchar](150) NOT NULL,
	[Acct_Name] [nvarchar](150) NOT NULL,
	[Acct_Label] [nvarchar](150) NULL,
	[Group_Code] [nvarchar](150) NULL,
	[Acct_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_MFSG_Acct_NSSLA] PRIMARY KEY CLUSTERED 
(
	[Acct_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MFSG_PIC_Particular]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MFSG_PIC_Particular](
	[Particular_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Particular_Code] [nvarchar](150) NOT NULL,
	[Particular_Name] [nvarchar](150) NOT NULL,
	[Particular_Label] [nvarchar](150) NULL,
	[Group_Code] [nvarchar](150) NULL,
	[Particular_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_MFSG_PIC_Particular] PRIMARY KEY CLUSTERED 
(
	[Particular_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_Dim_MFSG_NBFI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [dbo].[vw_Dim_MFSG_NBFI]
AS
SELECT 
		[RecNo_Idx]
		,[RecNo_Code]
      ,[RecNo_Name]
      ,[RecNo_Label]
      --,[Group_Code]
      ,[RecNo_Sort]
	  ,INDUSTRY_GROUP = 'FC'
  FROM [DES].[dbo].[Dim_MFSG_FC_RecNo]

  UNION ALL

SELECT 
		[RecNo_Idx]
    ,[RecNo_Code]
      ,[RecNo_Name]
      ,[RecNo_Label]
      --,[Group_Code]
      ,[RecNo_Sort]
	  ,INDUSTRY_GROUP = 'IH'
  FROM [DES].[dbo].[Dim_MFSG_IH_RecNo]

  UNION ALL

  SELECT
  		[RecNo_Idx]
      ,[RecNo_Code]
      ,[RecNo_Name]
      ,[RecNo_Label]
      --,[Group_Code]
      ,[RecNo_Sort]
	  ,INDUSTRY_GROUP = 'PAWNSHOP'
  FROM [DES].[dbo].[Dim_MFSG_Pawnshop_RecNo]

	UNION ALL

	SELECT
	[Acct_Idx]
      ,[Acct_Code]
      ,[Acct_Name]
      ,[Acct_Label]
      ,[Acct_Sort]
	  ,INDUSTRY_GROUP = 'GSIS_SSS'
  FROM [DES].[dbo].[Dim_MFSG_GSISSSS]

  UNION ALL

  SELECT 
	  Acct_Idx
      ,[Acct_Code]
      ,[Acct_Name]
      ,[Acct_Label]
      --,[Group_Code]
      ,[Acct_Sort]
	  ,INDUSTRY_GROUP = 'NSSLA'
  FROM [DES].[dbo].[Dim_MFSG_NSSLA_Acct]

  UNION ALL

   SELECT 
	  [Particular_Idx]
      ,[Particular_Code]
      ,[Particular_Name]
      ,[Particular_Label]
      --,[Group_Code]
      ,[Particular_Sort]
	  ,INDUSTRY_GROUP = 'PIC'
  FROM [DES].[dbo].[Dim_MFSG_PIC_Particular]

GO
/****** Object:  Table [dbo].[Fact_TBills]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_TBills](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[ISIN] [nvarchar](50) NULL,
	[Offering] [float] NULL,
	[High] [float] NULL,
	[Low] [float] NULL,
	[Average] [float] NULL,
	[Tendered] [float] NULL,
	[Volume] [float] NULL,
	[Rejected] [float] NULL,
	[Accepted] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_Fact_TBills]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_Fact_TBills]
AS
SELECT [Time_Idx]
      ,[Tenor_Idx] = 4
      ,[ISIN]
      ,[Offering]
      ,[High]
      ,[Low]
      ,[Average]
      ,[Tendered]
      ,[Volume]
      ,[Rejected]
  FROM [DES].[dbo].[Fact_TBills]
  UNION ALL
  SELECT [Time_Idx]
      ,[Tenor_Idx]
      ,[ISIN]
      ,[Offering]
      ,[High]
      ,[Low]
      ,[Average]
      ,[Tendered]
      ,[Volume]
      ,[Rejected]
  FROM [DES].[dbo].[Fact_TBills]
GO
/****** Object:  View [dbo].[vw_Dim_Time]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[vw_Dim_Time]
AS
SELECT [Time_Idx]
      ,[ActualDate] = cast([ActualDate] as date)
      ,[Year]
      ,[Quarter]
      ,[Month]
      ,[Week]
      ,[DayofYear]
      ,[DayofMonth]
      ,[DayofWeek]
      ,[IsWeekend]
      ,[IsHoliday]
      ,[BusinessYearWeek]
      ,[LeapYear]
	  ,[YearName] = cast(Year as varchar)
	  ,[QuarterName] = cast(Year as varchar) + ' Q' + cast(Quarter as varchar)
	  ,[QuarterSort] = Year * 100 + Quarter
	  ,[MonthYear] = DATENAME(mm,ActualDate) + space(1) + cast(Year as varchar)
	  ,[MonthSort] = Year * 100 + Month
	  ,[MonthName] = DATENAME(mm,ActualDate)
	  ,[MonthShortName] = left(DATENAME(mm,ActualDate),3)
	  ,[MonthNameYTD] = case when Month = 1 then left(DATENAME(mm,ActualDate),3) else 'Jan - ' + left(DATENAME(mm,ActualDate),3) end
	  ,[SemesterName] = case when Month between 1 and 6 then '1st Semester' else '2nd Semester' end
	  ,[MonthNumber] = 'M' + cast(Month as varchar)
	  ,[MonthIMFName] = cast(Year as varchar) + 'M' + cast(Month as varchar)
	  ,[DayNameYTD] = '1 Jan - ' + cast(DayofMonth as varchar) + space(1) + left(DATENAME(mm,ActualDate),3)
	  ,[ActualDateMonth] = cast(DATEADD(Day,([DayofMonth]*-1) + 1,[ActualDate]) as date)
  FROM [DES].[dbo].[Dim_Time]
GO
/****** Object:  Table [dbo].[Dim_BES_Branch]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_Branch](
	[Branch_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Branch_Code] [nvarchar](150) NOT NULL,
	[Branch_Name] [nvarchar](150) NOT NULL,
	[Branch_Label] [nvarchar](150) NULL,
	[Region_Idx] [int] NULL,
	[Branch_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_BES_Branch] PRIMARY KEY CLUSTERED 
(
	[Branch_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BES_Sector]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_Sector](
	[Sector_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Sector_Code] [nvarchar](150) NOT NULL,
	[Sector_Name] [nvarchar](150) NOT NULL,
	[Sector_Label] [nvarchar](150) NULL,
	[Sector_Sort] [int] NULL,
	[Sector_Sort2] [int] NULL,
 CONSTRAINT [PK_Dim_BES_Sector] PRIMARY KEY CLUSTERED 
(
	[Sector_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BES_SubSector]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_SubSector](
	[Subsector_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Subsector_Code] [nvarchar](150) NOT NULL,
	[Subsector_Name] [nvarchar](150) NOT NULL,
	[Subsector_Label] [nvarchar](150) NULL,
	[Sector_Idx] [int] NOT NULL,
	[Subsector_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_BES_Subsector] PRIMARY KEY CLUSTERED 
(
	[Subsector_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BES_Company]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_Company](
	[Company_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Company_Code] [nvarchar](150) NOT NULL,
	[Company_Name] [nvarchar](150) NOT NULL,
	[Company_Label] [nvarchar](150) NULL,
	[Subsector_Idx] [int] NULL,
	[Region_Idx] [int] NULL,
	[Company_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_BES_Company] PRIMARY KEY CLUSTERED 
(
	[Company_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Location_Region]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Location_Region](
	[Region_Idx] [int] NOT NULL,
	[Region_Code] [nvarchar](50) NOT NULL,
	[Region_Name] [nvarchar](150) NOT NULL,
	[Region_Label] [nvarchar](150) NULL,
	[Region_Sort] [int] NULL,
	[MajorIslandGroup_Idx] [int] NULL,
	[Region_Tag] [varchar](255) NULL,
	[Region_Label2] [nvarchar](150) NULL,
	[BES_Region_Code] [int] NULL,
 CONSTRAINT [PK_Dim_Location_Region] PRIMARY KEY CLUSTERED 
(
	[Region_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Weights_Population]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Weights_Population](
	[Time_Idx] [int] NOT NULL,
	[Subsector_Idx] [int] NOT NULL,
	[Sector_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[Count] [int] NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_Date] [datetime] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Weights_PopulationGT]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Weights_PopulationGT](
	[Time_Idx] [int] NOT NULL,
	[Classification] [nvarchar](255) NOT NULL,
	[Count] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Responses]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Responses](
	[Time_Idx] [int] NOT NULL,
	[Company_Idx] [int] NOT NULL,
	[Sector_Idx] [int] NOT NULL,
	[Subsector_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[ProductLine] [nvarchar](255) NULL,
	[ContactPerson] [nvarchar](255) NULL,
	[Designation] [nvarchar](255) NULL,
	[Email] [nvarchar](255) NULL,
	[Address1] [nvarchar](255) NULL,
	[Address2] [nvarchar](255) NULL,
	[TelephoneNumber] [nvarchar](255) NULL,
	[FaxNumber] [nvarchar](255) NULL,
	[DateReceive ] [date] NULL,
	[BusinessOutlookCQ] [nvarchar](255) NULL,
	[BusinessOutlookCQ_Code] [nvarchar](255) NULL,
	[BusinessOutlookNQ] [nvarchar](255) NULL,
	[BusinessOutlookNQ_Code] [nvarchar](255) NULL,
	[BusinessOutlookN12M] [nvarchar](255) NULL,
	[BusinessOutlookN12M_Code] [nvarchar](255) NULL,
	[CQReasonBusinessOutlook] [nvarchar](max) NULL,
	[NQReasonBusinessOutlook] [nvarchar](max) NULL,
	[N12MReasonBusinessOutlook] [nvarchar](max) NULL,
	[CQVolumeofBusinessActivity] [nvarchar](255) NULL,
	[CQVolumeofBusinessActivity_Code] [nvarchar](255) NULL,
	[NQVolumeofBusinessActivity] [nvarchar](255) NULL,
	[NQVolumeofBusinessActivity_Code] [nvarchar](255) NULL,
	[CQVolumeofTotalOrderBook] [nvarchar](255) NULL,
	[CQVolumeofTotalOrderBook_Code] [nvarchar](255) NULL,
	[NQVolumeofTotalOrderBook] [nvarchar](255) NULL,
	[NQVolumeofTotalOrderBook_Code] [nvarchar](255) NULL,
	[CQVolumeofImportOrderBook] [nvarchar](255) NULL,
	[CQVolumeofImportOrderBook_Code] [nvarchar](255) NULL,
	[NQVolumeofImportOrderBook] [nvarchar](255) NULL,
	[NQVolumeofImportOrderBook_Code] [nvarchar](255) NULL,
	[CQAverageSellingPricePriceofServices] [nvarchar](255) NULL,
	[CQAverageSellingPricePriceofServices_Code] [nvarchar](255) NULL,
	[NQAverageSellingPricePriceofServices] [nvarchar](255) NULL,
	[NQAverageSellingPricePriceofServices_Code] [nvarchar](255) NULL,
	[CQVolumeofExportOrderBook] [nvarchar](255) NULL,
	[CQVolumeofExportOrderBook_Code] [nvarchar](255) NULL,
	[NQVolumeofExportOrderBook] [nvarchar](255) NULL,
	[NQVolumeofExportOrderBook_Code] [nvarchar](255) NULL,
	[CQCapitalExpenditure] [nvarchar](255) NULL,
	[CQCapitalExpenditure_Code] [nvarchar](255) NULL,
	[NQCapitalExpenditure] [nvarchar](255) NULL,
	[NQCapitalExpenditure_Code] [nvarchar](255) NULL,
	[CQVolumeofStocks] [nvarchar](255) NULL,
	[CQVolumeofStocks_Code] [nvarchar](255) NULL,
	[NQVolumeofStocks] [nvarchar](255) NULL,
	[NQVolumeofStocks_Code] [nvarchar](255) NULL,
	[CQInventoryofRawMaterials] [nvarchar](255) NULL,
	[CQInventoryofRawMaterials_Code] [nvarchar](255) NULL,
	[NQInventoryofRawMaterials] [nvarchar](255) NULL,
	[NQInventoryofRawMaterials_Code] [nvarchar](255) NULL,
	[CQFinishedGoodsforSale] [nvarchar](255) NULL,
	[CQFinishedGoodsforSale_Code] [nvarchar](255) NULL,
	[NQFinishedGoodsforSale] [nvarchar](255) NULL,
	[NQFinishedGoodsforSale_Code] [nvarchar](255) NULL,
	[CQNetIncome] [nvarchar](255) NULL,
	[CQNetIncome_Code] [nvarchar](255) NULL,
	[NQNetIncome] [nvarchar](255) NULL,
	[NQNetIncome_Code] [nvarchar](255) NULL,
	[CQBusinessConditions] [nvarchar](255) NULL,
	[CQBusinessConditions_Code] [nvarchar](255) NULL,
	[NQBusinessConditions] [nvarchar](255) NULL,
	[NQBusinessConditions_Code] [nvarchar](255) NULL,
	[NumberofEmployees] [int] NULL,
	[NQNumberofEmployees] [nvarchar](255) NULL,
	[NQNumberofEmployees_Code] [nvarchar](255) NULL,
	[NQExpansionPlans] [nvarchar](255) NULL,
	[NQExpansionPlans_Code] [nvarchar](255) NULL,
	[CQFinancialConditions] [nvarchar](255) NULL,
	[CQFinancialConditions_Code] [nvarchar](255) NULL,
	[NQFinancialConditions] [nvarchar](255) NULL,
	[NQFinancialConditions_Code] [nvarchar](255) NULL,
	[Reason CQ] [nvarchar](max) NULL,
	[Reason NQ] [nvarchar](max) NULL,
	[CQAccesstoCredit] [nvarchar](255) NULL,
	[CQAccesstoCredit_Code] [nvarchar](255) NULL,
	[NQAccesstoCredit] [nvarchar](255) NULL,
	[NQAccesstoCredit_Code] [nvarchar](255) NULL,
	[Reason_A_CQ] [nvarchar](max) NULL,
	[Reason_A_NQ] [nvarchar](max) NULL,
	[CurrentPercentLevelofCapacityUtilization] [numeric](33, 20) NULL,
	[PresentTechnicalCapacity] [nvarchar](255) NULL,
	[PresentTechnicalCapacity_Code] [nvarchar](255) NULL,
	[None] [nvarchar](255) NULL,
	[Highinterestrate] [nvarchar](255) NULL,
	[Financialproblems] [nvarchar](255) NULL,
	[Insufficientdemand] [nvarchar](255) NULL,
	[Accesstocredit] [nvarchar](255) NULL,
	[Lackofequipment] [nvarchar](255) NULL,
	[Lackofmaterialinput] [nvarchar](255) NULL,
	[Uncleareconomiclaws] [nvarchar](255) NULL,
	[Foreigncompetition] [nvarchar](255) NULL,
	[Domesticcompetition] [nvarchar](255) NULL,
	[Laborproblems] [nvarchar](255) NULL,
	[Others] [nvarchar](255) NULL,
	[OthersSpecify] [nvarchar](4000) NULL,
	[LimitingFactor1] [nvarchar](255) NULL,
	[LFReason1] [nvarchar](max) NULL,
	[LimitingFactor2] [nvarchar](255) NULL,
	[LFReason2] [nvarchar](max) NULL,
	[LimitingFactor3] [nvarchar](255) NULL,
	[LFReason3] [nvarchar](max) NULL,
	[N12MVolumeofBusinessActivity] [nvarchar](255) NULL,
	[N12MVolumeofBusinessActivity_Code] [nvarchar](255) NULL,
	[N12MVolumeofExportOrderBook] [nvarchar](255) NULL,
	[N12MVolumeofExportOrderBook_Code] [nvarchar](255) NULL,
	[N12MVolumeofImportOrderBook] [nvarchar](255) NULL,
	[N12MVolumeofImportOrderBook_Code] [nvarchar](255) NULL,
	[N12MBusinessConditions] [nvarchar](255) NULL,
	[N12MBusinessConditions_Code] [nvarchar](255) NULL,
	[N12MAverageSellingPrice] [nvarchar](255) NULL,
	[N12MAverageSellingPrice_Code] [nvarchar](255) NULL,
	[N12MNumberofEmployees] [nvarchar](255) NULL,
	[N12MNumberofEmployees_Code] [nvarchar](255) NULL,
	[N12MExpansionPlans] [nvarchar](255) NULL,
	[N12MExpansionPlans_Code] [nvarchar](255) NULL,
	[CQAveragePesoBorrowingRate] [nvarchar](255) NULL,
	[CQAveragePesoBorrowingRate_Code] [nvarchar](255) NULL,
	[NQAveragePesoBorrowingRate] [nvarchar](255) NULL,
	[NQAveragePesoBorrowingRate_Code] [nvarchar](255) NULL,
	[N12MAveragePesoBorrowingRate] [nvarchar](255) NULL,
	[N12MAveragePesoBorrowingRate_Code] [nvarchar](255) NULL,
	[CQAveragePExchangeRate] [nvarchar](255) NULL,
	[CQAverageP$ExchangeRate_Code] [nvarchar](255) NULL,
	[NQAveragePExchangeRate] [nvarchar](255) NULL,
	[NQAverageP$ExchangeRate_Code] [nvarchar](255) NULL,
	[N12MAveragePExchangeRate] [nvarchar](255) NULL,
	[N12MAverageP$ExchangeRate_Code] [nvarchar](255) NULL,
	[CQInflationRate] [nvarchar](255) NULL,
	[CQInflationRate_Code] [nvarchar](255) NULL,
	[NQInflationRate] [nvarchar](255) NULL,
	[NQInflationRate_Code] [nvarchar](255) NULL,
	[N12MInflationRate] [nvarchar](255) NULL,
	[N12MInflationRate_Code] [nvarchar](255) NULL,
	[CQReasonInflationRateOutlook] [nvarchar](max) NULL,
	[NQReasonInflationRateOutlook] [nvarchar](max) NULL,
	[N12MReasonInflationOutlook] [nvarchar](max) NULL,
	[CQInflationRate_Value] [numeric](33, 20) NULL,
	[NQInflationRate_Value] [numeric](33, 20) NULL,
	[N12MInflationRate_Value] [numeric](33, 20) NULL,
	[CQExchangeRate_Value] [numeric](33, 20) NULL,
	[NQExchangeRate_Value] [numeric](33, 20) NULL,
	[N12MExchangeRate_Value] [numeric](33, 20) NULL,
	[ImporterExporter] [nvarchar](255) NULL,
	[SourceFile] [nvarchar](255) NULL,
	[Branch_Idx] [int] NULL,
	[Created_Date] [datetime] NULL,
	[Modified_Date] [datetime] NULL,
	[No] [nvarchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_BES_For_SPSS]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






/****** Script for SelectTopNRows command from SSMS  ******/

CREATE VIEW [dbo].[vw_BES_For_SPSS]
AS
SELECT [No]
      ,[GlobalWeights] = CAST([Population]as float) /CAST(H.[Count] as float)
	  ,[IndividualWeights] = (CAST([Population]as float) /CAST(H.[Count] as float))/ CAST(I.[Count] as float)
      ,[CompanyName] = Company_Name
      ,[Sectors] = Sector_Code
      ,[Subsector] = Subsector_Code
      ,[Region] = BES_Region_Code
      ,[ProductLine]
      ,[ContactPerson]
      ,[Designation]
      ,[Email Address] = [Email]
      ,[Address1]
      ,[Address2]
      ,[TelephoneNumber]
      ,[FaxNumber]
      ,[DateReceived] =[DateReceive ]
      ,[BusinessOutlookCQ] =[BusinessOutlookCQ_Code]
      ,[BusinessOutlookNQ] =[BusinessOutlookNQ_Code]
      ,[BusinessOutlookN12M] =[BusinessOutlookN12M_Code]
      ,[CQReasonBusinessOutlook]
      ,[NQReasonBusinessOutlook]
      ,[N12MReasonBusinessOutlook]
      ,[CQVolumeofBusinessActivity]=[CQVolumeofBusinessActivity_Code]
      ,[NQVolumeofBusinessActivity]=[NQVolumeofBusinessActivity_Code]
      ,[CQVolumeofTotalOrderBook]=[CQVolumeofTotalOrderBook_Code]
      ,[NQVolumeofTotalOrderBook]=[NQVolumeofTotalOrderBook_Code]
      ,[CQVolumeofImportOrderBook]=[CQVolumeofImportOrderBook_Code]
      ,[NQVolumeofImportOrderBook]=[NQVolumeofImportOrderBook_Code]
      ,[CQAverageSellingPricePriceofServices]=[CQAverageSellingPricePriceofServices_Code]
      ,[NQAverageSellingPricePriceofServices]=[NQAverageSellingPricePriceofServices_Code]
      ,[CQVolumeofExportOrderBook]=[CQVolumeofExportOrderBook_Code]
      ,[NQVolumeofExportOrderBook]=[NQVolumeofExportOrderBook_Code]
      ,[CQCapitalExpenditure]=[CQCapitalExpenditure_Code]
      ,[NQCapitalExpenditure]=[NQCapitalExpenditure_Code]
      ,[CQVolumeofStocks]=[CQVolumeofStocks_Code]
      ,[NQVolumeofStocks]=[NQVolumeofStocks_Code]
      ,[CQInventoryofRawMaterials]=[CQInventoryofRawMaterials_Code]
      ,[NQInventoryofRawMaterials]=[NQInventoryofRawMaterials_Code]
      ,[CQFinishedGoodsforSale]=[CQFinishedGoodsforSale_Code]
      ,[NQFinishedGoodsforSale]=[NQFinishedGoodsforSale_Code]
      ,[CQNetIncome]=[CQNetIncome_Code]
      ,[NQNetIncome]=[NQNetIncome_Code]
      ,[CQBusinessConditions]=[CQBusinessConditions_Code]
      ,[NQBusinessConditions]=[NQBusinessConditions_Code]
	  ,[CQFinancialConditions]=[CQFinancialConditions_Code]
      ,[NQFinancialConditions]=[NQFinancialConditions_Code]
	  ,[Reason CQ]
      ,[Reason NQ]
	  ,[CQAccesstoCredit]=[CQAccesstoCredit_Code]
      ,[NQAccesstoCredit]=[NQAccesstoCredit_Code]
      ,[Reason_A_CQ]
      ,[Reason_A_NQ]
      ,[CurrentPercentLevelofCapacityUtilization]
      ,[PresentTechnicalCapacity]=[PresentTechnicalCapacity_Code]
	  ,[NumberofEmployees]
      ,[None]
      ,[Highinterestrate]
      ,[Financialproblems]
      ,[Insufficientdemand]
      ,[Accesstocredit]
      ,[Lackofequipment]
      ,[Lackofmaterialinput]
      ,[Uncleareconomiclaws]
      ,[Foreigncompetition]
      ,[Domesticcompetition]
      ,[Laborproblems]
      ,[Others]
      ,[OthersSpecify]
      ,[LimitingFactor1]
     -- ,[LFReason1]
      ,[LimitingFactor2]
     -- ,[LFReason2]
      ,[LimitingFactor3]
      --,[LFReason3]
      ,[N12MVolumeofBusinessActivity]=[N12MVolumeofBusinessActivity_Code]
      ,[N12MVolumeofExportOrderBook]=[N12MVolumeofExportOrderBook_Code]
      ,[N12MVolumeofImportOrderBook]=[N12MVolumeofImportOrderBook_Code]
      ,[N12MBusinessConditions]=[N12MBusinessConditions_Code]
      ,[N12MAverageSellingPrice]=[N12MAverageSellingPrice_Code]
	  ,[NQNumberofEmployees]=[NQNumberofEmployees_Code]
      ,[N12MNumberofEmployees]=[N12MNumberofEmployees_Code]
      ,[NQExpansionPlans]=[NQExpansionPlans_Code]
	  ,[N12MExpansionPlans]=[N12MExpansionPlans_Code]
      ,[CQAveragePesoBorrowingRate] =[CQAveragePesoBorrowingRate_Code]
      ,[NQAveragePesoBorrowingRate]=[NQAveragePesoBorrowingRate_Code]
      ,[N12MAveragePesoBorrowingRate]=[N12MAveragePesoBorrowingRate_Code]
      ,[CQAverageP$ExchangeRate]=[CQAverageP$ExchangeRate_Code]
      ,[NQAverageP$ExchangeRate]=[NQAverageP$ExchangeRate_Code]
      ,[N12MAverageP$ExchangeRate]=[N12MAverageP$ExchangeRate_Code]
      ,[CQInflationRate]=[CQInflationRate_Code]
      ,[NQInflationRate]=[NQInflationRate_Code]
      ,[N12MInflationRate]=[N12MInflationRate_Code]
      ,[CQReasonInflationRateOutlook]
      ,[NQReasonInflationRateOutlook]
      ,[N12MReasonInflationOutlook]
      ,[CQInflationRate_Value]
      ,[NQInflationRate_Value]
      ,[N12MInflationRate_Value]
      ,[CQExchangeRate_Value]
      ,[NQExchangeRate_Value]
      ,[N12MExchangeRate_Value]
	  ,CASE WHEN [ImporterExporter] = 'IMPORTER'  THEN 1
	  WHEN [ImporterExporter] = 'EXPORTER'   THEN 2
	  WHEN [ImporterExporter] = 'BOTH'   THEN 3
	  WHEN [ImporterExporter] = 'DOMESTIC ORIENTED'  THEN 4
	  ELSE 5 END ImporterExporter
	  ,[Branch] = Branch_Name
  FROM [DES].[dbo].[Fact_BES_Responses] A
  LEFT JOIN Dim_BES_Sector B ON A.Sector_Idx = B.Sector_Idx
  LEFT JOIN Dim_BES_SubSector C ON A.Subsector_Idx = C.Subsector_Idx
  LEFT JOIN Dim_Location_Region D ON A.Region_Idx = D.Region_Idx
  LEFT JOIN Dim_BES_Company E ON A.Company_Idx = E.Company_Idx
  LEFT JOIN Dim_BES_Branch F ON A.Branch_Idx = F.Branch_Idx
  LEFT JOIN (SELECT Time_Idx, Subsector_Idx, Region_Tag, SUM([Count]) [Population]
			FROM Fact_BES_Weights_Population A
			JOIN Dim_Location_Region B ON A.Region_Idx = B.Region_Idx
			GROUP BY Time_Idx,Subsector_Idx, Region_Tag) G 
			 ON A.Time_Idx = G.Time_Idx AND A.Subsector_Idx = G.Subsector_Idx 
			 AND D.Region_Tag = G.Region_Tag
  LEFT JOIN (SELECT * FROM Fact_BES_Weights_PopulationGT
        WHERE [Classification] = 'Grand Total')H ON A.Time_Idx = H.Time_Idx
  LEFT JOIN (
		SELECT Time_Idx, Subsector_Idx, Region_Tag, [Count] = COUNT(*) FROM Fact_BES_Responses A
		JOIN Dim_Location_Region B ON A.Region_Idx = B.Region_Idx
		GROUP BY Time_Idx,Subsector_Idx, Region_Tag) I ON A.Time_Idx = I.Time_Idx AND A.Subsector_Idx = I.Subsector_Idx AND D.Region_Tag = I.Region_Tag
  WHERE LEFT(A.Time_Idx,6) = (SELECT  LEFT(MAX(Time_Idx),6) FROM  [DES].[dbo].[Fact_BES_Responses])
GO
/****** Object:  View [dbo].[vw_BES_OthersSpecified]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [dbo].[vw_BES_OthersSpecified]
AS


SELECT Time_Idx, Region_Idx, Company_Idx,
OthersSpecify FROM Fact_BES_Responses A
WHERE OthersSpecify IS NOT NULL AND OthersSpecify <> ''



GO
/****** Object:  Table [dbo].[Dim_Bank]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Bank](
	[Bank_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Bank_Code] [nvarchar](50) NOT NULL,
	[Bank_Name] [nvarchar](150) NOT NULL,
	[Bank_Label] [nvarchar](150) NULL,
	[Bank_Sort] [int] NULL,
	[Slos_Bank] [nvarchar](50) NULL,
 CONSTRAINT [PK_Dim_Bank] PRIMARY KEY CLUSTERED 
(
	[Bank_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_ITR_OtherSavingDeposit]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [dbo].[vw_ITR_OtherSavingDeposit]
AS
	

		SELECT distinct Time_Idx,
				PARTICULARS,
				C.Tenors_Idx,
				[IRLOWER]=AVG([IRLOWER] * 100) over (partition by Time_Idx,Tenor),
				[IRUPPER] = AVG([IRUPPER]* 100) over (partition by Time_Idx,Tenor)
	
				FROM (

					select Time_Idx,'Other Savings Account' as PARTICULARS,
					CASE 
					WHEN ACCTCODE IN ('215102000000000011') THEN 'up to 1 Month'
					WHEN ACCTCODE IN ('215102000000000021') THEN 'over 1 months to 3 months'
					WHEN ACCTCODE IN ('215102000000000031') THEN 'over 6 months to 1 year'
					WHEN ACCTCODE IN ('215102000000000041') THEN 'over 6 months to 1 year'
					WHEN ACCTCODE IN ('215102000000000051') THEN 'over 1 year to 5 years'
					WHEN ACCTCODE IN ('215102000000000061') THEN 'over 5 years'
								END 
					as 'Tenor',BKCODE,
					[IRUPPER] = CAST([IRUPPER] as float(15)) ,
					[IRLOWER] = CAST([IRLOWER]as float(15))
					from [DES].[dbo].[Fact_ESLIG_ITR_IRLDWeekly] with (NOLOCK) where PART in ('Form 1 Peso Dep')
					) A  
					LEFT JOIN [DES].[dbo].[Dim_Bank] bank on CASE 
						WHEN BKCODE = '50010' THEN '5000010'
						WHEN BKCODE = '50020' THEN '5000020'
						WHEN BKCODE = '50030' THEN '5000030'
						ELSE BKCODE
					END  = bank.Bank_Code
					JOIN [dbo].[Dim_ITR_Tenors] C on A.Tenor = C.Tenors_Code
					where bank.Bank_Code <> 'Unk'  
					and Tenor is not  null
					and (ISNULL(IRLOWER,0) <  1 AND ISNULL(IRUPPER,0) <  1) --AND ISNULL(WAIR,0) <  1 AND ISNULL(EIRLOWER,0) < 1 AND ISNULL(EIRUPPER,0) < 1)
					 
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_WARR]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_WARR](
	[Time_Idx] [int] NOT NULL,
	[CURCDE] [numeric](15, 0) NULL,
	[TERMS] [numeric](15, 0) NOT NULL,
	[CURDESC] [char](20) NULL,
	[BankType_Idx] [int] NOT NULL,
	[SUMGRANT] [numeric](38, 2) NULL,
	[SUMINT] [numeric](38, 12) NULL,
	[WARR] [numeric](38, 6) NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_FACT_ESLIG_Table4A]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[vw_FACT_ESLIG_Table4A]
AS
		
		
		
			--BANGKO SENTRAL RATES

			SELECT Time_Idx,
			[Level1] = 'BSP Rates',
			[Level2] = CASE 
					WHEN Rate_Idx = '4' THEN 'Overnight Lending Facility (OLF)'
					WHEN Rate_Idx = '3' THEN 'Overnight Deposit Facility (ODF)'
					WHEN Rate_Idx = '5' THEN 'Overnight RRP Facility'
					
			END ,
			[Level3] = '',
			WAIR = [Value]  ,
			SORT = '1'
			 FROM [dbo].[Fact_ESLIG_ITR_TenorRates] where Rate_Idx in (3,4,5) and Tenor_Idx  in (4)

			 UNION

			 SELECT [Auction Date_Idx],
			[Level1] = 'BSP Rates',
			[Level2] = 'Term Deposit Facility (TDF)',
			[Level3] = B.Tenors_Code,
			WAIR = [Weighted average accepted yield]  ,
			SORT = '2'
			 FROM [dbo].[Fact_ESLIG_ITR_TDFAuctionResult]  A
			 LEFT JOIN [dbo].[Dim_ITR_Tenors] B on
			 A.Tenor_Idx = B.Tenors_Idx
			 where  A.Tenor_Idx  in (2,3,4)
		
			 UNION

			 SELECT Time_Idx,
			[Level1] = 'BSP Rates',
			[Level2] = 'Rediscounting by loan maturity',
			[Level3] = CASE 
				WHEN A.TERMS = '90' THEN '90 Days'
				WHEN A.TERMS = '180' THEN '180 Days'
			
			END,
			WAIR = WARR 
			 ,
			SORT = '3'
			 FROM [dbo].[Fact_ESLIG_ITR_WARR] A where A.TERMS IN (90,180)
			 
			
GO
/****** Object:  View [dbo].[vw_FACT_SWCP_METRICPOUND]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [dbo].[vw_FACT_SWCP_METRICPOUND]
AS

--	U.S DOLLAR PER TROY OUNCE
--U.S. CENT PER POUND
--U.S. DOLLAR PER METRIC TON
		SELECT * FROM (

		  -- SELECT [Time_Idx]
		  --,[CommodityType_Idx]
		  --,[SWCP_Type] = 'U.S DOLLAR PER TROY OUNCE'
		  --,[Value] 
		  --FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] where CommodityType_Idx in ('34')

		  --UNION ALL

		   SELECT  [Time_Idx]
		  ,[CommodityType_Idx]
		  ,[SWCP_Type] = 'U.S. CENT PER POUND'
		  ,[Value] = ([Value] / 2204.62262  * 100 )
		  FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] 


		  
		  UNION ALL
		   SELECT [Time_Idx]
		  ,[CommodityType_Idx]
		  ,[SWCP_Type] = 'U.S. DOLLAR PER METRIC TON' 
		  ,[Value] 
		  FROM [DES].[dbo].[Fact_ESLIG_SWCP_MonthlyPrice] 
		
		) A
GO
/****** Object:  View [dbo].[vw_BES_Dim_Seasonality]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[vw_BES_Dim_Seasonality]
AS



SELECT * FROM (
SELECT 
BES_Seasonality_Code = 'No of Q1'
,BES_Seasonality_Name = 'Up'
,BES_Seasonality_Label = 'Up'
,BES_Seasonality_Sort = 1

UNION 

SELECT BES_Seasonality_Code = 'No of Q1'
,BES_Seasonality_Name = 'Steady'
,BES_Seasonality_Label = 'Steady'
,BES_Seasonality_Sort = 2

UNION 

SELECT BES_Seasonality_Code = 'No of Q1'
,BES_Seasonality_Name = 'Down'
,BES_Seasonality_Label = 'Down'
,BES_Seasonality_Sort = 3

) A

UNION ALL

SELECT * FROM (


SELECT 
BES_Seasonality_Code = 'No of Q2'
,BES_Seasonality_Name = 'Up'
,BES_Seasonality_Label = 'Up'
,BES_Seasonality_Sort = 1

UNION 

SELECT BES_Seasonality_Code = 'No of Q2'
,BES_Seasonality_Name = 'Steady'
,BES_Seasonality_Label = 'Steady'
,BES_Seasonality_Sort = 2

UNION 

SELECT BES_Seasonality_Code = 'No of Q2'
,BES_Seasonality_Name = 'Down'
,BES_Seasonality_Label = 'Down'
,BES_Seasonality_Sort = 3
) A

UNION ALL

SELECT * FROM (


SELECT 
BES_Seasonality_Code = 'No of Q3'
,BES_Seasonality_Name = 'Up'
,BES_Seasonality_Label = 'Up'
,BES_Seasonality_Sort = 1

UNION 

SELECT BES_Seasonality_Code = 'No of Q3'
,BES_Seasonality_Name = 'Steady'
,BES_Seasonality_Label = 'Steady'
,BES_Seasonality_Sort = 2

UNION 

SELECT BES_Seasonality_Code = 'No of Q3'
,BES_Seasonality_Name = 'Down'
,BES_Seasonality_Label = 'Down'
,BES_Seasonality_Sort = 3
) A

UNION ALL

SELECT * FROM (


SELECT 
BES_Seasonality_Code = 'No of Q4'
,BES_Seasonality_Name = 'Up'
,BES_Seasonality_Label = 'Up'
,BES_Seasonality_Sort = 1

UNION 

SELECT BES_Seasonality_Code = 'No of Q4'
,BES_Seasonality_Name = 'Steady'
,BES_Seasonality_Label = 'Steady'
,BES_Seasonality_Sort = 2

UNION 

SELECT BES_Seasonality_Code = 'No of Q4'
,BES_Seasonality_Name = 'Down'
,BES_Seasonality_Label = 'Down'
,BES_Seasonality_Sort = 3
) A




GO
/****** Object:  View [dbo].[vw_NAT_ImpliedPPPConvertion]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[vw_NAT_ImpliedPPPConvertion]
AS
		SELECT DISTINCT
		[Date_Code] = ISNULL(A.[Date],'01-01-1890') ,
		[Value] =
		CASE 
			WHEN A.[Value] = '.' THEN '0.0' 
			WHEN ISNUMERIC(A.[Value]) = 1 THEN CONVERT(MONEY,LTRIM(RTRIM(A.[Value])))
			
		ELSE '0.0' 
		END
		FROM (
		
			SELECT  distinct 
			--CASE WHEN CHARINDEX('.', [Column1]) <> '0' THEN REPLACE([Column1],SUBSTRING([Column1],1, CHARINDEX('.', [Column1]) + 1),'') ELSE [Column1] END as [Type],
			[Column2] as [Implied PPP conversion rate],
			CASE 
            
			 
			 WHEN [Date] = 'Column6'  THEN (SELECT Column6 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 WHEN [Date] = 'Column7'  THEN (SELECT Column7 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 WHEN [Date] = 'Column8'  THEN (SELECT Column8 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 WHEN [Date] = 'Column9'  THEN (SELECT Column9 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 
			 WHEN [Date] = 'Column10'  THEN (SELECT Column10 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 WHEN [Date] = 'Column11'  THEN (SELECT Column11 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 WHEN [Date] = 'Column12'  THEN (SELECT Column12 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 WHEN [Date] = 'Column13'  THEN (SELECT Column13 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 
			 WHEN [Date] = 'Column14'  THEN (SELECT Column14 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 WHEN [Date] = 'Column15'  THEN (SELECT Column15 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 WHEN [Date] = 'Column16'  THEN (SELECT Column16 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			 WHEN [Date] = 'Column17'  THEN (SELECT Column17 + '-01-01' from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
			
					 
			 --WHEN [Date] = 'Column27'  THEN (SELECT Column27 from  [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where ID =1 )
            ELSE '1970'
            END  as [Date],
			[Value]
			FROM
			(
		
					select * from [DES_Staging].[dbo].[Dump_Fact_ESLIG_NatAcc_WEO] where [ID] = 2
	
		
			) p
			UNPIVOT
			(
			  [Value] for [Date] IN
			  (Column6,Column7,Column8,Column9,Column10,
				Column11,Column12,Column13,Column14,Column15)
			) AS upvt 

		) A where [Date] <> '1970' and ISDATE([Date]) = 1 and  ISNUMERIC([Value]) =1
				

	


GO
/****** Object:  View [dbo].[vw_NGCOR_Report]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [dbo].[vw_NGCOR_Report]
AS


WITH NGCOR AS  (
SELECT COR_Year,
SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Tax Revenues] AS int)) AS [Tax Revenues],
SUM(CAST([Non-tax Revenues] AS int)) AS [Non-tax Revenues],
SUM(CAST([Grants] AS int)) AS [Grants],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Interest Payments] AS int)) AS [Interest Payments],
SUM(CAST([Tax Expenditures] AS int)) AS [Tax Expenditures],
SUM(CAST([Equity] AS int)) AS [Equity],
SUM(CAST([Net Lending] AS int)) AS [Net Lending],
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
SUM(CAST([Financing] AS int)) AS [Financing],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)],
SUM(CAST([Less: Amortization] AS int)) AS [External Less: Amortization],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([Less: Net Amortization] AS int)) AS [Less: Net Amortization],
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash]
FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated
GROUP BY COR_Year
)

, withNGCORTotal AS (
SELECT a.COR_Year,
	CASE WHEN a.[Revenues] <> b.[Revenues] THEN b.[Revenues] ELSE a.[Revenues] END AS [Revenues]
,	CASE WHEN a.[Tax Revenues] <> b.[Tax Revenues] THEN b.[Tax Revenues] ELSE a.[Tax Revenues] END AS [Tax Revenues]
,	CASE WHEN a.[Non-tax Revenues] <> b.[Non-tax Revenues] THEN b.[Non-tax Revenues] ELSE a.[Non-tax Revenues] END AS [Non-tax Revenues]
,	CASE WHEN a.[Grants] <> b.[Grants] THEN b.[Grants] ELSE a.[Grants] END AS [Grants]
,	CASE WHEN a.[Expenditures] <> b.[Expenditures] THEN b.[Expenditures] ELSE a.[Expenditures] END AS [Expenditures]
,	CASE WHEN a.[Interest Payments] <> b.[Interest Payments] THEN b.[Interest Payments] ELSE a.[Interest Payments] END AS [Interest Payments]
,	CASE WHEN a.[Tax Expenditures] <> b.[Tax Expenditures] THEN b.[Tax Expenditures] ELSE a.[Tax Expenditures] END AS [Tax Expenditures]
,	CASE WHEN a.[Equity] <> b.[Equity] THEN b.[Equity] ELSE a.[Equity] END AS [Equity]
,	CASE WHEN a.[Net Lending] <> b.[Net Lending] THEN b.[Net Lending] ELSE a.[Net Lending] END AS [Net Lending]
,	CASE WHEN a.[Surplus/(-)Deficit] <> (b.[Surplus/(-)Deficit]) THEN b.[Surplus/(-)Deficit] ELSE a.[Surplus/(-)Deficit] END AS [Surplus/(-)Deficit]
,	CASE WHEN a.[Financing] <> b.[Financing] THEN b.[Financing] ELSE a.[Financing] END AS [Financing]
,	CASE WHEN a.[External (Net)] <> b.[External (Net)] THEN b.[External (Net)] ELSE a.[External (Net)] END AS [External (Net)]
,	CASE WHEN a.[External (Gross)] <> b.[External (Gross)] THEN b.[External (Gross)] ELSE a.[External (Gross)] END AS [External (Gross)]
,	CASE WHEN a.[External Less: Amortization] <> b.[External Less: Amortization] THEN b.[External Less: Amortization] ELSE a.[External Less: Amortization] END AS [Less: Amortization]
,	CASE WHEN a.[Domestic (Net)] <> b.[Domestic (Net)] THEN b.[Domestic (Net)] ELSE a.[Domestic (Net)] END AS [Domestic (Net)]
,	CASE WHEN a.[Domestic (Gross)] <> b.[Domestic (Gross)] THEN b.[Domestic (Gross)] ELSE a.[Domestic (Gross)] END AS [Domestic (Gross)]
,	CASE WHEN a.[Less: Net Amortization] <> b.[Less: Net Amortization] THEN b.[Less: Net Amortization] ELSE a.[Less: Net Amortization] END AS [Less: Net Amortization]
,	CASE WHEN a.[Change-In-Cash] <> b.[Change-In-Cash] THEN b.[Change-In-Cash] ELSE a.[Change-In-Cash] END AS [Change-In-Cash]
FROM NGCOR a 
LEFT JOIN  [DES_Staging].[dbo].[Dump_FFSD_NGCOR_TOTAL_Consolidated] b ON a.COR_Year = b.[COR_Year]
)

, DebtServices AS  (
SELECT DebtServices_Year,
SUM(CAST([Domestic] AS int)) AS [Domestic],
SUM(CAST([Foreign] AS int)) AS [Foreign]
FROM [DES_Staging].[dbo].[Dump_FFSD_NGCOR_DebtServices_Consolidated]
GROUP BY DebtServices_Year
)

SELECT 
  a.COR_Year AS [Year]
, DATEFROMPARTS (a.COR_Year, 1, 1) AS COR_Date
, PSNA.GDP AS [GDP]
, a.[Revenues] AS [Revenues]
, ((a.Revenues - b.[Revenues]) / CAST(b.[Revenues] AS FLOAT)) * 100 AS [Revenue Annual Growth Rate (%)]   --: [(Revenue T - Revenue T-1) / Revenue T-1 ] x 100
, a.[Tax Revenues]
, (a.[Tax Revenues] / PSNA.GDP) * 100 AS [Revenues % to GDP]  
, a.[Non-tax Revenues] +  a.[Grants] AS [Non-Tax including Grants]
, a.[Expenditures] 
, ((a.[Expenditures] - b.[Expenditures]) / CAST(b.[Expenditures] AS FLOAT)) * 100 AS [Expenditures Annual Growth Rate (%)]
, a.[Interest Payments]
, ds.[Domestic] AS [Domestic Interest Payments]
, ds.[Foreign] AS [Foreign Interest Payments]
, a.[Equity] + a.[Net Lending] AS [Net Lending & Equity]
, a.[Surplus/(-)Deficit]
, (a.[Surplus/(-)Deficit] / PSNA.GDP) * 100 AS [Surplus/(-)Deficit % to GDP)] 
, a.[Financing]
, a.[Domestic (Gross)] - a.[Less: Net Amortization] AS [Net Domestic Borrowings]
, a.[Domestic (Gross)]
, a.[Less: Net Amortization]
, a.[External (Net)]
, a.[External (Gross)]
, a.[Less: Amortization]
, a.[Change-In-Cash]

FROM withNGCORTotal a
INNER JOIN [DES_Staging].[dbo].Conso_FFSD_PSNA PSNA		ON PSNA.PSNA_Year		= a.COR_Year
INNER JOIN DebtServices ds								ON ds.DebtServices_Year = a.[COR_Year]
INNER JOIN NGCOR b										ON (a.[COR_Year] - 1 )	= b.COR_Year


GO
/****** Object:  View [dbo].[vw_NGCOR_Report_2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO








CREATE VIEW [dbo].[vw_NGCOR_Report_2]
AS


WITH NGCOR AS  (
SELECT COR_Year,
SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Tax Revenues] AS int)) AS [Tax Revenues],
SUM(CAST([Non-tax Revenues] AS int)) AS [Non-tax Revenues],
SUM(CAST([Grants] AS int)) AS [Grants],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Interest Payments] AS int)) AS [Interest Payments],
SUM(CAST([Tax Expenditures] AS int)) AS [Tax Expenditures],
SUM(CAST([Equity] AS int)) AS [Equity],
SUM(CAST([Net Lending] AS int)) AS [Net Lending],
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
SUM(CAST([Financing] AS int)) AS [Financing],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)],
SUM(CAST([Less: Amortization] AS int)) AS [External Less: Amortization],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([Less: Net Amortization] AS int)) AS [Less: Net Amortization],
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash]
FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated
GROUP BY COR_Year
)

, withNGCORTotal AS (
SELECT a.COR_Year,
	CASE WHEN a.[Revenues] <> b.[Revenues] THEN b.[Revenues] ELSE a.[Revenues] END AS [Revenues]
,	CASE WHEN a.[Tax Revenues] <> b.[Tax Revenues] THEN b.[Tax Revenues] ELSE a.[Tax Revenues] END AS [Tax Revenues]
,	CASE WHEN a.[Non-tax Revenues] <> b.[Non-tax Revenues] THEN b.[Non-tax Revenues] ELSE a.[Non-tax Revenues] END AS [Non-tax Revenues]
,	CASE WHEN a.[Grants] <> b.[Grants] THEN b.[Grants] ELSE a.[Grants] END AS [Grants]
,	CASE WHEN a.[Expenditures] <> b.[Expenditures] THEN b.[Expenditures] ELSE a.[Expenditures] END AS [Expenditures]
,	CASE WHEN a.[Interest Payments] <> b.[Interest Payments] THEN b.[Interest Payments] ELSE a.[Interest Payments] END AS [Interest Payments]
,	CASE WHEN a.[Tax Expenditures] <> b.[Tax Expenditures] THEN b.[Tax Expenditures] ELSE a.[Tax Expenditures] END AS [Tax Expenditures]
,	CASE WHEN a.[Equity] <> b.[Equity] THEN b.[Equity] ELSE a.[Equity] END AS [Equity]
,	CASE WHEN a.[Net Lending] <> b.[Net Lending] THEN b.[Net Lending] ELSE a.[Net Lending] END AS [Net Lending]
,	CASE WHEN a.[Surplus/(-)Deficit] <> (b.[Surplus/(-)Deficit]) THEN b.[Surplus/(-)Deficit] ELSE a.[Surplus/(-)Deficit] END AS [Surplus/(-)Deficit]
,	CASE WHEN a.[Financing] <> b.[Financing] THEN b.[Financing] ELSE a.[Financing] END AS [Financing]
,	CASE WHEN a.[External (Net)] <> b.[External (Net)] THEN b.[External (Net)] ELSE a.[External (Net)] END AS [External (Net)]
,	CASE WHEN a.[External (Gross)] <> b.[External (Gross)] THEN b.[External (Gross)] ELSE a.[External (Gross)] END AS [External (Gross)]
,	CASE WHEN a.[External Less: Amortization] <> b.[External Less: Amortization] THEN b.[External Less: Amortization] ELSE a.[External Less: Amortization] END AS [Less: Amortization]
,	CASE WHEN a.[Domestic (Net)] <> b.[Domestic (Net)] THEN b.[Domestic (Net)] ELSE a.[Domestic (Net)] END AS [Domestic (Net)]
,	CASE WHEN a.[Domestic (Gross)] <> b.[Domestic (Gross)] THEN b.[Domestic (Gross)] ELSE a.[Domestic (Gross)] END AS [Domestic (Gross)]
,	CASE WHEN a.[Less: Net Amortization] <> b.[Less: Net Amortization] THEN b.[Less: Net Amortization] ELSE a.[Less: Net Amortization] END AS [Less: Net Amortization]
,	CASE WHEN a.[Change-In-Cash] <> b.[Change-In-Cash] THEN b.[Change-In-Cash] ELSE a.[Change-In-Cash] END AS [Change-In-Cash]
FROM NGCOR a 
LEFT JOIN  [DES_Staging].[dbo].[Dump_FFSD_NGCOR_TOTAL_Consolidated] b ON a.COR_Year = b.[COR_Year]
)

, DebtServices AS  (
SELECT DebtServices_Year,
SUM(CAST([Domestic] AS int)) AS [Domestic],
SUM(CAST([Foreign] AS int)) AS [Foreign]
FROM [DES_Staging].[dbo].[Dump_FFSD_NGCOR_DebtServices_Consolidated]
GROUP BY DebtServices_Year
)

SELECT 
  a.COR_Year AS [Year]
, DATEFROMPARTS (a.COR_Year, 1, 1) AS COR_Date
, PSNA.GDP AS [GDP]
, a.[Revenues] AS [Revenues]
, ((a.Revenues - b.[Revenues]) / CAST(b.[Revenues] AS FLOAT)) * 100 AS [Revenue Annual Growth Rate (%)]   --: [(Revenue T - Revenue T-1) / Revenue T-1 ] x 100
, a.[Tax Revenues]
, (a.[Tax Revenues] / PSNA.GDP) * 100 AS [Revenues % to GDP]  
, a.[Non-tax Revenues] +  a.[Grants] AS [Non-Tax including Grants]
, a.[Expenditures] 
, ((a.[Expenditures] - b.[Expenditures]) / CAST(b.[Expenditures] AS FLOAT)) * 100 AS [Expenditures Annual Growth Rate (%)]
, a.[Interest Payments]
, ds.[Domestic] AS [Domestic Interest Payments]
, ds.[Foreign] AS [Foreign Interest Payments]
, a.[Equity] + a.[Net Lending] AS [Net Lending & Equity]
, a.[Surplus/(-)Deficit]
, (a.[Surplus/(-)Deficit] / PSNA.GDP) * 100 AS [Surplus/(-)Deficit % to GDP)] 
, a.[Financing]
, a.[Domestic (Gross)] - a.[Less: Net Amortization] AS [Net Domestic Borrowings]
, a.[Domestic (Gross)]
, a.[Less: Net Amortization]
, a.[External (Net)]
, a.[External (Gross)]
, a.[Less: Amortization]
, a.[Change-In-Cash]

FROM withNGCORTotal a
INNER JOIN [DES_Staging].[dbo].Conso_FFSD_PSNA PSNA		ON PSNA.PSNA_Year		= a.COR_Year
INNER JOIN DebtServices ds								ON ds.DebtServices_Year = a.[COR_Year]
INNER JOIN NGCOR b										ON (a.[COR_Year] - 1 )	= b.COR_Year


GO
/****** Object:  View [dbo].[vw_NGCOR_Report_YTD]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO








CREATE VIEW [dbo].[vw_NGCOR_Report_YTD]
AS


with maxMonth AS 
(
SELECT max(COR_Month) AS MaxMonth FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated
WHERE COR_Year = (SELECT max(COR_Year)  FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated)  AND [Revenues] <> 0
)

, PSNA_Qtr AS (
SELECT * FROM [DES_Staging].[dbo].[Conso_FFSD_PSNA_Quarterly]
WHERE PSNA_Year = (SELECT max(COR_Year)  FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated)  
AND PSNA_Month = (SELECT MaxMonth FROM maxmonth)

UNION

SELECT * FROM [DES_Staging].[dbo].[Conso_FFSD_PSNA_Quarterly]
WHERE PSNA_Year = (SELECT max(COR_Year) -1  FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated)  
AND PSNA_Month = (SELECT MaxMonth FROM maxmonth)

)
, NGCOR_YTD_format AS 
(
SELECT COR_Year, COR_Month, 
SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Tax Revenues] AS int)) AS [Tax Revenues],
SUM(CAST([Non-tax Revenues] AS int)) AS [Non-tax Revenues],
SUM(CAST([Grants] AS int)) AS [Grants],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Interest Payments] AS int)) AS [Interest Payments],
SUM(CAST([Tax Expenditures] AS int)) AS [Tax Expenditures],
SUM(CAST([Equity] AS int)) AS [Equity],
SUM(CAST([Net Lending] AS int)) AS [Net Lending],
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
SUM(CAST([Financing] AS int)) AS [Financing],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)],
SUM(CAST([Less: Amortization] AS int)) AS [Less: Amortization],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([Less: Net Amortization] AS int)) AS [Less: Net Amortization],
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash]
FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated
WHERE COR_Year = (SELECT max(COR_Year) FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated) AND [Revenues] <> 0
AND  CAST(COR_Month AS INT) <= (SELECT MaxMonth FROM maxMonth) 
GROUP BY COR_Year , COR_Month

UNION 

SELECT COR_Year, COR_Month, 
SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Tax Revenues] AS int)) AS [Tax Revenues],
SUM(CAST([Non-tax Revenues] AS int)) AS [Non-tax Revenues],
SUM(CAST([Grants] AS int)) AS [Grants],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Interest Payments] AS int)) AS [Interest Payments],
SUM(CAST([Tax Expenditures] AS int)) AS [Tax Expenditures],
SUM(CAST([Equity] AS int)) AS [Equity],
SUM(CAST([Net Lending] AS int)) AS [Net Lending],
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
SUM(CAST([Financing] AS int)) AS [Financing],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)],
SUM(CAST([Less: Amortization] AS int)) AS [Less: Amortization],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([Less: Net Amortization] AS int)) AS [Less: Net Amortization],
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash]
FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated
WHERE COR_Year = (SELECT max(COR_Year) - 1 FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated) AND [Revenues] <> 0
AND  CAST(COR_Month AS INT) <= (SELECT MaxMonth  FROM maxMonth) 
GROUP BY COR_Year , COR_Month

UNION 

SELECT COR_Year, COR_Month, 
SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Tax Revenues] AS int)) AS [Tax Revenues],
SUM(CAST([Non-tax Revenues] AS int)) AS [Non-tax Revenues],
SUM(CAST([Grants] AS int)) AS [Grants],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Interest Payments] AS int)) AS [Interest Payments],
SUM(CAST([Tax Expenditures] AS int)) AS [Tax Expenditures],
SUM(CAST([Equity] AS int)) AS [Equity],
SUM(CAST([Net Lending] AS int)) AS [Net Lending],
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
SUM(CAST([Financing] AS int)) AS [Financing],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)],
SUM(CAST([Less: Amortization] AS int)) AS [Less: Amortization],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([Less: Net Amortization] AS int)) AS [Less: Net Amortization],
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash]
FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated
WHERE COR_Year = (SELECT max(COR_Year) - 2 FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated) AND [Revenues] <> 0
AND  CAST(COR_Month AS INT) <= (SELECT MaxMonth  FROM maxMonth) 
GROUP BY COR_Year , COR_Month


)

--SELECT * FROM NGCOR_YTD_format


, DebtServices AS  (
SELECT 
DebtServices_Year, 
DebtServices_Month,
CAST([Foreign] AS INT ) AS [Foreign],
CAST([Domestic] AS INT ) AS [Domestic]
FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_DebtServices_Consolidated
WHERE DebtServices_Year = (SELECT max(DebtServices_Year) FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_DebtServices_Consolidated)
AND  CAST(DebtServices_Month AS int) <= (SELECT maxMonth FROM maxMonth)

UNION 

SELECT 
DebtServices_Year, 
DebtServices_Month,
CAST([Foreign] AS INT ) AS [Foreign],
CAST([Domestic] AS INT ) AS [Domestic]
FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_DebtServices_Consolidated
WHERE DebtServices_Year = (SELECT max(DebtServices_Year) - 1 FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_DebtServices_Consolidated)
AND  CAST(DebtServices_Month AS int) <= (SELECT maxMonth FROM maxMonth) 
)

--SELECT * FROM DebtServices

--SELECT 
--a.*
--, b.Domestic AS [Domestic Interest Payments]
--, b.[Foreign] AS [Foreign Interest Payments]
--FROM NGCOR_YTD_format a
--INNER JOIN DebtServices b ON a.[COR_Year] = b.DebtServices_Year AND a.[COR_Month] = b.DebtServices_Month

, main AS 
(SELECT 
a.COR_Year AS [COR_Year], 
--a.COR_Month AS [COR_Month],
SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Tax Revenues] AS int)) AS [Tax Revenues],
SUM(CAST([Non-tax Revenues] AS int)) AS [Non-tax Revenues],
SUM(CAST([Grants] AS int)) AS [Grants],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Interest Payments] AS int)) AS [Interest Payments],
SUM(CAST([Tax Expenditures] AS int)) AS [Tax Expenditures],
SUM(CAST([Equity] AS int)) AS [Equity],
SUM(CAST([Net Lending] AS int)) AS [Net Lending],
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
SUM(CAST([Financing] AS int)) AS [Financing],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)],
SUM(CAST([Less: Amortization] AS int)) AS [Less: Amortization],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([Less: Net Amortization] AS int)) AS [Less: Net Amortization],
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash],
SUM(CAST([Domestic] AS int)) AS [Domestic Interest Payments],
SUM(CAST([Foreign] AS int)) AS  [Foreign Interest Payments]
FROM NGCOR_YTD_format a
LEFT JOIN DebtServices b ON a.[COR_Year] = b.DebtServices_Year AND a.[COR_Month] = b.DebtServices_Month
GROUP BY a.COR_Year  --, a.[COR_Month]
)

--SELECT * FROM main


SELECT 
a.[COR_Year]
,  CASE		WHEN (SELECT maxMonth FROM maxMonth) = 1 THEN 'Jan-Jan' 
			WHEN (SELECT maxMonth FROM maxMonth) = 2 THEN 'Jan-Feb' 
			WHEN (SELECT maxMonth FROM maxMonth) = 3 THEN 'Jan-Mar'
			WHEN (SELECT maxMonth FROM maxMonth) = 4 THEN 'Jan-Apr'
    		WHEN (SELECT maxMonth FROM maxMonth) = 5 THEN 'Jan-May' 
			WHEN (SELECT maxMonth FROM maxMonth) = 6 THEN 'Jan-Jun' 
			WHEN (SELECT maxMonth FROM maxMonth) = 7 THEN 'Jan-Jul'
			WHEN (SELECT maxMonth FROM maxMonth) = 8 THEN 'Jan-Aug'
  			WHEN (SELECT maxMonth FROM maxMonth) = 9 THEN 'Jan-Sep' 
			WHEN (SELECT maxMonth FROM maxMonth) = 10 THEN 'Jan-Oct' 
			WHEN (SELECT maxMonth FROM maxMonth) = 11 THEN 'Jan-Nov'
			WHEN (SELECT maxMonth FROM maxMonth) = 12 THEN 'Jan-Dec'
	END AS [Month]
, DATEFROMPARTS (a.COR_Year, 1, 1) AS COR_Date
, PSNA.GDP AS [GDP]
, d.GDP AS GDP_Qtr
, a.[Revenues] AS [Revenues]
, ((a.Revenues - c.[Revenues]) / CAST(c.[Revenues] AS FLOAT)) * 100 AS [Revenue Annual Growth Rate (%)]   --: [(Revenue T - Revenue T-1) / Revenue T-1 ] x 100
, a.[Tax Revenues] 
, CASE WHEN (SELECT maxMonth FROM maxMonth) IN (3,6,9,12) THEN (a.[Tax Revenues] / d.GDP) * 100 ELSE '' END AS [Revenues % to GDP]   
, a.[Non-tax Revenues] +  a.[Grants] AS [Non-Tax including Grants]
, a.[Expenditures] 
, ((a.[Expenditures] - c.[Expenditures]) / CAST(c.[Expenditures] AS FLOAT)) * 100 AS [Expenditures Annual Growth Rate (%)]
, a.[Interest Payments]
, a.[Domestic Interest Payments]
, a.[Foreign Interest Payments]
, a.[Equity] + a.[Net Lending] AS [Net Lending & Equity]
, a.[Surplus/(-)Deficit]
, CASE WHEN (SELECT maxMonth FROM maxMonth) IN (3,6,9,12) THEN (a.[Surplus/(-)Deficit] / d.GDP) * 100  ELSE '' END AS  [Surplus/(-)Deficit % to GDP)]
, a.[Financing]
, a.[Domestic (Gross)] - a.[Less: Net Amortization] AS [Net Domestic Borrowings]
, a.[Domestic (Gross)]
, a.[Less: Net Amortization]
, a.[External (Net)]
, a.[External (Gross)]
, a.[Less: Amortization]
, a.[Change-In-Cash]

FROM main a 
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_PSNA PSNA		ON PSNA.PSNA_Year	= a.COR_Year
LEFT JOIN main c					ON (a.[COR_Year] - 1 )	= c.COR_Year
LEFT JOIN PSNA_Qtr d				ON d.PSNA_Year = a.COR_Year
WHERE a.COR_Year = (SELECT max(COR_Year) FROM main)  OR a.COR_Year =  (SELECT max(COR_Year) - 1 FROM main)

GO
/****** Object:  View [dbo].[vw_NGDEBTRATIOS_PSNA]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[vw_NGDEBTRATIOS_PSNA]
AS
with PSNA_layout1 AS (
SELECT TOP 1
	  'GDP'					AS [Item]
	--, CAST('16556651.0832259' as float)	AS [2017Q1]
	--, CAST('16556651.0832259' as float)	AS [2017Q2]
	--, CAST('16556651.0832259' as float)	AS [2017Q3]
	--, CAST('16556651.0832259' as float)	AS [2017Q4]

	--, CAST('18265190.2581617' as float)	AS [2018Q1]
	--, CAST('18265190.2581617' as float)	AS [2018Q2]
	--, CAST('18265190.2581617' as float)	AS [2018Q3]
	--, CAST('18265190.2581617' as float)	AS [2018Q4]

	, CAST('4426077.13953298' as float)	AS [2019Q1]
	, CAST('4865973.13838879' as float)	AS [2019Q2]
	, CAST('4725892.43295097' as float)	AS [2019Q3]
	, CAST('5499920.46080928' as float)	AS [2019Q4]

	, CAST('4445833.77620725' as float)	AS [2020Q1]
	, CAST('4134663.3846541' as float)	AS [2020Q2]
	, CAST('4202942.49362966' as float)	AS [2020Q3]
	, CAST('5155142.76969132' as float)	AS [2020Q4]

	, CAST('4363699.98884155' as float)	AS [2021Q1]
	, CAST('4758902.62927677' as float)	AS [2021Q2]
	, CAST('4597172.87949716' as float)	AS [2021Q3]
	, CAST('5667434.14611494' as float)	AS [2021Q4]

FROM [DES_Staging].[dbo].[Dump_FFSD_CPSFP]

UNION

SELECT TOP 1
	  'GNI'					AS [Item]
	, CAST('4921330.48649612' as float)	AS [2019Q1]
	, CAST('5349515.73239161' as float)	AS [2019Q2]
	, CAST('5226643.36757156' as float)	AS [2019Q3]
	, CAST('5974570.76634182' as float)	AS [2019Q4]

	, CAST('4899963.06047703' as float)	AS [2020Q1]
	, CAST('4506603.78929354' as float)	AS [2020Q2]
	, CAST('4544100.48173389' as float)	AS [2020Q3]
	, CAST('5369180.2195346' as float)	AS [2020Q4]

	, CAST('4478699.70705978' as float)	AS [2021Q1]
	, CAST('4929655.13714985' as float)	AS [2021Q2]
	, CAST('4772094.9134449' as float)	AS [2021Q3]
	, CAST('5922836.87908234' as float)	AS [2021Q4]
FROM [DES_Staging].[dbo].[Dump_FFSD_CPSFP]


)
, PSNA_layout2 AS (
SELECT   *
FROM  
(
  SELECT *
  FROM  PSNA_layout1 
) AS TableToPivot 
UNPIVOT  
(  
  Amount
  FOR  [PSNA_Year] IN (

  [2019Q1]
, [2019Q2]
, [2019Q3]
, [2019Q4]
, [2020Q1]
, [2020Q2]
, [2020Q3]
, [2020Q4]
, [2021Q1]
, [2021Q2]
, [2021Q3]
, [2021Q4]

)  
) AS PivotTable
)

, PSNA_layout3 AS (
SELECT 
	[Item]
, LEFT([PSNA_Year] , 4) AS [Year] 
, RIGHT([PSNA_Year],2) AS [Quarter]
, CASE	WHEN RIGHT([PSNA_Year],2) = 'Q1' THEN 3 
		WHEN RIGHT([PSNA_Year],2) = 'Q2' THEN 6
		WHEN RIGHT([PSNA_Year],2) = 'Q3' THEN 9
		WHEN RIGHT([PSNA_Year],2) = 'Q4' THEN 12
  END [Month]
,  [Amount] 
FROM PSNA_layout2
)

SELECT 
	DATEFROMPARTS ([Year], [Month], 1) AS NGOSDEBT_Date 
	, *
FROM PSNA_layout3
--WHERE [Item] = 'GDP'

GO
/****** Object:  View [dbo].[vw_SELFI_Report]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [dbo].[vw_SELFI_Report]
AS


with OSDEBT AS  (
SELECT 
NGOSDEBT_Year,
--CAST(ROUND(CAST([I. Domestic Debt] AS DECIMAL(18,2))) / 1000 , 0AS INT ) AS INT)  AS [I. Domestic Debt],
CAST([I. Domestic Debt] AS INT ) AS [I. Domestic Debt],
CAST([Domestic Loans] AS INT ) AS [Domestic Loans],
CAST([Domestic Direct] AS INT ) AS [Domestic Direct],
CAST([Domestic Agencies] AS INT ) AS [Domestic Agencies],
CAST([NG Other Domestic] AS INT ) AS [NG Other Domestic],
CAST([BSP Provisional Advances] AS INT ) AS [BSP Provisional Advances],
CAST([Short-term borrowing from BSP] AS INT ) AS [Short-term borrowing from BSP],
CAST([Domestic Relent] AS INT ) AS [Domestic Relent],
CAST([Domestic Assumed] AS INT ) AS [Domestic Assumed],
CAST([Domestic PNB] AS INT ) AS [Domestic PNB],
CAST([Domestic DBP] AS INT ) AS [Domestic DBP],
CAST([Domestic NPC/PNPP] AS INT ) AS [Domestic NPC/PNPP],
CAST([Domestic NDC] AS INT ) AS [Domestic NDC],
CAST([Debt Securities] AS INT ) AS [Debt Securities],
CAST([II. External Debt] AS INT ) AS [II. External Debt],
CAST([External Loans] AS INT ) AS [External Loans],
CAST([External Direct] AS INT ) AS [External Direct],
CAST([External Agencies] AS INT ) AS [External Agencies],
CAST([External Relent] AS INT ) AS [External Relent],
CAST([External Assumed] AS INT ) AS [External Assumed],
CAST([External PNB] AS INT ) AS [External PNB],
CAST([External DBP] AS INT ) AS [External DBP],
CAST([External NPC/PNPP] AS INT ) AS [External NPC/PNPP],
CAST([External NDC] AS INT ) AS [External NDC],
CAST([External PAL] AS INT ) AS [External PAL],
CAST([External Debt Securities] AS INT ) AS [External Debt Securities],
CAST([T O T A L] AS INT ) AS [T O T A L],
CAST([Forex Rate Used] AS INT)  AS [Forex Rate Used]
FROM [DES_Staging].[dbo].Conso_FFSD_NGOSDEBT 
WHERE [NGOSDEBT_Month] = 12
--GROUP BY NGOSDEBT_Year
)

, NGCOR AS  (
SELECT COR_Year,
--CAST(ROUND(SUM(CAST([Revenues] AS DECIMAL(18,2))) / 1000 , 0) AS INT)  AS [Revenues],
SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Tax Revenues] AS int)) AS [Tax Revenues],
SUM(CAST([BIR] AS int)) AS [BIR],
SUM(CAST([Documentary Stamp] AS int)) AS [Documentary Stamp],
SUM(CAST([BIR Tax Expenditures] AS int)) AS [BIR Tax Expenditures],
SUM(CAST([BOC] AS int)) AS [BOC],
SUM(CAST([BOC Tax Expenditures] AS int)) AS [BOC Tax Expenditures],
SUM(CAST([Other Offices] AS int)) AS [Other Offices],
SUM(CAST([Non-tax Revenues] AS int)) AS [Non-tax Revenues],
SUM(CAST([BTr Income] AS int)) AS [BTr Income],
SUM(CAST([Fees and Charges] AS int)) AS [Fees and Charges],
SUM(CAST([Privatization] AS int)) AS [Privatization],
SUM(CAST([Income from Malampaya] AS int)) AS [Income from Malampaya],
SUM(CAST([Other non-tax] AS int)) AS [Other non-tax],
SUM(CAST([Grants] AS int)) AS [Grants],
--CAST(ROUND(SUM(CAST([Expenditures] AS DECIMAL(18,2))) / 1000 , 0) AS INT)  AS [Expenditures],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Allotment to LGUs] AS int)) AS [Allotment to LGUs],
SUM(CAST([Interest Payments] AS int)) AS [Interest Payments],
SUM(CAST([Tax Expenditures] AS int)) AS [Tax Expenditures],
SUM(CAST([Subsidy] AS int)) AS [Subsidy ],
SUM(CAST([Equity] AS int)) AS [Equity],
SUM(CAST([Net Lending] AS int)) AS [Net Lending],
SUM(CAST([NG Disbursements] AS int)) AS [NG Disbursements ],
--CAST(ROUND(SUM(CAST([Surplus/(-)Deficit]  AS DECIMAL(18,2))) / 1000 , 0) AS INT)  AS [Surplus/(-)Deficit] ,
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
--CAST(ROUND(SUM(CAST([Financing] AS DECIMAL(18,2))) / 1000 , 0) AS INT)  AS [Financing] ,
SUM(CAST([Financing] AS int)) AS [Financing],
--CAST(ROUND(SUM(CAST([External (Net)] AS DECIMAL(18,2))) / 1000 , 0) AS INT)  AS [External (Net)],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)],
SUM(CAST([Less: Amortization] AS int)) AS [Less: Amortization],
--CAST(ROUND(SUM(CAST([Domestic (Net)] AS DECIMAL(18,2))) / 1000 , 0) AS INT)  AS [Domestic (Net)],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([Less: Net Amortization] AS int)) AS [Less: Net Amortization],
SUM(CAST([Amortization] AS int)) AS [Amortization],
SUM(CAST([of which: Redemption from BSF] AS int)) AS [of which: Redemption from BSF],
--CAST(ROUND(SUM(CAST([Change-In-Cash] AS DECIMAL(18,2))) / 1000 , 0) AS INT)  AS [Change-In-Cash]
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash]
FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated
--WHERE [COR_Year] <> ( SELECT [COR_Year] FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated WHERE [Revenues] = 0 OR [Revenues] IS NULL)
GROUP BY COR_Year
)

SELECT 
NGCOR.COR_Year AS [Year]
, PSNA.GDP AS [GDP]

, '' AS [I.  National Government (NG) Fiscal Position]
, CAST(ROUND(CAST([Revenues] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Revenues]
--, [Revenues]  AS [Revenues]
, ([Revenues] / PSNA.GDP) * 100 AS [Revenues % to GDP]  
, CAST(ROUND(CAST([Expenditures] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Expenditures] 
--, [Expenditures] AS [Expenditures]
, ([Expenditures] / PSNA.GDP) * 100 AS [Expenditures % to GDP] 
, CAST(ROUND(CAST([Surplus/(-)Deficit] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Surplus/(-)Deficit]
--, [Surplus/(-)Deficit] AS [Surplus/(-)Deficit]
, ([Surplus/(-)Deficit] / PSNA.GDP) * 100 AS [Surplus/(-)Deficit % to GDP)] 
, '' AS [Financing]
, CAST(ROUND(CAST([Financing] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Borrowings (Net)]
--, [Financing]  AS [Borrowings (Net)]
, CAST(ROUND(CAST([Domestic (Net)] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Domestic (Net)] 
, CAST([Domestic (Net)]  AS float) / ABS([Surplus/(-)Deficit])  * 100 AS [Domestic % to total NG Deficit]    
, CAST(ROUND(CAST([External (Net)] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [External (Net)]
--, [External (Net)]  AS [External (Net)]
, CAST([External (Net)] AS FLOAT) / ABS([Surplus/(-)Deficit]) * 100 AS [External % to total NG Deficit]							
, CAST(ROUND(CAST([Change-In-Cash] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Change in Cash]
--, [Change-In-Cash]  AS [Change in Cash]
, (CAST([Change-In-Cash] AS FLOAT) / ABS([Surplus/(-)Deficit])) * 100 AS [Change in Cash % to total NG Deficit]		

, '' AS [Financing Mix]
, CAST([Domestic (Gross)] AS FLOAT) / ([Domestic (Gross)] + [External (Gross)]) * 100 AS [Financing Mix: Domestic]   
, CAST([External (Gross)] AS FLOAT) / ([Domestic (Gross)] + [External (Gross)]) * 100 AS [Financing Mix: External]
, '' AS [II. Consolidated Public Sector Financial Position (CPSFP)]
, CPSFP.[TOTAL SURPLUS+/DEFICIT-] AS [CPSFP SurplusDeficit]
, CPSFP.[TOTAL SURPLUS+/DEFICIT-] / PSNA.GDP * 100000  AS [CPSFP % to GDP]
--, CAST(ROUND(CAST(CPSFP.[TOTAL SURPLUS+/DEFICIT-] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [CPSFP SurplusDeficit]
--, CPSFP.[TOTAL SURPLUS+/DEFICIT-] AS [CPSFP SurplusDeficit]
--, (CAST(CPSFP.[TOTAL SURPLUS+/DEFICIT-] AS FLOAT) / PSNA.GDP) * 1000 AS [CPSFP % to GDP]

, '' AS [III. Outstanding Debt of the National Government]
,CAST(ROUND(CAST([T O T A L] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OS Total Debt]
--, [T O T A L] / 1000  AS [OS Total Debt]
, (CAST([T O T A L] AS FLOAT) / PSNA.GDP) * 100 AS [OS Total Debt % to GDP]
,CAST(ROUND(CAST([I. Domestic Debt]  AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OS Domestic Debt]
--, [I. Domestic Debt]  AS [OS Domestic Debt]
, ([I. Domestic Debt] / PSNA.GDP) * 100 AS [OS Domestic Debt % to GDP]
,CAST(ROUND(CAST([II. External Debt] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OS External Debt]
--, [II. External Debt] / 1000  AS [OS External Debt]
, (CAST([II. External Debt] AS FLOAT) / PSNA.GDP) * 100 AS [OS External Debt % to GDP]

, '' AS [IV. Outstanding Public Sector Debt]
, (CAST(OPSD.[Consolidated Public Sector] AS FLOAT) / PSNA.GDP) * 100 AS [OPSD Total Debt % to GDP]
, CAST(OPSD.[Consolidated Public Sector] AS FLOAT) AS [OPSD Total Debt]
, CAST(OPSD.[Consolidated Public Sector Domestic] AS FLOAT) AS [OPSD Domestic Debt]
--,CAST(ROUND(CAST(OPSD.[Domestic] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OPSD Domestic Debt % to GDP] 
, (CAST(OPSD.[Consolidated Public Sector Domestic] AS FLOAT) / PSNA.GDP) * 100000  AS [OPSD Domestic Debt % to GDP] 
, CAST(OPSD.[Consolidated Public Sector Foreign] AS FLOAT) AS [OPSD Foreign Debt]
--,CAST(ROUND(CAST(OPSD.[Foreign] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OPSD Foreign Debt % to GDP]
, ROUND((CAST(OPSD.[Consolidated Public Sector Foreign] AS FLOAT) / CAST(PSNA.GDP AS FLOAT)) * 100000, 0) AS [OPSD Foreign Debt % to GDP]

, '' AS [Memorandum Item]
, CAST(PEB.[Public] AS FLOAT) AS [Public Sector External Debt]
, (CAST(PEB.[Public] AS FLOAT) / PEB.[Gross Domestic Product (GDP)])  * 100 AS [Public Sector External Debt % to GDP]


FROM NGCOR
LEFT JOIN OSDEBT											ON NGCOR.COR_Year			= OSDEBT.NGOSDEBT_Year
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_OPSD OPSD  		ON OPSD.OPSD_Year			= NGCOR.COR_Year
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_CPSFP CPSFP		ON CPSFP.CPSFP_Year			= NGCOR.COR_Year
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_PSNA PSNA			ON PSNA.PSNA_Year			= NGCOR.COR_Year
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_PublicExtDebt PEB	ON PEB.PublicExtDebt_Year	= NGCOR.COR_Year




GO
/****** Object:  View [dbo].[vw_SELFI_YTD]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[vw_SELFI_YTD]
AS


with OSDEBT_YTD_format AS 
(
SELECT COR_Year, COR_Month,

SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
SUM(CAST([Financing] AS int)) AS [Financing],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)]
FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated
WHERE COR_Year = (SELECT max(COR_Year) FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated) AND [Revenues] <> 0
--AND  COR_Month = (SELECT max(COR_Month) FROM [DES_Staging].[dbo].Conso_FFSD_NGCOR) 
GROUP BY COR_Year , COR_Month

UNION 

SELECT COR_Year, COR_Month,
SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
SUM(CAST([Financing] AS int)) AS [Financing],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)]

FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated
WHERE COR_Year = (SELECT max(COR_Year) - 1 FROM [DES_Staging].[dbo].Dump_FFSD_NGCOR_Consolidated) AND [Revenues] <> 0
--AND  COR_Month = (SELECT max(COR_Month) FROM [DES_Staging].[dbo].Conso_FFSD_NGCOR) 
GROUP BY COR_Year , COR_Month
)

, maxMonth AS 
(
SELECT max(COR_Month) AS MaxMonth FROM OSDEBT_YTD_format
WHERE COR_Year = (SELECT max(COR_Year)  FROM OSDEBT_YTD_format)
)

, layout1 AS (
SELECT 
  a.COR_Year
, a.COR_Month
, a.[Revenues]
, a.Expenditures
, a.[Surplus/(-)Deficit]
, a.Financing
, a.[Domestic (Net)]
, a.[External (Net)]
, a.[Change-In-Cash]
, a.[Domestic (Gross)]
, a.[External (Gross)]
--, a.Expenditures
--, SUM(CAST(a.[Revenues] AS int)) AS [Revenues]
FROM OSDEBT_YTD_format a 
WHERE CAST(a.COR_Month AS int) <= (SELECT maxMonth FROM maxMonth)
--GROUP BY a.COR_Year, a.COR_Month 
)

, main AS (
SELECT --* FROM main
  a.COR_Year AS [Year]
, SUM(CAST(a.[Revenues] AS int)) AS [Revenues]
, SUM(CAST(a.[Expenditures] AS int)) AS [Expenditures]
, SUM(CAST(a.[Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit]
, SUM(CAST(a.[Financing] AS int)) AS [Borrowings (Net)]
, SUM(CAST(a.[Domestic (Net)] AS int)) AS [Domestic (Net)]
, SUM(CAST(a.[External (Net)] AS int)) AS [External (Net)]
, SUM(CAST(a.[Change-In-Cash] AS int)) AS [Change-In-Cash]
, SUM(CAST(a.[Domestic (Gross)] AS int)) AS [Domestic (Gross)]
, SUM(CAST(a.[External (Gross)] AS int)) AS [External (Gross)]
FROM layout1 a 
GROUP BY a.COR_Year 
)


, OSDEBT AS  (
SELECT 
NGOSDEBT_Year, NGOSDEBT_Month,
CAST([I. Domestic Debt] AS INT ) AS [I. Domestic Debt],
CAST([II. External Debt] AS INT ) AS [II. External Debt],
CAST([T O T A L] AS INT ) AS [T O T A L]
FROM [DES_Staging].[dbo].Conso_FFSD_NGOSDEBT 
INNER JOIN main ON NGOSDEBT_Year = main.[Year]	
WHERE CAST(NGOSDEBT_Month AS int)  = (SELECT maxMonth FROM maxMonth)
)

SELECT
  main.[Year]
,  CASE		WHEN OSDEBT.NGOSDEBT_Month = 1 THEN 'Jan-Jan' 
			WHEN OSDEBT.NGOSDEBT_Month = 2 THEN 'Jan-Feb' 
			WHEN OSDEBT.NGOSDEBT_Month = 3 THEN 'Jan-Mar'
			WHEN OSDEBT.NGOSDEBT_Month = 4 THEN 'Jan-Apr'
    		WHEN OSDEBT.NGOSDEBT_Month = 5 THEN 'Jan-May' 
			WHEN OSDEBT.NGOSDEBT_Month = 6 THEN 'Jan-Jun' 
			WHEN OSDEBT.NGOSDEBT_Month = 7 THEN 'Jan-Jul'
			WHEN OSDEBT.NGOSDEBT_Month = 8 THEN 'Jan-Aug'
  			WHEN OSDEBT.NGOSDEBT_Month = 9 THEN 'Jan-Sep' 
			WHEN OSDEBT.NGOSDEBT_Month = 10 THEN 'Jan-Oct' 
			WHEN OSDEBT.NGOSDEBT_Month = 11 THEN 'Jan-Nov'
			WHEN OSDEBT.NGOSDEBT_Month = 12 THEN 'Jan-Dec'
	END AS [Month]
, '' AS [I.  National Government (NG) Fiscal Position]
, CAST(ROUND(CAST(main.[Revenues] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Revenues]
, '' AS [Revenues % to GDP]
, CAST(ROUND(CAST(main.[Expenditures] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Expenditures] 
, '' AS [Expenditures % to GDP]
, CAST(ROUND(CAST(main.[Surplus/(-)Deficit] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Surplus/(-)Deficit]
, '' AS [Surplus/(-)Deficit % to GDP)]
, '' AS [Financing]
, CAST(ROUND(CAST(main.[Borrowings (Net)] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Borrowings (Net)]
, CAST(ROUND(CAST(main.[Domestic (Net)] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Domestic (Net)] 
, CAST(main.[Domestic (Net)]  AS float) / ABS(main.[Surplus/(-)Deficit]) * 100 AS [Domestic % to total NG Deficit]   
, CAST(ROUND(CAST(main.[External (Net)] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [External (Net)]
, CAST(main.[External (Net)] AS FLOAT) / ABS(main.[Surplus/(-)Deficit]) * 100 AS [External % to total NG Deficit]		
, CAST(ROUND(CAST(main.[Change-In-Cash] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Change in Cash]
, (CAST([Change-In-Cash] AS FLOAT) / ABS(main.[Surplus/(-)Deficit])) * 100 AS [Change in Cash % to total NG Deficit]		
, '' AS [Financing Mix]
, CAST([Domestic (Gross)] AS FLOAT) / ([Domestic (Gross)] + [External (Gross)]) * 100 AS [Financing Mix: Domestic]   
, CAST([External (Gross)] AS FLOAT) / ([Domestic (Gross)] + [External (Gross)]) * 100 AS [Financing Mix: External]
, '' AS [II. Consolidated Public Sector Financial Position (CPSFP)]
, CPSFP.[CPSFP SurplusDeficit]
, CPSFP.[CPSFP % to GDP]
--, CAST(ROUND(CAST(CPSFP.[TOTAL SURPLUS+/DEFICIT-] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [CPSFP SurplusDeficit]
--, (CAST(CPSFP.[TOTAL SURPLUS+/DEFICIT-] AS FLOAT) / PSNA.GDP) * 1000 AS [CPSFP % to GDP]
, '' AS [III. Outstanding Debt of the National Government]
, CAST(ROUND(CAST([T O T A L] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OS Total Debt]
, '' AS [OS Total Debt % to GDP]
, CAST(ROUND(CAST([I. Domestic Debt]  AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OS Domestic Debt]
, '' AS [OS Domestic Debt % to GDP]
, CAST(ROUND(CAST([II. External Debt] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OS External Debt]
, '' AS [OS External Debt % to GDP]
, '' AS [IV. Outstanding Public Sector Debt]
, '' AS [OPSD Total Debt % to GDP]
, '' AS [OPSD Total Debt]
, '' AS [OPSD Domestic Debt]
, '' AS [OPSD Domestic Debt % to GDP]
, '' AS [OPSD Foreign Debt]
, '' AS [OPSD Foreign Debt % to GDP]
, '' AS [Memorandum Item]
, '' AS [Public Sector External Debt]
, '' AS [Public Sector External Debt % to GDP]
FROM main
INNER JOIN OSDEBT											ON main.[Year]			= OSDEBT.NGOSDEBT_Year --AND main.COR_Month = OSDEBT.NGOSDEBT_Month
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_OPSD OPSD  		ON OPSD.OPSD_Year			= main.[Year]	
LEFT JOIN [DES_Staging].[dbo].vw_NGDEBT_CPSFP_Quarter CPSFP	ON CPSFP.[Year]				= main.[Year]	
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_PSNA PSNA			ON PSNA.PSNA_Year			= main.[Year]	
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_PublicExtDebt PEB	ON PEB.PublicExtDebt_Year	= main.[Year]	


UNION

SELECT
[Year], [Month]
, '' AS [I.  National Government (NG) Fiscal Position]
, NULL AS [Revenues]
, NULL AS [Revenues % to GDP]
, NULL AS [Expenditures] 
, NULL AS [Expenditures % to GDP]
, NULL AS [Surplus/(-)Deficit]
, NULL AS [Surplus/(-)Deficit % to GDP)]
, NULL AS [Financing]
, NULL AS [Borrowings (Net)]
, NULL AS [Domestic (Net)] 
, NULL AS [Domestic % to total NG Deficit]   
, NULL AS [External (Net)]
, NULL AS [External % to total NG Deficit]		
, NULL AS [Change in Cash]
, NULL AS [Change in Cash % to total NG Deficit]		
, NULL AS [Financing Mix]
, NULL AS [Financing Mix: Domestic]   
, NULL AS [Financing Mix: External]
, '' AS [II. Consolidated Public Sector Financial Position (CPSFP)]
, [CPSFP SurplusDeficit]
, [CPSFP % to GDP]
, '' AS [III. Outstanding Debt of the National Government]
, NULL AS [OS Total Debt]
, NULL AS [OS Total Debt % to GDP]
, NULL AS [OS Domestic Debt]
, NULL AS [OS Domestic Debt % to GDP]
, NULL AS [OS External Debt]
, NULL AS [OS External Debt % to GDP]
, ''   AS [IV. Outstanding Public Sector Debt]
, NULL AS [OPSD Total Debt % to GDP]
, NULL AS [OPSD Total Debt]
, NULL AS [OPSD Domestic Debt]
, NULL AS [OPSD Domestic Debt % to GDP]
, NULL AS [OPSD Foreign Debt]
, NULL AS [OPSD Foreign Debt % to GDP]
, '' AS [Memorandum Item]
, NULL AS [Public Sector External Debt]
, NULL AS [Public Sector External Debt % to GDP]
FROM [DES_STAGING].[dbo].vw_NGDEBT_CPSFP_Quarter


GO
/****** Object:  View [dbo].[vw_SELFI_YTD_2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [dbo].[vw_SELFI_YTD_2]
AS


with OSDEBT_YTD_format AS 
(
SELECT COR_Year, CAST(COR_Month As int) AS COR_Month,

SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
SUM(CAST([Financing] AS int)) AS [Financing],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)]
FROM [DES_Staging].[dbo].Conso_FFSD_NGCOR
WHERE COR_Year = (SELECT max(COR_Year) FROM [DES_Staging].[dbo].Conso_FFSD_NGCOR) AND [Revenues] <> 0
--AND  COR_Month = (SELECT max(COR_Month) FROM [DES_Staging].[dbo].Conso_FFSD_NGCOR) 
GROUP BY COR_Year , COR_Month

UNION 

SELECT COR_Year, COR_Month,
SUM(CAST([Revenues] AS int)) AS [Revenues],
SUM(CAST([Expenditures] AS int)) AS [Expenditures],
SUM(CAST([Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit],
SUM(CAST([Financing] AS int)) AS [Financing],
SUM(CAST([Domestic (Net)] AS int)) AS [Domestic (Net)],
SUM(CAST([External (Net)] AS int)) AS [External (Net)],
SUM(CAST([Change-In-Cash] AS int)) AS [Change-In-Cash],
SUM(CAST([Domestic (Gross)] AS int)) AS [Domestic (Gross)],
SUM(CAST([External (Gross)] AS int)) AS [External (Gross)]

FROM [DES_Staging].[dbo].Conso_FFSD_NGCOR
WHERE COR_Year = (SELECT max(COR_Year) - 1 FROM [DES_Staging].[dbo].Conso_FFSD_NGCOR) AND [Revenues] <> 0
--AND  COR_Month = (SELECT max(COR_Month) FROM [DES_Staging].[dbo].Conso_FFSD_NGCOR) 
GROUP BY COR_Year , COR_Month
)

, maxMonth AS 
(
SELECT max(COR_Month) AS MaxMonth FROM OSDEBT_YTD_format
WHERE COR_Year = (SELECT max(COR_Year)  FROM OSDEBT_YTD_format)
)

, layout1 AS (
SELECT 
  a.COR_Year
, a.COR_Month
, a.[Revenues]
, a.Expenditures
, a.[Surplus/(-)Deficit]
, a.Financing
, a.[Domestic (Net)]
, a.[External (Net)]
, a.[Change-In-Cash]
, a.[Domestic (Gross)]
, a.[External (Gross)]
--, a.Expenditures
--, SUM(CAST(a.[Revenues] AS int)) AS [Revenues]
FROM OSDEBT_YTD_format a 
WHERE CAST(a.COR_Month AS int) <= (SELECT maxMonth FROM maxMonth)
--GROUP BY a.COR_Year, a.COR_Month 
)

, main AS (
SELECT --* FROM main
  a.COR_Year AS [Year]
, SUM(CAST(a.[Revenues] AS int)) AS [Revenues]
, SUM(CAST(a.[Expenditures] AS int)) AS [Expenditures]
, SUM(CAST(a.[Surplus/(-)Deficit] AS int)) AS [Surplus/(-)Deficit]
, SUM(CAST(a.[Financing] AS int)) AS [Borrowings (Net)]
, SUM(CAST(a.[Domestic (Net)] AS int)) AS [Domestic (Net)]
, SUM(CAST(a.[External (Net)] AS int)) AS [External (Net)]
, SUM(CAST(a.[Change-In-Cash] AS int)) AS [Change-In-Cash]
, SUM(CAST(a.[Domestic (Gross)] AS int)) AS [Domestic (Gross)]
, SUM(CAST(a.[External (Gross)] AS int)) AS [External (Gross)]
FROM layout1 a 
GROUP BY a.COR_Year 
)


, OSDEBT AS  (
SELECT 
NGOSDEBT_Year, NGOSDEBT_Month,
CAST([I. Domestic Debt] AS INT ) AS [I. Domestic Debt],
CAST([II. External Debt] AS INT ) AS [II. External Debt],
CAST([T O T A L] AS INT ) AS [T O T A L]
, CASE	WHEN NGOSDEBT_Month = 4 OR NGOSDEBT_Month = 5 THEN 3 
		WHEN NGOSDEBT_Month = 7 OR NGOSDEBT_Month = 8  THEN 6
		WHEN NGOSDEBT_Month = 10 OR NGOSDEBT_Month = 11  THEN 9
		END AS NearestQuarter
FROM [DES_Staging].[dbo].Conso_FFSD_NGOSDEBT 
INNER JOIN main ON NGOSDEBT_Year = main.[Year]
WHERE CAST(NGOSDEBT_Month AS int)  = (SELECT maxMonth FROM maxMonth)
)


, QuarterGDP AS (
SELECT a.*, GDP_Q.GDP AS QuarterGDP
FROM OSDEBT a
INNER JOIN [DES_Staging].[dbo].[Conso_FFSD_PSNA_Quarterly] GDP_Q ON GDP_Q.PSNA_Year = NGOSDEBT_Year AND GDP_Q.PSNA_Month = a.NearestQuarter
)


--SELECT * FROM QuarterGDP

SELECT
  main.[Year]
,  CASE		WHEN QuarterGDP.NGOSDEBT_Month = 1 THEN 'Jan-Jan' 
			WHEN QuarterGDP.NGOSDEBT_Month = 2 THEN 'Jan-Feb' 
			WHEN QuarterGDP.NGOSDEBT_Month = 3 THEN 'Jan-Mar'
			WHEN QuarterGDP.NGOSDEBT_Month = 4 THEN 'Jan-Apr'
    		WHEN QuarterGDP.NGOSDEBT_Month = 5 THEN 'Jan-May' 
			WHEN QuarterGDP.NGOSDEBT_Month = 6 THEN 'Jan-Jun' 
			WHEN QuarterGDP.NGOSDEBT_Month = 7 THEN 'Jan-Jul'
			WHEN QuarterGDP.NGOSDEBT_Month = 8 THEN 'Jan-Aug'
  			WHEN QuarterGDP.NGOSDEBT_Month = 9 THEN 'Jan-Sep' 
			WHEN QuarterGDP.NGOSDEBT_Month = 10 THEN 'Jan-Oct' 
			WHEN QuarterGDP.NGOSDEBT_Month = 11 THEN 'Jan-Nov'
			WHEN QuarterGDP.NGOSDEBT_Month = 12 THEN 'Jan-Dec'
	END AS [Month]
, '' AS [I.  National Government (NG) Fiscal Position]
, CAST(ROUND(CAST(main.[Revenues] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Revenues]
, CAST(main.[Revenues] AS DECIMAL(18,2)) / QuarterGDP.QuarterGDP  AS [Revenues % to GDP]
, CAST(ROUND(CAST(main.[Expenditures] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Expenditures] 
, CAST(main.[Expenditures] AS DECIMAL(18,2)) / QuarterGDP.QuarterGDP AS [Expenditures % to GDP]
, CAST(ROUND(CAST(main.[Surplus/(-)Deficit] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Surplus/(-)Deficit]
, CAST(main.[Surplus/(-)Deficit] AS DECIMAL(18,2)) / QuarterGDP.QuarterGDP AS [Surplus/(-)Deficit % to GDP)]
, '' AS [Financing]
, CAST(ROUND(CAST(main.[Borrowings (Net)] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Borrowings (Net)]
, CAST(ROUND(CAST(main.[Domestic (Net)] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Domestic (Net)] 
, CAST(main.[Domestic (Net)]  AS float) / ABS(main.[Surplus/(-)Deficit]) * 100 AS [Domestic % to total NG Deficit]   
, CAST(ROUND(CAST(main.[External (Net)] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [External (Net)]
, CAST(main.[External (Net)] AS FLOAT) / ABS(main.[Surplus/(-)Deficit]) * 100 AS [External % to total NG Deficit]		
, CAST(ROUND(CAST(main.[Change-In-Cash] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [Change in Cash]
, (CAST([Change-In-Cash] AS FLOAT) / ABS(main.[Surplus/(-)Deficit])) * 100 AS [Change in Cash % to total NG Deficit]		
, '' AS [Financing Mix]
, CAST([Domestic (Gross)] AS FLOAT) / ([Domestic (Gross)] + [External (Gross)]) * 100 AS [Financing Mix: Domestic]   
, CAST([External (Gross)] AS FLOAT) / ([Domestic (Gross)] + [External (Gross)]) * 100 AS [Financing Mix: External]
, '' AS [II. Consolidated Public Sector Financial Position (CPSFP)]
, CPSFP.[CPSFP SurplusDeficit]
, CPSFP.[CPSFP % to GDP]
--, CAST(ROUND(CAST(CPSFP.[TOTAL SURPLUS+/DEFICIT-] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [CPSFP SurplusDeficit]
--, (CAST(CPSFP.[TOTAL SURPLUS+/DEFICIT-] AS FLOAT) / PSNA.GDP) * 1000 AS [CPSFP % to GDP]
, '' AS [III. Outstanding Debt of the National Government]
, CAST(ROUND(CAST([T O T A L] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OS Total Debt]
, '' AS [OS Total Debt % to GDP]
, CAST(ROUND(CAST([I. Domestic Debt]  AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OS Domestic Debt]
, '' AS [OS Domestic Debt % to GDP]
, CAST(ROUND(CAST([II. External Debt] AS DECIMAL(18,2)) / 1000, 0) AS INT) AS [OS External Debt]
, '' AS [OS External Debt % to GDP]
, '' AS [IV. Outstanding Public Sector Debt]
, '' AS [OPSD Total Debt % to GDP]
, '' AS [OPSD Total Debt]
, '' AS [OPSD Domestic Debt]
, '' AS [OPSD Domestic Debt % to GDP]
, '' AS [OPSD Foreign Debt]
, '' AS [OPSD Foreign Debt % to GDP]
, '' AS [Memorandum Item]
, '' AS [Public Sector External Debt]
, '' AS [Public Sector External Debt % to GDP]
FROM main
INNER JOIN QuarterGDP										ON main.[Year]				= QuarterGDP.NGOSDEBT_Year --AND main.COR_Month = OSDEBT.NGOSDEBT_Month
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_OPSD OPSD  		ON OPSD.OPSD_Year			= main.[Year]	
LEFT JOIN [DES_Staging].[dbo].vw_NGDEBT_CPSFP_Quarter CPSFP	ON CPSFP.[Year]				= main.[Year]	
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_PSNA PSNA			ON PSNA.PSNA_Year			= main.[Year]	
LEFT JOIN [DES_Staging].[dbo].Conso_FFSD_PublicExtDebt PEB	ON PEB.PublicExtDebt_Year	= main.[Year]	


UNION

SELECT
[Year], [Month]
, '' AS [I.  National Government (NG) Fiscal Position]
, NULL AS [Revenues]
, NULL AS [Revenues % to GDP]
, NULL AS [Expenditures] 
, NULL AS [Expenditures % to GDP]
, NULL AS [Surplus/(-)Deficit]
, NULL AS [Surplus/(-)Deficit % to GDP)]
, NULL AS [Financing]
, NULL AS [Borrowings (Net)]
, NULL AS [Domestic (Net)] 
, NULL AS [Domestic % to total NG Deficit]   
, NULL AS [External (Net)]
, NULL AS [External % to total NG Deficit]		
, NULL AS [Change in Cash]
, NULL AS [Change in Cash % to total NG Deficit]		
, NULL AS [Financing Mix]
, NULL AS [Financing Mix: Domestic]   
, NULL AS [Financing Mix: External]
, '' AS [II. Consolidated Public Sector Financial Position (CPSFP)]
, [CPSFP SurplusDeficit]
, [CPSFP % to GDP]
, '' AS [III. Outstanding Debt of the National Government]
, NULL AS [OS Total Debt]
, NULL AS [OS Total Debt % to GDP]
, NULL AS [OS Domestic Debt]
, NULL AS [OS Domestic Debt % to GDP]
, NULL AS [OS External Debt]
, NULL AS [OS External Debt % to GDP]
, ''   AS [IV. Outstanding Public Sector Debt]
, NULL AS [OPSD Total Debt % to GDP]
, NULL AS [OPSD Total Debt]
, NULL AS [OPSD Domestic Debt]
, NULL AS [OPSD Domestic Debt % to GDP]
, NULL AS [OPSD Foreign Debt]
, NULL AS [OPSD Foreign Debt % to GDP]
, '' AS [Memorandum Item]
, NULL AS [Public Sector External Debt]
, NULL AS [Public Sector External Debt % to GDP]
FROM [DES_STAGING].[dbo].vw_NGDEBT_CPSFP_Quarter


GO
/****** Object:  View [dbo].[XXX_vw_CPSFP]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[XXX_vw_CPSFP]
AS
WITH CPSFP_newList AS (
SELECT
	ID
, Column1 AS TitleName
, Column2
FROM    [DES_Staging].[dbo].[Dump_FFSD_SELFI_CPSFP]
WHERE  Column1 = 'TOTAL SURPLUS+/DEFICIT-'
)

, CPSFP_layout1 AS (
  SELECT  [ID]
  ,  (SELECT Column2 FROM [DES_Staging].[dbo].[Dump_FFSD_SELFI_CPSFP] WHERE [ID] = 3) AS [CPSFP_Year]
  , [TitleName]
  , CAST ([Column2] AS float) AS 'Amount'
  FROM CPSFP_newList
)


, main AS (
SELECT [TitleName], [CPSFP_Year] , sum(Amount) AS Amount 
FROM CPSFP_layout1
GROUP BY [TitleName], [CPSFP_Year]
)



SELECT  *
FROM  
(
  SELECT *
  FROM main
) AS TableToPivot 
PIVOT  
(  
  SUM(Amount)
  FOR  [TitleName] IN (
[TOTAL SURPLUS+/DEFICIT-]
)  
) AS PivotTable



GO
/****** Object:  View [dbo].[XXX_vw_CPSFP_Quarter]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [dbo].[XXX_vw_CPSFP_Quarter]
AS


WITH CPSFPQuarter_newList AS (
SELECT
	ID
, Column1 AS TitleName
,  (SELECT Column2 FROM [DES_Staging].[dbo].[Dump_FFSD_CPSFP_Quarter] WHERE [ID] = 4) AS [Year]
,  TRIM(REPLACE((SELECT Column2 FROM [DES_Staging].[dbo].[Dump_FFSD_CPSFP_Quarter] WHERE [ID] = 3),'Prelim', '')) AS [Month]
,  REPLACE(REPLACE(Column2,'(','-'),')','') AS Amount
FROM    [DES_Staging].[dbo].Dump_FFSD_CPSFP_Quarter
WHERE  Column1 = 'TOTAL SURPLUS+/DEFICIT-'

UNION

SELECT
	ID
, Column1 AS TitleName
,  (SELECT Column3 FROM [DES_Staging].[dbo].[Dump_FFSD_CPSFP_Quarter] WHERE [ID] = 4) AS [Year]
,  TRIM(REPLACE((SELECT Column2 FROM [DES_Staging].[dbo].[Dump_FFSD_CPSFP_Quarter] WHERE [ID] = 3),'Prelim', '')) AS [Month]
,  REPLACE(REPLACE(Column3,'(','-'),')','')  AS Amount
FROM    [DES_Staging].[dbo].Dump_FFSD_CPSFP_Quarter
WHERE  Column1 = 'TOTAL SURPLUS+/DEFICIT-'
)

, CPSFP_Percentage AS (

SELECT
	ID
, Column1 AS TitleName
,  (SELECT Column2 FROM [DES_Staging].[dbo].[Dump_FFSD_CPSFP_Quarter] WHERE [ID] = 4) AS [Year]
,  TRIM(REPLACE((SELECT Column2 FROM [DES_Staging].[dbo].[Dump_FFSD_CPSFP_Quarter] WHERE [ID] = 3),'Prelim', '')) AS [Month]
,  REPLACE(Column2,'%','') AS Amount
FROM    [DES_Staging].[dbo].Dump_FFSD_CPSFP_Quarter
WHERE  ID = (SELECT ID + 1  FROM    [DES_Staging].[dbo].Dump_FFSD_CPSFP_Quarter WHERE  Column1 = 'TOTAL SURPLUS+/DEFICIT-')

UNION

SELECT
	ID
, Column1 AS TitleName
,  (SELECT Column3 FROM [DES_Staging].[dbo].[Dump_FFSD_CPSFP_Quarter] WHERE [ID] = 4) AS [Year]
,  TRIM(REPLACE((SELECT Column2 FROM [DES_Staging].[dbo].[Dump_FFSD_CPSFP_Quarter] WHERE [ID] = 3),'Prelim', '')) AS [Month]
,  REPLACE(Column3,'%','') AS Amount
FROM    [DES_Staging].[dbo].Dump_FFSD_CPSFP_Quarter
WHERE  ID = (SELECT ID + 1  FROM    [DES_Staging].[dbo].Dump_FFSD_CPSFP_Quarter WHERE  Column1 = 'TOTAL SURPLUS+/DEFICIT-')

)

, main_CPSFP_Quarter AS (
SELECT a.[TitleName], a.[Year], a.[Month], SUM(CAST (a.[Amount] AS float)) AS [CPSFP SurplusDeficit]  , SUM(CAST (b.[Amount] AS float)) AS [CPSFP % to GDP]
FROM CPSFPQuarter_newList a
LEFT JOIN CPSFP_Percentage  b ON a.Year = b.Year AND a.Month = b.Month
GROUP BY a.[TitleName], a.[Year], a.[Month]
)

SELECT  [Year], [Month], [CPSFP SurplusDeficit], [CPSFP % to GDP]
, '' AS [I.  National Government (NG) Fiscal Position]
, '' AS [Revenues]
, '' AS [Revenues % to GDP]
, '' AS [Expenditures] 
, '' AS [Expenditures % to GDP]
, '' AS [Surplus/(-)Deficit]
, '' AS [Surplus/(-)Deficit % to GDP)]
, '' AS [Financing]
, '' AS [Borrowings (Net)]
, '' AS [Domestic (Net)] 
, '' AS [Domestic % to total NG Deficit]   
, '' AS [External (Net)]
, '' AS [External % to total NG Deficit]		
, '' AS [Change in Cash]
, '' AS [Change in Cash % to total NG Deficit]		
, '' AS [Financing Mix]
, '' AS [Financing Mix: Domestic]   
, '' AS [Financing Mix: External]
, '' AS [II. Consolidated Public Sector Financial Position (CPSFP)]
, '' AS [III. Outstanding Debt of the National Government]
, '' AS [OS Total Debt]
, '' AS [OS Total Debt % to GDP]
, '' AS [OS Domestic Debt]
, '' AS [OS Domestic Debt % to GDP]
, '' AS [OS External Debt]
, '' AS [OS External Debt % to GDP]
, '' AS [IV. Outstanding Public Sector Debt]
, '' AS [OPSD Total Debt % to GDP]
, '' AS [OPSD Total Debt]
, '' AS [OPSD Domestic Debt]
, '' AS [OPSD Domestic Debt % to GDP]
, '' AS [OPSD Foreign Debt]
, '' AS [OPSD Foreign Debt % to GDP]
, '' AS [Memorandum Item]
, '' AS [Public Sector External Debt]
, '' AS [Public Sector External Debt % to GDP]
FROM main_CPSFP_Quarter




GO
/****** Object:  View [dbo].[XXX_vw_ExchangeRates]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW [dbo].[XXX_vw_ExchangeRates]
AS
WITH CurrYear AS (SELECT ID, '2021' AS Year, 
                                            CASE WHEN [Period] = 'January' THEN 1 WHEN [Period] = 'February' THEN 2 WHEN [Period] = 'March' THEN 3 WHEN [Period] = 'April' THEN 4 WHEN [Period] = 'May' THEN 5 WHEN [Period] = 'June' THEN 6 WHEN [Period] = 'July' THEN 7 WHEN [Period] = 'August' THEN 8
                                             WHEN [Period] = 'September' THEN 9 WHEN [Period] = 'October' THEN 10 WHEN [Period] = 'November' THEN 11 WHEN [Period] = 'December' THEN 12 END AS Period, Average, [End-of-Period], Column5, Column6, Column7, Column8, Column9, Column10
                               FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR
                               WHERE (ID >=
                                                (SELECT ID
                                                FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_14
                                                WHERE (Year = '2021'))) AND (ID <
                                                (SELECT ID
                                                FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_13
                                                WHERE (Year = '2022')))
                               UNION
                               SELECT ID, '2020' AS Year, 
                                            CASE WHEN [Period] = 'January' THEN 1 WHEN [Period] = 'February' THEN 2 WHEN [Period] = 'March' THEN 3 WHEN [Period] = 'April' THEN 4 WHEN [Period] = 'May' THEN 5 WHEN [Period] = 'June' THEN 6 WHEN [Period] = 'July' THEN 7 WHEN [Period] = 'August' THEN 8
                                             WHEN [Period] = 'September' THEN 9 WHEN [Period] = 'October' THEN 10 WHEN [Period] = 'November' THEN 11 WHEN [Period] = 'December' THEN 12 END AS Period, Average, [End-of-Period], Column5, Column6, Column7, Column8, Column9, Column10
                               FROM   [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_12
                               WHERE (ID >=
                                                (SELECT ID
                                                FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_11
                                                WHERE (Year = '2020'))) AND (ID <
                                                (SELECT ID
                                                FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_10
                                                WHERE (Year = '2021')))
                               UNION
                               SELECT ID, '2019' AS Year, 
                                            CASE WHEN [Period] = 'January' THEN 1 WHEN [Period] = 'February' THEN 2 WHEN [Period] = 'March' THEN 3 WHEN [Period] = 'April' THEN 4 WHEN [Period] = 'May' THEN 5 WHEN [Period] = 'June' THEN 6 WHEN [Period] = 'July' THEN 7 WHEN [Period] = 'August' THEN 8
                                             WHEN [Period] = 'September' THEN 9 WHEN [Period] = 'October' THEN 10 WHEN [Period] = 'November' THEN 11 WHEN [Period] = 'December' THEN 12 END AS Period, Average, [End-of-Period], Column5, Column6, Column7, Column8, Column9, Column10
                               FROM   [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_9
                               WHERE (ID >=
                                                (SELECT ID
                                                FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_8
                                                WHERE (Year = '2019'))) AND (ID <
                                                (SELECT ID
                                                FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_7
                                                WHERE (Year = '2020')))
                               UNION
                               SELECT ID, '2018' AS Year, 
                                            CASE WHEN [Period] = 'January' THEN 1 WHEN [Period] = 'February' THEN 2 WHEN [Period] = 'March' THEN 3 WHEN [Period] = 'April' THEN 4 WHEN [Period] = 'May' THEN 5 WHEN [Period] = 'June' THEN 6 WHEN [Period] = 'July' THEN 7 WHEN [Period] = 'August' THEN 8
                                             WHEN [Period] = 'September' THEN 9 WHEN [Period] = 'October' THEN 10 WHEN [Period] = 'November' THEN 11 WHEN [Period] = 'December' THEN 12 END AS Period, Average, [End-of-Period], Column5, Column6, Column7, Column8, Column9, Column10
                               FROM   [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_6
                               WHERE (ID >=
                                                (SELECT ID
                                                FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_5
                                                WHERE (Year = '2018'))) AND (ID <
                                                (SELECT ID
                                                FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_4
                                                WHERE (Year = '2019')))
                               UNION
                               SELECT ID, '2017' AS Year, 
                                            CASE WHEN [Period] = 'January' THEN 1 WHEN [Period] = 'February' THEN 2 WHEN [Period] = 'March' THEN 3 WHEN [Period] = 'April' THEN 4 WHEN [Period] = 'May' THEN 5 WHEN [Period] = 'June' THEN 6 WHEN [Period] = 'July' THEN 7 WHEN [Period] = 'August' THEN 8
                                             WHEN [Period] = 'September' THEN 9 WHEN [Period] = 'October' THEN 10 WHEN [Period] = 'November' THEN 11 WHEN [Period] = 'December' THEN 12 END AS Period, Average, [End-of-Period], Column5, Column6, Column7, Column8, Column9, Column10
                               FROM   [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_3
                               WHERE (ID >=
                                                (SELECT ID
                                                FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_2
                                                WHERE (Year = '2017'))) AND (ID <
                                                (SELECT ID
                                                FROM    [DES_Staging].[dbo].Dump_FFSD_SELFI_PESODOLLAR AS Dump_FFSD_SELFI_PESODOLLAR_1
                                                WHERE (Year = '2018'))))
    SELECT Year, Period, DATEFROMPARTS(Year, Period, 1) AS SELFI_PESODOLLAR_Date, Average, [End-of-Period]
   FROM    CurrYear
GO
/****** Object:  View [dbo].[XXX_vw_Gross NG Debt Ratios]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[XXX_vw_Gross NG Debt Ratios]
AS


SELECT 
NGOSDEBT_Year
, NGOSDEBT_Month
, NGOSDEBT_Date
, [I. Domestic Debt]
, [II. External Debt]
,	CASE WHEN [NGOSDEBT_Month] = 1 OR [NGOSDEBT_Month] = 2 OR [NGOSDEBT_Month] = 3 THEN 'Q1'
			 WHEN [NGOSDEBT_Month] = 4 OR [NGOSDEBT_Month] = 5 OR [NGOSDEBT_Month] = 6 THEN 'Q2'
			 WHEN [NGOSDEBT_Month] = 7 OR [NGOSDEBT_Month] = 8 OR [NGOSDEBT_Month] = 9 THEN 'Q3'
			 ELSE 'Q4'
			END AS [Quarter]
FROM [DES_Staging].[dbo].[Conso_FFSD_NGOSDEBT]

GO
/****** Object:  View [dbo].[XXX_vw_Net NG Debt Ratios]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [dbo].[XXX_vw_Net NG Debt Ratios]
AS
with AnnualizedGDP AS (
SELECT 
       [Year]
      ,sum([Amount]) AS GDP
  FROM [DES_Staging].[dbo].[vw_NGDEBTRATIOS_PSNA]
  WHERE [Item] = 'GDP'
  GROUP BY [Year]
)

, AnnualizedGrossNGDebt AS (
SELECT 
a.[NGOSDEBT_Year]
, (a.[I. Domestic Debt] + a.[II. External Debt]) AS [Gross NG Debt]
FROM [DES_Staging].[dbo].[vw_Gross NG Debt Ratios] a
WHERE [NGOSDEBT_Month] = 12
)

, AnnualizeRateRemittance AS (
SELECT [Year], sum([Remittance in Peso]) AS [Remittance in Peso]
FROM  [DES_Staging].[dbo].[vw_Remittances]
GROUP BY [YEAR]
)

, layout1 AS (
SELECT [ID],
	[Column1] AS [Title],
	CASE WHEN [Column3] LIKE '(%' THEN CAST(REPLACE(REPLACE(REPLACE([Column3],'(',''), ')',''), ',','') AS float) * -1 
		ELSE REPLACE([Column3], ',','')
	END AS '2020'
,	CASE WHEN [Column5] LIKE '(%' THEN CAST(REPLACE(REPLACE(REPLACE([Column5],'(',''), ')',''), ',','') AS float) * -1 
		 WHEN [Column5] LIKE '%-%' THEN 0
		 ELSE REPLACE([Column5], ',','')
	END AS '2019'
FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table1]
WHERE [Column1] IN
(
'Cash and Cash Equivalents',
'Investments in Time Deposits',
'Treasury/Agency Cash Accounts',
'Investments',
'Receivables'
)
OR [ID] = 6

UNION

SELECT 
  [ID]
, [Column1]
, [Column2]
, [Column4]
FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table2]
WHERE [Column1] IN
(
'Inventories'
)

UNION

SELECT 
  [ID]
, [Column1]
, [Column2]
, [Column4]
FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table5]
WHERE [Column1] IN
(
'Other Current Assets',
'Investment Property',
'Property, Plant and Equipment'
)

UNION

  SELECT TOP 1
  [ID]
, [Column1]
, [Column2]
, [Column4]
FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table9]
WHERE [Column1] = 'Intangible Assets'

UNION

  SELECT --TOP 1
  [ID]
, [Column1]
, [Column3]
, [Column4]
FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table17]
WHERE [Column1] = 'Biological Assets'

UNION

  SELECT
  [ID]
, [Column1]
, [Column2]
, [Column4]
FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table18]
WHERE [Column1] = 'Total Assets'

UNION

  SELECT
  [ID]
, 'Loans Receivable GOCC' AS [Item]
, ROUND(CAST(REPLACE([Column2], ',','') AS float) / 1000 , 2)AS [Column2]
, ROUND(CAST(REPLACE([Column4], ',','') AS float) / 1000 , 2) AS [Column4]
FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table11]
WHERE [ID] BETWEEN (SELECT [ID] 
						FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table11] 
						WHERE  [Column1] = 'Loans Receivable-Government-Owned or Controlled Corporations') 
						AND 
						(SELECT [ID] + 2
						FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table11] 
						WHERE  [Column1] = 'Loans Receivable-Government-Owned or Controlled Corporations') 
AND [Column1] = 'Net value'

UNION

  SELECT
  [ID]
, 'Due from GOCC' AS [Item]
, ROUND(CAST(REPLACE([Column2], ',','') AS float) / 1000 , 2)AS [Column2]
, ROUND(CAST(REPLACE([Column4], ',','') AS float) / 1000 , 2) AS [Column4]
FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table12]
WHERE [ID] BETWEEN (SELECT [ID] 
						FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table12] 
						WHERE  [Column1] = 'Due from Government-Owned or Controlled Corporations') 
						AND 
						(SELECT [ID] + 2
						FROM [DES_Staging].[dbo].[Dump_FFSD_FinancialPosition_Table12] 
						WHERE  [Column1] = 'Due from Government-Owned or Controlled Corporations') 
AND [Column1] = 'Net value'

)

, layout2 AS (
  SELECT 
    [Year]
  , [Title]
  , CAST([Amount] AS float) AS Amount
  FROM 
(
SELECT *
FROM  layout1
WHERE [ID] <> 6
) AS tbl
UNPIVOT 
(

Amount FOR [Year] IN (      
       [2019]
      ,[2020]
	  )
) AS upv
)

, layout3 AS (
SELECT *
, ROUND((([Cash and Cash Equivalents] + [Investments in Time Deposits]) - [Treasury/Agency Cash Accounts]) / 1000, 2)  AS [Cash and cash equivalents (Gross of Treasury/Cash Accounts)]
, ([Investments] + [Receivables] + [Inventories] + [Other Current Assets] + ([Cash and Cash Equivalents] + [Investments in Time Deposits]) - [Treasury/Agency Cash Accounts]) AS [Total Current Assets]

FROM  
(
  SELECT *
  FROM layout2
) AS TableToPivot 
PIVOT  
(  
  MAX(Amount)
  FOR  [Title] IN (
[Cash and Cash Equivalents],
[Investments in Time Deposits],
[Treasury/Agency Cash Accounts],
[Investments],
[Receivables],
[Inventories],
[Other Current Assets],
[Investment Property],
[Property, Plant and Equipment],
[Intangible Assets],
[Biological Assets],
[Total Assets],
[Due from GOCC],
[Loans Receivable GOCC]
)  
) AS PivotTable
)

SELECT 
  a.[Year]
, c.[Gross NG Debt]  
, a.[Cash and cash equivalents (Gross of Treasury/Cash Accounts)] 
, b.[Amount] AS [RestrictedAccounts] 
, a.[Cash and cash equivalents (Gross of Treasury/Cash Accounts)] - b.[Amount] AS [Currency and Deposits] 
, d.GDP
, e.[Remittance in Peso] 
, a.[Cash and Cash Equivalents] 
, a.[Due from GOCC]
, a.[Loans Receivable GOCC]
, a.[Total Current Assets] / 1000 AS [Total Current Assets]
, b.[Amount]  + a.[Due from GOCC] + a.[Loans Receivable GOCC] AS [Restricted Assets and Claims on GOCC]
, (a.[Total Current Assets] / 1000) - (b.[Amount]  + a.[Due from GOCC] + a.[Loans Receivable GOCC]) AS [Short-term Assets]  -- 2020 Investments caused the discrepancy
, a.[Total Assets] / 1000 AS [Total Assets]
, a.[Investment Property] / 1000 AS [Investment Property]
, a.[Property, Plant and Equipment] / 1000 AS [Property, Plant and Equipment]
, a.[Biological Assets] / 1000 AS [Biological Assets]
, a.[Intangible Assets]/ 1000 AS [Intangible Assets]
, (a.[Investment Property] / 1000) + (a.[Property, Plant and Equipment] / 1000) + (a.[Intangible Assets] / 1000) + (a.[Biological Assets] / 1000) AS [Non-Financial Assets]
FROM layout3 a
LEFT JOIN [DES_Staging].[dbo].[vw_RestrictedAccounts] b ON a.[Year] = b.[Year]
LEFT JOIN  AnnualizedGrossNGDebt c ON c.NGOSDEBT_Year = a.[Year]
LEFT JOIN AnnualizedGDP d ON d.[Year] = a.[Year]
LEFT JOIN AnnualizeRateRemittance e ON e.[Year] = a.[Year]

GO
/****** Object:  View [dbo].[XXX_vw_NGCOR]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[XXX_vw_NGCOR]
AS



with COR_newParticularName AS (
SELECT 
	  [ID]
	  ,TRIM(REPLACE(REPLACE(REPLACE(REPLACE(TRIM([Particulars1]) + TRIM([Particulars2]) + TRIM([Particulars3]) + TRIM([Particulars4]) + TRIM([Particulars5]), '1/',''),'2/',''),'3/',''),'**','')) AS ParticularName
	  ,ROUND([Jan],0) AS [Jan]
      ,ROUND([Feb],0) AS [Feb]
      ,ROUND([Mar],0) AS [Mar]
      ,ROUND([Apr],0) AS [Apr]
      ,ROUND([May],0) AS [May]
      ,ROUND([Jun],0) AS [Jun]
      ,ROUND([Jul],0) AS [Jul]
      ,ROUND([Aug],0) AS [Aug]
      ,ROUND([Sep],0) AS [Sep]
      ,ROUND([Oct],0) AS [Oct]
      ,ROUND([Nov],0) AS [Nov]
      ,ROUND([Dec],0) AS [Dec]
  FROM [DES_Staging].[dbo].[Dump_FFSD_SELFI_NGCOR]
  WHERE [Jan] <> ''
  )

, COR_layout1 AS (
  SELECT  [ID],
  CASE	WHEN [ID] = 12	THEN 'BIR ' + [ParticularName] 
		WHEN [ID] = 16	THEN 'BOC ' + [ParticularName] 
		--WHEN [ID] = 33	THEN REPLACE([ParticularName], ' 1/' , '')
		--WHEN [ID] = 36	THEN REPLACE([ParticularName], ' 2/' , '')
		--WHEN [ID] = 49	THEN REPLACE([ParticularName], ' 3/' , '')
		ELSE [ParticularName]
  END AS [ParticularName]
  , [DES_Staging].[dbo].fn_month_name_to_number ([MonthName]) AS [MonthName]
  , (SELECT SUBSTRING(Particulars1,4,4) AS [Year] FROM [DES_Staging].[dbo].[Dump_FFSD_SELFI_NGCOR] WHERE [ID] = 1) AS [Year]
  , CASE WHEN Amount = '' THEN 0 ELSE Amount END AS Amount
--  , CAST([Amount] AS decimal) AS Amount
  FROM --newParticularName
(
SELECT *
FROM  COR_newParticularName
) AS tbl
UNPIVOT 
(

Amount FOR [MonthName] IN (      
	   [Jan]
	  ,[Feb]
      ,[Mar]
      ,[Apr]
      ,[May]
      ,[Jun]
      ,[Jul]
      ,[Aug]
      ,[Sep]
      ,[Oct]
      ,[Nov]
      ,[Dec])

) AS upv
)


, COR_layout2 AS (SELECT [ParticularName],  [MonthName] AS COR_Month, DATEFROMPARTS ([Year], [MonthName], 1) AS COR_Date, Amount 
from COR_layout1
)


, COR_layout3 AS (
SELECT  DATEPART(YEAR,COR_Date) AS COR_Year, *
FROM  
(
  SELECT *
  FROM COR_layout2
) AS TableToPivot 
PIVOT  
(  
  SUM(Amount)
  FOR  [ParticularName] IN (
[Revenues],
[Tax Revenues],
[BIR],
[Documentary Stamp],
[BIR Tax Expenditures],
[BOC],
[BOC Tax Expenditures],
[Other Offices],
[Non-tax Revenues],
[BTr Income],
[Fees and Charges],
[Privatization],
[Income from Malampaya],
[Other non-tax],
[Grants],
[Expenditures],
[Allotment to LGUs],
[Interest Payments],
[Tax Expenditures],
[Subsidy],
[Equity],
[Net Lending],
[NG Disbursements],
[Surplus/(-)Deficit],
[Financing],
[External (Net)],
[External (Gross)],
[Less: Amortization],
[Domestic (Net)],
[Domestic (Gross)],
[Less: Net Amortization],
[Amortization],
[of which: Redemption from BSF],
[Change-In-Cash]

)  
) AS PivotTable
)

SELECT * FROM COR_layout3


GO
/****** Object:  View [dbo].[XXX_vw_NGOSDEBT]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[XXX_vw_NGOSDEBT]
AS
--ONLY 2021 and 2020 are working. The others have different template format.

with NGOSDEBT_newParticularName AS (
SELECT 
	  [ID]
	  ,TRIM(REPLACE(REPLACE(REPLACE(REPLACE(TRIM([Particulars1]) + TRIM([Particulars2]) + TRIM([Particulars3]) + TRIM([Particulars4]) + TRIM([Particulars5]), '1/',''),'2/',''),'3/',''),'**',''))  AS ParticularName
	  ,ROUND([Jan],0) AS [Jan]
      ,ROUND([Feb],0) AS [Feb]
      ,ROUND([Mar],0) AS [Mar]
      ,ROUND([Apr],0) AS [Apr]
      ,ROUND([May],0) AS [May]
      ,ROUND([Jun],0) AS [Jun]
      ,ROUND([Jul],0) AS [Jul]
      ,ROUND([Aug],0) AS [Aug]
      ,ROUND([Sep],0) AS [Sep]
      ,ROUND([Oct],0) AS [Oct]
      ,ROUND([Nov],0) AS [Nov]
      ,ROUND([Dec],0) AS [Dec]
  FROM [DES_Staging].[dbo].[Dump_FFSD_SELFI_NGOSDEBT]
  WHERE [Jan] <> ''
  )

, NGOSDEBT_layout1 AS (
  SELECT  [ID],
  CASE	WHEN [ID] = 7 OR [ID]  = 8 OR [ID]  = 9 OR [ID]  = 12 OR [ID]  = 13 OR [ID]  = 14 OR [ID]  = 15 OR [ID]  = 16 OR [ID]  = 17 OR [ID]  = 18	THEN 'Domestic ' + [ParticularName] 
		WHEN [ID] > 21 AND [ID] < 36  THEN 'External ' + [ParticularName] 
--		WHEN [ID] = 11	THEN REPLACE([ParticularName], ' 1/' , '')
		ELSE [ParticularName]
  END AS [ParticularName]
  , [DES_Staging].[dbo].fn_month_name_to_number ([MonthName]) AS [MonthName]
  , (SELECT SUBSTRING(Particulars1,16,4) AS [Year] FROM [DES_Staging].[dbo].[Dump_FFSD_SELFI_NGOSDEBT] WHERE [ID] = 1) AS [Year]
  , CASE WHEN Amount = '' THEN 0 ELSE CAST([Amount] AS decimal) END AS Amount
  FROM --newParticularName
(
SELECT *
FROM  NGOSDEBT_newParticularName
) AS tbl
UNPIVOT 
(

Amount FOR [MonthName] IN (      
	   	   [Jan]
	  ,[Feb]
      ,[Mar]
      ,[Apr]
      ,[May]
      ,[Jun]
      ,[Jul]
      ,[Aug]
      ,[Sep]
      ,[Oct]
      ,[Nov]
      ,[Dec]
	  )

) AS upv
)

, NGOSDEBT_layout2 AS (SELECT [ParticularName], DATEFROMPARTS ([Year], [MonthName], 1) AS NGOSDEBT_Date, Amount 
from NGOSDEBT_layout1
)

, NGOSDEBT_layout3 AS (
SELECT  DATEPART(YEAR,NGOSDEBT_Date) AS NGOSDEBT_Year,  DATEPART(MONTH,NGOSDEBT_Date) AS NGOSDEBT_Month, *
FROM  
(
  SELECT *
  FROM NGOSDEBT_layout2
) AS TableToPivot 
PIVOT  
(  
  SUM(Amount)
  FOR  [ParticularName] IN (
[I. Domestic Debt],
[Domestic Loans],
[Domestic Direct],
[Domestic Agencies],
[NG Other Domestic],
[BSP Provisional Advances],
[Short-term borrowing from BSP],
[Domestic Relent],
[Domestic Assumed],
[Domestic PNB],
[Domestic DBP],
[Domestic NPC/PNPP],
[Domestic NDC],
[Debt Securities],
[II. External Debt],
[External Loans],
[External Direct],
[External Agencies],
[External Relent],
[External Assumed],
[External PNB],
[External DBP],
[External NPC/PNPP],
[External NDC],
[External PAL],
[External Debt Securities],
[T O T A L],
[Forex Rate Used]
)  
) AS PivotTable
)

SELECT * FROM NGOSDEBT_layout3
--WHERE NGOSDEBT_Month = 12

GO
/****** Object:  View [dbo].[XXX_vw_OPSD]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[XXX_vw_OPSD]
AS


with validCol AS 

(
SELECT * FROM [DES_Staging].[dbo].[Dump_FFSD_SELFI_OPSD]
WHERE ID >= (SELECT ID FROM [DES_Staging].[dbo].[Dump_FFSD_SELFI_OPSD] WHERE Column1 = '17. Total consolidated public sector debt (15-16)')
)


, OPSD_newList AS (
  SELECT 
	  [ID]
	, [Column1] AS [TitleName]
	, [Column2]
  FROM validCol
  WHERE [Column1] IN ('17. Total consolidated public sector debt (15-16)','% of GDP','Domestic','Foreign')
   )

, OPSD_layout1 AS (

  select [ID],
		(SELECT Column2 FROM [DES_Staging].[dbo].[Dump_FFSD_SELFI_OPSD] WHERE [ID] = 3) AS [OPSD_Year]
		 , [TitleName]
		 , CAST ([Column2] AS float) AS 'Amount'
         from OPSD_newList
)

, main AS (
SELECT [TitleName], [OPSD_Year] , sum(Amount) AS Amount 
FROM OPSD_layout1
GROUP BY [TitleName], [OPSD_Year]
)

SELECT  *
FROM  
(
  SELECT *
  FROM main
) AS TableToPivot 
PIVOT  
(  
  SUM(Amount)
  FOR  [TitleName] IN (
[17. Total consolidated public sector debt (15-16)],
[% of GDP],
[Domestic],
[Foreign]
)  
) AS PivotTable


GO
/****** Object:  View [dbo].[XXX_vw_PSNA]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[XXX_vw_PSNA]
AS


with main AS (
SELECT TOP 1
	  'GDP'					AS [Item]
	  , '2017' AS [PSNA_Year]
	, CAST('16556651.0832259' as float)	AS [Amount]
--	, CAST('18265190.2581617' as float)	AS [Amount]
--	, CAST('19517863.171682' as float)	AS [Amount]
--	, CAST('17938582.4241823' as float)	AS [Amount]
--	, CAST('19387209.6437304' as float)	AS [Amount]
FROM [DES_Staging].[dbo].[Dump_FFSD_SELFI_CPSFP]

UNION

SELECT TOP 1
	  'GNI'					AS [Item]
	 , '2017' AS [PSNA_Year]
	, CAST('18383179.1081043' as float)	AS [Amount]
--	, CAST('20212348.9161691' as float)	AS [Amount]
--	, CAST('21472060.3528011' as float)	AS [Amount]
--	, CAST('19319847.5510391' as float)	AS [Amount]
--	, CAST('20103286.6367369' as float)	AS [Amount]
FROM [DES_Staging].[dbo].[Dump_FFSD_SELFI_CPSFP]


)

SELECT  *
FROM  
(
  SELECT *
  FROM main
) AS TableToPivot 
PIVOT  
(  
  SUM(Amount)
  FOR  [Item] IN (
[GNI],
[GDP]
)  
) AS PivotTable


GO
/****** Object:  View [dbo].[XXX_vw_PublicExtDebt]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [dbo].[XXX_vw_PublicExtDebt]
AS



WITH PublicExtDebt_newList AS (
SELECT
       [Column3] AS [Item]
      ,[Column4] AS [Amount]
  FROM [DES_Staging].[dbo].[Dump_FFSD_NGDEBT_PublicExtDebt]
  WHERE [Column3] IN ('Public',  'Gross National Income (GNI)', 'Gross Domestic Product (GDP)')
	AND [ID] < 37

  )


, main AS (
  select 
		(SELECT Column4 FROM [DES_Staging].[dbo].[Dump_FFSD_NGDEBT_PublicExtDebt] WHERE [Column3] = ' I t e m') AS [PublicExtDebt_Year]
		 , [Item]
		 , CAST ([Amount] AS float) AS 'Amount'
         from PublicExtDebt_newList
)


SELECT  *
FROM  
(
  SELECT *
  FROM main
) AS TableToPivot 
PIVOT  
(  
  SUM(Amount)
  FOR  [Item] IN (
[Gross National Income (GNI)],
[Gross Domestic Product (GDP)],
[Public]
)  
) AS PivotTable



GO
/****** Object:  View [dbo].[XXX_vw_Remittances]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [dbo].[XXX_vw_Remittances]
AS
WITH YearlyFormat AS (SELECT ID, '2017' AS Year, 
CASE WHEN [Column2] = 'Jan' THEN 1 WHEN [Column2] = 'Feb' THEN 2 WHEN [Column2] = 'Mar' THEN 3 WHEN [Column2] = 'Apr' THEN 4 WHEN [Column2] = 'May' THEN 5 WHEN [Column2] = 'Jun' THEN 6 WHEN [Column2] = 'Jul' THEN 7 WHEN [Column2] = 'Aug' THEN
8 WHEN [Column2] = 'Sep' THEN 9 WHEN [Column2] = 'Oct' THEN 10 WHEN [Column2] = 'Nov' THEN 11 WHEN [Column2] = 'Dec' THEN 12 END AS MonthNumber, Column6
FROM   [DES_Staging].[dbo].Dump_FFSD_Remittances
WHERE (ID BETWEEN  (SELECT ID
FROM    [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_14
WHERE (Column1 LIKE '2017%')) AND
(SELECT CAST(ID AS int) + 11 AS End_ID
FROM    [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_13
WHERE (Column1 LIKE '2017%')))
UNION
SELECT ID, '2018' AS Year, 
CASE WHEN [Column2] = 'Jan' THEN 1 WHEN [Column2] = 'Feb' THEN 2 WHEN [Column2] = 'Mar' THEN 3 WHEN [Column2] = 'Apr' THEN 4 WHEN [Column2] = 'May' THEN 5 WHEN [Column2] = 'Jun' THEN 6 WHEN [Column2] = 'Jul' THEN 7 WHEN [Column2] = 'Aug' THEN
8 WHEN [Column2] = 'Sep' THEN 9 WHEN [Column2] = 'Oct' THEN 10 WHEN [Column2] = 'Nov' THEN 11 WHEN [Column2] = 'Dec' THEN 12 END AS MonthNumber, Column6
FROM   [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_12
WHERE (ID BETWEEN
(SELECT ID
FROM    [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_11
WHERE (Column1 LIKE '2018%')) AND
(SELECT CAST(ID AS int) + 11 AS End_ID
FROM    [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_10
WHERE (Column1 LIKE '2018%')))
UNION
SELECT ID, '2019' AS Year, 
CASE WHEN [Column2] = 'Jan' THEN 1 WHEN [Column2] = 'Feb' THEN 2 WHEN [Column2] = 'Mar' THEN 3 WHEN [Column2] = 'Apr' THEN 4 WHEN [Column2] = 'May' THEN 5 WHEN [Column2] = 'Jun' THEN 6 WHEN [Column2] = 'Jul' THEN 7 WHEN [Column2] = 'Aug' THEN
8 WHEN [Column2] = 'Sep' THEN 9 WHEN [Column2] = 'Oct' THEN 10 WHEN [Column2] = 'Nov' THEN 11 WHEN [Column2] = 'Dec' THEN 12 END AS MonthNumber, Column6
FROM   [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_9
WHERE (ID BETWEEN
(SELECT ID
FROM    [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_8
WHERE (Column1 LIKE '2019%')) AND
(SELECT CAST(ID AS int) + 11 AS End_ID
FROM    [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_7
WHERE (Column1 LIKE '2019%')))
UNION
SELECT ID, '2020' AS Year, 
CASE WHEN [Column2] = 'Jan' THEN 1 WHEN [Column2] = 'Feb' THEN 2 WHEN [Column2] = 'Mar' THEN 3 WHEN [Column2] = 'Apr' THEN 4 WHEN [Column2] = 'May' THEN 5 WHEN [Column2] = 'Jun' THEN 6 WHEN [Column2] = 'Jul' THEN 7 WHEN [Column2] = 'Aug' THEN
8 WHEN [Column2] = 'Sep' THEN 9 WHEN [Column2] = 'Oct' THEN 10 WHEN [Column2] = 'Nov' THEN 11 WHEN [Column2] = 'Dec' THEN 12 END AS MonthNumber, Column6
FROM   [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_6
WHERE (ID BETWEEN
(SELECT ID
FROM    [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_5
WHERE (Column1 LIKE '2020%')) AND
(SELECT CAST(ID AS int) + 11 AS End_ID
FROM    [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_4
WHERE (Column1 LIKE '2020%')))
UNION
SELECT ID, '2021' AS Year, 
CASE WHEN [Column2] = 'Jan' THEN 1 WHEN [Column2] = 'Feb' THEN 2 WHEN [Column2] = 'Mar' THEN 3 WHEN [Column2] = 'Apr' THEN 4 WHEN [Column2] = 'May' THEN 5 WHEN [Column2] = 'Jun' THEN 6 WHEN [Column2] = 'Jul' THEN 7 WHEN [Column2] = 'Aug' THEN
8 WHEN [Column2] = 'Sep' THEN 9 WHEN [Column2] = 'Oct' THEN 10 WHEN [Column2] = 'Nov' THEN 11 WHEN [Column2] = 'Dec' THEN 12 END AS MonthNumber, Column6
FROM   [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_3
WHERE (ID BETWEEN
(SELECT ID
FROM    [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_2
WHERE (Column1 LIKE '2021%')) AND
(SELECT CAST(ID AS int) + 11 AS End_ID
FROM    [DES_Staging].[dbo].Dump_FFSD_Remittances AS Dump_FFSD_Remittances_1
WHERE (Column1 LIKE '2021%'))))

, main AS (
SELECT [Year], [MonthNumber] , DATEFROMPARTS(Year, MonthNumber, 1) AS Remittance_Date, Column6 AS Remittance
FROM    YearlyFormat AS YearlyFormat_1
)

SELECT
a.[Year], a.MonthNumber
, REPLACE(a.[Remittance], ',','') AS RemittanceInUSD
, b.Average
, CAST(REPLACE(a.[Remittance], ',','') AS float) * CAST(b.Average AS Float) AS [Remittance in Peso]
FROM main a
LEFT JOIN [DES_Staging].[dbo].[vw_ExchangeRates] b ON a.[Year] = b.[Year] AND a.MonthNumber = b.[Period]
GO
/****** Object:  View [dbo].[XXX_vw_SELFI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [dbo].[XXX_vw_SELFI]
AS
with OSDEBT AS  (
SELECT NGOSDEBT_Year,
SUM([I. Domestic Debt]) AS [I. Domestic Debt],
SUM([Domestic Loans]) AS [Domestic Loans],
SUM([Domestic Direct]) AS [Domestic Direct],
SUM([Domestic Agencies]) AS [Domestic Agencies],
SUM([NG Other Domestic]) AS [NG Other Domestic],
SUM([BSP Provisional Advances]) AS [BSP Provisional Advances],
SUM([Short-term borrowing from BSP]) AS [Short-term borrowing from BSP],
SUM([Domestic Relent]) AS [Domestic Relent],
SUM([Domestic Assumed]) AS [Domestic Assumed],
SUM([Domestic PNB]) AS [Domestic PNB],
SUM([Domestic DBP]) AS [Domestic DBP],
SUM([Domestic NPC/PNPP]) AS [Domestic NPC/PNPP],
SUM([Domestic NDC]) AS [Domestic NDC],
SUM([Debt Securities]) AS [Debt Securities],
SUM([II. External Debt]) AS [II. External Debt],
SUM([External Loans]) AS [External Loans],
SUM([External Direct]) AS [External Direct],
SUM([External Agencies]) AS [External Agencies],
SUM([External Relent]) AS [External Relent],
SUM([External Assumed]) AS [External Assumed],
SUM([External PNB]) AS [External PNB],
SUM([External DBP]) AS [External DBP],
SUM([External NPC/PNPP]) AS [External NPC/PNPP],
SUM([External NDC]) AS [External NDC],
SUM([External PAL]) AS [External PAL],
SUM([External Debt Securities]) AS [External Debt Securities],
SUM([T O T A L]) AS [T O T A L],
SUM([Forex Rate Used]) AS [Forex Rate Used]
FROM vw_NGOSDEBT
GROUP BY NGOSDEBT_Year
)

, NGCOR AS  (
SELECT COR_Year,
SUM([Revenues]) AS [Revenues],
SUM([Tax Revenues]) AS [Tax Revenues],
SUM([BIR]) AS [BIR],
SUM([Documentary Stamp]) AS [Documentary Stamp],
SUM([BIR Tax Expenditures]) AS [BIR Tax Expenditures],
SUM([BOC]) AS [BOC],
SUM([BOC Tax Expenditures]) AS [BOC Tax Expenditures],
SUM([Other Offices]) AS [Other Offices],
SUM([Non-tax Revenues]) AS [Non-tax Revenues],
SUM([BTr Income]) AS [BTr Income],
SUM([Fees and Charges]) AS [Fees and Charges],
SUM([Privatization]) AS [Privatization],
SUM([Income from Malampaya]) AS [Income from Malampaya],
SUM([Other non-tax]) AS [Other non-tax],
SUM([Grants]) AS [Grants],
SUM([Expenditures]) AS [Expenditures],
SUM([Allotment to LGUs]) AS [Allotment to LGUs],
SUM([Interest Payments]) AS [Interest Payments],
SUM([Tax Expenditures]) AS [Tax Expenditures],
SUM([Subsidy ]) AS [Subsidy ],
SUM([Equity]) AS [Equity],
SUM([Net Lending]) AS [Net Lending],
SUM([NG Disbursements ]) AS [NG Disbursements ],
SUM([Surplus/(-)Deficit]) AS [Surplus/(-)Deficit],
SUM([Financing]) AS [Financing],
SUM([External (Net)]) AS [External (Net)],
SUM([External (Gross)]) AS [External (Gross)],
SUM([Less: Amortization]) AS [Less: Amortization],
SUM([Domestic (Net)]) AS [Domestic (Net)],
SUM([Domestic (Gross)]) AS [Domestic (Gross)],
SUM([Less: Net Amortization]) AS [Less: Net Amortization],
SUM([Amortization]) AS [Amortization],
SUM([of which: Redemption from BSF ]) AS [of which: Redemption from BSF ],
SUM([Change-In-Cash]) AS [Change-In-Cash]
FROM vw_NGCOR
GROUP BY COR_Year
)

, SELFI_layout1 AS (
SELECT 
NGCOR.COR_Year AS [Year]
, vw_PSNA.Amount AS [GDP]

, '' AS [I.  National Government (NG) Fiscal Position]
, [Revenues] AS [Revenues]
, ([Revenues] / vw_PSNA.Amount) * 100 AS [Revenues % to GDP]  
, [Expenditures] AS [Expenditures]
, ([Expenditures] / vw_PSNA.Amount) * 100 AS [Expenditures % to GDP] 
, [Surplus/(-)Deficit] AS [Surplus/(-)Deficit]
, ([Surplus/(-)Deficit] / vw_PSNA.Amount) * 100 AS [Surplus/(-)Deficit % to GDP)] 

, '' AS [Financing]
, [Financing] AS [Borrowings (Net)]
, [Domestic (Net)] AS [Domestic (Net)]
, [Domestic (Net)] / ABS([Surplus/(-)Deficit]) * 100 AS [Domestic % to total NG deficit]
, [External (Net)] AS [External (Net)]
, [External (Net)] / ABS([Surplus/(-)Deficit]) * 100 AS [External % to total NG deficit]
, [Change-In-Cash] AS [Change in Cash]
, ([Change-In-Cash] / ABS([Surplus/(-)Deficit])) * 100 AS [Change in Cash % to total NG deficit]

, '' AS [Financing Mix]
, [Domestic (Gross)] / ([Domestic (Gross)] + [External (Gross)]) AS [Financing Mix: Domestic]
, [External (Gross)] / ([Domestic (Gross)] + [External (Gross)]) AS [Financing Mix: External]

, '' AS [II. Consolidated Public Sector Financial Position (CPSFP)]
, vw_CPSFP.Amount AS [CPSFP SurplusDeficit]
, (vw_CPSFP.Amount / vw_PSNA.Amount) * 100 AS [CPSFP % to GDP]

, '' AS [III. Outstanding Debt of the National Government]
, [T O T A L] AS [OS Total Debt]
, ([T O T A L] / vw_PSNA.Amount) * 100 AS [OS Total Debt % to GDP]
, [I. Domestic Debt] AS [OS Domestic Debt]
, ([I. Domestic Debt] / vw_PSNA.Amount) * 100 AS [OS Domestic Debt % to GDP]
, [II. External Debt] AS [OS External Debt]
, ([II. External Debt] / vw_PSNA.Amount) * 100 AS [OS External Debt % to GDP]

, '' AS [IV. Outstanding Public Sector Debt]
, vw_OPSD.[% of GDP] AS [OPSD Total Debt % to GDP]
, vw_OPSD.[17. Total consolidated public sector debt (15-16)] AS [OPSD Total Debt]
, vw_OPSD.[Domestic] AS [OPSD Domestic Debt]
, (vw_OPSD.[Domestic] / vw_PSNA.Amount) * 100 AS [OPSD Domestic Debt % to GDP] 
, vw_OPSD.[Foreign] AS [OPSD Foreign Debt]
, (vw_OPSD.[Foreign] / vw_PSNA.Amount) * 100 AS [OPSD Foreign Debt % to GDP]

, '' AS [Memorandum Item]
, vw_PublicExtDebt.[PublicExtDebt] AS [Public Sector External Debt]
, (vw_PublicExtDebt.[PublicExtDebt] / vw_PublicExtDebt.GDP)  * 100 AS [Public Sector External Debt % to GDP]

FROM NGCOR
LEFT JOIN OSDEBT			ON NGCOR.COR_Year		= OSDEBT.NGOSDEBT_Year
LEFT JOIN vw_OPSD			ON vw_OPSD.OPSD_Year	=  NGCOR.COR_Year
LEFT JOIN vw_CPSFP			ON vw_CPSFP.CPSFP_Year	=  NGCOR.COR_Year
LEFT JOIN vw_PSNA			ON vw_PSNA.PSNA_Year	= NGCOR.COR_Year
LEFT JOIN vw_PublicExtDebt	ON vw_PublicExtDebt.PublicExtDebt_Year	= NGCOR.COR_Year
)

, SELFI_layout2 AS (

  SELECT  
	[Year]
	, [TitleName] 
	, CAST([Amount] AS float) AS Amount
	,CASE 
		WHEN [TitleName] = 'I.  National Government (NG) Fiscal Position' THEN 1
		WHEN [TitleName] = 'Revenues' THEN 2
		WHEN [TitleName] = 'Revenues % to GDP' THEN 3
		WHEN [TitleName] = 'Expenditures' THEN 4
		WHEN [TitleName] = 'Expenditures % to GDP' THEN 5
		WHEN [TitleName] = 'Surplus/(-)Deficit' THEN 6
		WHEN [TitleName] = 'Surplus/(-)Deficit % to GDP)' THEN 7

		WHEN [TitleName] = 'Financing' THEN 8
		WHEN [TitleName] = 'Borrowings (Net)' THEN 9
		WHEN [TitleName] = 'Domestic (Net)' THEN 10
		WHEN [TitleName] = 'Domestic % to total NG deficit' THEN 11
		WHEN [TitleName] = 'External (Net)' THEN 12
		WHEN [TitleName] = 'External % to total NG deficit' THEN 13
		WHEN [TitleName] = 'Change in Cash' THEN 14
		WHEN [TitleName] = 'Change in Cash % to total NG deficit' THEN 15

		WHEN [TitleName] = 'Financing Mix' THEN 16
		WHEN [TitleName] = 'Financing Mix: Domestic' THEN 17
		WHEN [TitleName] = 'Financing Mix: External' THEN 18
		WHEN [TitleName] = 'II. Consolidated Public Sector Financial Position (CPSFP)' THEN 19
		WHEN [TitleName] = 'CPSFP SurplusDeficit' THEN 20
		WHEN [TitleName] = 'CPSFP % to GDP ' THEN 21
		WHEN [TitleName] = 'III. Outstanding Debt of the National Government' THEN 22
		WHEN [TitleName] = 'OS Total Debt' THEN 23
		WHEN [TitleName] = 'OS Total Debt % to GDP' THEN 24
		WHEN [TitleName] = 'OS Domestic Debt' THEN 25
		WHEN [TitleName] = 'OS Domestic Debt % to GDP' THEN 26
		WHEN [TitleName] = 'OS External Debt' THEN 27
		WHEN [TitleName] = 'OS External Debt % to GDP' THEN 28
		WHEN [TitleName] = 'IV. Outstanding Public Sector Debt' THEN 29
		WHEN [TitleName] = 'OPSD Total Debt' THEN 30
		WHEN [TitleName] = 'OPSD Total Debt % to GDP' THEN 31
		WHEN [TitleName] = 'OPSD Domestic Debt' THEN 32
		WHEN [TitleName] = 'OPSD Domestic Debt % to GDP' THEN 33
		WHEN [TitleName] = 'OPSD Foreign Debt' THEN 34
		WHEN [TitleName] = 'OPSD Foreign Debt % to GDP' THEN 35

		WHEN [TitleName] = 'Memorandum Item' THEN 36
		WHEN [TitleName] = 'Public Sector External Debt' THEN 37
		WHEN [TitleName] = 'Public Sector External Debt % to GDP' THEN 38
		END AS [SortID]
  FROM 
(
SELECT
[Year]
, CAST([GDP] AS float) AS [GDP]
, CAST([I.  National Government (NG) Fiscal Position] AS float) AS [I.  National Government (NG) Fiscal Position]
, CAST([Revenues] AS float) AS [Revenues]
, CAST([Revenues % to GDP] AS float) AS [Revenues % to GDP]
, CAST([Expenditures] AS float) AS [Expenditures]
, CAST([Expenditures % to GDP] AS float) AS [Expenditures % to GDP]
, CAST([Surplus/(-)Deficit] AS float) AS [Surplus/(-)Deficit]
, CAST([Surplus/(-)Deficit % to GDP)] AS float) AS [Surplus/(-)Deficit % to GDP)]

, CAST([Financing] AS float) AS [Financing]
, CAST([Borrowings (Net)] AS float) AS [Borrowings (Net)]
, CAST([Domestic (Net)] AS float) AS [Domestic (Net)]
, CAST([Domestic % to total NG deficit] AS float) AS [Domestic % to total NG deficit]
, CAST([External (Net)] AS float) AS [External (Net)]
, CAST([External % to total NG deficit] AS float) AS [External % to total NG deficit]
, CAST([Change in Cash] AS float) AS [Change in Cash]
, CAST([Change in Cash % to total NG deficit] AS float) AS [Change in Cash % to total NG deficit]

, CAST([Financing Mix] AS float) AS [Financing Mix] 
, CAST([Financing Mix: Domestic] AS float) AS [Financing Mix: Domestic]
, CAST([Financing Mix: External]  AS float) AS [Financing Mix: External]
, CAST([II. Consolidated Public Sector Financial Position (CPSFP)] AS float) AS [II. Consolidated Public Sector Financial Position (CPSFP)]
, CAST([CPSFP SurplusDeficit] AS float) AS [CPSFP SurplusDeficit]
, CAST([CPSFP % to GDP] AS float) AS [CPSFP % to GDP]
, CAST([III. Outstanding Debt of the National Government] AS float) AS [III. Outstanding Debt of the National Government]
, CAST([OS Total Debt] AS float) AS [OS Total Debt]
, CAST([OS Total Debt % to GDP] AS float) AS [OS Total Debt % to GDP]
, CAST([OS Domestic Debt] AS float) AS [OS Domestic Debt]
, CAST([OS Domestic Debt % to GDP] AS float) AS [OS Domestic Debt % to GDP]
, CAST([OS External Debt] AS float) AS [OS External Debt]
, CAST([OS External Debt % to GDP] AS float) AS [OS External Debt % to GDP]
, CAST([IV. Outstanding Public Sector Debt] AS float) AS [IV. Outstanding Public Sector Debt]
, CAST([OPSD Total Debt % to GDP] AS float) AS [OPSD Total Debt % to GDP]
, CAST([OPSD Total Debt] AS float) AS[OPSD Total Debt]
, CAST([OPSD Domestic Debt] AS float) AS [OPSD Domestic Debt]
, CAST([OPSD Domestic Debt % to GDP] AS float) AS [OPSD Domestic Debt % to GDP]
, CAST([OPSD Foreign Debt] AS float) AS [OPSD Foreign Debt]
, CAST([OPSD Foreign Debt % to GDP] AS float) AS [OPSD Foreign Debt % to GDP]


, CAST([Memorandum Item] AS float) AS [Memorandum Item]
, CAST([Public Sector External Debt] AS float) AS [Public Sector External Debt]
, CAST([Public Sector External Debt % to GDP] AS float) AS [Public Sector External Debt % to GDP]

FROM  SELFI_layout1
) AS tbl
UNPIVOT 
(
Amount FOR [TitleName] IN (      
[I.  National Government (NG) Fiscal Position],
[Revenues],
[Revenues % to GDP],
[Expenditures],
[Expenditures % to GDP],
[Surplus/(-)Deficit],
[Surplus/(-)Deficit % to GDP)],
[Financing],
[Borrowings (Net)],
[Domestic (Net)],
[Domestic % to total NG deficit],
[External (Net)],
[External % to total NG deficit],
[Change in Cash],
[Change in Cash % to total NG deficit],
[Financing Mix],
[Financing Mix: Domestic],
[Financing Mix: External],
[II. Consolidated Public Sector Financial Position (CPSFP)],
[CPSFP SurplusDeficit],
[CPSFP % to GDP], 
[III. Outstanding Debt of the National Government],
[OS Total Debt],
[OS Total Debt % to GDP],
[OS Domestic Debt],
[OS Domestic Debt % to GDP],
[OS External Debt],
[OS External Debt % to GDP],
[IV. Outstanding Public Sector Debt],
[OPSD Total Debt],
[OPSD Total Debt % to GDP],
[OPSD Domestic Debt],
[OPSD Domestic Debt % to GDP],
[OPSD Foreign Debt],
[OPSD Foreign Debt % to GDP],
[Memorandum Item],
[Public Sector External Debt],
[Public Sector External Debt % to GDP]
	  )
) AS upv
)

SELECT 

[SortID],
[TitleName], 
CASE WHEN [2019] = 0 THEN NULL ELSE [2019] END AS [2019], 
CASE WHEN [2020] = 0 THEN NULL ELSE [2020] END AS [2020],
CASE WHEN [2021] = 0 THEN NULL ELSE [2021] END AS [2021] 
FROM  
(
  SELECT *
  FROM SELFI_layout2
) AS TableToPivot 
PIVOT  
(  
  SUM(Amount)
  FOR  [Year] IN (
[2019],
[2020],
[2021]

)  
) AS PivotTable

GO
/****** Object:  Table [dbo].[BSp_RATES2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BSp_RATES2](
	[PARTICULARS] [varchar](30) NOT NULL,
	[TENOR] [varchar](36) NULL,
	[BKCODE] [int] NULL,
	[Time_Idx] [int] NULL,
	[BASIS] [varchar](6) NULL,
	[PART] [varchar](17) NULL,
	[ACCTCODE] [varchar](18) NULL,
	[TVNOTRAN] [numeric](19, 5) NULL,
	[TVAMOUNT] [numeric](19, 5) NULL,
	[IRLOWER] [numeric](19, 5) NULL,
	[IRUPPER] [numeric](19, 5) NULL,
	[EIRLOWER] [numeric](19, 5) NULL,
	[EIRUPPER] [numeric](19, 5) NULL,
	[WAIR] [numeric](19, 5) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DES_DBChangeLog]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DES_DBChangeLog](
	[DBChangeLogID] [int] IDENTITY(1,1) NOT NULL,
	[DatabaseName] [varchar](255) NULL,
	[EventType] [varchar](50) NULL,
	[ObjectName] [varchar](255) NULL,
	[ObjectType] [varchar](255) NULL,
	[SqlCommand] [varchar](max) NULL,
	[EventDate] [datetime] NULL,
	[LoginName] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[DBChangeLogID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BankIndustry_Industry]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BankIndustry_Industry](
	[Industry_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Industry_Code] [nvarchar](50) NOT NULL,
	[Industry_Name] [nvarchar](150) NOT NULL,
	[Industry_Label] [nvarchar](150) NULL,
	[Industry_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_BankIndustry_Industry] PRIMARY KEY CLUSTERED 
(
	[Industry_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BankIndustry_Type]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BankIndustry_Type](
	[Type_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Type_Code] [nvarchar](50) NOT NULL,
	[Type_Name] [nvarchar](150) NOT NULL,
	[Type_Label] [nvarchar](150) NULL,
	[Type_Sort] [int] NULL,
	[Industry_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_BankIndustry_Type] PRIMARY KEY CLUSTERED 
(
	[Type_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BankType_BankType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BankType_BankType](
	[BankType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[BankType_Code] [nvarchar](50) NOT NULL,
	[BankType_Name] [nvarchar](150) NOT NULL,
	[BankType_Label] [nvarchar](150) NULL,
	[BankType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_BankType_BankType] PRIMARY KEY CLUSTERED 
(
	[BankType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BES_BCI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_BCI](
	[BCI_Idx] [int] IDENTITY(1,1) NOT NULL,
	[BCI_Code] [nvarchar](150) NOT NULL,
	[BCI_Name] [nvarchar](150) NOT NULL,
	[BCI_Label] [nvarchar](150) NULL,
	[Institution/Country_Idx] [int] NOT NULL,
	[BCI_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_BES_BCI] PRIMARY KEY CLUSTERED 
(
	[BCI_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BES_BusinessType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_BusinessType](
	[BusinessType_Idx] [int] NULL,
	[BusinessType_Name] [nvarchar](255) NULL,
	[BusinessType_Label] [nvarchar](255) NULL,
	[BusinessType_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BES_EmploymentSize]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_EmploymentSize](
	[EmploymentSize_Idx] [int] NULL,
	[EmploymentSize_Name] [nvarchar](255) NULL,
	[EmploymentSize_Label] [nvarchar](255) NULL,
	[EmploymentSize_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BES_OtherCountry]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_OtherCountry](
	[Institution_Country_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Institution_Country_Code] [nvarchar](150) NOT NULL,
	[Institution_Country_Name] [nvarchar](150) NOT NULL,
	[Institution_Country_Label] [nvarchar](150) NULL,
	[Institution_Country_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_BES_Institution_Country] PRIMARY KEY CLUSTERED 
(
	[Institution_Country_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BES_RegionalTable_Section]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_RegionalTable_Section](
	[Section_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Section_Title] [nvarchar](255) NULL,
	[Section_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_BES_RegionalTable_Section] PRIMARY KEY CLUSTERED 
(
	[Section_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BES_RegionalTable_SubSection]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_RegionalTable_SubSection](
	[Subsection_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Subsection_Title] [nvarchar](255) NOT NULL,
	[Section_Idx] [int] NOT NULL,
	[Subsection_Sort] [int] NOT NULL,
 CONSTRAINT [PK_Dim_BES_RegionalTable_SubSection] PRIMARY KEY CLUSTERED 
(
	[Subsection_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BES_Template]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BES_Template](
	[Idx] [int] IDENTITY(1,1) NOT NULL,
	[Template_Name] [nvarchar](255) NULL,
	[Category] [nvarchar](255) NULL,
	[SubCategory] [nvarchar](255) NULL,
	[Template_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_BES_Template] PRIMARY KEY CLUSTERED 
(
	[Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BSPIS_CFASMapping]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BSPIS_CFASMapping](
	[Account_Idx] [int] IDENTITY(1,1) NOT NULL,
	[L1] [nvarchar](255) NULL,
	[L2] [nvarchar](255) NULL,
	[L3] [nvarchar](255) NULL,
	[L4] [nvarchar](255) NULL,
	[L5] [nvarchar](255) NULL,
	[L6] [nvarchar](255) NULL,
	[Account_Code] [nvarchar](50) NULL,
	[Active] [int] NOT NULL,
	[Created_Date] [date] NULL,
	[Modified_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BSPIS_FinalOutputMapping]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BSPIS_FinalOutputMapping](
	[Account_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Account_Name] [nvarchar](255) NULL,
	[Account_Description] [nvarchar](255) NULL,
	[Account_Sort] [int] NOT NULL,
	[Active] [int] NOT NULL,
	[Created_Date] [date] NULL,
	[Modified_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BSPIS_OutputMapping]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BSPIS_OutputMapping](
	[Account_Idx] [int] IDENTITY(1,1) NOT NULL,
	[L1] [nvarchar](255) NULL,
	[L2] [nvarchar](255) NULL,
	[L3] [nvarchar](255) NULL,
	[L4] [nvarchar](255) NULL,
	[L5] [nvarchar](255) NULL,
	[Account_Description] [nvarchar](255) NULL,
	[Active] [int] NOT NULL,
	[Created_Date] [date] NULL,
	[Modified_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BSPRateType_BSPRateType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BSPRateType_BSPRateType](
	[BSPRateType_Idx] [int] NOT NULL,
	[BSPRateType_Code] [nvarchar](50) NOT NULL,
	[BSPRateType_Name] [nvarchar](150) NOT NULL,
	[BSPRateType_Label] [nvarchar](150) NULL,
	[BSPRateType_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_BSPTenorsRate_BSPTenorsRate]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_BSPTenorsRate_BSPTenorsRate](
	[BSPTenorsRate_Idx] [int] NOT NULL,
	[BSPTenorsRate_Code] [nvarchar](50) NOT NULL,
	[BSPTenorsRate_Name] [nvarchar](150) NOT NULL,
	[BSPTenorsRate_Label] [nvarchar](150) NULL,
	[BSPTenorsRate_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CES_BuyingConditions]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CES_BuyingConditions](
	[BuyingConditions_Idx] [int] IDENTITY(1,1) NOT NULL,
	[BuyingConditions_Code] [nvarchar](50) NOT NULL,
	[BuyingConditions_Name] [nvarchar](150) NOT NULL,
	[BuyingConditions_Label] [nvarchar](150) NULL,
	[BuyingConditions_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_CES_BuyingConditions] PRIMARY KEY CLUSTERED 
(
	[BuyingConditions_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CES_Classification]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CES_Classification](
	[Classification_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Classification_Code] [nvarchar](50) NOT NULL,
	[Classification_Name] [nvarchar](150) NOT NULL,
	[Classification_Label] [nvarchar](150) NULL,
	[Classification_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_CES_Classification] PRIMARY KEY CLUSTERED 
(
	[Classification_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CES_DebtDesc]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CES_DebtDesc](
	[DebtDesc_Idx] [int] IDENTITY(1,1) NOT NULL,
	[DebtDesc_Code] [nvarchar](50) NOT NULL,
	[DebtDesc_Name] [nvarchar](150) NOT NULL,
	[DebtDesc_Label] [nvarchar](150) NULL,
	[DebtDesc_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
	[DebtDesc_LabelSort] [int] NULL,
 CONSTRAINT [PK_Dim_CES_DebtDesc] PRIMARY KEY CLUSTERED 
(
	[DebtDesc_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CES_Distribution1]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CES_Distribution1](
	[Distribution1_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Distribution1_Code] [nvarchar](150) NULL,
	[Distribution1_Name] [nvarchar](150) NOT NULL,
	[Distribution1_Label] [nvarchar](150) NULL,
	[Distribution1_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
	[Distribution1_LabelSort] [int] NULL,
 CONSTRAINT [PK_Dim_CES_Distribution1] PRIMARY KEY CLUSTERED 
(
	[Distribution1_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CES_Distribution2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CES_Distribution2](
	[Distribution2_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Distribution2_Code] [nvarchar](50) NOT NULL,
	[Distribution2_Name] [nvarchar](150) NOT NULL,
	[Distribution2_Label] [nvarchar](150) NULL,
	[Distribution2_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_CES_Distribution2] PRIMARY KEY CLUSTERED 
(
	[Distribution2_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CES_Distribution3]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CES_Distribution3](
	[Distribution3_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Distribution3_Code] [nvarchar](50) NOT NULL,
	[Distribution3_Name] [nvarchar](150) NOT NULL,
	[Distribution3_Label] [nvarchar](150) NULL,
	[Distribution3_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_CES_Distribution3] PRIMARY KEY CLUSTERED 
(
	[Distribution3_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CES_Distribution4]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CES_Distribution4](
	[Distribution4_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Distribution4_Code] [nvarchar](100) NULL,
	[Distribution4_Name] [nvarchar](150) NOT NULL,
	[Distribution4_Label] [nvarchar](150) NULL,
	[Distribution4_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
	[Distribution4_LabelSort] [int] NULL,
	[Distribution4_NSort] [int] NULL,
	[Distribution4_Group] [nvarchar](100) NULL,
	[Distribution4_GSort] [int] NULL,
 CONSTRAINT [PK_Dim_CES_Distribution4] PRIMARY KEY CLUSTERED 
(
	[Distribution4_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CES_HouseLot]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CES_HouseLot](
	[HouseLot_Idx] [int] IDENTITY(1,1) NOT NULL,
	[HouseLot_Code] [nvarchar](50) NOT NULL,
	[HouseLot_Name] [nvarchar](150) NOT NULL,
	[HouseLot_Label] [nvarchar](150) NULL,
	[HouseLot_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_CES_HouseLot] PRIMARY KEY CLUSTERED 
(
	[HouseLot_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CES_Indicator]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CES_Indicator](
	[Indicator_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Indicator_Code] [nvarchar](50) NOT NULL,
	[Indicator_Name] [nvarchar](150) NOT NULL,
	[Indicator_Label] [nvarchar](150) NULL,
	[Indicator_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_CES_Indicator] PRIMARY KEY CLUSTERED 
(
	[Indicator_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CES_OFWRemittance_Use]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CES_OFWRemittance_Use](
	[Use_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Use_Code] [nvarchar](50) NOT NULL,
	[Use_Name] [nvarchar](150) NOT NULL,
	[Use_Label] [nvarchar](150) NULL,
	[Use_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_CES_OFWRemittance_Use] PRIMARY KEY CLUSTERED 
(
	[Use_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CFASLIB_FA0150]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CFASLIB_FA0150](
	[F0150_Idx] [int] IDENTITY(1,1) NOT NULL,
	[F0150_Analysis_Type] [char](2) NULL,
	[F0150_Analysis_Code] [char](15) NULL,
	[F0150_Analysis_Description] [char](55) NULL,
	[F0150_Address1] [char](35) NULL,
	[F0150_Address2] [char](35) NULL,
	[F0150_Address3] [char](35) NULL,
	[F0150_CC_Mail_Address] [char](10) NULL,
	[F0150_Tax_Number] [char](15) NULL,
	[F0150_Analysis_Code_Active] [char](1) NULL,
	[F0150_Process_UserID] [char](10) NULL,
	[F0150_Date] [numeric](8, 0) NULL,
	[F0150_Time] [numeric](9, 0) NULL,
	[F0150_TerminalID] [char](15) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CFASLIB_FA0710]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CFASLIB_FA0710](
	[F0710_Idx] [int] IDENTITY(1,1) NOT NULL,
	[F0710_TRANSACTION_TYPE] [numeric](4, 0) NULL,
	[F0710_TRANSTYPE_DESC] [char](50) NULL,
	[F0710_TRANSTYPE_ABBR] [char](10) NULL,
	[F0710_PROCESS_USERID] [char](10) NULL,
	[F0710_DATE] [numeric](8, 0) NULL,
	[F0710_TIME] [numeric](9, 0) NULL,
	[F0710_TERMINALID] [char](15) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CFASLIB_FA0720]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CFASLIB_FA0720](
	[F0720_Idx] [int] IDENTITY(1,1) NOT NULL,
	[F0720_GL_ACCOUNT_CODE] [numeric](6, 0) NULL,
	[F0720_GL_ACCOUNT_DESC] [char](50) NULL,
	[F0720_ADD_DESC] [char](50) NULL,
	[F0720_GL_ACCOUNT_ABBR] [char](10) NULL,
	[F0720_GL_ACCOUNT_TYPE] [char](1) NULL,
	[F0720_SL_INDICATOR] [char](1) NULL,
	[F0720_ORGAUNIT_INDICATOR] [char](1) NULL,
	[F0720_OWNER_ORGAUNIT] [char](3) NULL,
	[F0720_FC_INDICATOR] [char](1) NULL,
	[F0720_FC_CODE] [char](3) NULL,
	[F0720_BULLION_INDICATOR] [char](1) NULL,
	[F0720_GL_ACCOUNT_ACTIVE] [char](1) NULL,
	[F0720_CHANGE_ORDER_NO] [numeric](4, 0) NULL,
	[F0720_CHANGE_ORDER_DATE] [numeric](8, 0) NULL,
	[F0720_NEW_GL_ACCOUNT_CODE] [numeric](6, 0) NULL,
	[F0720_PROCESS_USERID] [char](10) NULL,
	[F0720_DATE] [numeric](8, 0) NULL,
	[F0720_TIME] [numeric](9, 0) NULL,
	[F0720_TERMINALID] [char](15) NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CFASLIB_FA0730]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CFASLIB_FA0730](
	[F0730_Idx] [int] IDENTITY(1,1) NOT NULL,
	[F0730_GL_Account_Code] [numeric](6, 0) NULL,
	[F0730_SL_Code] [numeric](12, 0) NULL,
	[F0730_Add_Desc] [nvarchar](50) NULL,
	[F0730_SL_Desc] [nvarchar](50) NULL,
	[F0730_SL_Abbr] [nvarchar](10) NULL,
	[F0730_SL_Type] [nvarchar](2) NULL,
	[F0730_Analysis_Type] [nvarchar](2) NULL,
	[F0730_OrgaUnit_Indicator] [nvarchar](1) NULL,
	[F0730_FC_Code] [nvarchar](3) NULL,
	[F0730_FC_Indicator] [nvarchar](1) NULL,
	[F0730_SL_Code_Active] [nvarchar](1) NULL,
	[F0730_Change_Order_No] [numeric](4, 0) NULL,
	[F0730_Change_Order_Date] [numeric](8, 0) NULL,
	[F0730_New_SL_Code] [numeric](12, 0) NULL,
	[F0730_Process_UserID] [nvarchar](10) NULL,
	[F0730_Date] [numeric](8, 0) NULL,
	[F0730_Time] [numeric](9, 0) NULL,
	[F0730_TerminalID] [nvarchar](15) NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CFASLIB_FA0740]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CFASLIB_FA0740](
	[F0740_Idx] [int] IDENTITY(1,1) NOT NULL,
	[F0740_ORGAUNIT_CODE] [char](3) NOT NULL,
	[F0740_ORGAUNIT_DESC] [char](50) NOT NULL,
	[F0740_ORGAUNIT_ABBR] [char](10) NOT NULL,
	[F0740_LAST_TICKET_NO] [numeric](6, 0) NOT NULL,
	[F0740_DAY_END_CONFIRM] [char](1) NOT NULL,
	[F0740_MONTH_END_CONFIRM] [char](1) NOT NULL,
	[F0740_PROCESS_USERID] [char](10) NOT NULL,
	[F0740_DATE] [numeric](8, 0) NOT NULL,
	[F0740_TIME] [numeric](9, 0) NOT NULL,
	[F0740_TERMINALID] [char](15) NOT NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CFASLIB_FA0750]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CFASLIB_FA0750](
	[F0750_Idx] [int] IDENTITY(1,1) NOT NULL,
	[F0750_FC_CODE] [char](3) NOT NULL,
	[F0750_FC_DESC] [char](50) NOT NULL,
	[F0750_FC_ABBR] [char](10) NOT NULL,
	[F0750_INT_RESERVES] [char](1) NOT NULL,
	[F0750_PROCESS_USERID] [char](10) NOT NULL,
	[F0750_DATE] [numeric](8, 0) NOT NULL,
	[F0750_TIME] [numeric](9, 0) NOT NULL,
	[F0750_TERMINALID] [char](15) NOT NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CFASLIB_FA0890]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CFASLIB_FA0890](
	[F0890_Idx] [int] IDENTITY(1,1) NOT NULL,
	[FA0890_NOTE_TYPE] [char](3) NULL,
	[F0890_FORMAT_NUMBER] [numeric](3, 0) NULL,
	[F0890_REFERENCE_NUMBER] [numeric](3, 0) NULL,
	[F0890_SERIAL_NUMBER] [numeric](5, 0) NULL,
	[F0890_LINE_CONTROL] [char](3) NULL,
	[F0890_CONTROL_DETAIL] [char](2) NULL,
	[F0890_SIGN] [char](1) NULL,
	[F0890_ADVANCE] [numeric](1, 0) NULL,
	[F0890_TYPE] [char](2) NULL,
	[F0890_COLUMN] [numeric](1, 0) NULL,
	[F0890_INDENT] [numeric](1, 0) NULL,
	[F0890_DESC] [char](50) NULL,
	[F0890_FROM_GL_ACCTCODE] [numeric](6, 0) NULL,
	[F0890_TO_GL_ACCTCODE] [numeric](6, 0) NULL,
	[F0890_FROM_SL_CODE] [numeric](12, 0) NULL,
	[F0890_TO_SL_CODE] [numeric](12, 0) NULL,
	[F0890_PROCESS_USERID] [char](10) NULL,
	[F0890_DATE] [numeric](8, 0) NULL,
	[F0890_TIME] [numeric](9, 0) NULL,
	[F0890_TERMINALID] [char](15) NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_City]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_City](
	[City_Idx] [int] IDENTITY(1,1) NOT NULL,
	[City_Code] [nvarchar](50) NOT NULL,
	[City_Name] [nvarchar](150) NOT NULL,
	[City_Label] [nvarchar](150) NULL,
	[City_Sort] [int] NULL,
	[District_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_City] PRIMARY KEY CLUSTERED 
(
	[City_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Commodity]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Commodity](
	[Commodity_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Commodity_Code] [nvarchar](50) NOT NULL,
	[Commodity_Desc] [nvarchar](400) NOT NULL,
	[Commodity_Lvl] [int] NOT NULL,
	[Commodity_Sort] [int] NOT NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_Commodity] PRIMARY KEY CLUSTERED 
(
	[Commodity_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Commodity_CommoditySubtype]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Commodity_CommoditySubtype](
	[CommoditySubtype_Idx] [int] NOT NULL,
	[CommoditySubtype_Code] [nvarchar](150) NOT NULL,
	[CommoditySubtype_Name] [nvarchar](150) NOT NULL,
	[CommoditySubtype_Label] [nvarchar](150) NULL,
	[CommoditySubtype_Sort] [int] NULL,
	[CommodityType_Idx] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Commodity_CommodityType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Commodity_CommodityType](
	[CommodityType_Idx] [int] NOT NULL,
	[CommodityType_Code] [nvarchar](150) NOT NULL,
	[CommodityType_Name] [nvarchar](150) NOT NULL,
	[CommodityType_Label] [nvarchar](150) NULL,
	[CommodityType_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Company_Company]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Company_Company](
	[Company_Idx] [int] NOT NULL,
	[Company_Code] [nvarchar](50) NOT NULL,
	[Company_Name] [nvarchar](150) NOT NULL,
	[Company_Label] [nvarchar](150) NULL,
	[Company_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Company_Type]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Company_Type](
	[Type_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Type_Code] [nvarchar](50) NOT NULL,
	[Type_Name] [nvarchar](150) NOT NULL,
	[Type_Label] [nvarchar](150) NULL,
	[Type_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_Company_Type] PRIMARY KEY CLUSTERED 
(
	[Type_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Country]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Country](
	[Country_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Country_Code] [nvarchar](50) NOT NULL,
	[Country_Name] [nvarchar](150) NOT NULL,
	[Country_Label] [nvarchar](150) NULL,
	[Country_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Country] PRIMARY KEY CLUSTERED 
(
	[Country_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CountryofOrigin]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CountryofOrigin](
	[CountryOfOrigin_Idx] [int] IDENTITY(1,1) NOT NULL,
	[CountryOfOrigin_Code] [nvarchar](50) NOT NULL,
	[CountryOfOrigin_Name] [nvarchar](150) NOT NULL,
	[CountryOfOrigin_Label] [nvarchar](150) NULL,
	[CountryOfOrigin_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CPPI_ActualPropertyUse]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CPPI_ActualPropertyUse](
	[ActualPropertyUse_Idx] [int] IDENTITY(1,1) NOT NULL,
	[ActualPropertyUse_Code] [varchar](50) NOT NULL,
	[ActualPropertyUse_Name] [varchar](100) NOT NULL,
	[ActualPropertyUse_All] [varchar](50) NULL,
	[ActualPropertyUse_Label] [varchar](50) NOT NULL,
	[ActualPropertyUse_Sort] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CPPI_Area]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CPPI_Area](
	[Area_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Area_Code] [varchar](50) NOT NULL,
	[Area_Name] [varchar](100) NOT NULL,
	[Area_Label] [varchar](50) NOT NULL,
	[Area_Sort] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CPPI_CommercialCondoSpaceType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CPPI_CommercialCondoSpaceType](
	[CommercialCondoSpaceType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[CommercialCondoSpaceType_Code] [varchar](50) NOT NULL,
	[CommercialCondoSpaceType_Name] [varchar](100) NOT NULL,
	[CommercialCondoSpaceType_Label] [varchar](50) NOT NULL,
	[CommercialCondoSpaceType_Sort] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CPPI_GeoClass]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CPPI_GeoClass](
	[GeoClass_Idx] [int] IDENTITY(1,1) NOT NULL,
	[GeoClass_Code] [varchar](50) NOT NULL,
	[GeoClass_Name] [varchar](100) NOT NULL,
	[GeoClass_Label] [varchar](50) NOT NULL,
	[GeoClass_Sort] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CPPI_GeographicalClassification]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CPPI_GeographicalClassification](
	[Classification_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Classification_Code] [nvarchar](50) NOT NULL,
	[Classification_Name] [nvarchar](150) NOT NULL,
	[Classification_Label] [nvarchar](150) NULL,
	[Classification_Sort] [int] NULL,
	[NCR_OANCR] [nchar](10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CPPI_HABUPropertyClassification]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CPPI_HABUPropertyClassification](
	[HABUPropertyClassification_Idx] [int] IDENTITY(1,1) NOT NULL,
	[HABUPropertyClassification_Code] [varchar](50) NOT NULL,
	[HABUPropertyClassification_Name] [varchar](100) NOT NULL,
	[HABUPropertyClassification_Label] [varchar](50) NOT NULL,
	[HABUPropertyClassification_Sort] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CPPI_IslandGroup]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CPPI_IslandGroup](
	[IslandGroup_Idx] [int] IDENTITY(1,1) NOT NULL,
	[IslandGroup_Code] [varchar](50) NOT NULL,
	[IslandGroup_Name] [varchar](100) NOT NULL,
	[IslandGroup_Label] [varchar](50) NOT NULL,
	[IslandGroup_Sort] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CPPI_PropertyLocation]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CPPI_PropertyLocation](
	[PropertyLocation_Idx] [int] IDENTITY(1,1) NOT NULL,
	[PropertyLocation_Code] [varchar](100) NOT NULL,
	[PropertyLocation_Name] [varchar](100) NOT NULL,
	[PropertyLocation_Label] [varchar](100) NOT NULL,
	[PropertyLocation_Sort] [int] NOT NULL,
	[PropertyLocation_Region] [varchar](100) NOT NULL,
	[PropertyLocation_Province] [varchar](100) NOT NULL,
	[Overall] [varchar](50) NULL,
	[NCR/AONCR] [varchar](50) NULL,
	[IslandGroup] [varchar](50) NULL,
	[IslandGroup_Sort] [int] NULL,
	[RegionLevel1] [varchar](50) NULL,
	[RegionLevel1_Sort] [int] NULL,
	[RegionLevel2] [varchar](50) NULL,
	[RegionLevel2_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CPPI_PropertyType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CPPI_PropertyType](
	[PropertyType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[PropertyType_Code] [varchar](50) NOT NULL,
	[PropertyType_Name] [varchar](100) NOT NULL,
	[PropertyType_Label] [varchar](50) NOT NULL,
	[PropertyType_Sort] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CPPI_UseOfProperty]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CPPI_UseOfProperty](
	[UseProperty_Idx] [int] NULL,
	[UseProperty_Code] [nvarchar](50) NULL,
	[UseProperty_Name] [nvarchar](50) NULL,
	[UseProperty_Label] [nvarchar](50) NOT NULL,
	[UseProperty_Sort] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_CSOC_DIMENSION]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_CSOC_DIMENSION](
	[PARTICULAR_Idx] [int] IDENTITY(1,1) NOT NULL,
	[PARTICULARCODE] [nvarchar](255) NULL,
	[PARTICULAR DESCRIPTION] [nvarchar](255) NULL,
	[RECNO] [nvarchar](50) NULL,
	[TOTRESCODE] [nvarchar](20) NULL,
	[PARTICULAR_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
	[PARTICULAR_GROUP_CODE] [nvarchar](255) NULL,
	[PARTICULAR_GROUP_DESC] [nvarchar](255) NULL,
	[CSOC_GROUP] [nvarchar](255) NULL,
 CONSTRAINT [PK_Dim_PWN] PRIMARY KEY CLUSTERED 
(
	[PARTICULAR_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Currency_Currency]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Currency_Currency](
	[Currency_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Currency_Code] [nvarchar](50) NOT NULL,
	[Currency_Name] [nvarchar](150) NOT NULL,
	[Currency_Label] [nvarchar](150) NULL,
	[Currency_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Currency_Currency] PRIMARY KEY CLUSTERED 
(
	[Currency_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_District]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_District](
	[District_Idx] [int] IDENTITY(1,1) NOT NULL,
	[District_Code] [nvarchar](50) NOT NULL,
	[District_Name] [nvarchar](150) NOT NULL,
	[District_Label] [nvarchar](150) NULL,
	[District_Sort] [int] NULL,
	[Province_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_District] PRIMARY KEY CLUSTERED 
(
	[District_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_DSS_Sectors_Currency_DSS_Level1]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level1](
	[DSS_Level1_Idx] [int] IDENTITY(1,1) NOT NULL,
	[DSS_Level1_Code] [nvarchar](50) NOT NULL,
	[DSS_Level1_Name] [nvarchar](150) NOT NULL,
	[DSS_Level1_Label] [nvarchar](150) NULL,
	[DSS_Level1_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_DSS_Sectors_Currency_DSS_Level1] PRIMARY KEY CLUSTERED 
(
	[DSS_Level1_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_DSS_Sectors_Currency_DSS_Level2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level2](
	[DSS_Level2_Idx] [int] IDENTITY(1,1) NOT NULL,
	[DSS_Level2_Code] [nvarchar](50) NOT NULL,
	[DSS_Level2_Name] [nvarchar](150) NOT NULL,
	[DSS_Level2_Label] [nvarchar](150) NULL,
	[DSS_Level2_Sort] [int] NULL,
	[DSS_Level1_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_DSS_Sectors_Currency_DSS_Level2] PRIMARY KEY CLUSTERED 
(
	[DSS_Level2_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_DSS_Sectors_Currency_DSS_Level3]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level3](
	[DSS_Level3_Idx] [int] IDENTITY(1,1) NOT NULL,
	[DSS_Level3_Code] [nvarchar](50) NOT NULL,
	[DSS_Level3_Name] [nvarchar](150) NOT NULL,
	[DSS_Level3_Label] [nvarchar](150) NULL,
	[DSS_Level3_Sort] [int] NULL,
	[DSS_Level2_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_DSS_Sectors_Currency_DSS_Level3] PRIMARY KEY CLUSTERED 
(
	[DSS_Level3_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_DSS_Sectors_Currency_DSS_Level4]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level4](
	[DSS_Level4_Idx] [int] IDENTITY(1,1) NOT NULL,
	[DSS_Level4_Code] [nvarchar](50) NOT NULL,
	[DSS_Level4_Name] [nvarchar](150) NOT NULL,
	[DSS_Level4_Label] [nvarchar](150) NULL,
	[DSS_Level4_Sort] [int] NULL,
	[DSS_Level3_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_DSS_Sectors_Currency_DSS_Level4] PRIMARY KEY CLUSTERED 
(
	[DSS_Level4_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_DSS_Sectors_Currency_DSS_Level5]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level5](
	[DSS_Level5_Idx] [int] IDENTITY(1,1) NOT NULL,
	[DSS_Level5_Code] [nvarchar](50) NOT NULL,
	[DSS_Level5_Name] [nvarchar](150) NOT NULL,
	[DSS_Level5_Label] [nvarchar](150) NULL,
	[DSS_Level5_Sort] [int] NULL,
	[DSS_Level4_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_DSS_Sectors_Currency_DSS_Level5] PRIMARY KEY CLUSTERED 
(
	[DSS_Level5_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_DSS_Sectors_Currency_DSS_Level6]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level6](
	[DSS_Level6_Idx] [int] IDENTITY(1,1) NOT NULL,
	[DSS_Level6_Code] [nvarchar](50) NOT NULL,
	[DSS_Level6_Name] [nvarchar](150) NOT NULL,
	[DSS_Level6_Label] [nvarchar](150) NULL,
	[DSS_Level6_Sort] [int] NULL,
	[DSS_Level5_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_DSS_Sectors_Currency_DSS_Level6] PRIMARY KEY CLUSTERED 
(
	[DSS_Level6_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_DSS_Sectors_Currency_DSS_Level7]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level7](
	[DSS_Level7_Idx] [int] IDENTITY(1,1) NOT NULL,
	[DSS_Level7_Code] [nvarchar](50) NOT NULL,
	[DSS_Level7_Name] [nvarchar](150) NOT NULL,
	[DSS_Level7_Label] [nvarchar](150) NULL,
	[DSS_Level7_Sort] [int] NULL,
	[DSS_Level6_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_DSS_Sectors_Currency_DSS_Level7] PRIMARY KEY CLUSTERED 
(
	[DSS_Level7_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_EconomicActivityCode_EconomicActivityCode]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_EconomicActivityCode_EconomicActivityCode](
	[EconomicActivityCode_Idx] [int] IDENTITY(1,1) NOT NULL,
	[EconomicActivityCode_Code] [nvarchar](50) NOT NULL,
	[EconomicActivityCode_Name] [nvarchar](255) NULL,
	[EconomicActivityCode_Label] [nvarchar](255) NULL,
	[EconomicActivityCode_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_EconomicActivityCode_EconomicActivityCode] PRIMARY KEY CLUSTERED 
(
	[EconomicActivityCode_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_EnergySalesCategory_EnergySalesCategory]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_EnergySalesCategory_EnergySalesCategory](
	[EnergySalesCategory_Idx] [int] IDENTITY(1,1) NOT NULL,
	[EnergySalesCategory_Code] [nvarchar](50) NOT NULL,
	[EnergySalesCategory_Name] [nvarchar](150) NOT NULL,
	[EnergySalesCategory_Label] [nvarchar](150) NULL,
	[EnergySalesCategory_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_EnergySalesCategory_EnergySalesCategory] PRIMARY KEY CLUSTERED 
(
	[EnergySalesCategory_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_EnergySalesCategory_EnergySalesType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_EnergySalesCategory_EnergySalesType](
	[EnergySalesType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[EnergySalesType_Code] [nvarchar](50) NOT NULL,
	[EnergySalesType_Name] [nvarchar](150) NOT NULL,
	[EnergySalesType_Label] [nvarchar](150) NULL,
	[EnergySalesType_Sort] [int] NULL,
	[EnergySalesCategory_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_EnergySalesCategory_EnergySalesType] PRIMARY KEY CLUSTERED 
(
	[EnergySalesType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Equities]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Equities](
	[Equities_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Equities_Code] [nvarchar](50) NOT NULL,
	[Equities_Name] [nvarchar](150) NOT NULL,
	[Equities_Label] [nvarchar](150) NULL,
	[Equities_Sort] [int] NULL,
	[Shelf_Idx] [int] NOT NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_Equities] PRIMARY KEY CLUSTERED 
(
	[Equities_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_ESLIG_PovertyIndicator]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_ESLIG_PovertyIndicator](
	[PovertyCode_Idx] [int] NOT NULL,
	[PovertyCode] [nvarchar](255) NULL,
	[PovertyIndicatorName] [nvarchar](255) NULL,
	[PovertyIndicatorLevel] [nvarchar](255) NULL,
	[PovertyIndicatorSort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_FishType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_FishType](
	[FishType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[FishType_Code] [nvarchar](50) NOT NULL,
	[FishType_Name] [nvarchar](150) NOT NULL,
	[FishType_Label] [nvarchar](150) NULL,
	[FishType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_FishType] PRIMARY KEY CLUSTERED 
(
	[FishType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_FSICountries_FSICountries]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_FSICountries_FSICountries](
	[FSICountries_Idx] [int] IDENTITY(1,1) NOT NULL,
	[FSICountries_Code] [nvarchar](50) NOT NULL,
	[FSICountries_Name] [nvarchar](150) NOT NULL,
	[FSICountries_Label] [nvarchar](150) NULL,
	[FSICountries_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_FSICountries_FSICountries] PRIMARY KEY CLUSTERED 
(
	[FSICountries_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_GIR_IRFCL_TitleName]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_GIR_IRFCL_TitleName](
	[TitleName_Idx] [int] NOT NULL,
	[Code] [nvarchar](50) NULL,
	[Name] [nvarchar](255) NULL,
	[Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Grid]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Grid](
	[Location_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Location_Code] [nvarchar](50) NOT NULL,
	[Location_Name] [nvarchar](150) NOT NULL,
	[Location_Label] [nvarchar](150) NULL,
	[Location_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Location_Location] PRIMARY KEY CLUSTERED 
(
	[Location_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DIM_GSIS_SSS]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DIM_GSIS_SSS](
	[DBank_Idx] [int] NOT NULL,
	[DBank Codes] [nvarchar](255) NULL,
	[DBank Accounts Title] [nvarchar](255) NULL,
 CONSTRAINT [PK_DIM_GSIS_SSS] PRIMARY KEY CLUSTERED 
(
	[DBank_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Industry]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Industry](
	[Industry_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Industry_Code] [nvarchar](150) NULL,
	[Industry_Name] [nvarchar](150) NOT NULL,
	[Industry_Label] [nvarchar](150) NULL,
	[Industry_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_Industry] PRIMARY KEY CLUSTERED 
(
	[Industry_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Industry_Industry]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Industry_Industry](
	[Industry_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Industry_Code] [nvarchar](50) NOT NULL,
	[Industry_Name] [nvarchar](150) NOT NULL,
	[Industry_Label] [nvarchar](150) NULL,
	[Industry_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Industry_Industry] PRIMARY KEY CLUSTERED 
(
	[Industry_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_INS_INDUSTRY]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_INS_INDUSTRY](
	[BNKIND_Idx] [int] IDENTITY(1,1) NOT NULL,
	[BNKIND] [int] NOT NULL,
	[BNKIND_Code] [nvarchar](50) NOT NULL,
	[BNKIND_Name] [nvarchar](150) NOT NULL,
	[BNKIND_Label] [nvarchar](150) NULL,
	[BNKIND_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_INS_INDUSTRY] PRIMARY KEY CLUSTERED 
(
	[BNKIND_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Institution]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Institution](
	[Institution_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Institution_Code] [nvarchar](50) NOT NULL,
	[Institution_Name] [nvarchar](150) NOT NULL,
	[Institution_Label] [nvarchar](150) NULL,
	[Institution_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Institution] PRIMARY KEY CLUSTERED 
(
	[Institution_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Investors_Investors_Level1]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Investors_Investors_Level1](
	[Investors_Level1_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Investors_Level1_Code] [nvarchar](50) NOT NULL,
	[Investors_Level1_Name] [nvarchar](150) NOT NULL,
	[Investors_Level1_Label] [nvarchar](150) NULL,
	[Investors_Level1_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Investors_Investors_Level1] PRIMARY KEY CLUSTERED 
(
	[Investors_Level1_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Investors_Investors_Level2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Investors_Investors_Level2](
	[Investors_Level2_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Investors_Level2_Code] [nvarchar](50) NOT NULL,
	[Investors_Level2_Name] [nvarchar](150) NOT NULL,
	[Investors_Level2_Label] [nvarchar](150) NULL,
	[Investors_Level2_Sort] [int] NULL,
	[Investors_Level1_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_Investors_Investors_Level2] PRIMARY KEY CLUSTERED 
(
	[Investors_Level2_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Investors_Investors_Level3]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Investors_Investors_Level3](
	[Investors_Level3_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Investors_Level3_Code] [nvarchar](50) NOT NULL,
	[Investors_Level3_Name] [nvarchar](150) NOT NULL,
	[Investors_Level3_Label] [nvarchar](150) NULL,
	[Investors_Level3_Sort] [int] NULL,
	[Investors_Level2_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_Investors_Investors_Level3] PRIMARY KEY CLUSTERED 
(
	[Investors_Level3_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Investors_Investors_Level4]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Investors_Investors_Level4](
	[Investors_Level4_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Investors_Level4_Code] [nvarchar](50) NOT NULL,
	[Investors_Level4_Name] [nvarchar](150) NOT NULL,
	[Investors_Level4_Label] [nvarchar](150) NULL,
	[Investors_Level4_Sort] [int] NULL,
	[Investors_Level3_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_Investors_Investors_Level4] PRIMARY KEY CLUSTERED 
(
	[Investors_Level4_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_IslandGroup]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_IslandGroup](
	[IslandGroup_Idx] [int] IDENTITY(1,1) NOT NULL,
	[IslandGroup_Code] [nvarchar](50) NOT NULL,
	[IslandGroup_Name] [nvarchar](150) NOT NULL,
	[IslandGroup_Label] [nvarchar](150) NULL,
	[IslandGroup_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Location_IslandGroup] PRIMARY KEY CLUSTERED 
(
	[IslandGroup_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Issuer_Issuer]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Issuer_Issuer](
	[Issuer_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Issuer_Code] [nvarchar](50) NOT NULL,
	[Issuer_Name] [nvarchar](150) NOT NULL,
	[Issuer_Label] [nvarchar](150) NULL,
	[Issuer_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Issuer_Issuer] PRIMARY KEY CLUSTERED 
(
	[Issuer_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_ITR_IBCLType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_ITR_IBCLType](
	[IBCLType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[IBCLType_Code] [nvarchar](150) NOT NULL,
	[IBCLType_Name] [nvarchar](150) NOT NULL,
	[IBCLType_Label] [nvarchar](150) NULL,
	[IBCLType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_ITR_IBCLType] PRIMARY KEY CLUSTERED 
(
	[IBCLType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_ITR_LendingSubType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_ITR_LendingSubType](
	[LendingSubType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[LendingSubType_Code] [nvarchar](150) NOT NULL,
	[LendingSubType_Name] [nvarchar](150) NOT NULL,
	[LendingSubType_Label] [nvarchar](150) NULL,
	[LendingSubType_Sort] [int] NULL,
	[LendingType_Code] [nvarchar](150) NULL,
 CONSTRAINT [PK_Dim_ITR_LendingSubType] PRIMARY KEY CLUSTERED 
(
	[LendingSubType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_ITR_LendingType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_ITR_LendingType](
	[LendingType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[LendingType_Code] [nvarchar](150) NOT NULL,
	[LendingType_Name] [nvarchar](150) NOT NULL,
	[LendingType_Label] [nvarchar](150) NULL,
	[LendingType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_ITR_LendingType] PRIMARY KEY CLUSTERED 
(
	[LendingType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_ITR_Rates]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_ITR_Rates](
	[Rates_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Rates_Code] [nvarchar](150) NOT NULL,
	[Rates_Name] [nvarchar](150) NOT NULL,
	[Rates_Label] [nvarchar](150) NULL,
	[Rates_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_ITR_Rates] PRIMARY KEY CLUSTERED 
(
	[Rates_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_LaborForce]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_LaborForce](
	[LaborForce_Idx] [int] NOT NULL,
	[LaborForce_Code] [nvarchar](50) NOT NULL,
	[LaborForce_Name] [nvarchar](150) NOT NULL,
	[LaborForce_Label] [nvarchar](150) NULL,
	[LaborForce_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_LaborForce_Indicator]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_LaborForce_Indicator](
	[Indicator_Idx] [int] NOT NULL,
	[Indicator_Code] [nvarchar](50) NOT NULL,
	[Indicator_Name] [nvarchar](150) NOT NULL,
	[Indicator_Label] [nvarchar](150) NULL,
	[Indicator_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_LaborStat_ASType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_LaborStat_ASType](
	[ASType_Idx] [int] NOT NULL,
	[ASType_Code] [nvarchar](50) NOT NULL,
	[ASType_Name] [nvarchar](150) NOT NULL,
	[ASType_Label] [nvarchar](150) NULL,
	[ASType_Sort] [int] NULL,
	[ESType_Idx] [int] NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_LaborStat_ESType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_LaborStat_ESType](
	[ESType_Idx] [int] NOT NULL,
	[ESType_Code] [nvarchar](50) NOT NULL,
	[ESType_Name] [nvarchar](150) NOT NULL,
	[ESType_Label] [nvarchar](150) NULL,
	[ESType_Sort] [int] NULL,
	[LSType_Idx] [int] NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_LaborStat_LSType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_LaborStat_LSType](
	[LSType_Idx] [int] NOT NULL,
	[LSType_Code] [nvarchar](50) NOT NULL,
	[LSType_Name] [nvarchar](150) NOT NULL,
	[LSType_Label] [nvarchar](150) NULL,
	[LSType_Sort] [int] NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Location_City]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Location_City](
	[City_Idx] [int] NOT NULL,
	[City_Code] [nvarchar](50) NOT NULL,
	[City_Name] [nvarchar](150) NOT NULL,
	[City_Label] [nvarchar](150) NULL,
	[City_Sort] [int] NULL,
	[Province_Idx] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Location_MajorIslandGroup]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Location_MajorIslandGroup](
	[MajorIslandGroup_Idx] [int] NOT NULL,
	[MajorIslandGroup_Code] [nvarchar](50) NOT NULL,
	[MajorIslandGroup_Name] [nvarchar](150) NOT NULL,
	[MajorIslandGroup_Label] [nvarchar](150) NULL,
	[MajorIslandGroup_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Location_MajorIslandGroup] PRIMARY KEY CLUSTERED 
(
	[MajorIslandGroup_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Location_Province]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Location_Province](
	[Province_Idx] [int] NOT NULL,
	[Province_Code] [nvarchar](50) NOT NULL,
	[Province_Name] [nvarchar](150) NOT NULL,
	[Province_Label] [nvarchar](150) NULL,
	[Province_Sort] [int] NULL,
	[Region_Idx] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Location_RegionTag]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Location_RegionTag](
	[RegionTag_Idx] [int] IDENTITY(1,1) NOT NULL,
	[RegionTag_Code] [nvarchar](50) NOT NULL,
	[RegionTag_Name] [nvarchar](400) NOT NULL,
	[RegionTag_Label] [nvarchar](400) NOT NULL,
	[RegionTag_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Location_RegionTag] PRIMARY KEY CLUSTERED 
(
	[RegionTag_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_LWR_AType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_LWR_AType](
	[AType_Idx] [int] NOT NULL,
	[AType_Code] [nvarchar](50) NOT NULL,
	[AType_Name] [nvarchar](150) NOT NULL,
	[AType_Label] [nvarchar](150) NULL,
	[AType_Sort] [int] NULL,
	[LType_Idx] [int] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_LWR_LType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_LWR_LType](
	[LType_Idx] [int] NOT NULL,
	[LType_Code] [nvarchar](50) NOT NULL,
	[LType_Name] [nvarchar](150) NOT NULL,
	[LType_Label] [nvarchar](150) NULL,
	[LType_Sort] [int] NULL,
	[LWRType_Idx] [int] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_LWR_LWRType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_LWR_LWRType](
	[LWRType_Idx] [int] NOT NULL,
	[LWRType_Code] [nvarchar](50) NOT NULL,
	[LWRType_Name] [nvarchar](150) NOT NULL,
	[LWRType_Label] [nvarchar](150) NULL,
	[LWRType_Sort] [int] NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MacroAssumptions_Type_MacroAssumptions_Type]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MacroAssumptions_Type_MacroAssumptions_Type](
	[MacroAssumptions_Type_Idx] [int] IDENTITY(1,1) NOT NULL,
	[MacroAssumptions_Type_Code] [nvarchar](50) NOT NULL,
	[MacroAssumptions_Type_Name] [nvarchar](150) NOT NULL,
	[MacroAssumptions_Type_Label] [nvarchar](150) NULL,
	[MacroAssumptions_Type_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_MacroAssumptions_Type_MacroAssumptions_Type] PRIMARY KEY CLUSTERED 
(
	[MacroAssumptions_Type_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_ManufacturingCustomerType_ManufacturingCustomerType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_ManufacturingCustomerType_ManufacturingCustomerType](
	[ManufacturingCustomerType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[ManufacturingCustomerType_Code] [nvarchar](50) NOT NULL,
	[ManufacturingCustomerType_Name] [nvarchar](150) NOT NULL,
	[ManufacturingCustomerType_Label] [nvarchar](150) NULL,
	[ManufacturingCustomerType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_ManufacturingCustomerType_ManufacturingCustomerType] PRIMARY KEY CLUSTERED 
(
	[ManufacturingCustomerType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Meralco_SalesCategory_Meralco_SalesCategory]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Meralco_SalesCategory_Meralco_SalesCategory](
	[Meralco_SalesCategory_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Meralco_SalesCategory_Code] [nvarchar](50) NOT NULL,
	[Meralco_SalesCategory_Name] [nvarchar](150) NOT NULL,
	[Meralco_SalesCategory_Label] [nvarchar](150) NULL,
	[Meralco_SalesCategory_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Meralco_SalesCategory_Meralco_SalesCategory] PRIMARY KEY CLUSTERED 
(
	[Meralco_SalesCategory_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Meralco_SalesCategory_Meralco_SalesType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Meralco_SalesCategory_Meralco_SalesType](
	[Meralco_SalesType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Meralco_SalesType_Code] [nvarchar](50) NOT NULL,
	[Meralco_SalesType_Name] [nvarchar](150) NOT NULL,
	[Meralco_SalesType_Label] [nvarchar](150) NULL,
	[Meralco_SalesType_Sort] [int] NULL,
	[Meralco_SalesCategory_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_Meralco_SalesCategory_Meralco_SalesType] PRIMARY KEY CLUSTERED 
(
	[Meralco_SalesType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MFSG_NBFI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MFSG_NBFI](
	[RecNo_Idx] [int] IDENTITY(1,1) NOT NULL,
	[RecNo_Code] [nvarchar](150) NOT NULL,
	[RecNo_Name] [nvarchar](150) NOT NULL,
	[RecNo_Label] [nvarchar](150) NULL,
	[RecNo_Sort] [int] NULL,
	[INDUSTRY_GROUP] [nvarchar](150) NULL,
	[Level_1] [nvarchar](150) NULL,
	[Level_2] [nvarchar](150) NULL,
	[Level_3] [nvarchar](150) NULL,
	[Level_4] [nvarchar](150) NULL,
	[Account Tittle] [nvarchar](150) NULL,
 CONSTRAINT [PK_Dim_MFSG_NBFI_RecNo] PRIMARY KEY CLUSTERED 
(
	[RecNo_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MFSG_OFCS_Output_Mapping]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MFSG_OFCS_Output_Mapping](
	[4SRcode_Idx] [int] IDENTITY(1,1) NOT NULL,
	[4SRLEVEL1] [nvarchar](255) NULL,
	[4SRLEVEL2] [nvarchar](255) NULL,
	[4SRLEVEL3] [nvarchar](255) NULL,
	[4SRLEVEL4] [nvarchar](255) NULL,
	[4SRLEVEL5] [nvarchar](255) NULL,
	[4SRLEVEL6] [nvarchar](255) NULL,
	[4SRLEVEL7] [nvarchar](255) NULL,
	[IFS_CODE] [nvarchar](255) NULL,
	[SORT] [int] NULL,
 CONSTRAINT [PK_Dim4SR_LEVEL] PRIMARY KEY CLUSTERED 
(
	[4SRcode_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MISSI_ManufactureType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MISSI_ManufactureType](
	[ManufactureType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[ManufactureType_Code] [nvarchar](150) NOT NULL,
	[ManufactureType_Name] [nvarchar](150) NOT NULL,
	[ManufactureType_Label] [nvarchar](150) NULL,
	[ManufactureType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_ManufactureType] PRIMARY KEY CLUSTERED 
(
	[ManufactureType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MM_BSCode]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MM_BSCode](
	[BS_Idx] [int] IDENTITY(1,1) NOT NULL,
	[BS_Code] [nvarchar](150) NOT NULL,
	[BS_Name] [nvarchar](150) NOT NULL,
	[BS_Label] [nvarchar](150) NULL,
	[BS_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_BS] PRIMARY KEY CLUSTERED 
(
	[BS_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MM_ICCode]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MM_ICCode](
	[IC_Idx] [int] IDENTITY(1,1) NOT NULL,
	[IC_Code] [nvarchar](150) NOT NULL,
	[IC_Name] [nvarchar](150) NOT NULL,
	[IC_Label] [nvarchar](150) NULL,
	[IC_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_IC] PRIMARY KEY CLUSTERED 
(
	[IC_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MM_IRCode]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MM_IRCode](
	[IR_Idx] [int] IDENTITY(1,1) NOT NULL,
	[IR_Code] [nvarchar](150) NOT NULL,
	[IR_Name] [nvarchar](150) NOT NULL,
	[IR_Label] [nvarchar](150) NULL,
	[IR_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_IR] PRIMARY KEY CLUSTERED 
(
	[IR_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MM_MPCode]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MM_MPCode](
	[MP_Idx] [int] IDENTITY(1,1) NOT NULL,
	[MP_Code] [nvarchar](150) NOT NULL,
	[MP_Name] [nvarchar](150) NOT NULL,
	[MP_Label] [nvarchar](150) NULL,
	[MP_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_MP] PRIMARY KEY CLUSTERED 
(
	[MP_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MM_TCCode]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MM_TCCode](
	[TC_Idx] [int] IDENTITY(1,1) NOT NULL,
	[TC_Code] [nvarchar](150) NOT NULL,
	[TC_Name] [nvarchar](150) NOT NULL,
	[TC_Label] [nvarchar](150) NULL,
	[TC_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_TC] PRIMARY KEY CLUSTERED 
(
	[TC_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_MonthValue]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_MonthValue](
	[Month] [int] NULL,
	[MonthName] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Nat_EconomicActivity]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Nat_EconomicActivity](
	[EconomicActivity_Idx] [int] IDENTITY(1,1) NOT NULL,
	[EconomicActivity_Code] [nvarchar](50) NOT NULL,
	[EconomicActivity_Name] [nvarchar](150) NOT NULL,
	[EconomicActivity_Label] [nvarchar](150) NULL,
	[EconomicActivity_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_EconomicActivity] PRIMARY KEY CLUSTERED 
(
	[EconomicActivity_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Nat_GCFType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Nat_GCFType](
	[GCFType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[GCFType_Code] [nvarchar](150) NOT NULL,
	[GCFType_Name] [nvarchar](150) NOT NULL,
	[GCFType_Label] [nvarchar](150) NULL,
	[SubSectorType_Idx] [int] NULL,
	[GCFType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_GCFType] PRIMARY KEY CLUSTERED 
(
	[GCFType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Nat_HFCEType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Nat_HFCEType](
	[HFCEType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[HFCEType_Code] [nvarchar](150) NOT NULL,
	[HFCEType_Name] [nvarchar](150) NOT NULL,
	[HFCEType_Label] [nvarchar](150) NULL,
	[HFCEType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_HFCEType] PRIMARY KEY CLUSTERED 
(
	[HFCEType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Nat_Sector]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Nat_Sector](
	[Sector_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Sector_Code] [nvarchar](50) NOT NULL,
	[Sector_Name] [nvarchar](150) NOT NULL,
	[Sector_Label] [nvarchar](150) NULL,
	[EconomicActivity_Idx] [int] NOT NULL,
	[Sector_Sort] [int] NULL,
	[Sector_Label2] [varchar](255) NULL,
	[Sector_Label_AC] [nvarchar](150) NULL,
 CONSTRAINT [PK_Dim_Nat_Sector] PRIMARY KEY CLUSTERED 
(
	[Sector_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Nat_SubSector]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Nat_SubSector](
	[SubSector_Idx] [int] IDENTITY(1,1) NOT NULL,
	[SubSector_Code] [nvarchar](150) NOT NULL,
	[SubSector_Name] [nvarchar](150) NOT NULL,
	[SubSector_Label] [nvarchar](150) NULL,
	[SubSector_Sort] [int] NULL,
	[Sector_Idx] [int] NULL,
	[SubSector_Label2] [varchar](255) NULL,
	[SubSector_Label3] [varchar](255) NULL,
	[Subector_Label_AC] [nvarchar](150) NULL,
 CONSTRAINT [PK_Dim_Nat_SubSector] PRIMARY KEY CLUSTERED 
(
	[SubSector_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Nat_SubSectorType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Nat_SubSectorType](
	[SubSectorType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[SubSectorType_Code] [nvarchar](150) NOT NULL,
	[SubSectorType_Name] [nvarchar](150) NOT NULL,
	[SubSectorType_Label] [nvarchar](150) NULL,
	[SubSectorType_Sort] [int] NULL,
	[SubSector_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_SubSectorType] PRIMARY KEY CLUSTERED 
(
	[SubSectorType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_NBFIBankKind]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_NBFIBankKind](
	[NBFIBankKind_Idx] [int] NOT NULL,
	[NBFIBankKind_Code] [nvarchar](50) NOT NULL,
	[NBFIBankKind_Name] [nvarchar](250) NOT NULL,
	[NBFIBankKind_Label] [nvarchar](250) NULL,
	[NBFIBankKind_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_NBFIParticular]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_NBFIParticular](
	[NBFIParticular_Idx] [int] NOT NULL,
	[Particular_Code] [nvarchar](200) NOT NULL,
	[Particular_Name] [nvarchar](250) NOT NULL,
	[Particular_level] [nvarchar](250) NULL,
	[Particular_Sort] [int] NULL,
	[Table] [nvarchar](50) NULL,
	[Particular_Group_code] [nvarchar](20) NULL,
	[Particular_Group] [nvarchar](50) NULL,
	[Particular_Type] [nvarchar](20) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_NBFIReport]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_NBFIReport](
	[NBFIReport_Idx] [int] NOT NULL,
	[NBFIReport_Code] [nvarchar](50) NOT NULL,
	[NBFIReport_Name] [nvarchar](250) NOT NULL,
	[NBFIReport_Label] [nvarchar](250) NULL,
	[NBFIReport_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_NSSLA_ACCOUNT]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_NSSLA_ACCOUNT](
	[ACCOUNT_Idx] [int] IDENTITY(1,1) NOT NULL,
	[PARTICULAR DESCRIPTION] [nvarchar](255) NULL,
	[PARTICULARCODE] [nvarchar](255) NULL,
	[ACCOUNT] [nvarchar](50) NULL,
	[TOTRESCODE] [nvarchar](20) NULL,
	[ACCOUNT_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
	[PARTICULAR_GROUP_CODE] [nvarchar](255) NULL,
	[PARTICULAR_GROUP_DESC] [nvarchar](255) NULL,
	[INDUSTRY_GROUP] [nvarchar](255) NULL,
 CONSTRAINT [PK_Dim_NSSLA] PRIMARY KEY CLUSTERED 
(
	[ACCOUNT_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_NUMFIN_Branch]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_NUMFIN_Branch](
	[Branch_Idx] [int] NOT NULL,
	[Branch_Code] [varchar](100) NOT NULL,
	[Branch_Name] [varchar](100) NOT NULL,
	[Branch_Label] [varchar](100) NOT NULL,
	[Branch_Sort] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_NUMFIN_FI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_NUMFIN_FI](
	[FI_Idx] [int] NOT NULL,
	[FI_Code] [varchar](100) NOT NULL,
	[FI_Name] [varchar](100) NOT NULL,
	[FI_Label] [varchar](100) NOT NULL,
	[FI_Sort] [int] NOT NULL,
	[FI_Parent_Idx] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_OFCS_FRPTI_Account]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_OFCS_FRPTI_Account](
	[Account_Code_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Account_Code] [nvarchar](255) NULL,
	[Account_ID] [nvarchar](255) NULL,
	[Account_Name] [nvarchar](255) NULL,
	[Account_Schedule] [nvarchar](255) NULL,
	[Code_Main_Code] [nvarchar](255) NULL,
	[Account_TAG] [nvarchar](255) NULL,
 CONSTRAINT [PK_ACCOUNT_CODE] PRIMARY KEY CLUSTERED 
(
	[Account_Code_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_OFCS_IFSCodeMapping]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_OFCS_IFSCodeMapping](
	[IFS_Idx] [int] IDENTITY(1,1) NOT NULL,
	[IC_Code] [nvarchar](255) NULL,
	[IC_Main_Code] [nvarchar](255) NULL,
	[GCG_Code] [nvarchar](255) NULL,
	[GCG_Main_Code] [nvarchar](255) NULL,
	[SEC_code] [nvarchar](255) NULL,
	[SEC_Main_Code] [nvarchar](255) NULL,
	[TRUST_Code] [nvarchar](255) NULL,
	[TRUST_Main_Code] [nvarchar](255) NULL,
	[NBWQB] [nvarchar](255) NULL,
	[NBWQB_Main_Code] [nvarchar](255) NULL,
	[IFS_Code] [nvarchar](255) NULL,
	[Account Description] [nvarchar](255) NULL,
	[Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_OFCS_Mapping]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_OFCS_Mapping](
	[RECNO_CODE_Idx] [int] IDENTITY(1,1) NOT NULL,
	[RECNO_CODE] [nvarchar](255) NULL,
	[RECNO] [nvarchar](255) NULL,
	[BNKIND] [nvarchar](255) NULL,
	[DESC] [nvarchar](255) NULL,
	[IFS_CODE] [nvarchar](255) NULL,
 CONSTRAINT [PK_DimRECNO_CODE] PRIMARY KEY CLUSTERED 
(
	[RECNO_CODE_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_OnshoreGSIssuances_OnshoreGSIssuances]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_OnshoreGSIssuances_OnshoreGSIssuances](
	[OnshoreGSIssuances_Idx] [int] IDENTITY(1,1) NOT NULL,
	[OnshoreGSIssuances_Code] [nvarchar](50) NOT NULL,
	[OnshoreGSIssuances_Name] [nvarchar](150) NOT NULL,
	[OnshoreGSIssuances_Label] [nvarchar](150) NULL,
	[OnshoreGSIssuances_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_OnshoreGSIssuances_OnshoreGSIssuances] PRIMARY KEY CLUSTERED 
(
	[OnshoreGSIssuances_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_OPI_CommodityType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_OPI_CommodityType](
	[CommodityType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[CommodityType_Code] [nvarchar](150) NOT NULL,
	[CommodityType_Name] [nvarchar](150) NOT NULL,
	[CommodityType_Label] [nvarchar](150) NULL,
	[CommodityType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Nat_CommodityType] PRIMARY KEY CLUSTERED 
(
	[CommodityType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_PlantType_PlantType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_PlantType_PlantType](
	[PlantType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[PlantType_Code] [nvarchar](50) NOT NULL,
	[PlantType_Name] [nvarchar](150) NOT NULL,
	[PlantType_Label] [nvarchar](150) NULL,
	[PlantType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_PlantType_PlantType] PRIMARY KEY CLUSTERED 
(
	[PlantType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_PMICategory]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_PMICategory](
	[PMICategory_Idx] [int] IDENTITY(1,1) NOT NULL,
	[PMICategory_Code] [nvarchar](50) NOT NULL,
	[PMICategory_Name] [nvarchar](150) NOT NULL,
	[PMICategory_Sort] [int] NULL,
	[PMICategory_Sub] [nvarchar](50) NULL,
 CONSTRAINT [PK_Dim_PMICategory] PRIMARY KEY CLUSTERED 
(
	[PMICategory_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_PMISector]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_PMISector](
	[Sector_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Sector_Code] [nvarchar](50) NOT NULL,
	[Sector_Name] [nvarchar](150) NOT NULL,
	[Sector_Label] [nvarchar](150) NULL,
	[Sector_Sort] [int] NULL,
	[PMICategory_idx] [int] NULL,
 CONSTRAINT [PK_Dim_SectorType] PRIMARY KEY CLUSTERED 
(
	[Sector_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Port]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Port](
	[Port_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Port_Code] [nvarchar](50) NOT NULL,
	[Port_Name] [nvarchar](150) NOT NULL,
	[Port_Label] [nvarchar](150) NULL,
	[Port_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Production_Category]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Production_Category](
	[Production_Category_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Production_Category_Code] [nvarchar](50) NOT NULL,
	[Production_Category_Name] [nvarchar](150) NOT NULL,
	[Production_Category_Label] [nvarchar](150) NULL,
	[Production_Category_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Production_Category] PRIMARY KEY CLUSTERED 
(
	[Production_Category_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Production_SubCategory]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Production_SubCategory](
	[Production_SubCategory_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Production_SubCategory_Code] [nvarchar](50) NOT NULL,
	[Production_SubCategory_Name] [nvarchar](150) NOT NULL,
	[Production_SubCategory_Label] [nvarchar](150) NULL,
	[Production_SubCategory_Sort] [int] NULL,
	[Production_Category_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_Production_SubCategory] PRIMARY KEY CLUSTERED 
(
	[Production_SubCategory_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Province]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Province](
	[Province_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Province_Code] [nvarchar](50) NOT NULL,
	[Province_Name] [nvarchar](150) NOT NULL,
	[Province_Label] [nvarchar](150) NULL,
	[Province_Sort] [int] NULL,
	[Region_Idx] [int] NULL,
 CONSTRAINT [PK_Dim_Province] PRIMARY KEY CLUSTERED 
(
	[Province_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_PurposeofCredit_PurposeofCredit]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_PurposeofCredit_PurposeofCredit](
	[PurposeofCredit_Idx] [int] IDENTITY(1,1) NOT NULL,
	[PurposeofCredit_Code] [nvarchar](50) NOT NULL,
	[PurposeofCredit_Name] [nvarchar](150) NOT NULL,
	[PurposeofCredit_Label] [nvarchar](150) NULL,
	[PurposeofCredit_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_PurposeofCredit_PurposeofCredit] PRIMARY KEY CLUSTERED 
(
	[PurposeofCredit_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Reg_SubType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Reg_SubType](
	[SubType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[SubType_Code] [nvarchar](50) NOT NULL,
	[SubType_Name] [nvarchar](150) NOT NULL,
	[SubType_Label] [nvarchar](150) NULL,
	[SubType_Sort] [int] NULL,
	[Type_Idx] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_Reg_SubType] PRIMARY KEY CLUSTERED 
(
	[SubType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Reg_Type]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Reg_Type](
	[Type_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Type_Code] [nvarchar](50) NOT NULL,
	[Type_Name] [nvarchar](150) NOT NULL,
	[Type_Label] [nvarchar](150) NULL,
	[Type_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_Reg_Type] PRIMARY KEY CLUSTERED 
(
	[Type_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Region]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Region](
	[Region_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Region_Code] [nvarchar](50) NOT NULL,
	[Region_Name] [nvarchar](150) NOT NULL,
	[Region_Label] [nvarchar](150) NULL,
	[Region_Label2] [nvarchar](150) NULL,
	[Region_Sort] [int] NULL,
	[IslandGroup_Idx] [int] NULL,
	[Region_Label4] [varchar](200) NULL,
 CONSTRAINT [PK_Dim_Region] PRIMARY KEY CLUSTERED 
(
	[Region_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Region_Region]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Region_Region](
	[Region_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Region_Code] [nvarchar](50) NOT NULL,
	[Region_Name] [nvarchar](150) NOT NULL,
	[Region_Label] [nvarchar](150) NULL,
	[Region_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_Region_Region] PRIMARY KEY CLUSTERED 
(
	[Region_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Regionbk]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Regionbk](
	[Region_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Region_Code] [nvarchar](50) NOT NULL,
	[Region_Name] [nvarchar](150) NOT NULL,
	[Region_Label] [nvarchar](150) NULL,
	[Region_Label2] [nvarchar](150) NULL,
	[Region_Sort] [int] NULL,
	[IslandGroup_Idx] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_ResidentType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_ResidentType](
	[ResidentType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[ResidentType_Code] [nvarchar](50) NOT NULL,
	[ResidentType_Name] [nvarchar](150) NOT NULL,
	[ResidentType_Label] [nvarchar](150) NULL,
	[ResidentType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_ResidentType] PRIMARY KEY CLUSTERED 
(
	[ResidentType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_RiceType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_RiceType](
	[RiceType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[RiceType_Code] [nvarchar](255) NOT NULL,
	[RiceType_Name] [nvarchar](255) NULL,
	[RiceType_Label] [nvarchar](255) NULL,
	[RiceType_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SALNType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SALNType](
	[SALN_Idx] [int] NOT NULL,
	[SALNCode] [nvarchar](255) NULL,
	[SALNType] [nvarchar](255) NULL,
	[SALNLevel] [nvarchar](255) NULL,
	[SALNGroup] [nvarchar](255) NULL,
	[SALNSort] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Sector]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Sector](
	[Sector_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Sector_Code] [nvarchar](50) NOT NULL,
	[Sector_Name] [nvarchar](150) NOT NULL,
	[Sector_Label] [nvarchar](150) NULL,
	[Sector_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
	[Group_Idx] [int] NULL,
	[Active] [int] NULL,
 CONSTRAINT [PK_Dim_Sector] PRIMARY KEY CLUSTERED 
(
	[Sector_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Sector_Group]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Sector_Group](
	[Group_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Group_Code] [nvarchar](50) NOT NULL,
	[Group_Name] [nvarchar](150) NOT NULL,
	[Group_Label] [nvarchar](150) NULL,
	[Group_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_Sector_Group] PRIMARY KEY CLUSTERED 
(
	[Group_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SectorType_SectorType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SectorType_SectorType](
	[SectorType_Idx] [int] NOT NULL,
	[SectorType_Code] [nvarchar](50) NOT NULL,
	[SectorType_Name] [nvarchar](150) NOT NULL,
	[SectorType_Label] [nvarchar](150) NULL,
	[SectorType_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Shelf]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Shelf](
	[Shelf_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Shelf_Code] [nvarchar](50) NOT NULL,
	[Shelf_Name] [nvarchar](150) NOT NULL,
	[Shelf_Label] [nvarchar](150) NULL,
	[Shelf_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_Shelf] PRIMARY KEY CLUSTERED 
(
	[Shelf_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_AssetSize]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_AssetSize](
	[AssetSize_Idx] [int] IDENTITY(1,1) NOT NULL,
	[AssetSizeCode] [nvarchar](50) NULL,
	[AssetSizeName] [nvarchar](50) NULL,
	[AssetSizeGroup] [nvarchar](50) NULL,
	[AssetSizeSort] [int] NULL,
 CONSTRAINT [PK_Dim_SLOSAssetSize_Idx_Idx] PRIMARY KEY CLUSTERED 
(
	[AssetSize_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_AssetSize_TYPE]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_AssetSize_TYPE](
	[ASSETTYPE_Idx] [int] IDENTITY(1,1) NOT NULL,
	[ASSETTYPE_Code] [nvarchar](255) NULL,
	[ASSETTYPE_Name] [nvarchar](255) NULL,
	[ASSETTYPE_Desc] [nvarchar](255) NULL,
	[ASSETTYPE_Group] [nvarchar](255) NULL,
	[ASSETTYPE_Sort] [int] NULL,
 CONSTRAINT [ASSETTYPE_LVT_Idx] PRIMARY KEY CLUSTERED 
(
	[ASSETTYPE_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_CreditStandard_Factors]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_CreditStandard_Factors](
	[CreditStandardFactors_Idx] [int] IDENTITY(1,1) NOT NULL,
	[CreditStandardFactorsCode] [nvarchar](50) NULL,
	[CreditStandardFactorsName] [nvarchar](255) NULL,
	[CreditStandardFactorsDesc] [nvarchar](255) NULL,
	[CreditStandardFactorsSort] [int] NULL,
	[CreditStandardFactorGroup] [nvarchar](255) NULL,
 CONSTRAINT [PK_Dim_SLOSCreditStandardFactors_Idx_Idx] PRIMARY KEY CLUSTERED 
(
	[CreditStandardFactors_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_CreditStandard_Factors_v1]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_CreditStandard_Factors_v1](
	[CreditStandardFactors_Idx] [int] IDENTITY(1,1) NOT NULL,
	[CreditStandardFactorsCode] [nvarchar](50) NULL,
	[CreditStandardFactorsName] [nvarchar](255) NULL,
	[CreditStandardFactorsDesc] [nvarchar](255) NULL,
	[CreditStandardFactorsSort] [int] NULL,
	[CreditStandardFactorGroup] [nvarchar](255) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_LVT]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_LVT](
	[LVT_Idx] [int] IDENTITY(1,1) NOT NULL,
	[LVTCODE] [nvarchar](50) NULL,
	[LVTNAME] [nvarchar](50) NULL,
	[LVTGROUP] [nvarchar](50) NULL,
	[LVTSORT] [int] NULL,
 CONSTRAINT [PK_Dim_SLOSLVT_Idx] PRIMARY KEY CLUSTERED 
(
	[LVT_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_MarketEnterpriseType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_MarketEnterpriseType](
	[Market_Idx] [int] IDENTITY(1,1) NOT NULL,
	[MarketCode] [nvarchar](50) NULL,
	[MarketName] [nvarchar](50) NULL,
	[MarketDesc] [nvarchar](50) NULL,
	[MarkertSort] [int] NULL,
	[MarketSortSub] [int] NULL,
	[QuestionCategoryCode] [nvarchar](10) NULL,
 CONSTRAINT [PK_Dim_SLOSMarket_Idx] PRIMARY KEY CLUSTERED 
(
	[Market_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_MarketEnterpriseType2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_MarketEnterpriseType2](
	[Market_Idx] [int] IDENTITY(1,1) NOT NULL,
	[MarketCode] [nvarchar](50) NULL,
	[MarketName] [nvarchar](50) NULL,
	[MarketDesc] [nvarchar](50) NULL,
	[MarkertSort] [int] NULL,
	[MarketSortSub] [int] NULL,
	[QuestionCategoryCode] [nvarchar](10) NULL,
	[MarketSort2] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_Question]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_Question](
	[Question_Idx] [int] IDENTITY(1,1) NOT NULL,
	[QuestionCode] [nvarchar](10) NULL,
	[QuestionName] [nvarchar](300) NULL,
	[QuestionDesc] [nvarchar](300) NULL,
	[QuestionCategoryCode] [nvarchar](255) NULL,
	[QuestionCategorySort] [int] NULL,
 CONSTRAINT [PK_Dim_SLOSQuestion_Idx_Idx] PRIMARY KEY CLUSTERED 
(
	[Question_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_Question_Group]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_Question_Group](
	[QuestionGroup_Idx] [int] IDENTITY(1,1) NOT NULL,
	[QuestionGroup_Code]  AS ([QuestionGroup_Idx]),
	[QuestionGroup_Name] [nvarchar](150) NULL,
	[QuestionGroup_Label] [nvarchar](150) NULL,
	[QuestionGroup_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_QuestionnaireCategory]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_QuestionnaireCategory](
	[QuestionnaireCategory_Idx] [int] IDENTITY(1,1) NOT NULL,
	[QuestionnaireCategoryCode] [nvarchar](10) NULL,
	[QuestionnaireID] [nvarchar](100) NULL,
	[QuestionnaireCategory] [nvarchar](100) NULL,
	[QuestionnaireName] [nvarchar](100) NULL,
	[QuestionTypeSort] [int] NULL,
 CONSTRAINT [PK_Dim_SLOSQuestionnaireCategory_Idx_] PRIMARY KEY CLUSTERED 
(
	[QuestionnaireCategory_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SLOS_QuestionType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SLOS_QuestionType](
	[QuestionType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[QuestionTypeCode] [nvarchar](20) NULL,
	[QuestionTypeName] [nvarchar](300) NULL,
	[QuestionTypeDesc] [nvarchar](300) NULL,
	[QuestionTypeSort] [int] NULL,
 CONSTRAINT [PK_Dim_SLOSQuestionType_Idx_] PRIMARY KEY CLUSTERED 
(
	[QuestionType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_STATBUL_BanksParticularAccount]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_STATBUL_BanksParticularAccount](
	[BankParticularAccount_Idx] [int] NOT NULL,
	[BankParticularAccount_Code] [nvarchar](200) NOT NULL,
	[BankParticularAccount] [nvarchar](250) NOT NULL,
	[BankParticularAccount_Group] [nvarchar](250) NULL,
	[BankParticularAccount_Type] [nvarchar](20) NULL,
	[IndustryGroup_Code] [nvarchar](10) NULL,
	[BankParticularAccount_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_STATBUL_Industry]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_STATBUL_Industry](
	[Industry_Idx] [int] NOT NULL,
	[IndustryCode] [nvarchar](10) NOT NULL,
	[IndustryName] [nvarchar](150) NOT NULL,
	[IndustryLabel] [nvarchar](150) NULL,
	[IndustryGroup] [nvarchar](100) NULL,
	[IndustryGroup_Name] [nvarchar](100) NULL,
	[IndustrySOrt] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_STATBUL_Institution]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_STATBUL_Institution](
	[Institution_Idx] [int] NOT NULL,
	[InstitutionCode] [nvarchar](20) NULL,
	[InstitutionName] [nvarchar](50) NULL,
	[InstitutionLevel] [nvarchar](50) NULL,
	[InstitutionGroup] [nvarchar](50) NULL,
	[InstitutionSort] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_STATBUL_StatementType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_STATBUL_StatementType](
	[StatementType_Idx] [int] NOT NULL,
	[StatementCode] [nvarchar](200) NOT NULL,
	[StatementName] [nvarchar](200) NOT NULL,
	[StatementParticular] [nvarchar](250) NOT NULL,
	[StatementSort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_STATBULDepositeAcountType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_STATBULDepositeAcountType](
	[DepositeAcountType_Idx] [int] NOT NULL,
	[DepositeAcountType_Code] [nvarchar](10) NOT NULL,
	[DepositeAcountType_Name] [nvarchar](150) NOT NULL,
	[DepositeAcountType_Label] [nvarchar](150) NULL,
	[DepositeAcountType_Group] [nvarchar](100) NULL,
	[DepositeAcountType_Sort] [int] NULL,
	[IndustryGroup_Name] [nvarchar](150) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_SurveyDesc]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_SurveyDesc](
	[SurveyDesc_Idx] [int] IDENTITY(1,1) NOT NULL,
	[SurveyDesc_Code] [nvarchar](50) NOT NULL,
	[SurveyDesc_Name] [nvarchar](150) NOT NULL,
	[SurveyDesc_Label] [nvarchar](150) NULL,
	[SurveyDesc_Sort] [int] NULL,
	[Created_Date] [date] NOT NULL,
 CONSTRAINT [PK_Dim_SurveyDesc] PRIMARY KEY CLUSTERED 
(
	[SurveyDesc_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_TBills_Tenor]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_TBills_Tenor](
	[Tenor_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Tenor_Code] [nvarchar](50) NOT NULL,
	[Tenor_Name] [nvarchar](150) NOT NULL,
	[Tenor_Label] [nvarchar](150) NULL,
	[Tenor_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_TBills_Tenor] PRIMARY KEY CLUSTERED 
(
	[Tenor_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_TBKinds]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_TBKinds](
	[TBKind_Idx] [int] NOT NULL,
	[TBCode] [nvarchar](100) NULL,
	[TBName] [nvarchar](100) NULL,
	[TBKinds] [nvarchar](100) NULL,
	[TBGroups] [nvarchar](100) NULL,
	[TBSort] [float] NULL,
	[PFSParticular_Idx] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_TBonds_Instrument]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_TBonds_Instrument](
	[Instrument_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Instrument_Code] [nvarchar](50) NOT NULL,
	[Instrument_Name] [nvarchar](150) NOT NULL,
	[Instrument_Label] [nvarchar](150) NULL,
	[Instrument_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_TBonds_Instrument] PRIMARY KEY CLUSTERED 
(
	[Instrument_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_TBonds_Tenor]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_TBonds_Tenor](
	[Tenor_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Tenor_Code] [nvarchar](50) NOT NULL,
	[Tenor_Name] [nvarchar](150) NOT NULL,
	[Tenor_Label] [nvarchar](150) NULL,
	[Tenor_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_TBonds_Tenor] PRIMARY KEY CLUSTERED 
(
	[Tenor_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Time_1]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Time_1](
	[Time_Idx] [int] NOT NULL,
	[Date_Code] [datetime] NULL,
	[Date_Name] [nvarchar](150) NULL,
	[Date_Label] [nvarchar](150) NULL,
	[Date_Sort] [int] NULL,
	[Week_Code] [nvarchar](50) NULL,
	[Week_Name] [nvarchar](150) NULL,
	[Week_Sort] [int] NULL,
	[Period_Code] [nvarchar](50) NULL,
	[Period_Name] [nvarchar](150) NULL,
	[Period_Sort] [int] NULL,
	[Quarter_Code] [nvarchar](50) NULL,
	[Quarter_Name] [nvarchar](150) NULL,
	[Quarter_Sort] [int] NULL,
	[Semester_Code] [nvarchar](50) NULL,
	[Semester_Name] [nvarchar](150) NULL,
	[Semester_Sort] [int] NULL,
	[Year_Code] [nvarchar](50) NULL,
	[Year_Name] [nvarchar](150) NULL,
	[Year_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Time_2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Time_2](
	[Time_Idx] [int] NOT NULL,
	[Date_Code] [nvarchar](50) NOT NULL,
	[Date_Name] [nvarchar](150) NULL,
	[Date_Label] [nvarchar](150) NULL,
	[Date_Sort] [int] NULL,
	[Week_Code] [nvarchar](50) NULL,
	[Week_Name] [nvarchar](150) NULL,
	[Week_Sort] [int] NULL,
	[Period_Code] [nvarchar](50) NULL,
	[Period_Name] [nvarchar](150) NULL,
	[Period_Sort] [int] NULL,
	[Quarter_Code] [nvarchar](50) NULL,
	[Quarter_Name] [nvarchar](150) NULL,
	[Quarter_Sort] [int] NULL,
	[Semester_Code] [nvarchar](50) NULL,
	[Semester_Name] [nvarchar](150) NULL,
	[Semester_Sort] [int] NULL,
	[Year_Code] [nvarchar](50) NULL,
	[Year_Name] [nvarchar](150) NULL,
	[Year_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Time_Auction]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Time_Auction](
	[Time_Idx] [int] NOT NULL,
	[Date_Code] [nvarchar](50) NOT NULL,
	[Date_Name] [nvarchar](150) NULL,
	[Date_Label] [nvarchar](150) NULL,
	[Date_Sort] [int] NULL,
	[Week_Code] [nvarchar](50) NULL,
	[Week_Name] [nvarchar](150) NULL,
	[Week_Sort] [int] NULL,
	[Period_Code] [nvarchar](50) NULL,
	[Period_Name] [nvarchar](150) NULL,
	[Period_Sort] [int] NULL,
	[Quarter_Code] [nvarchar](50) NULL,
	[Quarter_Name] [nvarchar](150) NULL,
	[Quarter_Sort] [int] NULL,
	[Semester_Code] [nvarchar](50) NULL,
	[Semester_Name] [nvarchar](150) NULL,
	[Semester_Sort] [int] NULL,
	[Year_Code] [nvarchar](50) NULL,
	[Year_Name] [nvarchar](150) NULL,
	[Year_Sort] [int] NULL,
	[Month_Name] [nvarchar](50) NULL,
	[YearToDate_Name] [nvarchar](150) NULL,
	[Month_SName] [nvarchar](50) NULL,
	[YearToDate_SName] [nvarchar](50) NULL,
	[Month_Sort] [int] NULL,
	[ActualDate] [datetime] NOT NULL,
	[Year] [int] NOT NULL,
	[Quarter] [int] NOT NULL,
	[Month] [int] NOT NULL,
	[Week] [int] NOT NULL,
	[DayofYear] [int] NOT NULL,
	[DayofMonth] [int] NOT NULL,
	[DayofWeek] [int] NOT NULL,
	[IsWeekend] [bit] NOT NULL,
	[IsHoliday] [bit] NULL,
	[BusinessYearWeek] [int] NOT NULL,
	[LeapYear] [tinyint] NOT NULL,
	[Month_YTDSname] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Time_Maturity]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Time_Maturity](
	[Time_Idx] [int] NOT NULL,
	[Date_Code] [nvarchar](50) NOT NULL,
	[Date_Name] [nvarchar](150) NULL,
	[Date_Label] [nvarchar](150) NULL,
	[Date_Sort] [int] NULL,
	[Week_Code] [nvarchar](50) NULL,
	[Week_Name] [nvarchar](150) NULL,
	[Week_Sort] [int] NULL,
	[Period_Code] [nvarchar](50) NULL,
	[Period_Name] [nvarchar](150) NULL,
	[Period_Sort] [int] NULL,
	[Quarter_Code] [nvarchar](50) NULL,
	[Quarter_Name] [nvarchar](150) NULL,
	[Quarter_Sort] [int] NULL,
	[Semester_Code] [nvarchar](50) NULL,
	[Semester_Name] [nvarchar](150) NULL,
	[Semester_Sort] [int] NULL,
	[Year_Code] [nvarchar](50) NULL,
	[Year_Name] [nvarchar](150) NULL,
	[Year_Sort] [int] NULL,
	[Month_Name] [nvarchar](50) NULL,
	[YearToDate_Name] [nvarchar](150) NULL,
	[Month_SName] [nvarchar](50) NULL,
	[YearToDate_SName] [nvarchar](50) NULL,
	[Month_Sort] [int] NULL,
	[ActualDate] [datetime] NOT NULL,
	[Year] [int] NOT NULL,
	[Quarter] [int] NOT NULL,
	[Month] [int] NOT NULL,
	[Week] [int] NOT NULL,
	[DayofYear] [int] NOT NULL,
	[DayofMonth] [int] NOT NULL,
	[DayofWeek] [int] NOT NULL,
	[IsWeekend] [bit] NOT NULL,
	[IsHoliday] [bit] NULL,
	[BusinessYearWeek] [int] NOT NULL,
	[LeapYear] [tinyint] NOT NULL,
	[Month_YTDSname] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Time_old]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Time_old](
	[Time_Idx] [int] IDENTITY(1,1) NOT NULL,
	[ActualDate] [datetime] NOT NULL,
	[Year] [int] NOT NULL,
	[Quarter] [int] NOT NULL,
	[Month] [int] NOT NULL,
	[Week] [int] NOT NULL,
	[DayofYear] [int] NOT NULL,
	[DayofMonth] [int] NOT NULL,
	[DayofWeek] [int] NOT NULL,
	[IsWeekend] [bit] NOT NULL,
	[IsHoliday] [bit] NULL,
	[BusinessYearWeek] [int] NOT NULL,
	[LeapYear] [tinyint] NOT NULL,
 CONSTRAINT [PK_Dim_Time_Time] PRIMARY KEY CLUSTERED 
(
	[Time_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Time_Settlement]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Time_Settlement](
	[Time_Idx] [int] NOT NULL,
	[Date_Code] [nvarchar](50) NOT NULL,
	[Date_Name] [nvarchar](150) NULL,
	[Date_Label] [nvarchar](150) NULL,
	[Date_Sort] [int] NULL,
	[Week_Code] [nvarchar](50) NULL,
	[Week_Name] [nvarchar](150) NULL,
	[Week_Sort] [int] NULL,
	[Period_Code] [nvarchar](50) NULL,
	[Period_Name] [nvarchar](150) NULL,
	[Period_Sort] [int] NULL,
	[Quarter_Code] [nvarchar](50) NULL,
	[Quarter_Name] [nvarchar](150) NULL,
	[Quarter_Sort] [int] NULL,
	[Semester_Code] [nvarchar](50) NULL,
	[Semester_Name] [nvarchar](150) NULL,
	[Semester_Sort] [int] NULL,
	[Year_Code] [nvarchar](50) NULL,
	[Year_Name] [nvarchar](150) NULL,
	[Year_Sort] [int] NULL,
	[Month_Name] [nvarchar](50) NULL,
	[YearToDate_Name] [nvarchar](150) NULL,
	[Month_SName] [nvarchar](50) NULL,
	[YearToDate_SName] [nvarchar](50) NULL,
	[Month_Sort] [int] NULL,
	[ActualDate] [datetime] NOT NULL,
	[Year] [int] NOT NULL,
	[Quarter] [int] NOT NULL,
	[Month] [int] NOT NULL,
	[Week] [int] NOT NULL,
	[DayofYear] [int] NOT NULL,
	[DayofMonth] [int] NOT NULL,
	[DayofWeek] [int] NOT NULL,
	[IsWeekend] [bit] NOT NULL,
	[IsHoliday] [bit] NULL,
	[BusinessYearWeek] [int] NOT NULL,
	[LeapYear] [tinyint] NOT NULL,
	[Month_YTDSname] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Time_Time_dcg]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Time_Time_dcg](
	[Time_Idx] [int] IDENTITY(1,1) NOT NULL,
	[ActualDate] [datetime] NOT NULL,
	[Year] [int] NOT NULL,
	[Quarter] [int] NOT NULL,
	[Month] [int] NOT NULL,
	[Week] [int] NOT NULL,
	[DayofYear] [int] NOT NULL,
	[DayofMonth] [int] NOT NULL,
	[DayofWeek] [int] NOT NULL,
	[IsWeekend] [bit] NOT NULL,
	[IsHoliday] [bit] NULL,
	[BusinessYearWeek] [int] NOT NULL,
	[LeapYear] [tinyint] NOT NULL,
 CONSTRAINT [PK_Dim_Time] PRIMARY KEY CLUSTERED 
(
	[Time_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_Time2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_Time2](
	[Time_Idx] [int] NOT NULL,
	[Date_Code] [nvarchar](50) NOT NULL,
	[Date_Name] [nvarchar](150) NULL,
	[Date_Label] [nvarchar](150) NULL,
	[Date_Sort] [int] NULL,
	[Week_Code] [nvarchar](50) NULL,
	[Week_Name] [nvarchar](150) NULL,
	[Week_Sort] [int] NULL,
	[Period_Code] [nvarchar](50) NULL,
	[Period_Name] [nvarchar](150) NULL,
	[Period_Sort] [int] NULL,
	[Quarter_Code] [nvarchar](50) NULL,
	[Quarter_Name] [nvarchar](150) NULL,
	[Quarter_Sort] [int] NULL,
	[Semester_Code] [nvarchar](50) NULL,
	[Semester_Name] [nvarchar](150) NULL,
	[Semester_Sort] [int] NULL,
	[Year_Code] [nvarchar](50) NULL,
	[Year_Name] [nvarchar](150) NULL,
	[Year_Sort] [int] NULL,
	[Month_Name] [nvarchar](50) NULL,
	[YearToDate_Name] [nvarchar](150) NULL,
	[Month_SName] [nvarchar](50) NULL,
	[YearToDate_SName] [nvarchar](50) NULL,
	[Month_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_TypeOfBorrower_TypeOfBorrower]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_TypeOfBorrower_TypeOfBorrower](
	[TypeOfBorrower_Idx] [int] IDENTITY(1,1) NOT NULL,
	[TypeOfBorrower_Code] [nvarchar](50) NOT NULL,
	[TypeOfBorrower_Name] [nvarchar](150) NOT NULL,
	[TypeOfBorrower_Label] [nvarchar](150) NULL,
	[TypeOfBorrower_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_TypeOfBorrower_TypeOfBorrower] PRIMARY KEY CLUSTERED 
(
	[TypeOfBorrower_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_TypeOfCredit_TypeOfCredit]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_TypeOfCredit_TypeOfCredit](
	[TypeOfCredit_Idx] [int] IDENTITY(1,1) NOT NULL,
	[TypeOfCredit_Code] [nvarchar](50) NOT NULL,
	[TypeOfCredit_Name] [nvarchar](150) NOT NULL,
	[TypeOfCredit_Label] [nvarchar](150) NULL,
	[TypeOfCredit_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_TypeOfCredit_TypeOfCredit] PRIMARY KEY CLUSTERED 
(
	[TypeOfCredit_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dim_WoodType]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dim_WoodType](
	[WoodType_Idx] [int] IDENTITY(1,1) NOT NULL,
	[WoodType_Code] [nvarchar](50) NOT NULL,
	[WoodType_Name] [nvarchar](150) NOT NULL,
	[WoodType_Label] [nvarchar](150) NULL,
	[WoodType_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_WoodType] PRIMARY KEY CLUSTERED 
(
	[WoodType_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EDWAuditLog]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EDWAuditLog](
	[DBName] [nvarchar](255) NOT NULL,
	[TBLName] [nvarchar](255) NOT NULL,
	[ETLAction] [nvarchar](255) NOT NULL,
	[ETLCount] [int] NOT NULL,
	[TimeStamp] [datetime] NOT NULL,
	[Details] [nvarchar](255) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EDWETLParam]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EDWETLParam](
	[GRPName] [nvarchar](50) NULL,
	[DTStart] [nvarchar](50) NULL,
	[DTEnd] [nvarchar](50) NULL,
	[IsActive] [nvarchar](50) NULL,
	[Status] [nvarchar](50) NULL,
	[use_DTEnd] [bit] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_GLobalWeights]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_GLobalWeights](
	[Time_Idx] [int] NOT NULL,
	[Subsector_Idx] [int] NOT NULL,
	[Sector_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[Global_Weights] [numeric](33, 20) NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_Date] [datetime] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical](
	[Time_Idx] [int] NOT NULL,
	[HighInterestRate] [float] NULL,
	[UnclearEconomicLaws] [float] NULL,
	[LackofEquipment] [float] NULL,
	[InsufficientDemand] [float] NULL,
	[AccesstoCredit] [float] NULL,
	[FinancialProblems] [float] NULL,
	[Competition] [float] NULL,
	[LaborProblems] [float] NULL,
	[LackofMaterialsInput] [float] NULL,
	[Others] [float] NULL,
	[None] [float] NULL,
	[CQ_P$ExchangeRate_Index] [float] NULL,
	[NQ_P$ExchangeRate_Index] [float] NULL,
	[N12M_P$ExchangeRate_Index] [float] NULL,
	[CQ_InflationRate_Index] [float] NULL,
	[NQ_InflationRate_Index] [float] NULL,
	[N12M_InflationRate_Index] [float] NULL,
	[CQ_PesoBorrowingRate_Index] [float] NULL,
	[NQ_PesoBorrowingRate_Index] [float] NULL,
	[N12M_PesoBorrowingRate_Index] [float] NULL,
	[CQ_InflationRateExpectations] [float] NULL,
	[NQ_InflationRateExpectations] [float] NULL,
	[N12M_InflationRateExpectations] [float] NULL,
	[CQ_ExchangeRateExpectations] [float] NULL,
	[NQ_ExchangeRateExpectations] [float] NULL,
	[N12M_ExchangeRateExpectations] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical_ByRegion]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical_ByRegion](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[CQ_CI] [float] NULL,
	[NQ_CI] [float] NULL,
	[N12M_CI] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical_ByRegion_RegionalLevels]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical_ByRegion_RegionalLevels](
	[Time_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[CQ_CI] [float] NULL,
	[NQ_CI] [float] NULL,
	[N12M_CI] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical_ByRegion2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical_ByRegion2](
	[Time_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[CQ_CI] [float] NULL,
	[NQ_CI] [float] NULL,
	[N12M_CI] [float] NULL,
	[CQImproving_Count] [int] NULL,
	[CQNoChange_Count] [int] NULL,
	[CQDeteriorating_Count] [int] NULL,
	[CQNoAnswer_Count] [int] NULL,
	[CQTotal_Count] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical_BySubsector]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical_BySubsector](
	[Time_Idx] [int] NOT NULL,
	[Sector_Idx] [int] NOT NULL,
	[Subsector_Idx] [int] NOT NULL,
	[CQ_CI] [float] NULL,
	[NQ_CI] [float] NULL,
	[N12M_CI] [float] NULL,
	[CQ_VoBA_Index] [float] NULL,
	[NQ_VoBA_Index] [float] NULL,
	[N12M_VoBA_Index] [float] NULL,
	[CQ_VoTOB_Index] [float] NULL,
	[CQ_CA_Index] [float] NULL,
	[CQ_FC_Index] [float] NULL,
	[NQ_EO_Index] [float] NULL,
	[N12M_EO_Index] [float] NULL,
	[AVG_CU] [float] NULL,
	[NQ_EP] [float] NULL,
	[N12M_EP] [float] NULL,
	[Respondent_Count] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical_BySubsector_RegionalLevels]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical_BySubsector_RegionalLevels](
	[Time_Idx] [int] NOT NULL,
	[Region__Idx] [int] NOT NULL,
	[Sector_Idx] [int] NOT NULL,
	[Subsector_Idx] [int] NOT NULL,
	[CQ_CI] [float] NULL,
	[NQ_CI] [float] NULL,
	[N12M_CI] [float] NULL,
	[CQ_VoBA_Index] [float] NULL,
	[NQ_VoBA_Index] [float] NULL,
	[N12M_VoBA_Index] [float] NULL,
	[CQ_VoTOB_Index] [float] NULL,
	[CQ_CA_Index] [float] NULL,
	[CQ_FC_Index] [float] NULL,
	[NQ_EO_Index] [float] NULL,
	[N12M_EO_Index] [float] NULL,
	[AVG_CU] [float] NULL,
	[NQ_EP] [float] NULL,
	[N12M_EP] [float] NULL,
	[Respondent_Count] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical_BySubsector_RegionalLevels_BAK]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical_BySubsector_RegionalLevels_BAK](
	[Time_Idx] [int] NOT NULL,
	[Region__Idx] [int] NOT NULL,
	[Sector_Idx] [int] NOT NULL,
	[Subsector_Idx] [int] NOT NULL,
	[CQ_CI] [float] NULL,
	[NQ_CI] [float] NULL,
	[N12M_CI] [float] NULL,
	[CQ_VoBA_Index] [float] NULL,
	[NQ_VoBA_Index] [float] NULL,
	[N12M_VoBA_Index] [float] NULL,
	[CQ_VoTOB_Index] [float] NULL,
	[CQ_CA_Index] [float] NULL,
	[CQ_FC_Index] [float] NULL,
	[NQ_EO_Index] [float] NULL,
	[N12M_EO_Index] [float] NULL,
	[AVG_CU] [float] NULL,
	[NQ_EP] [float] NULL,
	[N12M_EP] [float] NULL,
	[Respondent_Count] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical_EmploymentSize]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical_EmploymentSize](
	[Time_Idx] [int] NOT NULL,
	[Category] [nvarchar](255) NULL,
	[CQ_Index] [float] NULL,
	[NQ_Index] [float] NULL,
	[N12M_Index] [float] NULL,
	[Respondent_Count] [int] NULL,
	[Respondent%] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical_EmploymentSize_RegionalLevels]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical_EmploymentSize_RegionalLevels](
	[Time_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[Category] [nvarchar](255) NULL,
	[Respondent%] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical_ImportExportCat]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical_ImportExportCat](
	[Time_Idx] [int] NOT NULL,
	[Category] [nvarchar](255) NULL,
	[CQ_Index] [float] NULL,
	[NQ_Index] [float] NULL,
	[N12M_Index] [float] NULL,
	[Respondent_Count] [int] NULL,
	[Respondent%] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Historical_RegionalLevels]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Historical_RegionalLevels](
	[Time_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[HighInterestRate] [float] NULL,
	[UnclearEconomicLaws] [float] NULL,
	[LackofEquipment] [float] NULL,
	[InsufficientDemand] [float] NULL,
	[AccesstoCredit] [float] NULL,
	[FinancialProblems] [float] NULL,
	[Competition] [float] NULL,
	[LaborProblems] [float] NULL,
	[LackofMaterialsInput] [float] NULL,
	[Others] [float] NULL,
	[None] [float] NULL,
	[CQ_P$ExchangeRate_Index] [float] NULL,
	[NQ_P$ExchangeRate_Index] [float] NULL,
	[N12M_P$ExchangeRate_Index] [float] NULL,
	[CQ_InflationRate_Index] [float] NULL,
	[NQ_InflationRate_Index] [float] NULL,
	[N12M_InflationRate_Index] [float] NULL,
	[CQ_PesoBorrowingRate_Index] [float] NULL,
	[NQ_PesoBorrowingRate_Index] [float] NULL,
	[N12M_PesoBorrowingRate_Index] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_OtherCountries]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_OtherCountries](
	[Time_Idx] [int] NOT NULL,
	[Institution_Country_Idx] [int] NOT NULL,
	[BCI_Idx] [int] NOT NULL,
	[Value] [float] NULL,
	[Value_DESC] [nvarchar](255) NULL,
	[Highlight] [nvarchar](max) NULL,
	[Neutral_Index] [float] NULL,
	[Neutral_Index_Desc] [nvarchar](max) NULL,
	[Trend1] [nvarchar](255) NULL,
	[Trend2] [nvarchar](255) NULL,
	[Created_Date] [datetime] NULL,
	[Modified_Date] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_ReasonsTally]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_ReasonsTally](
	[Time_Idx] [int] NOT NULL,
	[Type] [nvarchar](255) NULL,
	[Reasons] [nvarchar](max) NULL,
	[Reason_Type] [nvarchar](255) NULL,
	[Sort] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_SampleList_NCR_Reg4]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_SampleList_NCR_Reg4](
	[Time_Idx] [int] NULL,
	[Sector_Idx] [int] NULL,
	[Subsector_Idx] [int] NULL,
	[Region_Idx] [int] NULL,
	[No#] [nvarchar](255) NULL,
	[Assigned Person] [nvarchar](255) NULL,
	[CompanyName] [nvarchar](255) NULL,
	[Product Line] [nvarchar](255) NULL,
	[ContactPerson] [nvarchar](255) NULL,
	[Designation] [nvarchar](255) NULL,
	[Contact] [nvarchar](255) NULL,
	[Email] [nvarchar](255) NULL,
	[Address1] [nvarchar](255) NULL,
	[Address2] [nvarchar](255) NULL,
	[TelephoneNumber] [nvarchar](255) NULL,
	[FaxNumber] [nvarchar](255) NULL,
	[FaxNumber1 (PC Fax)] [nvarchar](255) NULL,
	[FaxNumber2 (PC Fax)] [nvarchar](255) NULL,
	[FaxNumber2 (PC Fax - NDD)] [nvarchar](255) NULL,
	[FaxNumber3 (PC Fax - NDD)] [nvarchar](255) NULL,
	[FaxNumber4 (PC Fax - NDD)] [nvarchar](255) NULL,
	[Date Received] [datetime] NULL,
	[Year] [nvarchar](255) NULL,
	[Quarter] [nvarchar](255) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BES_Weights_Samples]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BES_Weights_Samples](
	[Time_Idx] [int] NOT NULL,
	[Subsector_Idx] [int] NOT NULL,
	[Sector_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[Count] [int] NULL,
	[Created_Date] [datetime] NOT NULL,
	[Modified_Date] [datetime] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BSPDailyRates]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BSPDailyRates](
	[Time_Idx] [int] NOT NULL,
	[BSPRateType_Idx] [int] NOT NULL,
	[BSPDailyRates] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BSPIS_Adjustment]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BSPIS_Adjustment](
	[Time_Idx] [int] NOT NULL,
	[Account_Idx] [int] NOT NULL,
	[Val] [numeric](18, 2) NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BSPIS_Adjustment_ForDOF]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BSPIS_Adjustment_ForDOF](
	[Time_Idx] [int] NOT NULL,
	[Account_Description] [nvarchar](50) NOT NULL,
	[Val] [numeric](18, 2) NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BSPIS_IncomeExpense_Conso]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BSPIS_IncomeExpense_Conso](
	[Time_Idx] [int] NOT NULL,
	[Account_Code] [nvarchar](50) NULL,
	[Note_Description] [nvarchar](150) NULL,
	[Account_Description] [nvarchar](150) NULL,
	[LC_Closing] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BSPIS_IncomeExpense_Conso_FinalOutput]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BSPIS_IncomeExpense_Conso_FinalOutput](
	[Time_Idx] [int] NOT NULL,
	[Month_Name] [nvarchar](20) NOT NULL,
	[Account_Idx] [int] NOT NULL,
	[Account_Description] [nvarchar](150) NULL,
	[LC_Closing] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BSPIS_IncomeExpense_Conso_Output]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BSPIS_IncomeExpense_Conso_Output](
	[Time_Idx] [int] NOT NULL,
	[Account_Description] [nvarchar](150) NULL,
	[LC_Closing] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BSPIS_IncomeExpense_ForDOF]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BSPIS_IncomeExpense_ForDOF](
	[Time_Idx] [int] NOT NULL,
	[Account_Description] [varchar](34) NOT NULL,
	[Account_Sort] [int] NOT NULL,
	[LC_Closing] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_BSPIS_Restated]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_BSPIS_Restated](
	[Time_Idx] [int] NOT NULL,
	[Account_Code] [nvarchar](50) NOT NULL,
	[Account_Description] [nvarchar](255) NOT NULL,
	[Val] [numeric](18, 2) NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Component]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Component](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[Classification_Idx] [int] NOT NULL,
	[SurveyDesc_Idx] [int] NOT NULL,
	[Better] [float] NULL,
	[Same] [float] NULL,
	[Worse] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_CompositeIndex]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_CompositeIndex](
	[Time_Idx] [int] NULL,
	[Distribution1_Idx] [int] NOT NULL,
	[SurveyDesc_Idx] [int] NOT NULL,
	[Better] [float] NULL,
	[Same] [float] NULL,
	[Worse] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_ConfIndex]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_ConfIndex](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[SurveyDesc_Idx] [int] NULL,
	[Commodity_Code] [nvarchar](50) NULL,
	[Commodity_Desc] [nvarchar](150) NULL,
	[DI] [float] NULL,
	[Weights] [float] NULL,
	[CPIWeights_Year] [int] NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Debt]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Debt](
	[Time_Idx] [int] NULL,
	[Distribution] [nvarchar](100) NULL,
	[Distribution_Sort] [int] NULL,
	[SurveyDesc_Idx] [int] NULL,
	[Val] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Debt(CQ)_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Debt(CQ)_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[Report_Tag] [varchar](38) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Debt_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Debt_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[Quarter_Tag] [varchar](15) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_DebtSitCQ]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_DebtSitCQ](
	[Time_Idx] [int] NULL,
	[DebtDesc_Idx] [int] NOT NULL,
	[SurveyDesc_Idx] [int] NOT NULL,
	[Val] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_EcoFam]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_EcoFam](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[Distribution1_Idx] [int] NOT NULL,
	[Classification_Idx] [int] NOT NULL,
	[SurveyDesc_Idx] [int] NOT NULL,
	[Better] [float] NULL,
	[Same] [float] NULL,
	[Worse] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_GTTB]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_GTTB](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[BuyingConditions_Idx] [int] NOT NULL,
	[SurveyDesc_Idx] [int] NOT NULL,
	[GoodTime_Count] [float] NULL,
	[NotGoodTime_Count] [float] NULL,
	[NotSure_Count] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_HouseLotITB]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_HouseLotITB](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[HouseLot_Idx] [int] NOT NULL,
	[SurveyDesc_Idx] [int] NOT NULL,
	[Count] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_InfForecast]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_InfForecast](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[SurveyDesc_Idx] [int] NULL,
	[Commodity_Code] [nvarchar](50) NULL,
	[Commodity_Desc] [nvarchar](150) NULL,
	[Commodity_Sort] [int] NULL,
	[DI_P] [float] NULL,
	[DI] [float] NULL,
	[Weights] [float] NULL,
	[CPIWeights_Year] [int] NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Inflation_Forecast_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Inflation_Forecast_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_OFWDistribution]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_OFWDistribution](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NULL,
	[Distribution] [nvarchar](100) NULL,
	[Val] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_OFWRemittances]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_OFWRemittances](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[Use_Idx] [int] NOT NULL,
	[Yes_Count] [float] NULL,
	[No_Count] [float] NULL,
	[YesRecoded_Count] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_PriceITB]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_PriceITB](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[Distribution2_Idx] [int] NOT NULL,
	[SurveyDesc_Idx] [int] NOT NULL,
	[Count] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_RecRemittances]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_RecRemittances](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[OFWRemittance_Use] [nvarchar](150) NULL,
	[Yes_Val] [float] NULL,
	[No_Val] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_ResIncGrp]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_ResIncGrp](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[Distribution1_Idx] [int] NOT NULL,
	[Val] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_ResponseRate]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_ResponseRate](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NULL,
	[Distribution] [nvarchar](100) NULL,
	[Val] [float] NULL,
	[Distribution_Sort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Savings_Hist_1]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Savings_Hist_1](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [varchar](41) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Savings_Hist_2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Savings_Hist_2](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [varchar](67) NOT NULL,
	[Income_Group] [varchar](67) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Savings_Hist_3]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Savings_Hist_3](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [varchar](84) NOT NULL,
	[Income_Group] [varchar](17) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Savings1]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Savings1](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NULL,
	[Distribution1_Idx] [int] NULL,
	[Val] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Savings2]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Savings2](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NULL,
	[Distribution4_Idx] [int] NULL,
	[Val] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Savings3]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Savings3](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NULL,
	[Distribution1_Idx] [int] NULL,
	[Val] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Savings4]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Savings4](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NULL,
	[Distribution4_Idx] [int] NULL,
	[Val] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_SelEcoInd]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_SelEcoInd](
	[Time_Idx] [int] NULL,
	[RegionTag_Idx] [int] NULL,
	[Indicator_Idx] [int] NULL,
	[SurveyDesc_Idx] [int] NOT NULL,
	[DI] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab1_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab1_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[Quarter_Tag] [varchar](15) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab11_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab11_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [varchar](56) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab12_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab12_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab13-14_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab13-14_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [varchar](46) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab16-17_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab16-17_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [varchar](54) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab2_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab2_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [nvarchar](150) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab3_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab3_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [nvarchar](150) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab4_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab4_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [nvarchar](150) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab5_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab5_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab6_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab6_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [varchar](82) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab7_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab7_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL,
	[Report_Tag] [varchar](81) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab8_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab8_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CES_Tab9_Hist]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CES_Tab9_Hist](
	[Time_Idx] [int] NULL,
	[Distribution_Desc] [nvarchar](255) NULL,
	[Val] [float] NULL,
	[RegionTag_Idx] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA0110C]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA0110C](
	[F0110C_Batch_Date] [numeric](8, 0) NULL,
	[F0110C_Batch_User] [nvarchar](15) NULL,
	[F0110C_BSP_GL_Account_Code] [numeric](6, 0) NULL,
	[F0110C_BSP_SL_Code] [numeric](6, 0) NULL,
	[F0110C_Analysis_Type] [nvarchar](2) NULL,
	[F0110C_Analysis_Code] [nvarchar](15) NULL,
	[F0110C_FC_Code] [nvarchar](3) NULL,
	[F0110C_LC_Opening] [numeric](15, 2) NULL,
	[F0110C_USD_Opening] [numeric](15, 2) NULL,
	[F0110C_FC_Opening] [numeric](15, 2) NULL,
	[F0110C_Status1] [nvarchar](1) NULL,
	[F0110C_Status2] [nvarchar](1) NULL,
	[F0110C_Status3] [nvarchar](1) NULL,
	[F0110C_Status4] [nvarchar](1) NULL,
	[F0110C_Status5] [nvarchar](1) NULL,
	[F0110C_Status6] [nvarchar](1) NULL,
	[F0110C_Status7] [nvarchar](1) NULL,
	[F0110C_Status8] [nvarchar](1) NULL,
	[F0110C_Status9] [nvarchar](1) NULL,
	[F0110C_Status10] [nvarchar](1) NULL,
	[F0110C_Process_UserID] [nvarchar](10) NULL,
	[F0110C_Date] [numeric](8, 0) NULL,
	[F0110C_Time] [numeric](9, 0) NULL,
	[F0110C_TerminalID] [nvarchar](15) NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA0206]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA0206](
	[F0206_GL_ACCOUNT_CODE] [numeric](6, 0) NULL,
	[F0206_SL_CODE] [numeric](12, 0) NULL,
	[F0206_ANALYSIS_TYPE] [nvarchar](2) NULL,
	[F0206_ANALYSIS_CODE] [nvarchar](15) NULL,
	[F0206_TRANSACTION_DATE] [numeric](8, 0) NULL,
	[F0206_LC_OPENING] [numeric](15, 2) NULL,
	[F0206_FC_OPENING] [numeric](15, 2) NULL,
	[F0206_USD_OPENING] [numeric](15, 2) NULL,
	[F0206_LC_DEBIT] [numeric](15, 2) NULL,
	[F0206_FC_DEBIT] [numeric](15, 2) NULL,
	[F0206_USD_DEBIT] [numeric](15, 2) NULL,
	[F0206_LC_CREDIT] [numeric](15, 2) NULL,
	[F0206_FC_CREDIT] [numeric](15, 2) NULL,
	[F0206_USD_CREDIT] [numeric](15, 2) NULL,
	[F0206_LC_CLOSING] [numeric](15, 2) NULL,
	[F0206_FC_CLOSING] [numeric](15, 2) NULL,
	[F0206_USD_CLOSING] [numeric](15, 2) NULL,
	[F0206_PROCESS_USERID] [nvarchar](10) NULL,
	[F0206_DATE] [numeric](8, 0) NULL,
	[F0206_TIME] [numeric](9, 0) NULL,
	[F0206_TERMINALID] [nvarchar](15) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA0206P]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA0206P](
	[F0206P_GL_ACCOUNT_CODE] [numeric](6, 0) NULL,
	[F0206P_SL_CODE] [numeric](12, 0) NULL,
	[F0206P_ANALYSIS_TYPE] [nvarchar](2) NULL,
	[F0206P_ANALYSIS_CODE] [nvarchar](15) NULL,
	[F0206P_TRANSACTION_DATE] [numeric](8, 0) NULL,
	[F0206P_LC_OPENING] [numeric](15, 2) NULL,
	[F0206P_FC_OPENING] [numeric](15, 2) NULL,
	[F0206P_USD_OPENING] [numeric](15, 2) NULL,
	[F0206P_LC_DEBIT] [numeric](15, 2) NULL,
	[F0206P_FC_DEBIT] [numeric](15, 2) NULL,
	[F0206P_USD_DEBIT] [numeric](15, 2) NULL,
	[F0206P_LC_CREDIT] [numeric](15, 2) NULL,
	[F0206P_FC_CREDIT] [numeric](15, 2) NULL,
	[F0206P_USD_CREDIT] [numeric](15, 2) NULL,
	[F0206P_LC_CLOSING] [numeric](15, 2) NULL,
	[F0206P_FC_CLOSING] [numeric](15, 2) NULL,
	[F0206P_USD_CLOSING] [numeric](15, 2) NULL,
	[F0206P_PROCESS_USERID] [nvarchar](10) NULL,
	[F0206P_DATE] [numeric](8, 0) NULL,
	[F0206P_TIME] [numeric](9, 0) NULL,
	[F0206P_TERMINALID] [nvarchar](15) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA0206S]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA0206S](
	[F0206S_GL_ACCOUNT_CODE] [numeric](6, 0) NULL,
	[F0206S_SL_CODE] [numeric](12, 0) NULL,
	[F0206S_ANALYSIS_TYPE] [nvarchar](2) NULL,
	[F0206S_ANALYSIS_CODE] [nvarchar](15) NULL,
	[F0206S_TRANSACTION_DATE] [numeric](8, 0) NULL,
	[F0206S_LC_OPENING] [numeric](15, 2) NULL,
	[F0206S_FC_OPENING] [numeric](15, 2) NULL,
	[F0206S_USD_OPENING] [numeric](15, 2) NULL,
	[F0206S_LC_DEBIT] [numeric](15, 2) NULL,
	[F0206S_FC_DEBIT] [numeric](15, 2) NULL,
	[F0206S_USD_DEBIT] [numeric](15, 2) NULL,
	[F0206S_LC_CREDIT] [numeric](15, 2) NULL,
	[F0206S_FC_CREDIT] [numeric](15, 2) NULL,
	[F0206S_USD_CREDIT] [numeric](15, 2) NULL,
	[F0206S_LC_CLOSING] [numeric](15, 2) NULL,
	[F0206S_FC_CLOSING] [numeric](15, 2) NULL,
	[F0206S_USD_CLOSING] [numeric](15, 2) NULL,
	[F0206S_PROCESS_USERID] [nvarchar](10) NULL,
	[F0206S_DATE] [numeric](8, 0) NULL,
	[F0206S_TIME] [numeric](9, 0) NULL,
	[F0206S_TERMINALID] [nvarchar](15) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA0207]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA0207](
	[F0207_GL_ACCOUNT_CODE] [numeric](6, 0) NULL,
	[F0207_SL_CODE] [numeric](12, 0) NULL,
	[F0207_ANALYSIS_TYPE] [nvarchar](2) NULL,
	[F0207_ANALYSIS_CODE] [nvarchar](15) NULL,
	[F0207_ORGAUNIT_CODE] [nvarchar](3) NULL,
	[F0207_TRANSACTION_DATE] [numeric](8, 0) NULL,
	[F0207_LC_OPENING] [numeric](15, 2) NULL,
	[F0207_FC_OPENING] [numeric](15, 2) NULL,
	[F0207_USD_OPENING] [numeric](15, 2) NULL,
	[F0207_LC_DEBIT] [numeric](15, 2) NULL,
	[F0207_FC_DEBIT] [numeric](15, 2) NULL,
	[F0207_USD_DEBIT] [numeric](15, 2) NULL,
	[F0207_LC_CREDIT] [numeric](15, 2) NULL,
	[F0207_FC_CREDIT] [numeric](15, 2) NULL,
	[F0207_USD_CREDIT] [numeric](15, 2) NULL,
	[F0207_LC_CLOSING] [numeric](15, 2) NULL,
	[F0207_FC_CLOSING] [numeric](15, 2) NULL,
	[F0207_USD_CLOSING] [numeric](15, 2) NULL,
	[F0207_PROCESS_USERID] [nvarchar](10) NULL,
	[F0207_DATE] [numeric](8, 0) NULL,
	[F0207_TIME] [numeric](9, 0) NULL,
	[F0207_TERMINALID] [nvarchar](15) NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA0210]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA0210](
	[F0210_POST_DATE] [numeric](8, 0) NULL,
	[F0210_POST_TIME] [numeric](9, 0) NULL,
	[F0210_TRANSACTION_DATE] [numeric](8, 0) NULL,
	[F0210_ORGAUNIT_CODE] [nvarchar](3) NULL,
	[F0210_TICKET_NUMBER] [numeric](6, 0) NULL,
	[F0210_TICKET_SEQUENSE] [numeric](4, 0) NULL,
	[F0210_GL_ACCOUNT_CODE] [numeric](6, 0) NULL,
	[F0210_SL_CODE] [numeric](12, 0) NULL,
	[F0210_SL_TYPE] [nvarchar](2) NULL,
	[F0210_ANALYSIS_TYPE] [nvarchar](2) NULL,
	[F0210_ANALYSIS_CODE] [nvarchar](15) NULL,
	[F0210_TRANSACTION_TYPE] [numeric](4, 0) NULL,
	[F0210_TRANSACTIONID] [nvarchar](7) NULL,
	[F0210_TRANSACTIONID_TYPE] [nvarchar](1) NULL,
	[F0210_SIGN] [nvarchar](1) NULL,
	[F0210_LC_AMOUNT] [numeric](15, 2) NULL,
	[F0210_FC_CODE] [nvarchar](3) NULL,
	[F0210_FC_AMOUNT] [numeric](15, 2) NULL,
	[F0210_USD_AMOUNT] [numeric](15, 2) NULL,
	[F0210_BULLION_WEIGHT] [numeric](15, 3) NULL,
	[F0210_BULLION_TYPE] [nvarchar](10) NULL,
	[F0210_VALUE_DATE] [numeric](8, 0) NULL,
	[F0210_REFERENCE_TICKET_NO] [numeric](6, 0) NULL,
	[F0210_PARTICULARS] [nvarchar](100) NULL,
	[F0210_IN_TRANSIT_INDICATOR] [nvarchar](1) NULL,
	[F0210_IN_TRANSIT_USER] [nvarchar](10) NULL,
	[F0210_IN_TRANSIT_ORGAUNIT] [nvarchar](3) NULL,
	[F0210_LC_CLOSING] [numeric](15, 2) NULL,
	[F0210_FC_CLOSING] [numeric](15, 2) NULL,
	[F0210_USD_CLOSING] [numeric](15, 2) NULL,
	[F0210_SOURCE] [nvarchar](5) NULL,
	[F0210_DISBR_ANALYSIS_TYPE] [nvarchar](2) NULL,
	[F0210_DISBR_ANALYSIS_CODE] [nvarchar](15) NULL,
	[F0210_IN_TRANSIT_STATUS] [nvarchar](1) NULL,
	[F0210_REFERENCE_DATE] [numeric](8, 0) NULL,
	[F0210_OWNER_ORGAUNIT] [nvarchar](3) NULL,
	[F0210_API_REFERENCE_DATE] [numeric](8, 0) NULL,
	[F0210_API_REFERENCE_NUMBER] [nvarchar](15) NULL,
	[F0210_PROCESS_USERID] [nvarchar](10) NULL,
	[F0210_TERMINALID] [nvarchar](15) NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA0630]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA0630](
	[F0630_TRANSACTIONID] [varchar](7) NULL,
	[F0630_TRANSLINE] [numeric](5, 0) NULL,
	[F0630_TRANSID_DESC] [varchar](50) NULL,
	[FO630_PARTICULARS] [varchar](100) NULL,
	[F0630_TRANSACTIONID_TYPE] [varchar](1) NULL,
	[F0630_TRANSACTION_TYPE] [numeric](4, 0) NULL,
	[F0630_GL_ACCOUNT_CODE] [numeric](6, 0) NULL,
	[F0630_SL_CODE] [numeric](12, 0) NULL,
	[F0630_SIGN] [varchar](1) NULL,
	[F0630_IN_TRANSIT_INDICATOR] [varchar](1) NULL,
	[F0630_IN_TRANSIT_ORGAUNIT] [varchar](3) NULL,
	[F0630_IN_TRANSIT_USER] [varchar](10) NULL,
	[F0630_PROCESS_USERID] [varchar](10) NULL,
	[F0630_DATE] [numeric](8, 0) NULL,
	[F0630_TIME] [numeric](9, 0) NULL,
	[F0630_TERMINALID] [varchar](15) NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA0885C]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA0885C](
	[F0885C_BSP_GL_Account_Code] [numeric](6, 0) NOT NULL,
	[F0885C_BSP_SL_Code] [numeric](6, 0) NOT NULL,
	[F0885C_Sub_System] [char](1) NOT NULL,
	[F0885C_FC_Code] [char](3) NOT NULL,
	[F0885C_GL_Account_Code] [numeric](6, 0) NOT NULL,
	[F0885C_SL_Code] [numeric](12, 0) NOT NULL,
	[F0885C_Analysis_Code_Source] [char](1) NOT NULL,
	[F0885C_Analysis_Type] [char](2) NOT NULL,
	[F0885C_Analysis_Code] [char](15) NOT NULL,
	[F0885C_Status1] [char](1) NOT NULL,
	[F0885C_Status2] [char](1) NOT NULL,
	[F0885C_Status3] [char](1) NOT NULL,
	[F0885C_Status4] [char](1) NOT NULL,
	[F0885C_Status5] [char](1) NOT NULL,
	[F0885C_Status6] [char](1) NOT NULL,
	[F0885C_Status7] [char](1) NOT NULL,
	[F0885C_Status8] [char](1) NOT NULL,
	[F0885C_Status9] [char](1) NOT NULL,
	[F0885C_Status10] [char](1) NOT NULL,
	[F0885C_Process_UserID] [char](10) NOT NULL,
	[F0885C_Date] [numeric](8, 0) NOT NULL,
	[F0885C_Time] [numeric](9, 0) NOT NULL,
	[F0885C_TerminalID] [char](15) NOT NULL,
	[Created_Date] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10002]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10002](
	[GL_ACCOUNT_CODE] [numeric](6, 0) NULL,
	[GL_ACCOUNT_DESC] [varchar](50) NULL,
	[SL_CODE] [numeric](12, 0) NULL,
	[SL_DESC] [nvarchar](50) NULL,
	[TRANSACTION_DATE] [numeric](8, 0) NULL,
	[SUBSL_TYPE] [nvarchar](2) NULL,
	[SUBSL_CODE] [nvarchar](15) NULL,
	[SUBSL_DESC] [varchar](55) NULL,
	[DEBIT] [numeric](15, 2) NULL,
	[CREDIT] [numeric](15, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10005]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10005](
	[BSP_GL_Account_Code] [numeric](6, 0) NULL,
	[BSP_SL_Code] [numeric](6, 0) NULL,
	[F0885C_GL_Account_Code] [numeric](6, 0) NOT NULL,
	[F0720_GL_Account_Desc] [varchar](50) NULL,
	[F0885C_SL_Code] [numeric](12, 0) NOT NULL,
	[F0730_SL_Desc] [nvarchar](50) NULL,
	[F0110C_Analysis_Type] [nvarchar](2) NULL,
	[DEBIT] [numeric](15, 2) NULL,
	[CREDIT] [numeric](15, 2) NULL,
	[F0110C_Batch_Date] [numeric](8, 0) NULL,
	[F0110C_Batch_User] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10009]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10009](
	[Time_Idx] [int] NOT NULL,
	[F0720_Idx] [int] NOT NULL,
	[GL_ACCOUNT_CODE] [numeric](6, 0) NOT NULL,
	[GL_ACCOUNT_ABBR] [varchar](50) NOT NULL,
	[GL_ACCOUNT_DESC] [varchar](150) NOT NULL,
	[GL_ACCOUNT_TYPE] [char](1) NULL,
	[GL_ACCOUNT_ACTIVE] [char](1) NULL,
	[F0730_Idx] [int] NOT NULL,
	[SL_CODE] [numeric](12, 0) NOT NULL,
	[SL_DESC] [nvarchar](50) NOT NULL,
	[F0150_Idx] [int] NOT NULL,
	[SUBSL_TYPE] [nvarchar](2) NOT NULL,
	[SUBSL_CODE] [nvarchar](15) NOT NULL,
	[SUBSL_DESC] [varchar](55) NOT NULL,
	[LC_CLOSING] [numeric](38, 2) NULL,
	[TRANSACTION_TAG] [varchar](4) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10009_INN801]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10009_INN801](
	[Time_Idx] [int] NOT NULL,
	[ACCOUNT_CODE] [nvarchar](96) NULL,
	[ACCOUNT_DESC] [char](50) NULL,
	[GL_ACCOUNT_TYPE] [char](1) NULL,
	[LC_CLOSING] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10009_INN802]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10009_INN802](
	[Time_Idx] [int] NOT NULL,
	[ACCOUNT_CODE] [nvarchar](96) NULL,
	[ACCOUNT_DESC] [char](50) NULL,
	[GL_ACCOUNT_TYPE] [char](1) NULL,
	[LC_CLOSING] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10009_INN803]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10009_INN803](
	[Time_Idx] [int] NOT NULL,
	[ACCOUNT_CODE] [nvarchar](96) NULL,
	[ACCOUNT_DESC] [char](50) NULL,
	[GL_ACCOUNT_TYPE] [char](1) NULL,
	[LC_CLOSING] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10009_INN804]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10009_INN804](
	[Time_Idx] [int] NOT NULL,
	[ACCOUNT_CODE] [nvarchar](96) NULL,
	[ACCOUNT_DESC] [char](50) NULL,
	[GL_ACCOUNT_TYPE] [char](1) NULL,
	[LC_CLOSING] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10009_INN805]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10009_INN805](
	[Time_Idx] [int] NOT NULL,
	[ACCOUNT_CODE] [nvarchar](96) NULL,
	[ACCOUNT_DESC] [char](50) NULL,
	[GL_ACCOUNT_TYPE] [char](1) NULL,
	[LC_CLOSING] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10009_INN806]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10009_INN806](
	[Time_Idx] [int] NOT NULL,
	[ACCOUNT_CODE] [nvarchar](96) NULL,
	[ACCOUNT_DESC] [char](50) NULL,
	[GL_ACCOUNT_TYPE] [char](1) NULL,
	[LC_CLOSING] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10009_INN807]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10009_INN807](
	[Time_Idx] [int] NOT NULL,
	[ACCOUNT_CODE] [nvarchar](96) NULL,
	[ACCOUNT_DESC] [char](50) NULL,
	[GL_ACCOUNT_TYPE] [char](1) NULL,
	[LC_CLOSING] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10009_INN808]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10009_INN808](
	[Time_Idx] [int] NOT NULL,
	[ACCOUNT_CODE] [nvarchar](96) NULL,
	[ACCOUNT_DESC] [char](50) NULL,
	[GL_ACCOUNT_TYPE] [char](1) NULL,
	[LC_CLOSING] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CFASLIB_FA10009_INN809]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CFASLIB_FA10009_INN809](
	[Time_Idx] [int] NOT NULL,
	[ACCOUNT_CODE] [nvarchar](96) NULL,
	[ACCOUNT_DESC] [char](50) NULL,
	[GL_ACCOUNT_TYPE] [char](1) NULL,
	[LC_CLOSING] [numeric](38, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPIB]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPIB](
	[CommoditySubtype_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPIInf_CCPI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPIInf_CCPI](
	[Time_Idx] [int] NOT NULL,
	[CoreCPI] [float] NULL,
	[CoreCPI_LY] [float] NULL,
	[InflationRate] [float] NULL,
	[InflationRate_LY] [float] NULL,
	[TrimmedMean] [float] NULL,
	[TrimmedMean_LY] [float] NULL,
	[WeightedMedian] [float] NULL,
	[WeightedMedian_LY] [float] NULL,
	[NetofVolatileItems] [float] NULL,
	[NetofVolatileItems_LY] [float] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPIInf_CPI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPIInf_CPI](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NULL,
	[Commodity_Idx] [int] NULL,
	[CPI] [float] NULL,
	[CPI_LY] [float] NULL,
	[Weights] [float] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPIInf_Inflation]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPIInf_Inflation](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NULL,
	[Commodity_Idx] [int] NULL,
	[Inflation] [float] NULL,
	[Weights] [float] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPIInf_SACPI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPIInf_SACPI](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NULL,
	[Commodity_Idx] [int] NULL,
	[SACPI] [float] NULL,
	[Weights] [float] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPIInf_Weights]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPIInf_Weights](
	[Time_Idx] [int] NOT NULL,
	[RegionTag_Idx] [int] NULL,
	[Commodity_Idx] [int] NULL,
	[Weights] [float] NULL,
	[Active] [int] NOT NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPPI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPPI](
	[ActualPropertyUse_Idx] [int] NOT NULL,
	[CommercialCondoSpaceType_Idx] [int] NOT NULL,
	[HABUPropertyClassification_Idx] [int] NOT NULL,
	[PropertyLocation_Idx] [int] NOT NULL,
	[PropertyType_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[Bank_Idx] [int] NOT NULL,
	[landvalue] [numeric](18, 2) NOT NULL,
	[landarea] [numeric](18, 2) NOT NULL,
	[totvalue] [numeric](18, 2) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPPI_GPrices]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPPI_GPrices](
	[Time_Idx] [nvarchar](8) NULL,
	[PropertyType_Idx] [nvarchar](1) NULL,
	[IslandGroup_Idx] [nvarchar](1) NULL,
	[GeoClass_Idx] [nvarchar](1) NULL,
	[gaveprice] [float] NULL,
	[totalvalue] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPPI_Mean_Median_Area]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPPI_Mean_Median_Area](
	[Time_Idx] [nvarchar](8) NULL,
	[Area_Idx] [nvarchar](1) NULL,
	[median_area] [float] NULL,
	[gaveprice_area] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPPI_Mean_Median_Overall]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPPI_Mean_Median_Overall](
	[Time_Idx] [nvarchar](8) NULL,
	[median_overall] [float] NULL,
	[gaveprice_overall] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPPI_Mean_Median_Type]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPPI_Mean_Median_Type](
	[Time_Idx] [nvarchar](8) NULL,
	[PropertyType_Idx] [nvarchar](1) NULL,
	[median_type] [float] NULL,
	[gaveprice_type] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_CPPI_Median_Area_Use]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_CPPI_Median_Area_Use](
	[Time_Idx] [nvarchar](8) NULL,
	[PropertyType_Idx] [nvarchar](1) NULL,
	[Area_Idx] [nvarchar](1) NULL,
	[median_area_type] [float] NULL,
	[max_area_type] [float] NULL,
	[min_area_type] [float] NULL,
	[count_area_type] [float] NULL,
	[total_area_type] [float] NULL,
	[gaveprice_area_type] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_DailyStocks]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_DailyStocks](
	[Time_Idx] [int] NOT NULL,
	[Stocks] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_DailyYieldCurve]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_DailyYieldCurve](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[BVALRate] [float] NULL,
	[BVALRateDiff] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_DSS]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_DSS](
	[DSS_Level7_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[Amount] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ER_AllCurrency]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ER_AllCurrency](
	[Time_Idx] [int] NULL,
	[Country_Idx] [int] NULL,
	[Euro] [numeric](18, 3) NULL,
	[USD] [numeric](18, 3) NULL,
	[PHP] [numeric](18, 3) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ER_USD]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ER_USD](
	[TIme_Idx] [int] NULL,
	[Country_Idx] [int] NULL,
	[Euro] [numeric](18, 3) NULL,
	[USD] [numeric](18, 3) NULL,
	[PHP] [numeric](18, 3) NULL,
	[BSPBuyingRate] [numeric](18, 3) NULL,
	[BSPSellingRate] [numeric](18, 3) NULL,
	[BSPReferencerate] [numeric](18, 3) NULL,
	[PDSClosingRate] [numeric](18, 3) NULL,
	[SRDRate] [numeric](18, 3) NULL,
	[GoldBuying] [numeric](18, 3) NULL,
	[SilverBuying] [numeric](18, 3) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_BCA_BES]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_BCA_BES](
	[Time_Idx] [int] NULL,
	[BES] [decimal](18, 4) NULL,
	[TOB] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_BCA_CapitalOutlay]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_BCA_CapitalOutlay](
	[Time_Idx] [int] NULL,
	[Level] [decimal](18, 4) NULL,
	[GrowthRate] [decimal](18, 4) NULL,
	[Standardized] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_BCA_TOUR]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_BCA_TOUR](
	[Time_Idx] [int] NULL,
	[TOUR] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_BCA_TradeImportExport]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_BCA_TradeImportExport](
	[Time_Idx] [int] NULL,
	[Trade] [decimal](18, 4) NULL,
	[Import] [decimal](18, 4) NULL,
	[Export] [decimal](18, 4) NULL,
	[TradeInGoods] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_BSPRates]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_BSPRates](
	[Time_Idx] [int] NULL,
	[Particulars] [nvarchar](255) NULL,
	[TENOR] [varchar](36) NULL,
	[BKCODE] [int] NULL,
	[BASIS] [varchar](6) NULL,
	[PART] [varchar](17) NULL,
	[ACCTCODE] [varchar](18) NULL,
	[TVNOTRAN] [numeric](19, 5) NULL,
	[TVAMOUNT] [numeric](19, 5) NULL,
	[IRLOWER] [numeric](19, 5) NULL,
	[IRUPPER] [numeric](19, 5) NULL,
	[EIRLOWER] [numeric](19, 5) NULL,
	[EIRUPPER] [numeric](19, 5) NULL,
	[WAIR] [numeric](19, 5) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDLendingRatesMonthlyFiltered]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDLendingRatesMonthlyFiltered](
	[Time_Idx] [int] NOT NULL,
	[LendingType_Idx] [int] NOT NULL,
	[Tenor] [int] NOT NULL,
	[Interest] [decimal](18, 4) NULL,
	[Outstanding] [decimal](18, 4) NULL,
	[Wair] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDLendingRatesMonthlyUnFiltered]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDLendingRatesMonthlyUnFiltered](
	[Time_Idx] [int] NOT NULL,
	[LendingType_Idx] [int] NOT NULL,
	[Tenor] [int] NOT NULL,
	[Interest] [decimal](18, 4) NULL,
	[Outstanding] [decimal](18, 4) NULL,
	[Wair] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDLendingRatesWeekly]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDLendingRatesWeekly](
	[Time_Idx] [int] NOT NULL,
	[LendingType_Idx] [int] NOT NULL,
	[LendingSubType] [nvarchar](255) NOT NULL,
	[IRLower] [decimal](18, 4) NULL,
	[IRUpper] [decimal](18, 4) NULL,
	[EIRLower] [decimal](18, 4) NULL,
	[EIRUpper] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDLoans]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDLoans](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[Amount] [decimal](33, 20) NULL,
	[IRLower] [float] NULL,
	[IRUpper] [float] NULL,
	[WAIR] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDLoansTotal]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDLoansTotal](
	[Time_Idx] [int] NOT NULL,
	[Total_Amount] [float] NULL,
	[Total_IRLower] [float] NULL,
	[Total_IRUpper] [float] NULL,
	[Total_EIRLower] [float] NULL,
	[Total_EIRUpper] [float] NULL,
	[Total_WAIR] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDLoansTotalUnFiltered]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDLoansTotalUnFiltered](
	[Time_Idx] [int] NOT NULL,
	[Total_Amount] [float] NULL,
	[Total_IRLower] [float] NULL,
	[Total_IRUpper] [float] NULL,
	[Total_EIRLower] [float] NULL,
	[Total_EIRUpper] [float] NULL,
	[Total_WAIR] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDLoansUnFiltered]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDLoansUnFiltered](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[Amount] [decimal](33, 20) NULL,
	[IRLower] [float] NULL,
	[IRUpper] [float] NULL,
	[WAIR] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDMonthly]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDMonthly](
	[BKCODE] [int] NULL,
	[Time_Idx] [int] NULL,
	[BASIS] [varchar](7) NULL,
	[PART] [varchar](17) NULL,
	[ACCTCODE] [varchar](18) NULL,
	[FREQUENCY] [varchar](64) NULL,
	[INTEREST] [numeric](19, 5) NULL,
	[AVERAGELD] [numeric](19, 5) NULL,
	[WAIR] [real] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDNewLoansGrantedFiltered]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDNewLoansGrantedFiltered](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[LendingType_Idx] [int] NOT NULL,
	[Amount] [float] NULL,
	[IRLower] [float] NULL,
	[IRUpper] [float] NULL,
	[EIRLower] [float] NULL,
	[EIRUpper] [float] NULL,
	[WAIR] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDNewLoansGrantedUnFiltered]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDNewLoansGrantedUnFiltered](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[LendingType_Idx] [int] NOT NULL,
	[Amount] [float] NULL,
	[IRLower] [float] NULL,
	[IRUpper] [float] NULL,
	[EIRLower] [float] NULL,
	[EIRUpper] [float] NULL,
	[WAIR] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDSavingDeposit]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDSavingDeposit](
	[Time_Idx] [int] NOT NULL,
	[Part] [varchar](100) NOT NULL,
	[Interest] [numeric](19, 5) NULL,
	[Desposit] [numeric](19, 5) NULL,
	[WAIR] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDSavingDepositFiltered]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDSavingDepositFiltered](
	[Time_Idx] [int] NOT NULL,
	[Deposit Cat] [varchar](100) NOT NULL,
	[Part] [varchar](100) NOT NULL,
	[Interest] [numeric](19, 5) NULL,
	[Desposit] [numeric](19, 5) NULL,
	[WAIR] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDSavingDepositWeeklyFiltered]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDSavingDepositWeeklyFiltered](
	[Time_Idx] [int] NOT NULL,
	[Part] [varchar](100) NOT NULL,
	[IRUPPER] [float] NULL,
	[IRLOWER] [float] NULL,
	[EIRUPPER] [float] NULL,
	[EIRLOWER] [float] NULL,
	[WAIR] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDTimeDeposit]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDTimeDeposit](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[Part] [varchar](300) NOT NULL,
	[Bank_Idx] [int] NOT NULL,
	[Acct_Code] [varchar](300) NOT NULL,
	[Amount] [numeric](19, 5) NULL,
	[IRLower] [real] NULL,
	[IRUpper] [real] NULL,
	[EIRLower] [real] NULL,
	[EIRUpper] [real] NULL,
	[WAIR] [real] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDTimeDepositOverall]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDTimeDepositOverall](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[Part] [varchar](30) NOT NULL,
	[Amount] [numeric](19, 5) NULL,
	[WAIR] [numeric](30, 15) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_IRLDTimeDepositOverallUnfiltered]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_IRLDTimeDepositOverallUnfiltered](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[Part] [varchar](30) NOT NULL,
	[Amount] [numeric](19, 5) NULL,
	[WAIR] [numeric](30, 15) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_TenorRatesMonthly]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_TenorRatesMonthly](
	[Time_Idx] [int] NULL,
	[Tenor_Idx] [varchar](100) NOT NULL,
	[Rate_Idx] [varchar](100) NOT NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ITR_YTDWAIR]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ITR_YTDWAIR](
	[Time_Idx] [int] NULL,
	[Rates] [varchar](100) NOT NULL,
	[WAIR] [decimal](33, 20) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_MISSI_CUR]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_MISSI_CUR](
	[Time_Idx] [int] NULL,
	[Type_Idx] [int] NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_MISSI_VaPI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_MISSI_VaPI](
	[Time_Idx] [int] NULL,
	[Type_Idx] [int] NULL,
	[Index] [decimal](18, 4) NULL,
	[Index Tagging] [varchar](2) NULL,
	[GrowthRate] [decimal](18, 4) NULL,
	[GrowthRate Tagging] [varchar](2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_MISSI_VoPI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_MISSI_VoPI](
	[Time_Idx] [int] NULL,
	[Type_Idx] [int] NULL,
	[Index] [decimal](18, 4) NULL,
	[Index Tagging] [varchar](2) NULL,
	[GrowthRate] [decimal](18, 4) NULL,
	[GrowthRate Tagging] [varchar](2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_MM_RERB]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_MM_RERB](
	[Time_Idx] [int] NOT NULL,
	[Value] [float] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_MM_RERB_BKP]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_MM_RERB_BKP](
	[Time_Idx] [int] NOT NULL,
	[Value] [float] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_MM_Transaction]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_MM_Transaction](
	[Time_Idx] [int] NOT NULL,
	[Institution_Name] [varchar](200) NULL,
	[Investor_Buyer] [varchar](200) NULL,
	[Reference_Number] [varchar](200) NULL,
	[Line_Entries] [varchar](200) NULL,
	[Transaction_Amount] [decimal](18, 4) NULL,
	[Borrowing_Selling_Rate] [decimal](18, 4) NULL,
	[Borrowing_Selling_Idx] [int] NULL,
	[Maturity_Period_Idx] [int] NULL,
	[Instrument_Idx] [int] NULL,
	[Transaction_Idx] [int] NULL,
	[Investor_Buyer_Idx] [int] NULL,
	[Investor_Buyer_Number] [varchar](200) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_MM_Transaction_202307]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_MM_Transaction_202307](
	[Time_Idx] [int] NOT NULL,
	[Institution_Name] [varchar](200) NULL,
	[Investor_Buyer] [varchar](200) NULL,
	[Reference_Number] [varchar](200) NULL,
	[Line_Entries] [varchar](200) NULL,
	[Transaction_Amount] [decimal](18, 4) NULL,
	[Borrowing_Selling_Rate] [decimal](18, 4) NULL,
	[Borrowing_Selling_Idx] [int] NULL,
	[Maturity_Period_Idx] [int] NULL,
	[Instrument_Idx] [int] NULL,
	[Transaction_Idx] [int] NULL,
	[Investor_Buyer_Idx] [int] NULL,
	[Investor_Buyer_Number] [varchar](200) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_MM_Transaction_20231130bk]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_MM_Transaction_20231130bk](
	[Time_Idx] [int] NOT NULL,
	[Institution_Name] [varchar](200) NULL,
	[Investor_Buyer] [varchar](200) NULL,
	[Reference_Number] [varchar](200) NULL,
	[Line_Entries] [varchar](200) NULL,
	[Transaction_Amount] [decimal](18, 4) NULL,
	[Borrowing_Selling_Rate] [decimal](18, 4) NULL,
	[Borrowing_Selling_Idx] [int] NULL,
	[Maturity_Period_Idx] [int] NULL,
	[Instrument_Idx] [int] NULL,
	[Transaction_Idx] [int] NULL,
	[Investor_Buyer_Idx] [int] NULL,
	[Investor_Buyer_Number] [varchar](200) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_ConsodilatedAccounts]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_ConsodilatedAccounts](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [varchar](200) NOT NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_GCF]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_GCF](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_GRDP]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_GRDP](
	[Time_Idx] [int] NOT NULL,
	[Region_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_Import_BKP]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_Import_BKP](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_MFG]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_MFG](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NOT NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_PerCapita]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_PerCapita](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL,
	[LY_Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_PerCapitaQ3]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_PerCapitaQ3](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL,
	[LY_Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_PerCapitaSEM]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_PerCapitaSEM](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL,
	[LY_Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_PerCapitaYear]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_PerCapitaYear](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL,
	[LY_Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_PerCapitaYear_Q12023]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_PerCapitaYear_Q12023](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL,
	[LY_Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_PerCapitaYear_Q22023]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_PerCapitaYear_Q22023](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL,
	[LY_Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_REOD]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_REOD](
	[Time_Idx] [int] NOT NULL,
	[Type] [varchar](100) NOT NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryExp]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL,
	[LY_Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryExp_Annual]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp_Annual](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL,
	[LY_Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryExp_Q12023]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp_Q12023](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryExp_Q22023]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp_Q22023](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryExp_Q32023]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp_Q32023](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryExp_Q42022]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp_Q42022](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryExpBaKAC]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryExpBaKAC](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryInd]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL,
	[LY_Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryInd_Annual]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd_Annual](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL,
	[LY_Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryInd_Q12023]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd_Q12023](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryInd_Q22023]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd_Q22023](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryInd_Q32023]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd_Q32023](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryInd_Q42022]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd_Q42022](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_SummaryIndBaKAC]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_SummaryIndBaKAC](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](100) NOT NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_NAT_WEO]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_NAT_WEO](
	[Time_Idx] [int] NOT NULL,
	[Value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_OPI_GRPI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_OPI_GRPI](
	[Time_Idx] [int] NULL,
	[Location_Idx] [int] NULL,
	[Type_Idx] [int] NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_OPI_GWPI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_OPI_GWPI](
	[Time_Idx] [int] NULL,
	[Location_Idx] [int] NULL,
	[Type_Idx] [int] NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_OPI_PPI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_OPI_PPI](
	[Time_Idx] [int] NULL,
	[Type_Idx] [int] NULL,
	[Index] [decimal](18, 4) NULL,
	[Index Tagging] [varchar](2) NULL,
	[GrowthRate] [decimal](18, 4) NULL,
	[GrowthRate Tagging] [varchar](2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PMI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PMI](
	[Time_Idx] [int] NOT NULL,
	[Manufacturing] [numeric](18, 2) NULL,
	[RetailWholesale] [numeric](18, 2) NULL,
	[Services] [numeric](18, 2) NULL,
	[Composite] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PMI_PISM]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PMI_PISM](
	[Sector_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[PMI_Values] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PMI_SPGlobal]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PMI_SPGlobal](
	[Time_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_POVERTYINDICATOR]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_POVERTYINDICATOR](
	[Province_Name] [nvarchar](max) NOT NULL,
	[Values] [numeric](18, 2) NULL,
	[Time_Idx] [int] NOT NULL,
	[PovertyCode_Idx] [int] NULL,
	[Province_Code] [nvarchar](20) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PptInd_LicensedToSell]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PptInd_LicensedToSell](
	[Time_Idx] [int] NOT NULL,
	[Residential_Units] [int] NULL,
	[Condominium] [int] NULL,
	[Others] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PptInd_Market_Land]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PptInd_Market_Land](
	[Time_Idx] [int] NOT NULL,
	[Location] [varchar](150) NULL,
	[Grade] [varchar](150) NULL,
	[Value] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PptInd_Market_OfficeCapital]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeCapital](
	[Time_Idx] [int] NOT NULL,
	[Location] [varchar](150) NULL,
	[Grade] [varchar](150) NULL,
	[Value] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PptInd_Market_OfficeRental]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeRental](
	[Time_Idx] [int] NOT NULL,
	[Location] [varchar](150) NULL,
	[Grade] [varchar](150) NULL,
	[Value] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PptInd_Market_OfficeSpaceDemand]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeSpaceDemand](
	[Time_Idx] [int] NOT NULL,
	[Location] [varchar](150) NULL,
	[Type] [varchar](150) NULL,
	[Value] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PptInd_Market_ResidentialCapital]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PptInd_Market_ResidentialCapital](
	[Time_Idx] [int] NOT NULL,
	[Location] [varchar](150) NULL,
	[Grade] [varchar](150) NULL,
	[Value] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PptInd_Market_ResidentialRental]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PptInd_Market_ResidentialRental](
	[Time_Idx] [int] NOT NULL,
	[Location] [varchar](150) NULL,
	[Grade] [varchar](150) NULL,
	[Value] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PptInd_Market_VacancyRate]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PptInd_Market_VacancyRate](
	[Time_Idx] [int] NOT NULL,
	[Location] [varchar](150) NULL,
	[Market] [varchar](150) NULL,
	[Grade] [varchar](150) NULL,
	[Value] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_PptInd_NumberFloorArea]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_PptInd_NumberFloorArea](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[ResidentType_Idx] [int] NOT NULL,
	[Number] [numeric](18, 2) NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_FisheriesVolume]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_FisheriesVolume](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Fish_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_GoldSilver]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_GoldSilver](
	[Time_Idx] [int] NOT NULL,
	[Gold] [numeric](18, 2) NULL,
	[Silver] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_InlandCommercialFisheries]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_InlandCommercialFisheries](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Fish_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_ProInd_NumberFloorArea]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_ProInd_NumberFloorArea](
	[Time_Idx] [int] NOT NULL,
	[City_Idx] [int] NOT NULL,
	[ResidentType_Idx] [int] NOT NULL,
	[Number] [numeric](18, 2) NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_SWCP_AnnualIndexWeights]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_SWCP_AnnualIndexWeights](
	[CommodityType_Idx] [int] NOT NULL,
	[Energy and Non-Energy Indices] [decimal](18, 4) NULL,
	[Share of Sub-Group Indices] [decimal](18, 4) NULL,
	[Food Index] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_SWCP_AnnualIndices]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_SWCP_AnnualIndices](
	[Time_Idx] [int] NOT NULL,
	[CommodityType_Idx] [int] NOT NULL,
	[SWCP_Type] [varchar](100) NOT NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_SWCP_AnnualPrice]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_SWCP_AnnualPrice](
	[Time_Idx] [int] NOT NULL,
	[CommodityType_Idx] [int] NOT NULL,
	[SWCP_Type] [varchar](100) NOT NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_SWCP_MonthlyIndexWeights]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_SWCP_MonthlyIndexWeights](
	[CommodityType_Idx] [int] NOT NULL,
	[Energy and Non-Energy Indices] [decimal](18, 4) NULL,
	[Share of Sub-Group Indices] [decimal](18, 4) NULL,
	[Food Index] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESLIG_SWCP_MonthlyIndices]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESLIG_SWCP_MonthlyIndices](
	[Time_Idx] [int] NOT NULL,
	[CommodityType_Idx] [int] NOT NULL,
	[SWCP_Type] [varchar](100) NOT NULL,
	[Value] [decimal](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESSD3_GIR]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESSD3_GIR](
	[Time_Idx] [int] NOT NULL,
	[Short-Term Liabilities] [numeric](18, 4) NULL,
	[Accrued Interest Receivable] [numeric](18, 4) NULL,
	[Add:  Reserves Tranche Position in the IMF] [numeric](18, 4) NULL,
	[Cash] [numeric](18, 4) NULL,
	[Cash Collateral Paid] [numeric](18, 4) NULL,
	[Demand Deposits] [numeric](18, 4) NULL,
	[Due from Foreign Banks] [numeric](18, 4) NULL,
	[Due from Broker] [numeric](18, 4) NULL,
	[Foreign Investments] [numeric](18, 4) NULL,
	[Foreign Securities Purchased under agreements to resell] [numeric](18, 4) NULL,
	[Gold] [numeric](18, 4) NULL,
	[Gross International Reserves] [numeric](18, 4) NULL,
	[Less:  Liabilities] [numeric](18, 4) NULL,
	[Loan to IMF] [numeric](18, 4) NULL,
	[Net International Reserves] [numeric](18, 4) NULL,
	[SDR Holdings] [numeric](18, 4) NULL,
	[Time Deposits] [numeric](18, 4) NULL,
	[Use of Funds Credits] [numeric](18, 4) NULL,
	[Reserves Position in the Fund] [numeric](18, 4) NULL,
	[Foreign Investments Total] [numeric](18, 4) NULL,
	[Foreign Exchange] [numeric](18, 4) NULL,
	[Total Reserve Liabilities] [numeric](18, 4) NULL,
	[Public Sector] [numeric](18, 4) NULL,
	[Private Sector] [numeric](18, 4) NULL,
	[ExternalDebt_Priv_NonBanks] [numeric](18, 4) NULL,
	[ST_Loan_Priv_NonBanks] [numeric](18, 4) NULL,
	[OutstandingOriginal] [numeric](18, 4) NULL,
	[MLT falling due for the next 12 months] [numeric](18, 4) NULL,
	[ResidualMaturity] [numeric](18, 4) NULL,
	[ImportCover] [numeric](18, 4) NULL,
	[ST_Original] [numeric](18, 4) NULL,
	[ST_Residual] [numeric](18, 4) NULL,
	[Change in NIR (Monthly)] [numeric](18, 4) NULL,
	[Change in NIR  (Cumulative)] [numeric](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESSD3_GIR_FXRD]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESSD3_GIR_FXRD](
	[Time_Idx] [int] NOT NULL,
	[Net Investment Income] [numeric](18, 8) NULL,
	[NG Deposits] [numeric](18, 8) NULL,
	[Other Deposits] [numeric](18, 8) NULL,
	[Gold Monetization (Increase in Gold in Bullion Vault)] [numeric](18, 8) NULL,
	[Receipt Net BSPs Foreign Exchange Operations] [numeric](18, 8) NULL,
	[Receipt Net Others] [numeric](18, 8) NULL,
	[Net Investment Losses] [numeric](18, 8) NULL,
	[Bangko Sentral ng Pilipinas (BSP)] [numeric](18, 8) NULL,
	[National Government (NG)] [numeric](18, 8) NULL,
	[Disbursement Other Withdrawals] [numeric](18, 8) NULL,
	[Disbursement Net BSP's Foreign Exchange Operations] [numeric](18, 8) NULL,
	[Disbursement Net Others] [numeric](18, 8) NULL,
	[GIR Revaluation] [numeric](18, 8) NULL,
	[Total Revaluation] [numeric](18, 8) NULL,
	[FCD-TOP] [numeric](18, 8) NULL,
	[FCD-PSALM] [numeric](18, 8) NULL,
	[FCD-AABs] [numeric](18, 8) NULL,
	[FCD-NPC] [numeric](18, 8) NULL,
	[Disbursement FCD TOP] [numeric](18, 8) NULL,
	[Disbursement FCD AABS] [numeric](18, 8) NULL,
	[Disbursement FCD PSALM] [numeric](18, 8) NULL,
	[Disbursement FCD NPC] [numeric](18, 8) NULL,
	[Disbursement Revaluation - Gold Holdings] [numeric](18, 8) NULL,
	[Disbursement IMF Transaction under NAB] [numeric](18, 8) NULL,
	[Disbursement IMF Transaction under FTP] [numeric](18, 8) NULL,
	[Disbursement Net Sale/Redemption of Non-IR FX Assets (ROP Bonds)] [numeric](18, 8) NULL,
	[Disbursement Non-IR FX Assets-EMP4-ALCB (Net Investment Activity)] [numeric](18, 8) NULL,
	[Disbursement Net Revaluation -  Foreign Currency-Denom. Reserves] [numeric](18, 8) NULL,
	[Receipts Revaluation - Gold Holdings] [numeric](18, 8) NULL,
	[Receipts Net Revaluation -  Foreign Currency-Denom. Reserves] [numeric](18, 8) NULL,
	[Receipts IMF Transaction under NAB] [numeric](18, 8) NULL,
	[Receipts IMF Transaction under FTP] [numeric](18, 8) NULL,
	[Receipts Net Sale/Redemption of Non-IR FX Assets (ROP Bonds)] [numeric](18, 8) NULL,
	[Receipts General Allocation of SDR] [numeric](18, 8) NULL,
	[Receipt Non-IR FX Assets-EMP4-ALCB (Net Investment Activity] [numeric](18, 8) NULL,
	[Foreign Investments (FX Fluctation) Revaluation] [numeric](18, 8) NULL,
	[FX Fluctuation - SDR Holdings] [numeric](18, 8) NULL,
	[Demand Deposit Revaluation] [numeric](18, 8) NULL,
	[FX Fluctuation - Reserves Position with the IMF] [numeric](18, 8) NULL,
	[BISIP Series ILF-CNY G1 Revaluation -FX] [numeric](18, 8) NULL,
	[Time Deposits Revaluation] [numeric](18, 8) NULL,
	[RIR FX Fluctuation FS Purchased under agrmts to resell] [numeric](18, 8) NULL,
	[FX Fluctuation - Loan To IMF] [numeric](18, 8) NULL,
	[FX Fluctuation - Currency holdings (Greater Manila Regional Office)] [numeric](18, 8) NULL,
	[Due from Broker Revaluation] [numeric](18, 8) NULL,
	[Due from/(to) Broker Revaluation] [numeric](18, 8) NULL,
	[FX Fluctuation - Others] [numeric](18, 8) NULL,
	[Foreign Investments (Price Fluctuation) Revaluation] [numeric](18, 8) NULL,
	[BISIP Series ILF-CNY G1 Revaluation - Price] [numeric](18, 8) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESSD3_GIR_IRFCL]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESSD3_GIR_IRFCL](
	[Time_Idx] [int] NOT NULL,
	[(2) IMF reserve position] [numeric](18, 4) NULL,
	[(3) SDRs] [numeric](18, 4) NULL,
	[(4) Gold (including gold deposits and, if appropriate, gold swapped)] [numeric](18, 4) NULL,
	[(a) Securities*] [numeric](18, 4) NULL,
	[(b) Total currency and deposits with:] [numeric](18, 4) NULL,
	[(d) securities lent and on repo] [numeric](18, 4) NULL,
	[(i) other national central banks, BIS and IMF] [numeric](18, 4) NULL,
	[(ii) banks headquartered in the reporting country] [numeric](18, 4) NULL,
	[(iii) banks headquartered outside the reporting country] [numeric](18, 4) NULL,
	[A. Official reserve assets] [numeric](18, 4) NULL,
	[B. Other foreign currency assets (specify)] [numeric](18, 4) NULL,
	[deposits not included in official reserve assets] [numeric](18, 4) NULL,
	[Interest] [numeric](18, 4) NULL,
	[lent or repoed and included in Section I] [numeric](18, 4) NULL,
	[of which: located abroad] [numeric](18, 4) NULL,
	[Other] [numeric](18, 4) NULL,
	[Other contingent liablities - More than 1 and up to 3 months] [numeric](18, 4) NULL,
	[Other contingent liablities - More than 3 months and up to 1 year] [numeric](18, 4) NULL,
	[Other contingent liablities - Total] [numeric](18, 4) NULL,
	[Other contingent liablities - Up to 1 month] [numeric](18, 4) NULL,
	[Outflow_Interest inflows (+)] [numeric](18, 4) NULL,
	[Outflow_Interest More than 1 and up to 3 months] [numeric](18, 4) NULL,
	[Outflow_Interest More than 3 months and up to 1 year] [numeric](18, 4) NULL,
	[Outflow_Interest_Total] [numeric](18, 4) NULL,
	[Outflow_Interest Up to 1 month] [numeric](18, 4) NULL,
	[Outflow_Principal More than 1 and up to 3 months] [numeric](18, 4) NULL,
	[Outflow_Principal More than 3 months and up to 1 year] [numeric](18, 4) NULL,
	[Outflow_Principal_Total] [numeric](18, 4) NULL,
	[Outflow_Principal Up to 1 month] [numeric](18, 4) NULL,
	[Principal] [numeric](18, 4) NULL,
	[securities not included in official reserve assets] [numeric](18, 4) NULL,
	[volume in millions of fine troy ounces] [numeric](18, 4) NULL,
	[Long positions _Total] [numeric](18, 4) NULL,
	[Long positions _Up to 1 month] [numeric](18, 4) NULL,
	[Long positions_More than 1 and up to 3 months] [numeric](18, 4) NULL,
	[Long positions_More than 3 months and up to 1 year] [numeric](18, 4) NULL,
	[(a) currency composition of reserves (by groups of currencies)] [numeric](18, 4) NULL,
	[currencies in SDR basket] [numeric](18, 4) NULL,
	[currencies not in SDR basket] [numeric](18, 4) NULL,
	[(5) Other reserve assets (specify)] [numeric](18, 4) NULL,
	[financial derivatives] [numeric](18, 4) NULL,
	[loans to nonbank nonresidents] [numeric](18, 4) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESSD3_GIR_IRFCL_II]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESSD3_GIR_IRFCL_II](
	[Time_Idx] [nvarchar](50) NOT NULL,
	[TitleName_Idx] [int] NULL,
	[Up to 1 month] [float] NULL,
	[More than 1 and up to 3 months] [float] NULL,
	[More than 3 months and up to 1 year] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_ESSD3_GIR_IRFCL_II_Backup]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_ESSD3_GIR_IRFCL_II_Backup](
	[Time_Idx] [nvarchar](50) NOT NULL,
	[TitleName_Idx] [int] NULL,
	[Up to 1 month] [float] NULL,
	[More than 1 and up to 3 months] [float] NULL,
	[More than 3 months and up to 1 year] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FFSD_NGCOR]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FFSD_NGCOR](
	[Time_Idx] [nvarchar](50) NOT NULL,
	[GDP] [float] NULL,
	[Revenues] [float] NULL,
	[Revenue Annual Growth Rate (%)] [numeric](18, 15) NULL,
	[Tax Revenues] [float] NULL,
	[Revenues % to GDP] [numeric](18, 15) NULL,
	[Non-Tax including Grants] [float] NULL,
	[Expenditures] [float] NULL,
	[Expenditures Annual Growth Rate (%)] [numeric](18, 15) NULL,
	[Interest Payments] [float] NULL,
	[Domestic Interest Payments] [float] NULL,
	[Foreign Interest Payments] [float] NULL,
	[Net Lending & Equity] [float] NULL,
	[Surplus/(-)Deficit] [float] NULL,
	[Surplus/(-)Deficit % to GDP)] [numeric](18, 15) NULL,
	[Financing] [float] NULL,
	[Net Domestic Borrowings] [float] NULL,
	[Domestic (Gross)] [float] NULL,
	[Less: Net Amortization] [float] NULL,
	[External (Net)] [float] NULL,
	[External (Gross)] [float] NULL,
	[Less: Amortization] [float] NULL,
	[Change-In-Cash] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FFSD_NGCOR_YTD]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FFSD_NGCOR_YTD](
	[Time_Idx] [nvarchar](50) NOT NULL,
	[GDP_Qtr] [float] NULL,
	[Revenues] [float] NULL,
	[Revenue Annual Growth Rate (%)] [float] NULL,
	[Tax Revenues] [float] NULL,
	[Tax Revenues Complete] [float] NULL,
	[Revenues % to GDP] [float] NULL,
	[Non-Tax including Grants] [float] NULL,
	[Expenditures] [float] NULL,
	[Expenditures Annual Growth Rate (%)] [float] NULL,
	[Interest Payments] [float] NULL,
	[Domestic Interest Payments] [float] NULL,
	[Foreign Interest Payments] [float] NULL,
	[Net Lending & Equity] [float] NULL,
	[Surplus/(-)Deficit] [float] NULL,
	[Surplus/(-)Deficit Complete] [float] NULL,
	[Surplus/(-)Deficit % to GDP)] [float] NULL,
	[Financing] [float] NULL,
	[Net Domestic Borrowings] [float] NULL,
	[Domestic (Gross)] [float] NULL,
	[Less: Net Amortization] [float] NULL,
	[External (Net)] [float] NULL,
	[External (Gross)] [float] NULL,
	[Less: Amortization] [float] NULL,
	[Change-In-Cash] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FFSD_SELFI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FFSD_SELFI](
	[Time_Idx] [int] NOT NULL,
	[GDP] [float] NULL,
	[Revenues] [float] NULL,
	[Revenues % to GDP] [float] NULL,
	[Expenditures] [float] NULL,
	[Expenditures % to GDP] [float] NULL,
	[Surplus/(-)Deficit] [float] NULL,
	[Surplus/(-)Deficit % to GDP)] [float] NULL,
	[Borrowings (Net)] [float] NULL,
	[Domestic (Net)] [float] NULL,
	[Domestic % to total NG Deficit] [float] NULL,
	[External (Net)] [float] NULL,
	[External % to total NG Deficit] [float] NULL,
	[Change in Cash] [float] NULL,
	[Change in Cash % to total NG Deficit] [float] NULL,
	[Financing Mix: Domestic] [float] NULL,
	[Financing Mix: External] [float] NULL,
	[CPSFP SurplusDeficit] [float] NULL,
	[CPSFP % to GDP] [float] NULL,
	[OS Total Debt] [float] NULL,
	[OS Total Debt % to GDP] [float] NULL,
	[OS Domestic Debt] [float] NULL,
	[OS Domestic Debt % to GDP] [float] NULL,
	[OS External Debt] [float] NULL,
	[OS External Debt % to GDP] [float] NULL,
	[OPSD Total Debt] [float] NULL,
	[OPSD Total Debt % to GDP] [float] NULL,
	[OPSD Domestic Debt] [float] NULL,
	[OPSD Domestic Debt % to GDP] [float] NULL,
	[OPSD Foreign Debt] [float] NULL,
	[OPSD Foreign Debt % to GDP] [float] NULL,
	[Public Sector External Debt] [float] NULL,
	[Public Sector External Debt % to GDP] [float] NULL,
	[NominalGDPinUSD] [float] NULL,
	[NominalGDPinPHP] [float] NULL,
	[FX_Average] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FFSD_SELFI_YTD]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FFSD_SELFI_YTD](
	[Time_Idx] [int] NOT NULL,
	[GDP_Qtr] [float] NULL,
	[Revenues] [float] NULL,
	[Revenues Complete] [float] NULL,
	[Revenues % to GDP] [float] NULL,
	[Expenditures] [float] NULL,
	[Expenditures Complete] [float] NULL,
	[Expenditures % to GDP] [float] NULL,
	[Surplus/(-)Deficit] [float] NULL,
	[Surplus/(-)Deficit Complete] [float] NULL,
	[Surplus/(-)Deficit % to GDP)] [float] NULL,
	[Borrowings (Net)] [float] NULL,
	[Domestic (Net)] [float] NULL,
	[External (Net)] [float] NULL,
	[Change in Cash] [float] NULL,
	[Financing Mix: Domestic] [float] NULL,
	[Financing Mix: External] [float] NULL,
	[Domestic (Gross)] [float] NULL,
	[External (Gross)] [float] NULL,
	[CPSFP SurplusDeficit] [float] NULL,
	[CPSFP % to GDP] [float] NULL,
	[OS Total Debt] [float] NULL,
	[OS Total Debt Complete] [float] NULL,
	[OS Total Debt % to GDP] [float] NULL,
	[OS Domestic Debt] [float] NULL,
	[OS Domestic Debt Complete] [float] NULL,
	[OS Domestic Debt % to GDP] [float] NULL,
	[OS External Debt] [float] NULL,
	[OS External Debt Complete] [float] NULL,
	[OS External Debt % to GDP] [float] NULL,
	[OPSD Total Debt] [float] NULL,
	[OPSD Total Debt Complete] [float] NULL,
	[OPSD Total Debt % to GDP] [float] NULL,
	[OPSD Domestic Debt] [float] NULL,
	[OPSD Domestic Debt Complete] [float] NULL,
	[OPSD Domestic Debt % to GDP] [float] NULL,
	[OPSD Foreign Debt] [float] NULL,
	[OPSD Foreign Debt Complete] [float] NULL,
	[OPSD Foreign Debt % to GDP] [float] NULL,
	[Public Sector External Debt] [float] NULL,
	[Public Sector External Debt Complete] [float] NULL,
	[Public Sector External Debt % to GDP] [float] NULL,
	[NominalGDPinUSD] [float] NULL,
	[NominalGDPinPHP] [float] NULL,
	[ForeignExchange] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FSI]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FSI](
	[FSICountries_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[Total regulatory capital] [numeric](18, 2) NULL,
	[Tier 1 capital] [numeric](18, 2) NULL,
	[Regulatory Risk-weighted assets] [numeric](18, 2) NULL,
	[Nonperforming loans] [numeric](18, 2) NULL,
	[NFL Total gross loans] [numeric](18, 2) NULL,
	[Nonperforming loans net of provisions] [numeric](18, 2) NULL,
	[Loan concentration by economic activity] [numeric](18, 2) NULL,
	[Total gross loans to nonfinancial corporations] [numeric](18, 2) NULL,
	[Net income before taxes] [numeric](18, 2) NULL,
	[Return on Assets Total assets] [numeric](18, 2) NULL,
	[Net income after taxes] [numeric](18, 2) NULL,
	[Capital] [numeric](18, 2) NULL,
	[Interest margin] [numeric](18, 2) NULL,
	[Interest Margin Gross income] [numeric](18, 2) NULL,
	[Interest Margin Noninterest expenses] [numeric](18, 2) NULL,
	[Liquid assets] [numeric](18, 2) NULL,
	[Liquid Assets Total assets] [numeric](18, 2) NULL,
	[Short-term liabilities] [numeric](18, 2) NULL,
	[Net open position in foreign exchange] [numeric](18, 2) NULL,
	[Loans to Emerging and developing Asia] [numeric](18, 2) NULL,
	[Loans to Advanced economies] [numeric](18, 2) NULL,
	[Loans to Sub-Saharan Africa] [numeric](18, 2) NULL,
	[Loans to Emerging and developing Europe] [numeric](18, 2) NULL,
	[Loans to Latin America and the Caribbean] [numeric](18, 2) NULL,
	[Loans to Middle East and Central Asia] [numeric](18, 2) NULL,
	[Geographic distribution of total loans: Advanced economies] [numeric](18, 2) NULL,
	[Geographic distribution of total loans: Emerging and developing Asia] [numeric](18, 2) NULL,
	[Geographic distribution of total loans: Emerging and developing Europe] [numeric](18, 2) NULL,
	[Geographic distribution of total loans: Latin America and the Caribbean] [numeric](18, 2) NULL,
	[Geographic distribution of total loans: Middle East and Central Asia] [numeric](18, 2) NULL,
	[Geographic distribution of total loans: Sub-Saharan Africa] [numeric](18, 2) NULL,
	[Trading income] [numeric](18, 2) NULL,
	[Trading Income Gross income] [numeric](18, 2) NULL,
	[Personnel expenses] [numeric](18, 2) NULL,
	[Personal Expenses Noninterest expenses] [numeric](18, 2) NULL,
	[Customer deposits] [numeric](18, 2) NULL,
	[Total (noninterbank) loans] [numeric](18, 2) NULL,
	[Commercial real estate loans] [numeric](18, 2) NULL,
	[Residential real estate loans] [numeric](18, 2) NULL,
	[Real Estate Loans Total gross loans] [numeric](18, 2) NULL,
	[TIER-1 Capital to Assets Tier 1 capital] [numeric](18, 2) NULL,
	[TIER-1 Capital to Assets Total assets] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FX_Daily_Cur_Peso]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FX_Daily_Cur_Peso](
	[Time_Idx] [int] NOT NULL,
	[aud_peso_d] [float] NULL,
	[eur_peso_d] [float] NULL,
	[jpy_peso_d] [float] NULL,
	[usd_peso_d] [float] NULL,
	[cny_peso_d] [float] NULL,
	[hkd_peso_d] [float] NULL,
	[idr_peso_d] [float] NULL,
	[myr_peso_d] [float] NULL,
	[sar_peso_d] [float] NULL,
	[sgd_peso_d] [float] NULL,
	[krw_peso_d] [float] NULL,
	[twd_peso_d] [float] NULL,
	[thb_peso_d] [float] NULL,
	[aed_peso_d] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FX_Daily_Forward_Rates]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FX_Daily_Forward_Rates](
	[Time_Idx] [int] NOT NULL,
	[usd_php_b] [float] NULL,
	[usd_php_o] [float] NULL,
	[swap_1m_b] [float] NULL,
	[swap_1m_o] [float] NULL,
	[swap_2m_b] [float] NULL,
	[swap_2m_o] [float] NULL,
	[swap_3m_b] [float] NULL,
	[swap_3m_o] [float] NULL,
	[swap_6m_b] [float] NULL,
	[swap_6m_o] [float] NULL,
	[swap_1y_b] [float] NULL,
	[swap_1y_o] [float] NULL,
	[FX Settlement Rate] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FX_Daily_NEER]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FX_Daily_NEER](
	[Time_Idx] [int] NOT NULL,
	[neer_yoy_d] [float] NULL,
	[neer_chained_d] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FX_Daily_NEER_A]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FX_Daily_NEER_A](
	[Time_Idx] [int] NOT NULL,
	[neer_a_yoy_d] [float] NULL,
	[neer_a_chained_d] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FX_Daily_NEER_D]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FX_Daily_NEER_D](
	[Time_Idx] [int] NOT NULL,
	[neer_d_yoy_d] [float] NULL,
	[neer_d_chained_d] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FX_Daily_Peso_Cur]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FX_Daily_Peso_Cur](
	[Time_Idx] [int] NOT NULL,
	[peso_aud_d] [float] NULL,
	[peso_eur_d] [float] NULL,
	[peso_jpy_d] [float] NULL,
	[peso_usd_d] [float] NULL,
	[peso_cny_d] [float] NULL,
	[peso_hkd_d] [float] NULL,
	[peso_idr_d] [float] NULL,
	[peso_myr_d] [float] NULL,
	[peso_sar_d] [float] NULL,
	[peso_sgd_d] [float] NULL,
	[peso_krw_d] [float] NULL,
	[peso_twd_d] [float] NULL,
	[peso_thb_d] [float] NULL,
	[peso_aed_d] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FX_Daily_REER]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FX_Daily_REER](
	[Time_Idx] [int] NOT NULL,
	[reer_yoy_d] [float] NULL,
	[reer_chained_d] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FX_Daily_REER_A]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FX_Daily_REER_A](
	[Time_Idx] [int] NOT NULL,
	[reer_a_yoy_d] [float] NULL,
	[reer_a_chained_d] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FX_Daily_REER_D]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FX_Daily_REER_D](
	[Time_Idx] [int] NOT NULL,
	[reer_d_yoy_d] [float] NULL,
	[reer_d_chained_d] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_FX_Weights]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_FX_Weights](
	[Time_Idx] [int] NOT NULL,
	[aud] [float] NULL,
	[eur] [float] NULL,
	[jpy] [float] NULL,
	[usd] [float] NULL,
	[cny] [float] NULL,
	[hkd] [float] NULL,
	[idr] [float] NULL,
	[myr] [float] NULL,
	[sar] [float] NULL,
	[sgd] [float] NULL,
	[krw] [float] NULL,
	[twd] [float] NULL,
	[thb] [float] NULL,
	[aed] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_Gross NG Debt Ratios]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_Gross NG Debt Ratios](
	[Time_Idx] [int] NOT NULL,
	[Gross NG Debt] [numeric](18, 2) NULL,
	[GDP] [numeric](18, 2) NULL,
	[GNI] [numeric](18, 2) NULL,
	[Cash Remittance in Peso] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_GS_Issued_Offshore]    Script Date: 12/1/2023 3:41:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_GS_Issued_Offshore](
	[Time_Idx] [int] NOT NULL,
	[Residents ] [numeric](18, 2) NULL,
	[Private Sector ] [numeric](18, 2) NULL,
	[Public Banks] [numeric](18, 2) NULL,
	[Public Banks Trust Departments ] [numeric](18, 2) NULL,
	[Public Non-bank Financial Institutions] [numeric](18, 2) NULL,
	[Others] [numeric](18, 2) NULL,
	[Public Sector ] [numeric](18, 2) NULL,
	[National Government (Bond Sinking Fund)] [numeric](18, 2) NULL,
	[BSP] [numeric](18, 2) NULL,
	[GOCC] [numeric](18, 2) NULL,
	[Government Financial Institutions] [numeric](18, 2) NULL,
	[Private Banks] [numeric](18, 2) NULL,
	[Private Banks Trust Departments ] [numeric](18, 2) NULL,
	[Private Non-bank Financial Institutions] [numeric](18, 2) NULL,
	[Non-residents ] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_GS_Issued_Onshore]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_GS_Issued_Onshore](
	[Time_Idx] [int] NOT NULL,
	[Total Outstanding Government Securities Issued Onshore] [numeric](18, 2) NULL,
	[Banks] [numeric](18, 2) NULL,
	[Bangko Sentral ng Pilipinas (based on BSP-FM reports)] [numeric](18, 2) NULL,
	[Insurance Companies] [numeric](18, 2) NULL,
	[Investment Houses] [numeric](18, 2) NULL,
	[Custodians] [numeric](18, 2) NULL,
	[Depository] [numeric](18, 2) NULL,
	[Private Corporations] [numeric](18, 2) NULL,
	[Government Corporations] [numeric](18, 2) NULL,
	[Local Government Units] [numeric](18, 2) NULL,
	[Tax-exempt Institutions] [numeric](18, 2) NULL,
	[Other residents] [numeric](18, 2) NULL,
	[Non-residents] [numeric](18, 2) NULL,
	[OS GS held by banks] [numeric](18, 2) NULL,
	[OS GS issued onshore held by the BSP %] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_GSOffshore]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_GSOffshore](
	[Investors_Level4_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[Amount] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_GSOnshore]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_GSOnshore](
	[Time_Idx] [int] NOT NULL,
	[OnshoreGSIssuances_Idx] [int] NOT NULL,
	[Amount] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_IBCLTransactions]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_IBCLTransactions](
	[Time_Idx] [int] NOT NULL,
	[BSPRateType_Idx] [int] NOT NULL,
	[BSPTenorsRate_Idx] [int] NOT NULL,
	[IBCLRate] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_LDR]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_LDR](
	[Time_Idx] [int] NOT NULL,
	[Industry_Idx] [int] NOT NULL,
	[TotalLoanPortfolio] [float] NULL,
	[InterbankLoansReceivables] [float] NULL,
	[TotalDepositLiabilities] [float] NULL,
	[TLP_exclusiveofIBL_netofamortization] [float] NULL,
	[TotalRepurchaseAgreement] [float] NULL,
	[DemandAndNow] [float] NULL,
	[LTNCD] [float] NULL,
	[Savings] [float] NULL,
	[LDRTime] [float] NULL,
	[LoansandReceivables_others_netofamortization] [float] NULL,
	[LoansNet] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_LDR_TotalRepurchaseAgreement]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_LDR_TotalRepurchaseAgreement](
	[Time_Idx] [int] NOT NULL,
	[Industry_Idx] [int] NOT NULL,
	[TotalRepurchaseAgreement] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MacroAssumptions]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MacroAssumptions](
	[Time_Idx] [int] NOT NULL,
	[MacroAssumptions_Type_Idx] [int] NOT NULL,
	[GDP] [numeric](18, 2) NULL,
	[NG Surplus/-Deficit] [numeric](18, 2) NULL,
	[NG Surplus/-Deficit % to GDP] [numeric](18, 2) NULL,
	[Surplus/Deficit Projection] [numeric](18, 2) NULL,
	[Surplus/-Deficit % to GDP Projection] [numeric](18, 2) NULL,
	[CPSFP Surplus/Deficit Projection] [numeric](18, 2) NULL,
	[CPSFP Surplus/Deficit % to GDP Projection] [numeric](18, 2) NULL,
	[CPSFP (Surplus/Deficit)] [numeric](18, 2) NULL,
	[CPSFP Surplus/Deficit % to GDP] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MERALCO_EnergySales]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MERALCO_EnergySales](
	[Time_Idx] [int] NOT NULL,
	[Meralco_SalesType_Idx] [int] NOT NULL,
	[Meralco_EnergySalesAmount] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MERALCO_KWH_Sales_Perf]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MERALCO_KWH_Sales_Perf](
	[Time_Idx] [int] NOT NULL,
	[ManufacturingCustomerType_Idx] [int] NOT NULL,
	[Meralco_ElectricityConsumptionAmount] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_CAR_Conso]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_CAR_Conso](
	[Time_Idx] [int] NULL,
	[Industry_Idx] [int] NULL,
	[CAR_Ratio_Conso] [decimal](18, 3) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_CAR_Solo]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_CAR_Solo](
	[Time_Idx] [int] NULL,
	[Industry_idx] [int] NULL,
	[Fact_CAR_Ratio_Solo] [decimal](18, 3) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_NBFI]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_NBFI](
	[Time_idx] [int] NOT NULL,
	[NBFIParticular_Idx] [int] NOT NULL,
	[NBFIBankKind_Idx] [int] NOT NULL,
	[Particular_Group] [nvarchar](250) NOT NULL,
	[Particular_Type] [nvarchar](250) NOT NULL,
	[Particular] [nvarchar](250) NOT NULL,
	[Amount] [numeric](18, 3) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FACT_MFSG_NBFI_FC_for del]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FACT_MFSG_NBFI_FC_for del](
	[Time_Idx] [int] NOT NULL,
	[BNKIND_Idx] [int] NOT NULL,
	[PARTICULAR_Idx] [int] NULL,
	[AMOUNT] [numeric](38, 2) NULL,
	[INDUSTRY_GROUP] [varchar](8) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_NBFI_SSS_GSIS f del]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_NBFI_SSS_GSIS f del](
	[Time_idx] [int] NOT NULL,
	[NBFIParticular_Idx] [int] NOT NULL,
	[NBFIBankKind_Idx] [int] NOT NULL,
	[Particular_Group] [nvarchar](250) NOT NULL,
	[Particular_Type] [nvarchar](250) NOT NULL,
	[Particular] [nvarchar](250) NOT NULL,
	[Amount] [numeric](18, 3) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FACT_MFSG_NBFIs]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FACT_MFSG_NBFIs](
	[Time_Idx] [int] NOT NULL,
	[BNKIND_Idx] [int] NOT NULL,
	[PARTICULAR_Idx] [int] NULL,
	[AMOUNT] [numeric](38, 3) NULL,
	[INDUSTRY_GROUP] [varchar](8) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FACT_MFSG_OFCS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FACT_MFSG_OFCS](
	[TRDATE] [numeric](8, 0) NULL,
	[RECNO_CODE_Idx] [int] NULL,
	[4SRcode_Idx] [int] NOT NULL,
	[BNKIND_Idx] [int] NOT NULL,
	[AMOUNT] [float] NULL,
	[SOURCE_TYPE] [varchar](5) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_SLOS_ADDITIONAL_RESULTS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_SLOS_ADDITIONAL_RESULTS](
	[Time_Idx] [int] NOT NULL,
	[ASSETTYPE_LVT_Idx] [int] NOT NULL,
	[BankName] [nvarchar](50) NULL,
	[ASSET_SIZE] [nvarchar](200) NULL,
	[Values] [numeric](18, 2) NOT NULL,
	[SubmissionCount] [int] NULL,
	[Lower] [nvarchar](70) NULL,
	[Upper] [nvarchar](70) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS](
	[Time_Idx] [int] NOT NULL,
	[Question_Idx] [int] NOT NULL,
	[QuestionType_Idx] [int] NOT NULL,
	[CreditStandardFactors_Idx] [int] NOT NULL,
	[Market_Idx] [int] NOT NULL,
	[Market_code] [nvarchar](50) NULL,
	[III_Values] [decimal](18, 14) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES](
	[Time_Idx] [int] NOT NULL,
	[Question_Idx] [int] NOT NULL,
	[QuestionType_Idx] [int] NOT NULL,
	[QuestionGroup_Idx] [int] NULL,
	[CreditStandardFactors_Idx] [int] NOT NULL,
	[Market_Idx] [int] NOT NULL,
	[Market_code] [nvarchar](50) NULL,
	[I_Values] [decimal](18, 14) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS](
	[Time_Idx] [int] NOT NULL,
	[Question_Idx] [int] NOT NULL,
	[QuestionType_Idx] [int] NOT NULL,
	[QUESTIONGROUP_idx] [int] NULL,
	[CreditStandardFactors_Idx] [int] NOT NULL,
	[Market_Idx] [int] NOT NULL,
	[Market_code] [nvarchar](50) NULL,
	[II_Values] [decimal](18, 14) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_SLOS_REMARKS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_SLOS_REMARKS](
	[Time_Idx] [int] NOT NULL,
	[ITEM_CODE] [nvarchar](10) NULL,
	[SUB_ITEM] [nvarchar](200) NULL,
	[BANK_NAME] [nvarchar](200) NULL,
	[REMARK] [nvarchar](max) NULL,
	[Bank_Idx] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_STATBUL_PFS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_STATBUL_PFS](
	[Time_Idx] [int] NOT NULL,
	[SALN_Type] [nvarchar](100) NULL,
	[Value] [numeric](18, 2) NULL,
	[PFS_Type] [nvarchar](100) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_STATBUL_TAB1_47]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_STATBUL_TAB1_47](
	[Time_idx] [int] NOT NULL,
	[DepositAcountType_idx] [int] NOT NULL,
	[Industry_Code] [int] NULL,
	[Bank_Code] [nvarchar](10) NULL,
	[Sched_No] [nvarchar](10) NULL,
	[Value] [numeric](18, 2) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_STATBUL_TAB1_48_DEPOSIT_LIABILITIES]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_STATBUL_TAB1_48_DEPOSIT_LIABILITIES](
	[Time_idx] [int] NOT NULL,
	[DepositAcountType_idx] [int] NOT NULL,
	[Industry_Idx] [int] NULL,
	[Bank_Code] [nvarchar](10) NULL,
	[Sched_No] [nvarchar](10) NULL,
	[Peso_Value] [numeric](18, 2) NOT NULL,
	[Foreign_Value] [numeric](18, 2) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_STATBUL_TAB1_51_52_53_BS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_STATBUL_TAB1_51_52_53_BS](
	[Time_idx] [int] NOT NULL,
	[BankParticularAccount_Idx] [int] NOT NULL,
	[Industry_idx] [int] NOT NULL,
	[Bank_Code] [nvarchar](10) NULL,
	[Sched_No] [nvarchar](10) NULL,
	[RecNo] [nvarchar](10) NULL,
	[Value] [numeric](18, 2) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_STATBUL_TOTRES]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_STATBUL_TOTRES](
	[Time_idx] [int] NOT NULL,
	[Institution_Idx] [int] NOT NULL,
	[PFSParticular_idx] [int] NOT NULL,
	[SALN_Idx] [int] NULL,
	[Value] [float] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_STATBUL_TOTRES_Ori]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_STATBUL_TOTRES_Ori](
	[Time_idx] [int] NOT NULL,
	[Institution_Idx] [int] NOT NULL,
	[PFSParticular_idx] [int] NOT NULL,
	[SALN_Idx] [int] NULL,
	[Value] [numeric](18, 2) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_STATBUL_TOTRES_test]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_STATBUL_TOTRES_test](
	[Time_idx] [int] NOT NULL,
	[Institution_Idx] [int] NOT NULL,
	[PFSParticular_idx] [int] NOT NULL,
	[SALN_Idx] [int] NULL,
	[Value] [float] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_MFSG_TOTRES_BANKS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_MFSG_TOTRES_BANKS](
	[Time_Idx] [int] NOT NULL,
	[TrDate] [numeric](8, 0) NOT NULL,
	[BkCode] [numeric](6, 0) NOT NULL,
	[TotalAsset] [numeric](19, 2) NULL,
	[INDCODE] [numeric](2, 0) NULL,
	[BRANCH] [numeric](5, 0) NULL,
	[BOOK] [numeric](1, 0) NULL,
	[BANKTYPE] [nchar](2) NOT NULL,
	[DomesticForeign] [nchar](1) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_Net NG Debt Ratio]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_Net NG Debt Ratio](
	[Time_Idx] [int] NOT NULL,
	[Currency & Deposits] [numeric](18, 2) NULL,
	[Short-term Assets] [numeric](18, 2) NULL,
	[Total Financial Assets] [numeric](18, 2) NULL,
	[NG Debt Ratio (Net of Currency and Deposits)] [numeric](18, 2) NULL,
	[NG Debt Ratio (Net of Short-term Assets)] [numeric](18, 2) NULL,
	[NG Debt Ratio (Net of Total Financial Assets)] [numeric](18, 2) NULL,
	[Cash Remittance in Peso] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_NPL]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_NPL](
	[Time_Idx] [int] NOT NULL,
	[Bank_Idx] [int] NOT NULL,
	[TotalLoans] [numeric](18, 2) NULL,
	[GrossNPL] [numeric](18, 2) NULL,
	[NetNPL] [numeric](18, 2) NULL,
	[LLP] [numeric](18, 2) NULL,
	[ROPOA] [numeric](18, 2) NULL,
	[ROPOAGross] [numeric](18, 2) NULL,
	[NonPerformingAssets] [numeric](18, 2) NULL,
	[RetructuredLoans] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_NUMFIN]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_NUMFIN](
	[Time_Idx] [int] NOT NULL,
	[Category_Idx] [int] NOT NULL,
	[Branch_Idx] [int] NOT NULL,
	[NUMFIN] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_Numfin1]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_Numfin1](
	[Time_Idx] [int] NOT NULL,
	[Category_Idx] [int] NOT NULL,
	[Branch_Idx] [int] NOT NULL,
	[NUMFIN] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_Poverty]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_Poverty](
	[Province_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[PovertyIncidenceinPercent] [numeric](18, 2) NULL,
	[PerCapitaPovertyThresholdinPesos] [numeric](18, 2) NULL,
	[PerCapitaFoodThresholdinPesos] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_PSALM_Grid]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_PSALM_Grid](
	[Location_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[Energy Sales] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_PSALM_PlantType]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_PSALM_PlantType](
	[PlantType_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[Energy Sales] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_PSALM_SummaryEnergySales]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_PSALM_SummaryEnergySales](
	[Location_Idx] [int] NOT NULL,
	[EnergySalesType_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[Energy Sales] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_PSEFRatios]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_PSEFRatios](
	[Time_Idx] [int] NOT NULL,
	[PriceEarningsRatio] [numeric](18, 2) NULL,
	[DebtEquityRatio] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_PSEMCapValue]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_PSEMCapValue](
	[Time_Idx] [int] NOT NULL,
	[Company_Idx] [int] NOT NULL,
	[MarketCapitalization] [numeric](18, 2) NULL,
	[ValueTurnover] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_PSESectoralReview]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_PSESectoralReview](
	[Time_Idx] [int] NOT NULL,
	[SectorType_Idx] [int] NOT NULL,
	[StockMarketCapitilization] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_PSESummary]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_PSESummary](
	[Time_Idx] [int] NOT NULL,
	[SectorType_Idx] [int] NOT NULL,
	[PSEiIndex] [numeric](18, 2) NULL,
	[StockTransactionVolume] [numeric](18, 2) NULL,
	[StockTransactionValue] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_RICE_ArrivalOfImported]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_RICE_ArrivalOfImported](
	[Time_Idx] [int] NOT NULL,
	[NumberOfSPSICUsed] [float] NULL,
	[VolumeOfRiceArrivalInMetricTons] [float] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_RICE_PH_Imports]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_RICE_PH_Imports](
	[Province_Idx] [int] NOT NULL,
	[RiceType_Idx] [int] NOT NULL,
	[CountryOfOrigin_Idx] [int] NOT NULL,
	[Port_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[VolumeOfRiceImportsInMetricTons] [float] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_RICE_SPSICIssuedAndVolumeApplied]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_RICE_SPSICIssuedAndVolumeApplied](
	[Time_Idx] [int] NOT NULL,
	[NumberOfSPSICIssuedForImportationOfMilledRice] [float] NULL,
	[VolumeOfMilledRiceImportationAppliedInMetricTons] [float] NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SLI_Indicator]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SLI_Indicator](
	[Time_Idx] [int] NOT NULL,
	[LaborForce_Idx] [int] NULL,
	[Indicator] [nvarchar](150) NULL,
	[Estimate] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SLI_LaborForce]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SLI_LaborForce](
	[Time_Idx] [int] NOT NULL,
	[Province_Idx] [int] NULL,
	[City_Idx] [int] NULL,
	[LaborForce_Idx] [int] NOT NULL,
	[Population_Estimate] [numeric](18, 2) NULL,
	[Population_StErr] [numeric](18, 2) NULL,
	[Population_COV] [numeric](18, 2) NULL,
	[Rate_Estimate] [numeric](18, 2) NULL,
	[Rate_StErr] [numeric](18, 2) NULL,
	[Rate_COV] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SLI_LaborStatistics]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SLI_LaborStatistics](
	[Time_Idx] [int] NOT NULL,
	[LSType_Idx] [int] NULL,
	[ESType_Idx] [int] NULL,
	[ASType_Idx] [int] NULL,
	[Value] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SLI_LegislatedWageRates]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SLI_LegislatedWageRates](
	[Time_Idx] [int] NOT NULL,
	[LWRType_Idx] [int] NULL,
	[LType_Idx] [int] NULL,
	[Region_Idx] [int] NULL,
	[AType_Idx] [int] NULL,
	[Value] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SLI_MajorIndustryGrp]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SLI_MajorIndustryGrp](
	[Time_Idx] [int] NOT NULL,
	[MajorIndustryGrp] [nvarchar](150) NULL,
	[Estimate] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SOCF_Equity]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SOCF_Equity](
	[Time_Idx] [int] NOT NULL,
	[Group_Idx] [int] NULL,
	[Sector_Idx] [int] NULL,
	[Company_Idx] [int] NULL,
	[SubType_Idx] [int] NULL,
	[CapitalRaised] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL,
	[Date_Listed] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SOCF_PO]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SOCF_PO](
	[Time_Idx] [int] NOT NULL,
	[Sector_Idx] [int] NULL,
	[Company_Idx] [int] NULL,
	[SubType_Idx] [int] NULL,
	[OfferPrice] [numeric](18, 2) NULL,
	[OfferSharesPrimary] [numeric](18, 2) NULL,
	[OfferSharesSecondary] [numeric](18, 2) NULL,
	[CapitalRaised] [numeric](18, 2) NULL,
	[TotalSizePO] [numeric](18, 2) NULL,
	[IPO] [numeric](18, 2) NULL,
	[FollowOn] [numeric](18, 2) NULL,
	[TotalCapitalRaised] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SOCF_PP]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SOCF_PP](
	[Time_Idx] [int] NOT NULL,
	[Sector_Idx] [int] NOT NULL,
	[Company_Idx] [int] NOT NULL,
	[OfferPrice] [numeric](18, 2) NULL,
	[SharesListed] [numeric](18, 2) NULL,
	[CapitalRaised] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SOCF_Securities]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SOCF_Securities](
	[Time_Idx] [int] NOT NULL,
	[Company_Idx] [int] NOT NULL,
	[Equities_Idx] [int] NULL,
	[SubType_Idx] [int] NULL,
	[InstrumentType] [nvarchar](50) NULL,
	[OrderNo] [numeric](18, 2) NULL,
	[Series] [numeric](18, 2) NULL,
	[Listing] [nvarchar](50) NULL,
	[IssueValue] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_SOCF_SR]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_SOCF_SR](
	[Time_Idx] [int] NOT NULL,
	[Sector_Idx] [int] NOT NULL,
	[Company_Idx] [int] NOT NULL,
	[OfferPrice] [numeric](18, 2) NULL,
	[OfferShares] [numeric](18, 2) NULL,
	[CapitalRaised] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_TBills_Series_Annual]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_TBills_Series_Annual](
	[Time_Idx] [int] NULL,
	[ISIN] [nvarchar](max) NULL,
	[Show] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_TBills_Series_Monthly]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_TBills_Series_Monthly](
	[Time_Idx] [int] NULL,
	[ISIN] [nvarchar](max) NULL,
	[Show] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_TBonds]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_TBonds](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[Instrument_Idx] [int] NOT NULL,
	[ISIN] [nvarchar](50) NULL,
	[Offering] [float] NULL,
	[CouponRate] [float] NULL,
	[High] [float] NULL,
	[Low] [float] NULL,
	[Average] [float] NULL,
	[Tendered] [float] NULL,
	[Volume] [float] NULL,
	[Rejected] [float] NULL,
	[Accepted] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_TBonds_Series_Annual]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_TBonds_Series_Annual](
	[Time_Idx] [int] NULL,
	[ISIN] [nvarchar](max) NULL,
	[Show] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_TBonds_Series_Monthly]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_TBonds_Series_Monthly](
	[Time_Idx] [int] NULL,
	[ISIN] [nvarchar](max) NULL,
	[Show] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_TCRS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_TCRS](
	[Time_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[BankType_Idx] [int] NOT NULL,
	[Industry_Idx] [int] NOT NULL,
	[PurposeofCredit_Idx] [int] NOT NULL,
	[TypeOfBorrower_Idx] [int] NOT NULL,
	[EconomicActivityCode_Idx] [int] NOT NULL,
	[TypeOfCredit_Idx] [int] NOT NULL,
	[Amount] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_TradeOil]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_TradeOil](
	[Time_Idx] [int] NOT NULL,
	[DubaiCrudeOilSpotPrices] [numeric](18, 2) NULL,
	[BrentCrudeOilSpotPrices] [numeric](18, 2) NULL,
	[DubaiCrudeOilFuturePrices] [numeric](18, 2) NULL,
	[BrentCrudeOilFuturePrices] [numeric](18, 2) NULL,
	[LoadDate_Idx] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_Unknown_Type_NAT]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_Unknown_Type_NAT](
	[Time_Idx] [int] NOT NULL,
	[Type_Idx] [int] NOT NULL,
	[Prices] [varchar](100) NOT NULL,
	[Sector] [varchar](1000) NOT NULL,
	[Value] [float] NULL,
	[TableName] [varchar](1000) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_VolumeProduction]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_VolumeProduction](
	[Time_Idx] [int] NOT NULL,
	[Country_Idx] [int] NOT NULL,
	[IslandGroup_Idx] [int] NOT NULL,
	[City_Idx] [int] NOT NULL,
	[Province_Idx] [int] NOT NULL,
	[Region_Idx] [int] NOT NULL,
	[District_Idx] [int] NOT NULL,
	[AnimalType_Idx] [int] NOT NULL,
	[FishType_Idx] [int] NOT NULL,
	[Production_Cat_Idx] [int] NOT NULL,
	[Value] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_WKI_TAB22]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_WKI_TAB22](
	[Time_Idx] [int] NOT NULL,
	[Rate] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_WKI_TAB3]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_WKI_TAB3](
	[Time_Idx] [int] NOT NULL,
	[Rate] [numeric](18, 2) NULL,
	[Created_Date] [date] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_WKITab22]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_WKITab22](
	[Time_Idx] [int] NOT NULL,
	[OvernightPhilippineInterbankReferenceRate] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Fact_YieldCurve]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Fact_YieldCurve](
	[Time_Idx] [int] NOT NULL,
	[Tenor_Idx] [int] NOT NULL,
	[BVALRate] [real] NULL,
	[BVALRateDiff] [real] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FITPRO_CLB_Hist]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FITPRO_CLB_Hist](
	[AsOfDate] [nvarchar](8) NULL,
	[Reporting Department] [nvarchar](255) NULL,
	[Name of Closed Bank] [nvarchar](255) NULL,
	[Date Closed] [nvarchar](255) NULL,
	[MB Res. #] [nvarchar](255) NULL,
	[MB Res. Date] [nvarchar](255) NULL,
	[TIN] [nvarchar](255) NULL,
	[Surname] [nvarchar](255) NULL,
	[First Name] [nvarchar](255) NULL,
	[Middle Name] [nvarchar](255) NULL,
	[Mother's Maiden Name (In case of married woman)] [nvarchar](255) NULL,
	[Civil Status] [nvarchar](255) NULL,
	[Gender] [nvarchar](255) NULL,
	[Date of Birth (mm-dd-yyyy)] [nvarchar](255) NULL,
	[Address (Last Known)] [nvarchar](255) NULL,
	[Position] [nvarchar](255) NULL,
	[Department / Unit (if applicable)] [nvarchar](255) NULL,
	[Division] [float] NULL,
	[Remarks] [nvarchar](255) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FSS_Fitpro_CLB_Hist]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FSS_Fitpro_CLB_Hist](
	[Reporting Department] [nvarchar](255) NULL,
	[Name of Closed Bank] [nvarchar](255) NULL,
	[Date Closed] [nvarchar](255) NULL,
	[MB Res. #] [nvarchar](255) NULL,
	[MB Res. Date] [nvarchar](255) NULL,
	[TIN] [nvarchar](255) NULL,
	[Surname] [nvarchar](255) NULL,
	[First Name] [nvarchar](255) NULL,
	[Middle Name] [nvarchar](255) NULL,
	[Mother's Maiden Name (In case of married woman)] [nvarchar](255) NULL,
	[Civil Status] [nvarchar](255) NULL,
	[Gender] [nvarchar](255) NULL,
	[Date of Birth (mm-dd-yyyy)] [nvarchar](255) NULL,
	[Address (Last Known)] [nvarchar](255) NULL,
	[Position] [nvarchar](255) NULL,
	[Department / Unit (if applicable)] [nvarchar](255) NULL,
	[Division] [float] NULL,
	[Remarks] [nvarchar](255) NULL,
	[TRDATE] [nvarchar](8) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PFSParticular]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PFSParticular](
	[PFSParticular_Idx] [int] NOT NULL,
	[PFSParticularCode] [nvarchar](255) NULL,
	[PFSParticularName] [nvarchar](255) NULL,
	[PFSParticularDesc] [nvarchar](255) NULL,
	[PFSParticularLevel] [int] NULL,
	[PFSParticularGroup] [nvarchar](255) NULL,
	[PFSParticularSubGroup] [nvarchar](255) NULL,
	[PFSCode] [nvarchar](255) NULL,
	[PFSParticularSort] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SSIS_Properties]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SSIS_Properties](
	[FolderPath] [varchar](100) NULL,
	[ErrorPath] [varchar](100) NULL,
	[DestinationPath] [varchar](100) NULL,
	[LogPath] [varchar](100) NULL,
	[TableName] [varchar](100) NULL,
	[FileName] [varchar](100) NULL,
	[StartReadingFromRow] [varchar](100) NULL,
	[StartingColumn] [varchar](100) NULL,
	[EndingColumn] [varchar](100) NULL,
	[EndingColumnCount] [varchar](100) NULL,
	[SheetNametoLoad] [varchar](100) NULL,
	[SchemaName] [varchar](100) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[t1]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[t1](
	[time_idx] [int] NOT NULL,
	[Value] [float] NULL,
	[Prices] [varchar](100) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[t2]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[t2](
	[time_idx] [int] NOT NULL,
	[Value] [float] NULL,
	[Prices] [varchar](100) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[t3]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[t3](
	[time_idx] [int] NOT NULL,
	[Value] [float] NULL,
	[Prices] [varchar](100) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TableCreator]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TableCreator](
	[TableName] [varchar](100) NULL,
	[FieldName] [varchar](100) NULL,
	[DataType] [varchar](100) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[test_09082023]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[test_09082023](
	[value] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tmp1]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tmp1](
	[Time_Idx] [int] NOT NULL,
	[ITEM_CODE] [nvarchar](10) NULL,
	[SUB_ITEM] [nvarchar](200) NULL,
	[BANK_NAME] [nvarchar](200) NULL,
	[REMARK] [nvarchar](max) NULL,
	[Bank_Idx] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[vw_Dim_Time_BSPRates]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[vw_Dim_Time_BSPRates](
	[Time_Idx] [int] NOT NULL,
	[ActualDate] [varchar](30) NULL,
	[Year] [int] NOT NULL,
	[Quarter] [int] NOT NULL,
	[Month] [int] NOT NULL,
	[Week] [int] NOT NULL,
	[DayofYear] [int] NOT NULL,
	[DayofMonth] [int] NOT NULL,
	[DayofWeek] [int] NOT NULL,
	[IsWeekend] [bit] NOT NULL,
	[IsHoliday] [bit] NULL,
	[BusinessYearWeek] [int] NOT NULL,
	[LeapYear] [tinyint] NOT NULL,
	[YearName] [varchar](30) NULL,
	[QuarterName] [varchar](62) NULL,
	[QuarterSort] [int] NULL,
	[MonthYear] [nvarchar](61) NULL,
	[MonthSort] [int] NULL,
	[MonthName] [nvarchar](30) NULL,
	[MonthShortName] [nvarchar](3) NULL,
	[MonthNameYTD] [nvarchar](9) NULL,
	[SemesterName] [varchar](12) NOT NULL,
	[MonthNumber] [varchar](31) NULL,
	[MonthIMFName] [varchar](61) NULL,
	[DayNameYTD] [nvarchar](42) NULL,
	[ActualDateMonth] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Index [IX_Fact_MFSG_SLOS_REMARKS]    Script Date: 12/1/2023 3:41:33 PM ******/
CREATE NONCLUSTERED INDEX [IX_Fact_MFSG_SLOS_REMARKS] ON [dbo].[Fact_MFSG_SLOS_REMARKS]
(
	[Time_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Dim_BankIndustry_Type] ADD  CONSTRAINT [DF_Dim_BankIndustry_Type__Industry_Idx]  DEFAULT ((-1)) FOR [Industry_Idx]
GO
ALTER TABLE [dbo].[Dim_City] ADD  CONSTRAINT [DF_Dim_Cityt_Idx]  DEFAULT ((-1)) FOR [District_Idx]
GO
ALTER TABLE [dbo].[Dim_Company] ADD  CONSTRAINT [DF_Dim_Company__Industry_Idx]  DEFAULT ((-1)) FOR [Industry_Idx]
GO
ALTER TABLE [dbo].[Dim_Company] ADD  CONSTRAINT [DF_Dim_Company__Type_Idx]  DEFAULT ((-1)) FOR [Type_Idx]
GO
ALTER TABLE [dbo].[Dim_Company] ADD  CONSTRAINT [DF_Dim_Company__Sector_Idx]  DEFAULT ((-1)) FOR [Sector_Idx]
GO
ALTER TABLE [dbo].[Dim_District] ADD  CONSTRAINT [DF_Dim_District_Idx]  DEFAULT ((-1)) FOR [Province_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level2] ADD  CONSTRAINT [DF_Dim_DSS_Sectors_Currency_DSS_Level2__DSS_Level1_Idx]  DEFAULT ((-1)) FOR [DSS_Level1_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level3] ADD  CONSTRAINT [DF_Dim_DSS_Sectors_Currency_DSS_Level3__DSS_Level2_Idx]  DEFAULT ((-1)) FOR [DSS_Level2_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level4] ADD  CONSTRAINT [DF_Dim_DSS_Sectors_Currency_DSS_Level4__DSS_Level3_Idx]  DEFAULT ((-1)) FOR [DSS_Level3_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level5] ADD  CONSTRAINT [DF_Dim_DSS_Sectors_Currency_DSS_Level5__DSS_Level4_Idx]  DEFAULT ((-1)) FOR [DSS_Level4_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level6] ADD  CONSTRAINT [DF_Dim_DSS_Sectors_Currency_DSS_Level6__DSS_Level5_Idx]  DEFAULT ((-1)) FOR [DSS_Level5_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level7] ADD  CONSTRAINT [DF_Dim_DSS_Sectors_Currency_DSS_Level7__DSS_Level6_Idx]  DEFAULT ((-1)) FOR [DSS_Level6_Idx]
GO
ALTER TABLE [dbo].[Dim_EnergySalesCategory_EnergySalesType] ADD  CONSTRAINT [DF_Dim_EnergySalesCategory_EnergySalesType__EnergySalesCategory_Idx]  DEFAULT ((-1)) FOR [EnergySalesCategory_Idx]
GO
ALTER TABLE [dbo].[Dim_Equities] ADD  CONSTRAINT [DF_Dim_Equities__Shelf_Idx]  DEFAULT (NULL) FOR [Shelf_Idx]
GO
ALTER TABLE [dbo].[Dim_Investors_Investors_Level2] ADD  CONSTRAINT [DF_Dim_Investors_Investors_Level2__Investors_Level1_Idx]  DEFAULT ((-1)) FOR [Investors_Level1_Idx]
GO
ALTER TABLE [dbo].[Dim_Investors_Investors_Level3] ADD  CONSTRAINT [DF_Dim_Investors_Investors_Level3__Investors_Level2_Idx]  DEFAULT ((-1)) FOR [Investors_Level2_Idx]
GO
ALTER TABLE [dbo].[Dim_Investors_Investors_Level4] ADD  CONSTRAINT [DF_Dim_Investors_Investors_Level4__Investors_Level3_Idx]  DEFAULT ((-1)) FOR [Investors_Level3_Idx]
GO
ALTER TABLE [dbo].[Dim_Meralco_SalesCategory_Meralco_SalesType] ADD  CONSTRAINT [DF_Dim_Meralco_SalesCategory_Meralco_SalesType__Meralco_SalesCategory_Idx]  DEFAULT ((-1)) FOR [Meralco_SalesCategory_Idx]
GO
ALTER TABLE [dbo].[Dim_Nat_ExportType] ADD  CONSTRAINT [DF_Dim_Nat_ExportType_Idx]  DEFAULT ((-1)) FOR [SubSectorType_Idx]
GO
ALTER TABLE [dbo].[Dim_Nat_GCFType] ADD  CONSTRAINT [DF_Dim_Nat_GCFType_Idx]  DEFAULT ((-1)) FOR [SubSectorType_Idx]
GO
ALTER TABLE [dbo].[Dim_Nat_ImportType] ADD  CONSTRAINT [DF_Dim_Nat_ImportType_Idx]  DEFAULT ((-1)) FOR [SubSectorType_Idx]
GO
ALTER TABLE [dbo].[Dim_Nat_Sector] ADD  CONSTRAINT [DF_Dim_Sector_Idx]  DEFAULT ((-1)) FOR [EconomicActivity_Idx]
GO
ALTER TABLE [dbo].[Dim_Nat_SubSector] ADD  CONSTRAINT [DF_Dim_SubSector_Idx]  DEFAULT ((-1)) FOR [Sector_Idx]
GO
ALTER TABLE [dbo].[Dim_Nat_SubSectorType] ADD  CONSTRAINT [DF_Dim_Nat_SubSectorType_Idx]  DEFAULT ((-1)) FOR [SubSector_Idx]
GO
ALTER TABLE [dbo].[Dim_Production_SubCategory] ADD  CONSTRAINT [DF_Dim_SubCategory_Idx]  DEFAULT ((-1)) FOR [Production_Category_Idx]
GO
ALTER TABLE [dbo].[Dim_Province] ADD  CONSTRAINT [DF_Dim_Province__Region_Idx]  DEFAULT ((-1)) FOR [Region_Idx]
GO
ALTER TABLE [dbo].[Dim_Reg_SubType] ADD  CONSTRAINT [DF_Dim_Reg_SubType__Type_Idx]  DEFAULT ((-1)) FOR [Type_Idx]
GO
ALTER TABLE [dbo].[Dim_Region] ADD  CONSTRAINT [DF_Dim_Region_Idx]  DEFAULT ((-1)) FOR [IslandGroup_Idx]
GO
ALTER TABLE [dbo].[Dim_Sector] ADD  CONSTRAINT [DF_Dim_Sector__Group_Idx]  DEFAULT ((-1)) FOR [Group_Idx]
GO
ALTER TABLE [dbo].[EDWAuditLog] ADD  CONSTRAINT [DF_AuditLog_TimeStamp]  DEFAULT (getdate()) FOR [TimeStamp]
GO
ALTER TABLE [dbo].[EDWETLParam] ADD  CONSTRAINT [DF_EDWETLParam_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Fact_DSS] ADD  DEFAULT ((-1)) FOR [DSS_Level7_Idx]
GO
ALTER TABLE [dbo].[Fact_DSS] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_BES] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_CapitalOutlay] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_TOUR] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_TradeImportExport] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IBCL] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDLendingRatesMonthlyFiltered] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDLendingRatesMonthlyUnFiltered] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDLendingRatesWeekly] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDLoans] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDLoansTotal] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDLoansTotalUnFiltered] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDLoansUnFiltered] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDNewLoansGrantedFiltered] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDNewLoansGrantedUnFiltered] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDSavingDeposit] ADD  CONSTRAINT [DF__Fact_ESLI__Time___6C98FCFF]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDSavingDepositFiltered] ADD  CONSTRAINT [DF__Fact_ESLI__Time___7345FA8E]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDSavingDepositWeeklyFiltered] ADD  CONSTRAINT [DF__Fact_ESLI__Time___556B7EE4]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDTimeDeposit] ADD  CONSTRAINT [DF__Fact_ESLI__Time___64ADC274]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDTimeDepositOverall] ADD  CONSTRAINT [DF__Fact_ESLI__Time___20D7BB14]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_IRLDTimeDepositOverallUnfiltered] ADD  CONSTRAINT [DF__Fact_ESLI__Time___6AD0B01E]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_SecuritiesAuctionResult] ADD  DEFAULT ((-1)) FOR [Auction Date_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_SecuritiesAuctionResult] ADD  DEFAULT ((-1)) FOR [Settlement Date_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_SecuritiesAuctionResult] ADD  DEFAULT ((-1)) FOR [Maturity Date_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_TDFAuctionResult] ADD  DEFAULT ((-1)) FOR [Auction Date_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_TenorRates] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_TenorRatesMonthly] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_WARR] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ITR_YTDWAIR] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MISSI_CUR] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MISSI_VaPI] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MISSI_VoPI] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_RERB] ADD  CONSTRAINT [DF__Fact_ESLI__Time___07EC11B9]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_AFF] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_ConsodilatedAccounts] ADD  CONSTRAINT [DF__Fact_ESLI__Time___4905A7FF]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_Export] ADD  CONSTRAINT [DF__Fact_ESLI__Time___6DCD185A]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_GCF] ADD  CONSTRAINT [DF__Fact_ESLI__Time___2F2FFC0C]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_GRDP] ADD  CONSTRAINT [DF__Fact_ESLI__Time___6B8FCA2D]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_HFCE] ADD  CONSTRAINT [DF__Fact_ESLI__Time___3118447E]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_Import] ADD  CONSTRAINT [DF__Fact_ESLI__Time___719DA93E]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_MFG] ADD  CONSTRAINT [DF__Fact_ESLI__Time___783FB9D5]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_PerCapita] ADD  CONSTRAINT [DF__Fact_ESLI__Time___33008CF0]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_PerCapitaYear] ADD  CONSTRAINT [DF__Fact_ESLI__Time___37F02A96]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_REOD] ADD  CONSTRAINT [DF__Fact_ESLI__Time___33F4B129]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp] ADD  CONSTRAINT [DF__Fact_ESLI__Time___6F605B11]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp_Annual] ADD  CONSTRAINT [DF__Fact_ESLIG__Time___33008CF0]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd] ADD  CONSTRAINT [DF__Fact_ESLI__Time___723CC7BC]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd_Annual] ADD  CONSTRAINT [DF__Fact_ESLIG__Time___SummaryInd]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_WEO] ADD  CONSTRAINT [DF__Fact_ESLI__Time___4BE214AA]  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_OPI_GRPI] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_OPI_GWPI] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_OPI_PPI] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_LicensedToSell] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_Land] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeCapital] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeRental] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeSpaceDemand] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_ResidentialCapital] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_ResidentialRental] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_VacancyRate] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_NumberFloorArea] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_NumberFloorArea] ADD  DEFAULT ((-1)) FOR [Province_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_NumberFloorArea] ADD  DEFAULT ((-1)) FOR [ResidentType_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_AquaCulture] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_CommercialFisheries] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_FisheriesVolume] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_GoldSilver] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_InlandCommercialFisheries] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_Livestock] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_MajorForestProducts] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_MarineMunicipallFisheries] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_NumberFloorArea] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_NumberFloorArea] ADD  DEFAULT ((-1)) FOR [City_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_NumberFloorArea] ADD  DEFAULT ((-1)) FOR [ResidentType_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_OtherCropsAreaHarvested] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_OtherCropsVolume] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_PalayCornAreaHarvested] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_PalayCornVolume] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_PoultryEggsVolume] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_AnnualIndices] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_AnnualPrice] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_MonthlyIndices] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_MonthlyPrice] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_FSI] ADD  DEFAULT ((-1)) FOR [FSICountries_Idx]
GO
ALTER TABLE [dbo].[Fact_FSI] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_Gross NG Debt Ratios] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_GS_Issued_Offshore] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_GS_Issued_Onshore] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_GSOffshore] ADD  DEFAULT ((-1)) FOR [Investors_Level4_Idx]
GO
ALTER TABLE [dbo].[Fact_GSOffshore] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_GSOnshore] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_GSOnshore] ADD  DEFAULT ((-1)) FOR [OnshoreGSIssuances_Idx]
GO
ALTER TABLE [dbo].[Fact_MacroAssumptions] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_MacroAssumptions] ADD  DEFAULT ((-1)) FOR [MacroAssumptions_Type_Idx]
GO
ALTER TABLE [dbo].[Fact_MERALCO_EnergySales] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_MERALCO_EnergySales] ADD  DEFAULT ((-1)) FOR [Meralco_SalesType_Idx]
GO
ALTER TABLE [dbo].[Fact_MERALCO_KWH_Sales_Perf] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_MERALCO_KWH_Sales_Perf] ADD  DEFAULT ((-1)) FOR [ManufacturingCustomerType_Idx]
GO
ALTER TABLE [dbo].[Fact_Net NG Debt Ratio] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_PSALM_Grid] ADD  DEFAULT ((-1)) FOR [Location_Idx]
GO
ALTER TABLE [dbo].[Fact_PSALM_Grid] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_PSALM_PlantType] ADD  DEFAULT ((-1)) FOR [PlantType_Idx]
GO
ALTER TABLE [dbo].[Fact_PSALM_PlantType] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_PSALM_SummaryEnergySales] ADD  DEFAULT ((-1)) FOR [Location_Idx]
GO
ALTER TABLE [dbo].[Fact_PSALM_SummaryEnergySales] ADD  DEFAULT ((-1)) FOR [EnergySalesType_Idx]
GO
ALTER TABLE [dbo].[Fact_PSALM_SummaryEnergySales] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_RICE_ArrivalOfImported] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_RICE_PH_Imports] ADD  DEFAULT ((-1)) FOR [Province_Idx]
GO
ALTER TABLE [dbo].[Fact_RICE_PH_Imports] ADD  DEFAULT ((-1)) FOR [RiceType_Idx]
GO
ALTER TABLE [dbo].[Fact_RICE_PH_Imports] ADD  DEFAULT ((-1)) FOR [CountryOfOrigin_Idx]
GO
ALTER TABLE [dbo].[Fact_RICE_PH_Imports] ADD  DEFAULT ((-1)) FOR [Port_Idx]
GO
ALTER TABLE [dbo].[Fact_RICE_PH_Imports] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_RICE_SPSICIssuedAndVolumeApplied] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds] ADD  DEFAULT ((-1)) FOR [Type_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds] ADD  DEFAULT ((-1)) FOR [Sector_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds] ADD  DEFAULT ((-1)) FOR [Group_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds] ADD  DEFAULT ((-1)) FOR [Company_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity] ADD  DEFAULT ((-1)) FOR [Group_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity] ADD  DEFAULT ((-1)) FOR [Sector_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity] ADD  DEFAULT ((-1)) FOR [Company_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity] ADD  DEFAULT ((-1)) FOR [SubType_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_PO] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_PO] ADD  DEFAULT ((-1)) FOR [Sector_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_PO] ADD  DEFAULT ((-1)) FOR [Company_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_PO] ADD  DEFAULT ((-1)) FOR [SubType_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_PP] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_PP] ADD  DEFAULT ((-1)) FOR [Sector_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_PP] ADD  DEFAULT ((-1)) FOR [Company_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities] ADD  DEFAULT ((-1)) FOR [Company_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities] ADD  DEFAULT ((-1)) FOR [Equities_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities] ADD  DEFAULT ((-1)) FOR [SubType_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_SR] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_SR] ADD  DEFAULT ((-1)) FOR [Sector_Idx]
GO
ALTER TABLE [dbo].[Fact_SOCF_SR] ADD  DEFAULT ((-1)) FOR [Company_Idx]
GO
ALTER TABLE [dbo].[Fact_TBills] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_TBills] ADD  DEFAULT ((-1)) FOR [Tenor_Idx]
GO
ALTER TABLE [dbo].[Fact_TBonds] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_TBonds] ADD  DEFAULT ((-1)) FOR [Tenor_Idx]
GO
ALTER TABLE [dbo].[Fact_TBonds] ADD  DEFAULT ((-1)) FOR [Instrument_Idx]
GO
ALTER TABLE [dbo].[Fact_TCRS] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_TCRS] ADD  DEFAULT ((-1)) FOR [Region_Idx]
GO
ALTER TABLE [dbo].[Fact_TCRS] ADD  DEFAULT ((-1)) FOR [BankType_Idx]
GO
ALTER TABLE [dbo].[Fact_TCRS] ADD  DEFAULT ((-1)) FOR [Industry_Idx]
GO
ALTER TABLE [dbo].[Fact_TCRS] ADD  DEFAULT ((-1)) FOR [PurposeofCredit_Idx]
GO
ALTER TABLE [dbo].[Fact_TCRS] ADD  DEFAULT ((-1)) FOR [TypeOfBorrower_Idx]
GO
ALTER TABLE [dbo].[Fact_TCRS] ADD  DEFAULT ((-1)) FOR [EconomicActivityCode_Idx]
GO
ALTER TABLE [dbo].[Fact_TCRS] ADD  DEFAULT ((-1)) FOR [TypeOfCredit_Idx]
GO
ALTER TABLE [dbo].[Fact_Unknown_Type_NAT] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] ADD  DEFAULT ((-1)) FOR [Country_Idx]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] ADD  DEFAULT ((-1)) FOR [IslandGroup_Idx]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] ADD  DEFAULT ((-1)) FOR [City_Idx]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] ADD  DEFAULT ((-1)) FOR [Province_Idx]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] ADD  DEFAULT ((-1)) FOR [Region_Idx]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] ADD  DEFAULT ((-1)) FOR [District_Idx]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] ADD  DEFAULT ((-1)) FOR [AnimalType_Idx]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] ADD  DEFAULT ((-1)) FOR [FishType_Idx]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] ADD  DEFAULT ((-1)) FOR [Production_Cat_Idx]
GO
ALTER TABLE [dbo].[Fact_WKI_TAB22] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Fact_WKI_TAB3] ADD  DEFAULT ((-1)) FOR [Time_Idx]
GO
ALTER TABLE [dbo].[Dim_BankIndustry_Type]  WITH CHECK ADD  CONSTRAINT [FK_Dim_BankIndustry_Type__Industry_Idx] FOREIGN KEY([Industry_Idx])
REFERENCES [dbo].[Dim_BankIndustry_Industry] ([Industry_Idx])
GO
ALTER TABLE [dbo].[Dim_BankIndustry_Type] CHECK CONSTRAINT [FK_Dim_BankIndustry_Type__Industry_Idx]
GO
ALTER TABLE [dbo].[Dim_BES_BCI]  WITH CHECK ADD  CONSTRAINT [FK_Dim_BES_BCI_Dim_BES_OtherCountry] FOREIGN KEY([Institution/Country_Idx])
REFERENCES [dbo].[Dim_BES_OtherCountry] ([Institution_Country_Idx])
GO
ALTER TABLE [dbo].[Dim_BES_BCI] CHECK CONSTRAINT [FK_Dim_BES_BCI_Dim_BES_OtherCountry]
GO
ALTER TABLE [dbo].[Dim_BES_Branch]  WITH CHECK ADD  CONSTRAINT [FK_Dim_BES_Branch_Dim_Location_Region] FOREIGN KEY([Region_Idx])
REFERENCES [dbo].[Dim_Location_Region] ([Region_Idx])
GO
ALTER TABLE [dbo].[Dim_BES_Branch] CHECK CONSTRAINT [FK_Dim_BES_Branch_Dim_Location_Region]
GO
ALTER TABLE [dbo].[Dim_BES_RegionalTable_SubSection]  WITH CHECK ADD  CONSTRAINT [FK_Dim_BES_RegionalTable_SubSection_Dim_BES_RegionalTable_Section] FOREIGN KEY([Section_Idx])
REFERENCES [dbo].[Dim_BES_RegionalTable_Section] ([Section_Idx])
GO
ALTER TABLE [dbo].[Dim_BES_RegionalTable_SubSection] CHECK CONSTRAINT [FK_Dim_BES_RegionalTable_SubSection_Dim_BES_RegionalTable_Section]
GO
ALTER TABLE [dbo].[Dim_BES_SubSector]  WITH CHECK ADD  CONSTRAINT [FK_Dim_BES_SubSector_Dim_BES_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_BES_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Dim_BES_SubSector] CHECK CONSTRAINT [FK_Dim_BES_SubSector_Dim_BES_Sector]
GO
ALTER TABLE [dbo].[Dim_City]  WITH CHECK ADD  CONSTRAINT [FK_Dim_City_Idx] FOREIGN KEY([District_Idx])
REFERENCES [dbo].[Dim_District] ([District_Idx])
GO
ALTER TABLE [dbo].[Dim_City] CHECK CONSTRAINT [FK_Dim_City_Idx]
GO
ALTER TABLE [dbo].[Dim_Company]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Company__Sector_Idx] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Dim_Company] CHECK CONSTRAINT [FK_Dim_Company__Sector_Idx]
GO
ALTER TABLE [dbo].[Dim_Company]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Company__Type_Idx] FOREIGN KEY([Type_Idx])
REFERENCES [dbo].[Dim_Company_Type] ([Type_Idx])
GO
ALTER TABLE [dbo].[Dim_Company] CHECK CONSTRAINT [FK_Dim_Company__Type_Idx]
GO
ALTER TABLE [dbo].[Dim_District]  WITH CHECK ADD  CONSTRAINT [FK_Dim_District_Idx] FOREIGN KEY([Province_Idx])
REFERENCES [dbo].[Dim_Province] ([Province_Idx])
GO
ALTER TABLE [dbo].[Dim_District] CHECK CONSTRAINT [FK_Dim_District_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level2]  WITH CHECK ADD  CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level2__DSS_Level1_Idx] FOREIGN KEY([DSS_Level1_Idx])
REFERENCES [dbo].[Dim_DSS_Sectors_Currency_DSS_Level1] ([DSS_Level1_Idx])
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level2] CHECK CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level2__DSS_Level1_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level3]  WITH CHECK ADD  CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level3__DSS_Level2_Idx] FOREIGN KEY([DSS_Level2_Idx])
REFERENCES [dbo].[Dim_DSS_Sectors_Currency_DSS_Level2] ([DSS_Level2_Idx])
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level3] CHECK CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level3__DSS_Level2_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level4]  WITH CHECK ADD  CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level4__DSS_Level3_Idx] FOREIGN KEY([DSS_Level3_Idx])
REFERENCES [dbo].[Dim_DSS_Sectors_Currency_DSS_Level3] ([DSS_Level3_Idx])
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level4] CHECK CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level4__DSS_Level3_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level5]  WITH CHECK ADD  CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level5__DSS_Level4_Idx] FOREIGN KEY([DSS_Level4_Idx])
REFERENCES [dbo].[Dim_DSS_Sectors_Currency_DSS_Level4] ([DSS_Level4_Idx])
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level5] CHECK CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level5__DSS_Level4_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level6]  WITH CHECK ADD  CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level6__DSS_Level5_Idx] FOREIGN KEY([DSS_Level5_Idx])
REFERENCES [dbo].[Dim_DSS_Sectors_Currency_DSS_Level5] ([DSS_Level5_Idx])
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level6] CHECK CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level6__DSS_Level5_Idx]
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level7]  WITH CHECK ADD  CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level7__DSS_Level6_Idx] FOREIGN KEY([DSS_Level6_Idx])
REFERENCES [dbo].[Dim_DSS_Sectors_Currency_DSS_Level6] ([DSS_Level6_Idx])
GO
ALTER TABLE [dbo].[Dim_DSS_Sectors_Currency_DSS_Level7] CHECK CONSTRAINT [FK_Dim_DSS_Sectors_Currency_DSS_Level7__DSS_Level6_Idx]
GO
ALTER TABLE [dbo].[Dim_EnergySalesCategory_EnergySalesType]  WITH CHECK ADD  CONSTRAINT [FK_Dim_EnergySalesCategory_EnergySalesType__EnergySalesCategory_Idx] FOREIGN KEY([EnergySalesCategory_Idx])
REFERENCES [dbo].[Dim_EnergySalesCategory_EnergySalesCategory] ([EnergySalesCategory_Idx])
GO
ALTER TABLE [dbo].[Dim_EnergySalesCategory_EnergySalesType] CHECK CONSTRAINT [FK_Dim_EnergySalesCategory_EnergySalesType__EnergySalesCategory_Idx]
GO
ALTER TABLE [dbo].[Dim_Equities]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Equities__Shelf_Idx] FOREIGN KEY([Shelf_Idx])
REFERENCES [dbo].[Dim_Shelf] ([Shelf_Idx])
GO
ALTER TABLE [dbo].[Dim_Equities] CHECK CONSTRAINT [FK_Dim_Equities__Shelf_Idx]
GO
ALTER TABLE [dbo].[Dim_Investors_Investors_Level2]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Investors_Investors_Level2__Investors_Level1_Idx] FOREIGN KEY([Investors_Level1_Idx])
REFERENCES [dbo].[Dim_Investors_Investors_Level1] ([Investors_Level1_Idx])
GO
ALTER TABLE [dbo].[Dim_Investors_Investors_Level2] CHECK CONSTRAINT [FK_Dim_Investors_Investors_Level2__Investors_Level1_Idx]
GO
ALTER TABLE [dbo].[Dim_Investors_Investors_Level3]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Investors_Investors_Level3__Investors_Level2_Idx] FOREIGN KEY([Investors_Level2_Idx])
REFERENCES [dbo].[Dim_Investors_Investors_Level2] ([Investors_Level2_Idx])
GO
ALTER TABLE [dbo].[Dim_Investors_Investors_Level3] CHECK CONSTRAINT [FK_Dim_Investors_Investors_Level3__Investors_Level2_Idx]
GO
ALTER TABLE [dbo].[Dim_Investors_Investors_Level4]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Investors_Investors_Level4__Investors_Level3_Idx] FOREIGN KEY([Investors_Level3_Idx])
REFERENCES [dbo].[Dim_Investors_Investors_Level3] ([Investors_Level3_Idx])
GO
ALTER TABLE [dbo].[Dim_Investors_Investors_Level4] CHECK CONSTRAINT [FK_Dim_Investors_Investors_Level4__Investors_Level3_Idx]
GO
ALTER TABLE [dbo].[Dim_Location_Region]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Location_Region_Dim_Location_MajorIslandGroup] FOREIGN KEY([MajorIslandGroup_Idx])
REFERENCES [dbo].[Dim_Location_MajorIslandGroup] ([MajorIslandGroup_Idx])
GO
ALTER TABLE [dbo].[Dim_Location_Region] CHECK CONSTRAINT [FK_Dim_Location_Region_Dim_Location_MajorIslandGroup]
GO
ALTER TABLE [dbo].[Dim_Meralco_SalesCategory_Meralco_SalesType]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Meralco_SalesCategory_Meralco_SalesType__Meralco_SalesCategory_Idx] FOREIGN KEY([Meralco_SalesCategory_Idx])
REFERENCES [dbo].[Dim_Meralco_SalesCategory_Meralco_SalesCategory] ([Meralco_SalesCategory_Idx])
GO
ALTER TABLE [dbo].[Dim_Meralco_SalesCategory_Meralco_SalesType] CHECK CONSTRAINT [FK_Dim_Meralco_SalesCategory_Meralco_SalesType__Meralco_SalesCategory_Idx]
GO
ALTER TABLE [dbo].[Dim_PMISector]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Dim_PMICategory_PMICategory_Idx] FOREIGN KEY([PMICategory_idx])
REFERENCES [dbo].[Dim_PMICategory] ([PMICategory_Idx])
GO
ALTER TABLE [dbo].[Dim_PMISector] CHECK CONSTRAINT [FK_Dim_Dim_PMICategory_PMICategory_Idx]
GO
ALTER TABLE [dbo].[Dim_PMISector]  WITH CHECK ADD  CONSTRAINT [FK_Dim_PMISector_Dim_PMISector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_PMISector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Dim_PMISector] CHECK CONSTRAINT [FK_Dim_PMISector_Dim_PMISector]
GO
ALTER TABLE [dbo].[Dim_Reg_SubType]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Reg_SubType__Type_Idx] FOREIGN KEY([Type_Idx])
REFERENCES [dbo].[Dim_Reg_Type] ([Type_Idx])
GO
ALTER TABLE [dbo].[Dim_Reg_SubType] CHECK CONSTRAINT [FK_Dim_Reg_SubType__Type_Idx]
GO
ALTER TABLE [dbo].[Dim_Region]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Region_Idx] FOREIGN KEY([Region_Idx])
REFERENCES [dbo].[Dim_Region] ([Region_Idx])
GO
ALTER TABLE [dbo].[Dim_Region] CHECK CONSTRAINT [FK_Dim_Region_Idx]
GO
ALTER TABLE [dbo].[Dim_Sector]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Sector__Group_Idx] FOREIGN KEY([Group_Idx])
REFERENCES [dbo].[Dim_Sector_Group] ([Group_Idx])
GO
ALTER TABLE [dbo].[Dim_Sector] CHECK CONSTRAINT [FK_Dim_Sector__Group_Idx]
GO
ALTER TABLE [dbo].[Fact_BES_GLobalWeights]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_GLobalWeights_Dim_BES_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_BES_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_GLobalWeights] CHECK CONSTRAINT [FK_Fact_BES_GLobalWeights_Dim_BES_Sector]
GO
ALTER TABLE [dbo].[Fact_BES_GLobalWeights]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_GLobalWeights_Dim_BES_SubSector] FOREIGN KEY([Subsector_Idx])
REFERENCES [dbo].[Dim_BES_SubSector] ([Subsector_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_GLobalWeights] CHECK CONSTRAINT [FK_Fact_BES_GLobalWeights_Dim_BES_SubSector]
GO
ALTER TABLE [dbo].[Fact_BES_GLobalWeights]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_GLobalWeights_Dim_Location_Region] FOREIGN KEY([Region_Idx])
REFERENCES [dbo].[Dim_Location_Region] ([Region_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_GLobalWeights] CHECK CONSTRAINT [FK_Fact_BES_GLobalWeights_Dim_Location_Region]
GO
ALTER TABLE [dbo].[Fact_BES_GLobalWeights]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_GLobalWeights_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_GLobalWeights] CHECK CONSTRAINT [FK_Fact_BES_GLobalWeights_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_Historical]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Historical_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Historical] CHECK CONSTRAINT [FK_Fact_BES_Historical_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_Historical_ByRegion]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Historical_ByRegion_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Historical_ByRegion] CHECK CONSTRAINT [FK_Fact_BES_Historical_ByRegion_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_BES_Historical_ByRegion]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Historical_ByRegion_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Historical_ByRegion] CHECK CONSTRAINT [FK_Fact_BES_Historical_ByRegion_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_Historical_ByRegion_RegionalLevels]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Historical_ByRegion_RegionalLevels_Dim_Location_Region] FOREIGN KEY([Region_Idx])
REFERENCES [dbo].[Dim_Location_Region] ([Region_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Historical_ByRegion_RegionalLevels] CHECK CONSTRAINT [FK_Fact_BES_Historical_ByRegion_RegionalLevels_Dim_Location_Region]
GO
ALTER TABLE [dbo].[Fact_BES_Historical_ByRegion2]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Historical_ByRegion_Dim_Location_Region] FOREIGN KEY([Region_Idx])
REFERENCES [dbo].[Dim_Location_Region] ([Region_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Historical_ByRegion2] CHECK CONSTRAINT [FK_Fact_BES_Historical_ByRegion_Dim_Location_Region]
GO
ALTER TABLE [dbo].[Fact_BES_Historical_BySubsector]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Historical_BySubsector_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Historical_BySubsector] CHECK CONSTRAINT [FK_Fact_BES_Historical_BySubsector_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_Historical_BySubsector_RegionalLevels]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Historical_BySubsector_RegionalLevels_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Historical_BySubsector_RegionalLevels] CHECK CONSTRAINT [FK_Fact_BES_Historical_BySubsector_RegionalLevels_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_Historical_ImportExportCat]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Historical_ImportExportCat_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Historical_ImportExportCat] CHECK CONSTRAINT [FK_Fact_BES_Historical_ImportExportCat_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_Historical_RegionalLevels]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Historical_RegionalLevels_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Historical_RegionalLevels] CHECK CONSTRAINT [FK_Fact_BES_Historical_RegionalLevels_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_OtherCountries]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_OtherCountries_Dim_BES_BCI] FOREIGN KEY([BCI_Idx])
REFERENCES [dbo].[Dim_BES_BCI] ([BCI_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_OtherCountries] CHECK CONSTRAINT [FK_Fact_BES_OtherCountries_Dim_BES_BCI]
GO
ALTER TABLE [dbo].[Fact_BES_OtherCountries]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_OtherCountries_Dim_BES_OtherCountry] FOREIGN KEY([Institution_Country_Idx])
REFERENCES [dbo].[Dim_BES_OtherCountry] ([Institution_Country_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_OtherCountries] CHECK CONSTRAINT [FK_Fact_BES_OtherCountries_Dim_BES_OtherCountry]
GO
ALTER TABLE [dbo].[Fact_BES_OtherCountries]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_OtherCountries_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_OtherCountries] CHECK CONSTRAINT [FK_Fact_BES_OtherCountries_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_ReasonsTally]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_ReasonsTally_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_ReasonsTally] CHECK CONSTRAINT [FK_Fact_BES_ReasonsTally_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_Responses]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Responses_Dim_BES_Branch] FOREIGN KEY([Branch_Idx])
REFERENCES [dbo].[Dim_BES_Branch] ([Branch_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Responses] CHECK CONSTRAINT [FK_Fact_BES_Responses_Dim_BES_Branch]
GO
ALTER TABLE [dbo].[Fact_BES_Responses]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Responses_Dim_BES_Company] FOREIGN KEY([Company_Idx])
REFERENCES [dbo].[Dim_BES_Company] ([Company_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Responses] CHECK CONSTRAINT [FK_Fact_BES_Responses_Dim_BES_Company]
GO
ALTER TABLE [dbo].[Fact_BES_Responses]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Responses_Dim_BES_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_BES_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Responses] CHECK CONSTRAINT [FK_Fact_BES_Responses_Dim_BES_Sector]
GO
ALTER TABLE [dbo].[Fact_BES_Responses]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Responses_Dim_BES_SubSector] FOREIGN KEY([Subsector_Idx])
REFERENCES [dbo].[Dim_BES_SubSector] ([Subsector_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Responses] CHECK CONSTRAINT [FK_Fact_BES_Responses_Dim_BES_SubSector]
GO
ALTER TABLE [dbo].[Fact_BES_Responses]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Responses_Dim_Location_Region] FOREIGN KEY([Region_Idx])
REFERENCES [dbo].[Dim_Location_Region] ([Region_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Responses] CHECK CONSTRAINT [FK_Fact_BES_Responses_Dim_Location_Region]
GO
ALTER TABLE [dbo].[Fact_BES_Responses]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Responses_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Responses] CHECK CONSTRAINT [FK_Fact_BES_Responses_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_SampleList_NCR_Reg4]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_SampleList_NCR_Reg4_Dim_BES_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_BES_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_SampleList_NCR_Reg4] CHECK CONSTRAINT [FK_Fact_BES_SampleList_NCR_Reg4_Dim_BES_Sector]
GO
ALTER TABLE [dbo].[Fact_BES_SampleList_NCR_Reg4]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_SampleList_NCR_Reg4_Dim_BES_SubSector] FOREIGN KEY([Subsector_Idx])
REFERENCES [dbo].[Dim_BES_SubSector] ([Subsector_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_SampleList_NCR_Reg4] CHECK CONSTRAINT [FK_Fact_BES_SampleList_NCR_Reg4_Dim_BES_SubSector]
GO
ALTER TABLE [dbo].[Fact_BES_SampleList_NCR_Reg4]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_SampleList_NCR_Reg4_Dim_Location_Region] FOREIGN KEY([Region_Idx])
REFERENCES [dbo].[Dim_Location_Region] ([Region_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_SampleList_NCR_Reg4] CHECK CONSTRAINT [FK_Fact_BES_SampleList_NCR_Reg4_Dim_Location_Region]
GO
ALTER TABLE [dbo].[Fact_BES_SampleList_NCR_Reg4]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_SampleList_NCR_Reg4_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_SampleList_NCR_Reg4] CHECK CONSTRAINT [FK_Fact_BES_SampleList_NCR_Reg4_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Population]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Weights_Population_Dim_BES_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_BES_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Population] CHECK CONSTRAINT [FK_Fact_BES_Weights_Population_Dim_BES_Sector]
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Population]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Weights_Population_Dim_BES_SubSector] FOREIGN KEY([Subsector_Idx])
REFERENCES [dbo].[Dim_BES_SubSector] ([Subsector_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Population] CHECK CONSTRAINT [FK_Fact_BES_Weights_Population_Dim_BES_SubSector]
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Population]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Weights_Population_Dim_Location_Region] FOREIGN KEY([Region_Idx])
REFERENCES [dbo].[Dim_Location_Region] ([Region_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Population] CHECK CONSTRAINT [FK_Fact_BES_Weights_Population_Dim_Location_Region]
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Population]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Weights_Population_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Population] CHECK CONSTRAINT [FK_Fact_BES_Weights_Population_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_Weights_PopulationGT]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Weights_PopulationGT_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Weights_PopulationGT] CHECK CONSTRAINT [FK_Fact_BES_Weights_PopulationGT_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Samples]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Weights_Samples_Dim_BES_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_BES_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Samples] CHECK CONSTRAINT [FK_Fact_BES_Weights_Samples_Dim_BES_Sector]
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Samples]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Weights_Samples_Dim_BES_SubSector] FOREIGN KEY([Subsector_Idx])
REFERENCES [dbo].[Dim_BES_SubSector] ([Subsector_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Samples] CHECK CONSTRAINT [FK_Fact_BES_Weights_Samples_Dim_BES_SubSector]
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Samples]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Weights_Samples_Dim_Location_Region] FOREIGN KEY([Region_Idx])
REFERENCES [dbo].[Dim_Location_Region] ([Region_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Samples] CHECK CONSTRAINT [FK_Fact_BES_Weights_Samples_Dim_Location_Region]
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Samples]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BES_Weights_Samples_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_BES_Weights_Samples] CHECK CONSTRAINT [FK_Fact_BES_Weights_Samples_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_Component]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Component_Dim_CES_Classification] FOREIGN KEY([Classification_Idx])
REFERENCES [dbo].[Dim_CES_Classification] ([Classification_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Component] CHECK CONSTRAINT [FK_Fact_CES_Component_Dim_CES_Classification]
GO
ALTER TABLE [dbo].[Fact_CES_Component]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Component_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Component] CHECK CONSTRAINT [FK_Fact_CES_Component_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_Component]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Component_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Component] CHECK CONSTRAINT [FK_Fact_CES_Component_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_Component]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Component_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Component] CHECK CONSTRAINT [FK_Fact_CES_Component_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_CompositeIndex]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_CompositeIndex_Dim_CES_Distribution1] FOREIGN KEY([Distribution1_Idx])
REFERENCES [dbo].[Dim_CES_Distribution1] ([Distribution1_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_CompositeIndex] CHECK CONSTRAINT [FK_Fact_CES_CompositeIndex_Dim_CES_Distribution1]
GO
ALTER TABLE [dbo].[Fact_CES_CompositeIndex]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_CompositeIndex_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_CompositeIndex] CHECK CONSTRAINT [FK_Fact_CES_CompositeIndex_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_CompositeIndex]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_CompositeIndex_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_CompositeIndex] CHECK CONSTRAINT [FK_Fact_CES_CompositeIndex_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_ConfIndex]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_ConfIndex_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_ConfIndex] CHECK CONSTRAINT [FK_Fact_CES_ConfIndex_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_ConfIndex]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_ConfIndex_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_ConfIndex] CHECK CONSTRAINT [FK_Fact_CES_ConfIndex_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_ConfIndex]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_ConfIndex_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_ConfIndex] CHECK CONSTRAINT [FK_Fact_CES_ConfIndex_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_Debt]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Debt_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Debt] CHECK CONSTRAINT [FK_Fact_CES_Debt_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_Debt]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Debt_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Debt] CHECK CONSTRAINT [FK_Fact_CES_Debt_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_DebtSitCQ]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_DebtSitCQ_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_DebtSitCQ] CHECK CONSTRAINT [FK_Fact_CES_DebtSitCQ_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_DebtSitCQ]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_DebtSitCQ_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_DebtSitCQ] CHECK CONSTRAINT [FK_Fact_CES_DebtSitCQ_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_EcoFam]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_EcoFam_Dim_CES_Classification] FOREIGN KEY([Classification_Idx])
REFERENCES [dbo].[Dim_CES_Classification] ([Classification_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_EcoFam] CHECK CONSTRAINT [FK_Fact_CES_EcoFam_Dim_CES_Classification]
GO
ALTER TABLE [dbo].[Fact_CES_EcoFam]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_EcoFam_Dim_CES_Distribution1] FOREIGN KEY([Distribution1_Idx])
REFERENCES [dbo].[Dim_CES_Distribution1] ([Distribution1_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_EcoFam] CHECK CONSTRAINT [FK_Fact_CES_EcoFam_Dim_CES_Distribution1]
GO
ALTER TABLE [dbo].[Fact_CES_EcoFam]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_EcoFam_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_EcoFam] CHECK CONSTRAINT [FK_Fact_CES_EcoFam_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_EcoFam]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_EcoFam_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_EcoFam] CHECK CONSTRAINT [FK_Fact_CES_EcoFam_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_EcoFam]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_EcoFam_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_EcoFam] CHECK CONSTRAINT [FK_Fact_CES_EcoFam_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_GTTB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_GTTB_Dim_CES_BuyingConditions] FOREIGN KEY([BuyingConditions_Idx])
REFERENCES [dbo].[Dim_CES_BuyingConditions] ([BuyingConditions_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_GTTB] CHECK CONSTRAINT [FK_Fact_CES_GTTB_Dim_CES_BuyingConditions]
GO
ALTER TABLE [dbo].[Fact_CES_GTTB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_GTTB_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_GTTB] CHECK CONSTRAINT [FK_Fact_CES_GTTB_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_GTTB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_GTTB_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_GTTB] CHECK CONSTRAINT [FK_Fact_CES_GTTB_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_GTTB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_GTTB_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_GTTB] CHECK CONSTRAINT [FK_Fact_CES_GTTB_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_HouseLotITB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_HouseLotITB_Dim_CES_HouseLot] FOREIGN KEY([HouseLot_Idx])
REFERENCES [dbo].[Dim_CES_HouseLot] ([HouseLot_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_HouseLotITB] CHECK CONSTRAINT [FK_Fact_CES_HouseLotITB_Dim_CES_HouseLot]
GO
ALTER TABLE [dbo].[Fact_CES_HouseLotITB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_HouseLotITB_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_HouseLotITB] CHECK CONSTRAINT [FK_Fact_CES_HouseLotITB_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_HouseLotITB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_HouseLotITB_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_HouseLotITB] CHECK CONSTRAINT [FK_Fact_CES_HouseLotITB_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_HouseLotITB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_HouseLotITB_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_HouseLotITB] CHECK CONSTRAINT [FK_Fact_CES_HouseLotITB_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_InfForecast]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_InfForecast_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_InfForecast] CHECK CONSTRAINT [FK_Fact_CES_InfForecast_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_InfForecast]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_InfForecast_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_InfForecast] CHECK CONSTRAINT [FK_Fact_CES_InfForecast_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_InfForecast]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_InfForecast_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_InfForecast] CHECK CONSTRAINT [FK_Fact_CES_InfForecast_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_OFWDistribution]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_OFWDistribution_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_OFWDistribution] CHECK CONSTRAINT [FK_Fact_CES_OFWDistribution_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_OFWDistribution]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_OFWDistribution_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_OFWDistribution] CHECK CONSTRAINT [FK_Fact_CES_OFWDistribution_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_OFWRemittances]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_OFWRemittances_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_OFWRemittances] CHECK CONSTRAINT [FK_Fact_CES_OFWRemittances_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_OFWRemittances]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_OFWRemittances_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_OFWRemittances] CHECK CONSTRAINT [FK_Fact_CES_OFWRemittances_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_PriceITB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_PriceITB_Dim_CES_Distribution2] FOREIGN KEY([Distribution2_Idx])
REFERENCES [dbo].[Dim_CES_Distribution2] ([Distribution2_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_PriceITB] CHECK CONSTRAINT [FK_Fact_CES_PriceITB_Dim_CES_Distribution2]
GO
ALTER TABLE [dbo].[Fact_CES_PriceITB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_PriceITB_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_PriceITB] CHECK CONSTRAINT [FK_Fact_CES_PriceITB_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_PriceITB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_PriceITB_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_PriceITB] CHECK CONSTRAINT [FK_Fact_CES_PriceITB_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_PriceITB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_PriceITB_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_PriceITB] CHECK CONSTRAINT [FK_Fact_CES_PriceITB_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_RecRemittances]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_RecRemittances_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_RecRemittances] CHECK CONSTRAINT [FK_Fact_CES_RecRemittances_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_RecRemittances]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_RecRemittances_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_RecRemittances] CHECK CONSTRAINT [FK_Fact_CES_RecRemittances_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_ResIncGrp]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_ResIncGrp_Dim_CES_Distribution1] FOREIGN KEY([Distribution1_Idx])
REFERENCES [dbo].[Dim_CES_Distribution1] ([Distribution1_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_ResIncGrp] CHECK CONSTRAINT [FK_Fact_CES_ResIncGrp_Dim_CES_Distribution1]
GO
ALTER TABLE [dbo].[Fact_CES_ResIncGrp]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_ResIncGrp_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_ResIncGrp] CHECK CONSTRAINT [FK_Fact_CES_ResIncGrp_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_ResIncGrp]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_ResIncGrp_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_ResIncGrp] CHECK CONSTRAINT [FK_Fact_CES_ResIncGrp_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_ResponseRate]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_ResponseRate_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_ResponseRate] CHECK CONSTRAINT [FK_Fact_CES_ResponseRate_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_ResponseRate]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_ResponseRate_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_ResponseRate] CHECK CONSTRAINT [FK_Fact_CES_ResponseRate_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_Savings1]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings1_Dim_CES_Distribution1] FOREIGN KEY([Distribution1_Idx])
REFERENCES [dbo].[Dim_CES_Distribution1] ([Distribution1_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings1] CHECK CONSTRAINT [FK_Fact_CES_Savings1_Dim_CES_Distribution1]
GO
ALTER TABLE [dbo].[Fact_CES_Savings1]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings1_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings1] CHECK CONSTRAINT [FK_Fact_CES_Savings1_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_Savings1]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings1_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings1] CHECK CONSTRAINT [FK_Fact_CES_Savings1_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_Savings2]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings2_Dim_CES_Distribution4] FOREIGN KEY([Distribution4_Idx])
REFERENCES [dbo].[Dim_CES_Distribution4] ([Distribution4_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings2] CHECK CONSTRAINT [FK_Fact_CES_Savings2_Dim_CES_Distribution4]
GO
ALTER TABLE [dbo].[Fact_CES_Savings2]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings2_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings2] CHECK CONSTRAINT [FK_Fact_CES_Savings2_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_Savings2]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings2_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings2] CHECK CONSTRAINT [FK_Fact_CES_Savings2_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_Savings3]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings3_Dim_CES_Distribution1] FOREIGN KEY([Distribution1_Idx])
REFERENCES [dbo].[Dim_CES_Distribution1] ([Distribution1_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings3] CHECK CONSTRAINT [FK_Fact_CES_Savings3_Dim_CES_Distribution1]
GO
ALTER TABLE [dbo].[Fact_CES_Savings3]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings3_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings3] CHECK CONSTRAINT [FK_Fact_CES_Savings3_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_Savings3]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings3_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings3] CHECK CONSTRAINT [FK_Fact_CES_Savings3_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_Savings4]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings4_Dim_CES_Distribution4] FOREIGN KEY([Distribution4_Idx])
REFERENCES [dbo].[Dim_CES_Distribution4] ([Distribution4_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings4] CHECK CONSTRAINT [FK_Fact_CES_Savings4_Dim_CES_Distribution4]
GO
ALTER TABLE [dbo].[Fact_CES_Savings4]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings4_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings4] CHECK CONSTRAINT [FK_Fact_CES_Savings4_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_Savings4]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_Savings4_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_Savings4] CHECK CONSTRAINT [FK_Fact_CES_Savings4_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CES_SelEcoInd]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_SelEcoInd_Dim_CES_Indicator] FOREIGN KEY([Indicator_Idx])
REFERENCES [dbo].[Dim_CES_Indicator] ([Indicator_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_SelEcoInd] CHECK CONSTRAINT [FK_Fact_CES_SelEcoInd_Dim_CES_Indicator]
GO
ALTER TABLE [dbo].[Fact_CES_SelEcoInd]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_SelEcoInd_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_SelEcoInd] CHECK CONSTRAINT [FK_Fact_CES_SelEcoInd_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CES_SelEcoInd]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_SelEcoInd_Dim_SurveyDesc] FOREIGN KEY([SurveyDesc_Idx])
REFERENCES [dbo].[Dim_SurveyDesc] ([SurveyDesc_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_SelEcoInd] CHECK CONSTRAINT [FK_Fact_CES_SelEcoInd_Dim_SurveyDesc]
GO
ALTER TABLE [dbo].[Fact_CES_SelEcoInd]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CES_SelEcoInd_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CES_SelEcoInd] CHECK CONSTRAINT [FK_Fact_CES_SelEcoInd_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CPIInf_CCPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_CCPI_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_CCPI] CHECK CONSTRAINT [FK_Fact_CPIInf_CCPI_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CPIInf_CPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_CPI_Dim_Commodity] FOREIGN KEY([Commodity_Idx])
REFERENCES [dbo].[Dim_Commodity] ([Commodity_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_CPI] CHECK CONSTRAINT [FK_Fact_CPIInf_CPI_Dim_Commodity]
GO
ALTER TABLE [dbo].[Fact_CPIInf_CPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_CPI_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_CPI] CHECK CONSTRAINT [FK_Fact_CPIInf_CPI_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CPIInf_CPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_CPI_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_CPI] CHECK CONSTRAINT [FK_Fact_CPIInf_CPI_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CPIInf_Inflation]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_Inflation_Dim_Commodity] FOREIGN KEY([Commodity_Idx])
REFERENCES [dbo].[Dim_Commodity] ([Commodity_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_Inflation] CHECK CONSTRAINT [FK_Fact_CPIInf_Inflation_Dim_Commodity]
GO
ALTER TABLE [dbo].[Fact_CPIInf_Inflation]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_Inflation_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_Inflation] CHECK CONSTRAINT [FK_Fact_CPIInf_Inflation_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CPIInf_Inflation]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_Inflation_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_Inflation] CHECK CONSTRAINT [FK_Fact_CPIInf_Inflation_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CPIInf_SACPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_SACPI_Dim_Commodity] FOREIGN KEY([Commodity_Idx])
REFERENCES [dbo].[Dim_Commodity] ([Commodity_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_SACPI] CHECK CONSTRAINT [FK_Fact_CPIInf_SACPI_Dim_Commodity]
GO
ALTER TABLE [dbo].[Fact_CPIInf_SACPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_SACPI_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_SACPI] CHECK CONSTRAINT [FK_Fact_CPIInf_SACPI_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CPIInf_SACPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_SACPI_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_SACPI] CHECK CONSTRAINT [FK_Fact_CPIInf_SACPI_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_CPIInf_Weights]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_Weights_Dim_Commodity] FOREIGN KEY([Commodity_Idx])
REFERENCES [dbo].[Dim_Commodity] ([Commodity_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_Weights] CHECK CONSTRAINT [FK_Fact_CPIInf_Weights_Dim_Commodity]
GO
ALTER TABLE [dbo].[Fact_CPIInf_Weights]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_Weights_Dim_Location_RegionTag] FOREIGN KEY([RegionTag_Idx])
REFERENCES [dbo].[Dim_Location_RegionTag] ([RegionTag_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_Weights] CHECK CONSTRAINT [FK_Fact_CPIInf_Weights_Dim_Location_RegionTag]
GO
ALTER TABLE [dbo].[Fact_CPIInf_Weights]  WITH CHECK ADD  CONSTRAINT [FK_Fact_CPIInf_Weights_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_CPIInf_Weights] CHECK CONSTRAINT [FK_Fact_CPIInf_Weights_Dim_Time]
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_FC]  WITH CHECK ADD  CONSTRAINT [FK_FACT_CSOC_NBFI_FC_Dim_CSOC_DIMENSION] FOREIGN KEY([PARTICULAR_Idx])
REFERENCES [dbo].[Dim_CSOC_DIMENSION] ([PARTICULAR_Idx])
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_FC] CHECK CONSTRAINT [FK_FACT_CSOC_NBFI_FC_Dim_CSOC_DIMENSION]
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_FC]  WITH CHECK ADD  CONSTRAINT [FK_FACT_CSOC_NBFI_FC_Dim_INS_INDUSTRY] FOREIGN KEY([BNKIND_Idx])
REFERENCES [dbo].[Dim_INS_INDUSTRY] ([BNKIND_Idx])
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_FC] CHECK CONSTRAINT [FK_FACT_CSOC_NBFI_FC_Dim_INS_INDUSTRY]
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_FC]  WITH CHECK ADD  CONSTRAINT [FK_FACT_CSOC_NBFI_FC_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_FC] CHECK CONSTRAINT [FK_FACT_CSOC_NBFI_FC_Dim_Time]
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_IH]  WITH CHECK ADD  CONSTRAINT [FK_FACT_CSOC_NBFI_IH_Dim_CSOC_DIMENSION] FOREIGN KEY([PARTICULAR_Idx])
REFERENCES [dbo].[Dim_CSOC_DIMENSION] ([PARTICULAR_Idx])
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_IH] CHECK CONSTRAINT [FK_FACT_CSOC_NBFI_IH_Dim_CSOC_DIMENSION]
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_IH]  WITH CHECK ADD  CONSTRAINT [FK_FACT_CSOC_NBFI_IH_Dim_INS_INDUSTRY] FOREIGN KEY([BNKIND_Idx])
REFERENCES [dbo].[Dim_INS_INDUSTRY] ([BNKIND_Idx])
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_IH] CHECK CONSTRAINT [FK_FACT_CSOC_NBFI_IH_Dim_INS_INDUSTRY]
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_IH]  WITH CHECK ADD  CONSTRAINT [FK_FACT_CSOC_NBFI_IH_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_IH] CHECK CONSTRAINT [FK_FACT_CSOC_NBFI_IH_Dim_Time]
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_PAWNSHOP]  WITH CHECK ADD  CONSTRAINT [FK_FACT_CSOC_NBFI_PAWNSHOP_Dim_CSOC_DIMENSION] FOREIGN KEY([PARTICULAR_Idx])
REFERENCES [dbo].[Dim_CSOC_DIMENSION] ([PARTICULAR_Idx])
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_PAWNSHOP] CHECK CONSTRAINT [FK_FACT_CSOC_NBFI_PAWNSHOP_Dim_CSOC_DIMENSION]
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_PAWNSHOP]  WITH CHECK ADD  CONSTRAINT [FK_FACT_CSOC_NBFI_PAWNSHOP_Dim_INS_INDUSTRY] FOREIGN KEY([BNKIND_Idx])
REFERENCES [dbo].[Dim_INS_INDUSTRY] ([BNKIND_Idx])
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_PAWNSHOP] CHECK CONSTRAINT [FK_FACT_CSOC_NBFI_PAWNSHOP_Dim_INS_INDUSTRY]
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_PAWNSHOP]  WITH CHECK ADD  CONSTRAINT [FK_FACT_CSOC_NBFI_PAWNSHOP_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[FACT_CSOC_NBFI_PAWNSHOP] CHECK CONSTRAINT [FK_FACT_CSOC_NBFI_PAWNSHOP_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_DSS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_DSS_DSS_Sectors_Currency_DSS_Level7] FOREIGN KEY([DSS_Level7_Idx])
REFERENCES [dbo].[Dim_DSS_Sectors_Currency_DSS_Level7] ([DSS_Level7_Idx])
GO
ALTER TABLE [dbo].[Fact_DSS] CHECK CONSTRAINT [FK_Fact_DSS_DSS_Sectors_Currency_DSS_Level7]
GO
ALTER TABLE [dbo].[Fact_DSS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_DSS_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_DSS] CHECK CONSTRAINT [FK_Fact_DSS_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_BES]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BCA_BES_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_BES] CHECK CONSTRAINT [FK_Fact_BCA_BES_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_CapitalOutlay]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BCA_CapitalOutlay_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_CapitalOutlay] CHECK CONSTRAINT [FK_Fact_BCA_CapitalOutlay_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_TOUR]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BCA_TOUR_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_TOUR] CHECK CONSTRAINT [FK_Fact_BCA_TOUR_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_TradeImportExport]  WITH CHECK ADD  CONSTRAINT [FK_Fact_BCA_TradeImportExport_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_BCA_TradeImportExport] CHECK CONSTRAINT [FK_Fact_BCA_TradeImportExport_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MISSI_CUR]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MISSI_CUR_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_MISSI_CUR] CHECK CONSTRAINT [FK_Fact_MISSI_CUR_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MISSI_VaPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MISSI_VaPI_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_MISSI_VaPI] CHECK CONSTRAINT [FK_Fact_MISSI_VaPI_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MISSI_VoPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MISSI_VoPI_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_MISSI_VoPI] CHECK CONSTRAINT [FK_Fact_MISSI_VoPI_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_RERB]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_MM_RERB_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_RERB] CHECK CONSTRAINT [FK_Fact_ESLIG_MM_RERB_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_MM_BSCode] FOREIGN KEY([Borrowing_Selling_Idx])
REFERENCES [dbo].[Dim_MM_BSCode] ([BS_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction] CHECK CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_MM_BSCode]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_MM_ICCode] FOREIGN KEY([Instrument_Idx])
REFERENCES [dbo].[Dim_MM_ICCode] ([IC_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction] CHECK CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_MM_ICCode]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_MM_IRCode] FOREIGN KEY([Investor_Buyer_Idx])
REFERENCES [dbo].[Dim_MM_IRCode] ([IR_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction] CHECK CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_MM_IRCode]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_MM_MPCode] FOREIGN KEY([Maturity_Period_Idx])
REFERENCES [dbo].[Dim_MM_MPCode] ([MP_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction] CHECK CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_MM_MPCode]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_MM_TCCode] FOREIGN KEY([Transaction_Idx])
REFERENCES [dbo].[Dim_MM_TCCode] ([TC_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction] CHECK CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_MM_TCCode]
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_MM_Transaction] CHECK CONSTRAINT [FK_Fact_ESLIG_MM_Transaction_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_ConsodilatedAccounts]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ConsolidatedAccounts_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_ConsodilatedAccounts] CHECK CONSTRAINT [FK_Fact_ConsolidatedAccounts_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_Export]  WITH CHECK ADD  CONSTRAINT [FK_Fact_Export_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_Export] CHECK CONSTRAINT [FK_Fact_Export_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_GCF]  WITH CHECK ADD  CONSTRAINT [FK_Fact_GCF_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_GCF] CHECK CONSTRAINT [FK_Fact_GCF_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_GRDP]  WITH CHECK ADD  CONSTRAINT [FK_Fact_GRDP_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_GRDP] CHECK CONSTRAINT [FK_Fact_GRDP_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_HFCE]  WITH CHECK ADD  CONSTRAINT [FK_Fact_HFCE_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_HFCE] CHECK CONSTRAINT [FK_Fact_HFCE_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_Import]  WITH CHECK ADD  CONSTRAINT [FK_Fact_Import_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_Import] CHECK CONSTRAINT [FK_Fact_Import_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_MFG]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MFG_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_MFG] CHECK CONSTRAINT [FK_Fact_MFG_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_PerCapita]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PerCapita_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_PerCapita] CHECK CONSTRAINT [FK_Fact_PerCapita_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_REOD]  WITH CHECK ADD  CONSTRAINT [FK_Fact_REOD_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_REOD] CHECK CONSTRAINT [FK_Fact_REOD_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp_Annual]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_NAT_SummaryExp_Annual] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp_Annual] CHECK CONSTRAINT [FK_Fact_ESLIG_NAT_SummaryExp_Annual]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp_Annual]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SummaryExp_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryExp_Annual] CHECK CONSTRAINT [FK_Fact_SummaryExp_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SummaryInd_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd] CHECK CONSTRAINT [FK_Fact_SummaryInd_Time_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd_Annual]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SummaryInd_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_SummaryInd_Annual] CHECK CONSTRAINT [FK_Fact_SummaryInd_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_WEO]  WITH CHECK ADD  CONSTRAINT [FK_Fact_WEO_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_NAT_WEO] CHECK CONSTRAINT [FK_Fact_WEO_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_OPI_GRPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_OPI_GRPI_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_OPI_GRPI] CHECK CONSTRAINT [FK_Fact_OPI_GRPI_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_OPI_GWPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_OPI_GWPI_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_OPI_GWPI] CHECK CONSTRAINT [FK_Fact_OPI_GWPI_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_OPI_PPI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_OPI_PPI_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_OPI_PPI] CHECK CONSTRAINT [FK_Fact_OPI_PPI_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_LicensedToSell]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PptInd_LicensedToSell_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_LicensedToSell] CHECK CONSTRAINT [FK_Fact_PptInd_LicensedToSell_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_Land]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PptInd_Market_Land_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_Land] CHECK CONSTRAINT [FK_Fact_PptInd_Market_Land_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeCapital]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PptInd_Market_OfficeCapital_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeCapital] CHECK CONSTRAINT [FK_Fact_PptInd_Market_OfficeCapital_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeRental]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PptInd_Market_OfficeRental_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeRental] CHECK CONSTRAINT [FK_Fact_PptInd_Market_OfficeRental_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeSpaceDemand]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PptInd_Market_OfficeSpaceDemand_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_OfficeSpaceDemand] CHECK CONSTRAINT [FK_Fact_PptInd_Market_OfficeSpaceDemand_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_ResidentialCapital]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PptInd_Market_ResidentialCapital_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_ResidentialCapital] CHECK CONSTRAINT [FK_Fact_PptInd_Market_ResidentialCapital_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_ResidentialRental]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PptInd_Market_ResidentialRental_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_ResidentialRental] CHECK CONSTRAINT [FK_Fact_PptInd_Market_ResidentialRental_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_VacancyRate]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PptInd_Market_VacancyRate_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_Market_VacancyRate] CHECK CONSTRAINT [FK_Fact_PptInd_Market_VacancyRate_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_NumberFloorArea]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_PptInd_NumberFloorArea_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_PptInd_NumberFloorArea] CHECK CONSTRAINT [FK_Fact_ESLIG_PptInd_NumberFloorArea_Time_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_AquaCulture]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PROPERTY_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_AquaCulture] CHECK CONSTRAINT [FK_Fact_PROPERTY_Time_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_CommercialFisheries]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_ProInd_CommercialFisheries_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_CommercialFisheries] CHECK CONSTRAINT [FK_Fact_ESLIG_ProInd_CommercialFisheries_Time_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_FisheriesVolume]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_ProInd_FisheriesVolume_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_FisheriesVolume] CHECK CONSTRAINT [FK_Fact_ESLIG_ProInd_FisheriesVolume_Time_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_InlandCommercialFisheries]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_ProInd_InlandCommercialFisheries_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_InlandCommercialFisheries] CHECK CONSTRAINT [FK_Fact_ESLIG_ProInd_InlandCommercialFisheries_Time_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_MarineMunicipallFisheries]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_ProInd_MarineMunicipallFisheries_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_MarineMunicipallFisheries] CHECK CONSTRAINT [FK_Fact_ESLIG_ProInd_MarineMunicipallFisheries_Time_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_NumberFloorArea]  WITH CHECK ADD  CONSTRAINT [FK_Fact_ESLIG_ProInd_NumberFloorArea_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_ProInd_NumberFloorArea] CHECK CONSTRAINT [FK_Fact_ESLIG_ProInd_NumberFloorArea_Time_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_AnnualIndices]  WITH CHECK ADD  CONSTRAINT [FK_ESLIG_SWCP_AnnualIndices_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_AnnualIndices] CHECK CONSTRAINT [FK_ESLIG_SWCP_AnnualIndices_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_AnnualPrice]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SWCP_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_AnnualPrice] CHECK CONSTRAINT [FK_Fact_SWCP_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_MonthlyIndices]  WITH CHECK ADD  CONSTRAINT [FK_ESLIG_SWCP_MonthlyIndices_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_MonthlyIndices] CHECK CONSTRAINT [FK_ESLIG_SWCP_MonthlyIndices_Time]
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_MonthlyPrice]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SWCP_MonthlyPrice_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_ESLIG_SWCP_MonthlyPrice] CHECK CONSTRAINT [FK_Fact_SWCP_MonthlyPrice_Time]
GO
ALTER TABLE [dbo].[Fact_FSI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_FSI_FSICountries_FSICountries] FOREIGN KEY([FSICountries_Idx])
REFERENCES [dbo].[Dim_FSICountries_FSICountries] ([FSICountries_Idx])
GO
ALTER TABLE [dbo].[Fact_FSI] CHECK CONSTRAINT [FK_Fact_FSI_FSICountries_FSICountries]
GO
ALTER TABLE [dbo].[Fact_FSI]  WITH CHECK ADD  CONSTRAINT [FK_Fact_FSI_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_FSI] CHECK CONSTRAINT [FK_Fact_FSI_Time]
GO
ALTER TABLE [dbo].[Fact_Gross NG Debt Ratios]  WITH CHECK ADD  CONSTRAINT [FK_Fact_Gross NG Debt Ratios_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_Gross NG Debt Ratios] CHECK CONSTRAINT [FK_Fact_Gross NG Debt Ratios_Time]
GO
ALTER TABLE [dbo].[Fact_GS_Issued_Offshore]  WITH CHECK ADD  CONSTRAINT [FK_Fact_GS_Issued_Offshore_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_GS_Issued_Offshore] CHECK CONSTRAINT [FK_Fact_GS_Issued_Offshore_Time_Time]
GO
ALTER TABLE [dbo].[Fact_GS_Issued_Onshore]  WITH CHECK ADD  CONSTRAINT [FK_Fact_GS_Issued_Onshore_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_GS_Issued_Onshore] CHECK CONSTRAINT [FK_Fact_GS_Issued_Onshore_Time]
GO
ALTER TABLE [dbo].[Fact_GSOffshore]  WITH CHECK ADD  CONSTRAINT [FK_Fact_GSOffshore_Investors_Investors_Level4] FOREIGN KEY([Investors_Level4_Idx])
REFERENCES [dbo].[Dim_Investors_Investors_Level4] ([Investors_Level4_Idx])
GO
ALTER TABLE [dbo].[Fact_GSOffshore] CHECK CONSTRAINT [FK_Fact_GSOffshore_Investors_Investors_Level4]
GO
ALTER TABLE [dbo].[Fact_GSOffshore]  WITH CHECK ADD  CONSTRAINT [FK_Fact_GSOffshore_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_GSOffshore] CHECK CONSTRAINT [FK_Fact_GSOffshore_Time]
GO
ALTER TABLE [dbo].[Fact_GSOnshore]  WITH CHECK ADD  CONSTRAINT [FK_Fact_GSOnshore_OnshoreGSIssuances_OnshoreGSIssuances] FOREIGN KEY([OnshoreGSIssuances_Idx])
REFERENCES [dbo].[Dim_OnshoreGSIssuances_OnshoreGSIssuances] ([OnshoreGSIssuances_Idx])
GO
ALTER TABLE [dbo].[Fact_GSOnshore] CHECK CONSTRAINT [FK_Fact_GSOnshore_OnshoreGSIssuances_OnshoreGSIssuances]
GO
ALTER TABLE [dbo].[Fact_GSOnshore]  WITH CHECK ADD  CONSTRAINT [FK_Fact_GSOnshore_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_GSOnshore] CHECK CONSTRAINT [FK_Fact_GSOnshore_Time]
GO
ALTER TABLE [dbo].[Fact_MacroAssumptions]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MacroAssumptions_MacroAssumptions_Type_MacroAssumptions_Type] FOREIGN KEY([MacroAssumptions_Type_Idx])
REFERENCES [dbo].[Dim_MacroAssumptions_Type_MacroAssumptions_Type] ([MacroAssumptions_Type_Idx])
GO
ALTER TABLE [dbo].[Fact_MacroAssumptions] CHECK CONSTRAINT [FK_Fact_MacroAssumptions_MacroAssumptions_Type_MacroAssumptions_Type]
GO
ALTER TABLE [dbo].[Fact_MacroAssumptions]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MacroAssumptions_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MacroAssumptions] CHECK CONSTRAINT [FK_Fact_MacroAssumptions_Time]
GO
ALTER TABLE [dbo].[Fact_MERALCO_EnergySales]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MERALCO_EnergySales_Meralco_SalesCategory_Meralco_SalesType] FOREIGN KEY([Meralco_SalesType_Idx])
REFERENCES [dbo].[Dim_Meralco_SalesCategory_Meralco_SalesType] ([Meralco_SalesType_Idx])
GO
ALTER TABLE [dbo].[Fact_MERALCO_EnergySales] CHECK CONSTRAINT [FK_Fact_MERALCO_EnergySales_Meralco_SalesCategory_Meralco_SalesType]
GO
ALTER TABLE [dbo].[Fact_MERALCO_EnergySales]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MERALCO_EnergySales_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MERALCO_EnergySales] CHECK CONSTRAINT [FK_Fact_MERALCO_EnergySales_Time]
GO
ALTER TABLE [dbo].[Fact_MERALCO_KWH_Sales_Perf]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MERALCO_ManufacturingCustomer_ManufacturingCustomerType_ManufacturingCustomerType] FOREIGN KEY([ManufacturingCustomerType_Idx])
REFERENCES [dbo].[Dim_ManufacturingCustomerType_ManufacturingCustomerType] ([ManufacturingCustomerType_Idx])
GO
ALTER TABLE [dbo].[Fact_MERALCO_KWH_Sales_Perf] CHECK CONSTRAINT [FK_Fact_MERALCO_ManufacturingCustomer_ManufacturingCustomerType_ManufacturingCustomerType]
GO
ALTER TABLE [dbo].[Fact_MERALCO_KWH_Sales_Perf]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MERALCO_ManufacturingCustomer_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MERALCO_KWH_Sales_Perf] CHECK CONSTRAINT [FK_Fact_MERALCO_ManufacturingCustomer_Time]
GO
ALTER TABLE [dbo].[Fact_MFSG_GSIS_SSS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_GSIS_SSS_Dim_CSOC_DIMENSION] FOREIGN KEY([Particular_Idx])
REFERENCES [dbo].[Dim_CSOC_DIMENSION] ([PARTICULAR_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_GSIS_SSS] CHECK CONSTRAINT [FK_Fact_GSIS_SSS_Dim_CSOC_DIMENSION]
GO
ALTER TABLE [dbo].[Fact_MFSG_GSIS_SSS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_GSIS_SSS_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_GSIS_SSS] CHECK CONSTRAINT [FK_Fact_GSIS_SSS_Dim_Time]
GO
ALTER TABLE [dbo].[FACT_MFSG_NBFI_FC_for del]  WITH CHECK ADD  CONSTRAINT [FACT_MFSG_NBFI_FCDim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[FACT_MFSG_NBFI_FC_for del] CHECK CONSTRAINT [FACT_MFSG_NBFI_FCDim_Time]
GO
ALTER TABLE [dbo].[FACT_MFSG_NBFI_NSSLA]  WITH CHECK ADD  CONSTRAINT [FK_FACT_MFSG_NBFI_NSSLA_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[FACT_MFSG_NBFI_NSSLA] CHECK CONSTRAINT [FK_FACT_MFSG_NBFI_NSSLA_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_MFSG_NBFI_PICs]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MFSG_NBFI_PICs_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_NBFI_PICs] CHECK CONSTRAINT [FK_Fact_MFSG_NBFI_PICs_Dim_Time]
GO
ALTER TABLE [dbo].[FACT_MFSG_NBFIs]  WITH CHECK ADD  CONSTRAINT [FACT_MFSG_NBFI_FCDim_Time_KEY] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[FACT_MFSG_NBFIs] CHECK CONSTRAINT [FACT_MFSG_NBFI_FCDim_Time_KEY]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_ADDITIONAL_RESULTS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MFSG_SLOS_ADDITIONAL_RESULTS_ASSETTYPE_LVT] FOREIGN KEY([ASSETTYPE_LVT_Idx])
REFERENCES [dbo].[Dim_SLOS_AssetSize_TYPE] ([ASSETTYPE_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_ADDITIONAL_RESULTS] CHECK CONSTRAINT [FK_Fact_MFSG_SLOS_ADDITIONAL_RESULTS_ASSETTYPE_LVT]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_ADDITIONAL_RESULTS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MFSG_SLOS_ADDITIONAL_RESULTS_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_ADDITIONAL_RESULTS] CHECK CONSTRAINT [FK_Fact_MFSG_SLOS_ADDITIONAL_RESULTS_Time]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_III_SLOS_CreditStandardFactors] FOREIGN KEY([CreditStandardFactors_Idx])
REFERENCES [dbo].[Dim_SLOS_CreditStandard_Factors] ([CreditStandardFactors_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS] CHECK CONSTRAINT [FK_Fact_III_SLOS_CreditStandardFactors]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_III_SLOS_Market] FOREIGN KEY([Market_Idx])
REFERENCES [dbo].[Dim_SLOS_MarketEnterpriseType] ([Market_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS] CHECK CONSTRAINT [FK_Fact_III_SLOS_Market]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_III_SLOS_QUESTIONCODE] FOREIGN KEY([Question_Idx])
REFERENCES [dbo].[Dim_SLOS_Question] ([Question_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS] CHECK CONSTRAINT [FK_Fact_III_SLOS_QUESTIONCODE]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_III_SLOS_QUESTIONTYPE] FOREIGN KEY([QuestionType_Idx])
REFERENCES [dbo].[Dim_SLOS_QuestionType] ([QuestionType_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS] CHECK CONSTRAINT [FK_Fact_III_SLOS_QUESTIONTYPE]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_III_SLOS_TIME] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS] CHECK CONSTRAINT [FK_Fact_III_SLOS_TIME]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]  WITH CHECK ADD  CONSTRAINT [FK_Fact_I_SLOS_CreditStandardFactors] FOREIGN KEY([CreditStandardFactors_Idx])
REFERENCES [dbo].[Dim_SLOS_CreditStandard_Factors] ([CreditStandardFactors_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES] CHECK CONSTRAINT [FK_Fact_I_SLOS_CreditStandardFactors]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]  WITH CHECK ADD  CONSTRAINT [FK_Fact_I_SLOS_Market] FOREIGN KEY([Market_Idx])
REFERENCES [dbo].[Dim_SLOS_MarketEnterpriseType] ([Market_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES] CHECK CONSTRAINT [FK_Fact_I_SLOS_Market]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]  WITH CHECK ADD  CONSTRAINT [FK_Fact_I_SLOS_QUESTIONCODE] FOREIGN KEY([Question_Idx])
REFERENCES [dbo].[Dim_SLOS_Question] ([Question_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES] CHECK CONSTRAINT [FK_Fact_I_SLOS_QUESTIONCODE]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]  WITH CHECK ADD  CONSTRAINT [FK_Fact_I_SLOS_QUESTIONTYPE] FOREIGN KEY([QuestionType_Idx])
REFERENCES [dbo].[Dim_SLOS_QuestionType] ([QuestionType_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES] CHECK CONSTRAINT [FK_Fact_I_SLOS_QUESTIONTYPE]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]  WITH CHECK ADD  CONSTRAINT [FK_Fact_I_SLOS_TIME] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES] CHECK CONSTRAINT [FK_Fact_I_SLOS_TIME]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_II_SLOS_CreditStandardFactors] FOREIGN KEY([CreditStandardFactors_Idx])
REFERENCES [dbo].[Dim_SLOS_CreditStandard_Factors] ([CreditStandardFactors_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS] CHECK CONSTRAINT [FK_Fact_II_SLOS_CreditStandardFactors]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_II_SLOS_Market] FOREIGN KEY([Market_Idx])
REFERENCES [dbo].[Dim_SLOS_MarketEnterpriseType] ([Market_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS] CHECK CONSTRAINT [FK_Fact_II_SLOS_Market]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_II_SLOS_QUESTIONCODE] FOREIGN KEY([Question_Idx])
REFERENCES [dbo].[Dim_SLOS_Question] ([Question_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS] CHECK CONSTRAINT [FK_Fact_II_SLOS_QUESTIONCODE]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_II_SLOS_QUESTIONTYPE] FOREIGN KEY([QuestionType_Idx])
REFERENCES [dbo].[Dim_SLOS_QuestionType] ([QuestionType_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS] CHECK CONSTRAINT [FK_Fact_II_SLOS_QUESTIONTYPE]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_II_SLOS_TIME] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS] CHECK CONSTRAINT [FK_Fact_II_SLOS_TIME]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_REMARKS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MFSG_SLOS_REMARKS_Fact_MFSG_SLOS_REMARKS_Bank_] FOREIGN KEY([Bank_Idx])
REFERENCES [dbo].[Dim_Bank] ([Bank_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_REMARKS] CHECK CONSTRAINT [FK_Fact_MFSG_SLOS_REMARKS_Fact_MFSG_SLOS_REMARKS_Bank_]
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_REMARKS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MFSG_SLOS_REMARKS_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_SLOS_REMARKS] CHECK CONSTRAINT [FK_Fact_MFSG_SLOS_REMARKS_Time]
GO
ALTER TABLE [dbo].[Fact_MFSG_TOTRES_BANKS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_MFSG_TOTRES_BANKS_Dim_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_MFSG_TOTRES_BANKS] CHECK CONSTRAINT [FK_Fact_MFSG_TOTRES_BANKS_Dim_Time]
GO
ALTER TABLE [dbo].[Fact_Net NG Debt Ratio]  WITH CHECK ADD  CONSTRAINT [FK_Fact_Net NG Debt Ratio_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_Net NG Debt Ratio] CHECK CONSTRAINT [FK_Fact_Net NG Debt Ratio_Time]
GO
ALTER TABLE [dbo].[Fact_PSALM_Grid]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PSALM_Grid_Dim_Grid] FOREIGN KEY([Location_Idx])
REFERENCES [dbo].[Dim_Grid] ([Location_Idx])
GO
ALTER TABLE [dbo].[Fact_PSALM_Grid] CHECK CONSTRAINT [FK_Fact_PSALM_Grid_Dim_Grid]
GO
ALTER TABLE [dbo].[Fact_PSALM_Grid]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PSALM_Location_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_PSALM_Grid] CHECK CONSTRAINT [FK_Fact_PSALM_Location_Time]
GO
ALTER TABLE [dbo].[Fact_PSALM_PlantType]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PSALM_PlantType_PlantType_PlantType] FOREIGN KEY([PlantType_Idx])
REFERENCES [dbo].[Dim_PlantType_PlantType] ([PlantType_Idx])
GO
ALTER TABLE [dbo].[Fact_PSALM_PlantType] CHECK CONSTRAINT [FK_Fact_PSALM_PlantType_PlantType_PlantType]
GO
ALTER TABLE [dbo].[Fact_PSALM_PlantType]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PSALM_PlantType_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_PSALM_PlantType] CHECK CONSTRAINT [FK_Fact_PSALM_PlantType_Time]
GO
ALTER TABLE [dbo].[Fact_PSALM_SummaryEnergySales]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PSALM_EnergySales_EnergySalesCategory_EnergySalesType] FOREIGN KEY([EnergySalesType_Idx])
REFERENCES [dbo].[Dim_EnergySalesCategory_EnergySalesType] ([EnergySalesType_Idx])
GO
ALTER TABLE [dbo].[Fact_PSALM_SummaryEnergySales] CHECK CONSTRAINT [FK_Fact_PSALM_EnergySales_EnergySalesCategory_EnergySalesType]
GO
ALTER TABLE [dbo].[Fact_PSALM_SummaryEnergySales]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PSALM_EnergySales_Grid] FOREIGN KEY([Location_Idx])
REFERENCES [dbo].[Dim_Grid] ([Location_Idx])
GO
ALTER TABLE [dbo].[Fact_PSALM_SummaryEnergySales] CHECK CONSTRAINT [FK_Fact_PSALM_EnergySales_Grid]
GO
ALTER TABLE [dbo].[Fact_PSALM_SummaryEnergySales]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PSALM_EnergySales_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_PSALM_SummaryEnergySales] CHECK CONSTRAINT [FK_Fact_PSALM_EnergySales_Time]
GO
ALTER TABLE [dbo].[Fact_RICE_ArrivalOfImported]  WITH CHECK ADD  CONSTRAINT [FK_Fact_RICE_ArrivalOfImported_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_RICE_ArrivalOfImported] CHECK CONSTRAINT [FK_Fact_RICE_ArrivalOfImported_Time]
GO
ALTER TABLE [dbo].[Fact_RICE_PH_Imports]  WITH CHECK ADD  CONSTRAINT [FK_Fact_RICE_PH_Imports_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_RICE_PH_Imports] CHECK CONSTRAINT [FK_Fact_RICE_PH_Imports_Time]
GO
ALTER TABLE [dbo].[Fact_RICE_SPSICIssuedAndVolumeApplied]  WITH CHECK ADD  CONSTRAINT [FK_Fact_RICE_SPSICIssuedAndVolumeApplied_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_RICE_SPSICIssuedAndVolumeApplied] CHECK CONSTRAINT [FK_Fact_RICE_SPSICIssuedAndVolumeApplied_Time]
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Bonds_Company] FOREIGN KEY([Company_Idx])
REFERENCES [dbo].[Dim_Company] ([Company_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds] CHECK CONSTRAINT [FK_Fact_SOCF_Bonds_Company]
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Bonds_Company_Type] FOREIGN KEY([Type_Idx])
REFERENCES [dbo].[Dim_Company_Type] ([Type_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds] CHECK CONSTRAINT [FK_Fact_SOCF_Bonds_Company_Type]
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Bonds_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds] CHECK CONSTRAINT [FK_Fact_SOCF_Bonds_Sector]
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Bonds_Sector_Group] FOREIGN KEY([Group_Idx])
REFERENCES [dbo].[Dim_Sector_Group] ([Group_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds] CHECK CONSTRAINT [FK_Fact_SOCF_Bonds_Sector_Group]
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Bonds_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Bonds] CHECK CONSTRAINT [FK_Fact_SOCF_Bonds_Time]
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Equity_Company] FOREIGN KEY([Company_Idx])
REFERENCES [dbo].[Dim_Company] ([Company_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity] CHECK CONSTRAINT [FK_Fact_SOCF_Equity_Company]
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Equity_Reg_Subtype] FOREIGN KEY([SubType_Idx])
REFERENCES [dbo].[Dim_Reg_SubType] ([SubType_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity] CHECK CONSTRAINT [FK_Fact_SOCF_Equity_Reg_Subtype]
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Equity_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity] CHECK CONSTRAINT [FK_Fact_SOCF_Equity_Sector]
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Equity_Sector_Group] FOREIGN KEY([Group_Idx])
REFERENCES [dbo].[Dim_Sector_Group] ([Group_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity] CHECK CONSTRAINT [FK_Fact_SOCF_Equity_Sector_Group]
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Equity_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Equity] CHECK CONSTRAINT [FK_Fact_SOCF_Equity_Time]
GO
ALTER TABLE [dbo].[Fact_SOCF_PO]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_PO_Company] FOREIGN KEY([Company_Idx])
REFERENCES [dbo].[Dim_Company] ([Company_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_PO] CHECK CONSTRAINT [FK_Fact_SOCF_PO_Company]
GO
ALTER TABLE [dbo].[Fact_SOCF_PO]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_PO_Reg_Subtype] FOREIGN KEY([SubType_Idx])
REFERENCES [dbo].[Dim_Reg_SubType] ([SubType_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_PO] CHECK CONSTRAINT [FK_Fact_SOCF_PO_Reg_Subtype]
GO
ALTER TABLE [dbo].[Fact_SOCF_PO]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_PO_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_PO] CHECK CONSTRAINT [FK_Fact_SOCF_PO_Sector]
GO
ALTER TABLE [dbo].[Fact_SOCF_PO]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_PO_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_PO] CHECK CONSTRAINT [FK_Fact_SOCF_PO_Time]
GO
ALTER TABLE [dbo].[Fact_SOCF_PP]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_PP_Company] FOREIGN KEY([Company_Idx])
REFERENCES [dbo].[Dim_Company] ([Company_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_PP] CHECK CONSTRAINT [FK_Fact_SOCF_PP_Company]
GO
ALTER TABLE [dbo].[Fact_SOCF_PP]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_PP_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_PP] CHECK CONSTRAINT [FK_Fact_SOCF_PP_Sector]
GO
ALTER TABLE [dbo].[Fact_SOCF_PP]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_PP_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_PP] CHECK CONSTRAINT [FK_Fact_SOCF_PP_Time]
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Securities_Company] FOREIGN KEY([Company_Idx])
REFERENCES [dbo].[Dim_Company] ([Company_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities] CHECK CONSTRAINT [FK_Fact_SOCF_Securities_Company]
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Securities_Equities] FOREIGN KEY([Equities_Idx])
REFERENCES [dbo].[Dim_Equities] ([Equities_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities] CHECK CONSTRAINT [FK_Fact_SOCF_Securities_Equities]
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Securities_Reg_Subtype] FOREIGN KEY([SubType_Idx])
REFERENCES [dbo].[Dim_Reg_SubType] ([SubType_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities] CHECK CONSTRAINT [FK_Fact_SOCF_Securities_Reg_Subtype]
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_Securities_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_Securities] CHECK CONSTRAINT [FK_Fact_SOCF_Securities_Time]
GO
ALTER TABLE [dbo].[Fact_SOCF_SR]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_SR_Company] FOREIGN KEY([Company_Idx])
REFERENCES [dbo].[Dim_Company] ([Company_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_SR] CHECK CONSTRAINT [FK_Fact_SOCF_SR_Company]
GO
ALTER TABLE [dbo].[Fact_SOCF_SR]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_SR_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_Sector] ([Sector_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_SR] CHECK CONSTRAINT [FK_Fact_SOCF_SR_Sector]
GO
ALTER TABLE [dbo].[Fact_SOCF_SR]  WITH CHECK ADD  CONSTRAINT [FK_Fact_SOCF_SR_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_SOCF_SR] CHECK CONSTRAINT [FK_Fact_SOCF_SR_Time]
GO
ALTER TABLE [dbo].[Fact_TBills]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TBills_TBills_Tenor] FOREIGN KEY([Tenor_Idx])
REFERENCES [dbo].[Dim_TBills_Tenor] ([Tenor_Idx])
GO
ALTER TABLE [dbo].[Fact_TBills] CHECK CONSTRAINT [FK_Fact_TBills_TBills_Tenor]
GO
ALTER TABLE [dbo].[Fact_TBills]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TBills_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_TBills] CHECK CONSTRAINT [FK_Fact_TBills_Time_Time]
GO
ALTER TABLE [dbo].[Fact_TBonds]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TBonds_TBonds_Instrument] FOREIGN KEY([Instrument_Idx])
REFERENCES [dbo].[Dim_TBonds_Instrument] ([Instrument_Idx])
GO
ALTER TABLE [dbo].[Fact_TBonds] CHECK CONSTRAINT [FK_Fact_TBonds_TBonds_Instrument]
GO
ALTER TABLE [dbo].[Fact_TBonds]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TBonds_TBonds_Tenor] FOREIGN KEY([Tenor_Idx])
REFERENCES [dbo].[Dim_TBonds_Tenor] ([Tenor_Idx])
GO
ALTER TABLE [dbo].[Fact_TBonds] CHECK CONSTRAINT [FK_Fact_TBonds_TBonds_Tenor]
GO
ALTER TABLE [dbo].[Fact_TBonds]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TBonds_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_TBonds] CHECK CONSTRAINT [FK_Fact_TBonds_Time_Time]
GO
ALTER TABLE [dbo].[Fact_TCRS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TCRS_BankType_BankType] FOREIGN KEY([BankType_Idx])
REFERENCES [dbo].[Dim_BankType_BankType] ([BankType_Idx])
GO
ALTER TABLE [dbo].[Fact_TCRS] CHECK CONSTRAINT [FK_Fact_TCRS_BankType_BankType]
GO
ALTER TABLE [dbo].[Fact_TCRS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TCRS_EconomicActivityCode_EconomicActivityCode] FOREIGN KEY([EconomicActivityCode_Idx])
REFERENCES [dbo].[Dim_EconomicActivityCode_EconomicActivityCode] ([EconomicActivityCode_Idx])
GO
ALTER TABLE [dbo].[Fact_TCRS] CHECK CONSTRAINT [FK_Fact_TCRS_EconomicActivityCode_EconomicActivityCode]
GO
ALTER TABLE [dbo].[Fact_TCRS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TCRS_Industry_Industry] FOREIGN KEY([Industry_Idx])
REFERENCES [dbo].[Dim_Industry_Industry] ([Industry_Idx])
GO
ALTER TABLE [dbo].[Fact_TCRS] CHECK CONSTRAINT [FK_Fact_TCRS_Industry_Industry]
GO
ALTER TABLE [dbo].[Fact_TCRS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TCRS_PurposeofCredit_PurposeofCredit] FOREIGN KEY([PurposeofCredit_Idx])
REFERENCES [dbo].[Dim_PurposeofCredit_PurposeofCredit] ([PurposeofCredit_Idx])
GO
ALTER TABLE [dbo].[Fact_TCRS] CHECK CONSTRAINT [FK_Fact_TCRS_PurposeofCredit_PurposeofCredit]
GO
ALTER TABLE [dbo].[Fact_TCRS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TCRS_Region_Region] FOREIGN KEY([Region_Idx])
REFERENCES [dbo].[Dim_Region_Region] ([Region_Idx])
GO
ALTER TABLE [dbo].[Fact_TCRS] CHECK CONSTRAINT [FK_Fact_TCRS_Region_Region]
GO
ALTER TABLE [dbo].[Fact_TCRS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TCRS_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_TCRS] CHECK CONSTRAINT [FK_Fact_TCRS_Time]
GO
ALTER TABLE [dbo].[Fact_TCRS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TCRS_TypeOfBorrower_TypeOfBorrower] FOREIGN KEY([TypeOfBorrower_Idx])
REFERENCES [dbo].[Dim_TypeOfBorrower_TypeOfBorrower] ([TypeOfBorrower_Idx])
GO
ALTER TABLE [dbo].[Fact_TCRS] CHECK CONSTRAINT [FK_Fact_TCRS_TypeOfBorrower_TypeOfBorrower]
GO
ALTER TABLE [dbo].[Fact_TCRS]  WITH CHECK ADD  CONSTRAINT [FK_Fact_TCRS_TypeOfCredit_TypeOfCredit] FOREIGN KEY([TypeOfCredit_Idx])
REFERENCES [dbo].[Dim_TypeOfCredit_TypeOfCredit] ([TypeOfCredit_Idx])
GO
ALTER TABLE [dbo].[Fact_TCRS] CHECK CONSTRAINT [FK_Fact_TCRS_TypeOfCredit_TypeOfCredit]
GO
ALTER TABLE [dbo].[Fact_VolumeProduction]  WITH CHECK ADD  CONSTRAINT [FK_Fact_VolumeProduction_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time_old] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_VolumeProduction] CHECK CONSTRAINT [FK_Fact_VolumeProduction_Time_Time]
GO
ALTER TABLE [dbo].[Fact_WKI_TAB22]  WITH CHECK ADD  CONSTRAINT [FK_Fact_WKI_TAB22_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_WKI_TAB22] CHECK CONSTRAINT [FK_Fact_WKI_TAB22_Time]
GO
ALTER TABLE [dbo].[Fact_WKI_TAB3]  WITH CHECK ADD  CONSTRAINT [FK_Fact_WKI_TAB3_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO
ALTER TABLE [dbo].[Fact_WKI_TAB3] CHECK CONSTRAINT [FK_Fact_WKI_TAB3_Time]
GO
/****** Object:  StoredProcedure [dbo].[_usp_Load_ALL_StagingToEDW]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[_usp_Load_ALL_StagingToEDW]
AS
BEGIN
	SET NOCOUNT ON;

EXEC [dbo].[usp_Load_MasterData]
EXEC [dbo].[usp_Load_Fact_FSI]
EXEC [dbo].[usp_Load_Fact_SELFI]
EXEC [dbo].[usp_Load_Fact_GrossNGDebtRatios]
EXEC [dbo].[usp_Load_Fact_NetNGDebtRatios]
EXEC [dbo].[usp_Load_Fact_PSALM_PlantType]
EXEC [dbo].[usp_Load_Fact_PSALM_Location]
EXEC [dbo].[usp_Load_Fact_MERALCO_EnergySales]
EXEC [dbo].[usp_Load_Fact_MERALCO_ManufacturingCustomer]
EXEC [dbo].[usp_Load_Fact_MacroAssumptions]
EXEC [dbo].[usp_Load_Fact_GS_Issued_Onshore]
EXEC [dbo].[usp_Load_Fact_GSOnshore]
EXEC [dbo].[usp_Load_Fact_GSOffshore] 
EXEC [dbo].[usp_Load_Fact_TCRS]
EXEC [dbo].[usp_Load_Fact_DSS]
END

GO
/****** Object:  StoredProcedure [dbo].[GETETLParam]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE proc [dbo].[GETETLParam]( @GRPName as nvarchar(50) ) 
as 

SELECT [DTStart],
CASE WHEN use_dtend = 1 then [DTEnd] else CONVERT(varchar,getdate()-1,112) END AS DTEnd
  FROM [DES].[dbo].[EDWETLParam]
  where GRPName = @GRPName and IsActive = '1' ;


--SELECT [DTStart] ,[DTEnd]
--  FROM [DES].[dbo].[EDWETLParam]
--  where GRPName = @GRPName and IsActive = '1' ;
GO
/****** Object:  StoredProcedure [dbo].[GNIGDP]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GNIGDP]
AS
BEGIN
	SET NOCOUNT ON;
SELECT distinct [Time_Idx]
      ,[Type_Idx]
      ,[Prices]
      ,[Value]
  FROM [DES].[dbo].[Fact_ESLIG_NAT_SummaryExp] where[Type_Idx] in (4,6) and Prices in ('Constant','Current')

UNION ALL

SELECT distinct [Time_Idx]
      ,[Type_Idx]
      ,[Prices]
      ,[Value] 
  FROM [DES].[dbo].[Fact_ESLIG_NAT_SummaryInd] where[Type_Idx] in (29,30) and Prices in ('Constant','Current')
END

GO
/****** Object:  StoredProcedure [dbo].[INS_DIM_TENOR_TENOR]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[INS_DIM_TENOR_TENOR] 
as

INSERT INTO Dim_Tenor_Tenor (Tenor_Code, Tenor_Name, Tenor_Label, Tenor_Sort)
SELECT Tenor_Code, Tenor_Name, Tenor_Label, Tenor_Sort FROM DES_Staging.dbo.S_Dim_Tenor_Tenor
where not exists (select Tenor_Code, Tenor_Name, Tenor_Label, Tenor_Sort from DIM_Tenor_Tenor where Tenor_Code = DES_Staging.dbo.S_Dim_Tenor_Tenor.Tenor_Code)
order by Tenor_Sort
GO
/****** Object:  StoredProcedure [dbo].[SetETLParams]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE proc [dbo].[SetETLParams]( @GRPName as nvarchar(50)) 
as 

update A
set A.[DTStart] = B.DTStart, A.[DTEnd] = B.DTEnd
from dbo.EDWETLParam A
join (SELECT GRPName, DTEnd as DTStart, CONVERT(varchar,getdate()-1,112) AS DTEnd
from dbo.EDWETLParam) B
on A.GRPName = B.GRPName
where A.GRPName = @GRPName 
GO
/****** Object:  StoredProcedure [dbo].[usp_CreateTables]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [dbo].[usp_CreateTables]
AS

DECLARE @SQL varchar(max)
,@TableName varchar(100)
,@FieldName varchar(100)
,@DataType varchar(100)


DECLARE table_cursor CURSOR FOR
SELECT DISTINCT TableName = REPLACE(TableName,' ','')  
FROM TableCreator

OPEN table_cursor   
FETCH NEXT FROM table_cursor INTO @TableName

WHILE @@FETCH_STATUS = 0   
BEGIN  

	SELECT @SQL = ' CREATE TABLE [dbo].[' + @TableName +']('
	+ ' Dummy varchar(50) ) ON [PRIMARY]' 

	EXEC (@SQL)

	DECLARE field_cursor CURSOR FOR
	SELECT FieldName = REPLACE(FieldName,' ','') 
	,DataType
	FROM TableCreator
	WHERE REPLACE(TableName,' ','')  = @TableName

	OPEN field_cursor   
	FETCH NEXT FROM field_cursor INTO @FieldName, @DataType

	WHILE @@FETCH_STATUS = 0   
	BEGIN   

		SELECT @SQL = ' ALTER TABLE [dbo].[' + @TableName +']'
		+ ' ADD [' + @FieldName + '] ' +  @DataType + ' NULL'

		EXEC (@SQL)
			
		FETCH NEXT FROM field_cursor INTO @FieldName, @DataType
	END   

	CLOSE field_cursor   
	DEALLOCATE field_cursor 

	SELECT @SQL = ' ALTER TABLE [dbo].[' + @TableName +']'
	+ ' DROP COLUMN Dummy' 

	EXEC (@SQL)

	FETCH NEXT FROM table_cursor INTO @TableName
END   

CLOSE table_cursor   
DEALLOCATE table_cursor 
GO
/****** Object:  StoredProcedure [dbo].[usp_DropTables]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [dbo].[usp_DropTables]
AS

DECLARE @SQL varchar(max)
,@TableName varchar(100)
,@FieldName varchar(100)
,@DataType varchar(100)


DECLARE table_cursor CURSOR FOR
SELECT DISTINCT TableName = REPLACE(TableName,' ','')  
FROM TableCreator

OPEN table_cursor   
FETCH NEXT FROM table_cursor INTO @TableName

WHILE @@FETCH_STATUS = 0   
BEGIN  

	SELECT @SQL = ' DROP TABLE [dbo].[' + @TableName +']'

	EXEC (@SQL)

	FETCH NEXT FROM table_cursor INTO @TableName
END   

CLOSE table_cursor   
DEALLOCATE table_cursor 
GO
/****** Object:  StoredProcedure [dbo].[usp_Insert_To_MonthlyBTRHolders_GovtSec]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Insert_To_MonthlyBTRHolders_GovtSec] 
AS
BEGIN


WITH BTRHolders_GovtSec AS (
SELECT 
  (SELECT SUBSTRING([Column2], 16,4) AS [Year] FROM [DES_Staging].[dbo].[Dump_FFSD_BTRHolders_GovtSec] a WHERE [Column1] = 'PARTICULARS') AS [Year]
, (SELECT SUBSTRING([Column2], 7,3) AS [Month] FROM [DES_Staging].[dbo].[Dump_FFSD_BTRHolders_GovtSec] a WHERE [Column1] = 'PARTICULARS') AS [Month]
, (SELECT [dbo].[fn_month_name_to_number] (SUBSTRING([Column2], 7,3)) as [MonthNo] FROM [DES_Staging].[dbo].[Dump_FFSD_BTRHolders_GovtSec] a WHERE [Column1] = 'PARTICULARS') AS [MonthNo]
, [Column1] AS [Title]
, CASE WHEN [Column2] IS NULL THEN 0 ELSE [Column2] END AS Amount
FROM [DES_Staging].[dbo].[Dump_FFSD_BTRHolders_GovtSec] a
WHERE [Column1] IN 
(
  'Banks'
, 'Insurance Companies'
, 'Investment Houses'
, 'Custodians (FAO Taxable Accts)'
, 'Depository (Nominee)'
, 'Private Corporations'
, 'GOCCs'
, 'Local Government Units'
, 'Tax-Exempt Institutions'
, 'Others'
, 'of which: Non-Residents'
)

)
, BTRHolders_GovtSec_layout1 AS (
SELECT  *
FROM  
(
  SELECT *
  FROM BTRHolders_GovtSec
) AS TableToPivot 
PIVOT  
(  
  SUM(Amount)
  FOR  [Title] IN (
  [Banks]
, [Insurance Companies]
, [Investment Houses]
, [Custodians (FAO Taxable Accts)]
, [Depository (Nominee)]
, [Private Corporations]
, [GOCCs]
, [Local Government Units]
, [Tax-Exempt Institutions]
, [Others]
, [of which: Non-Residents]
)  
) AS PivotTable
)

INSERT INTO [DES_Staging].[dbo].[Monthly_BTRHolders_GovtSec]
SELECT 
  [Year]
, [Month]
, [MonthNo]
, [Banks]
, [Insurance Companies]
, [Investment Houses]
, [Custodians (FAO Taxable Accts)] AS [Custodians]
, [Depository (Nominee)] AS [Depository]
, [Private Corporations]
, [GOCCs] AS [Government Corporations]
, [Local Government Units]
, [Tax-Exempt Institutions]
, [Others] AS [Other residents]
, [of which: Non-Residents] AS [Non-Residents]
FROM BTRHolders_GovtSec_layout1

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_ESLIG_Fact_YieldCurve]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Load_ESLIG_Fact_YieldCurve] 
as

--TRUNCATE TABLE  Fact_YieldCurve 

DELETE FROM [DES].[dbo].[Fact_YieldCurve]
FROM [DES].[dbo].[Fact_YieldCurve] A
JOIN [DES_Staging].[dbo].[S_Fact_YieldCurve] B
ON  A.Time_Idx = REPLACE(B.Time_Code,'-','') 

INSERT INTO Fact_YieldCurve (Time_Idx, Tenor_Idx, BVALRate, BVALRateDiff)
SELECT dt.Time_Idx, t.Tenor_Idx, BVALRate, BVALRateDiff FROM DES_Staging.dbo.S_Fact_YieldCurve main 
inner join Dim_YieldCurve_Tenor t on t.Tenor_Code = main.Tenor_Code
inner join Dim_time dt on dt.Date_Code = main.Time_Code

GO
/****** Object:  StoredProcedure [dbo].[usp_LOAD_ESLIG_NAT_SUMMARYEXP]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE PROC [dbo].[usp_LOAD_ESLIG_NAT_SUMMARYEXP]
AS
BEGIN
		TRUNCATE TABLE [S_Fact_ESLIG_Nat_SummaryExp]

		--INSERT INTO STAGING FACT TABLE
		INSERT INTO [S_Fact_ESLIG_Nat_SummaryExp]
		SELECT 
		   [Date_Code]
		  ,[Type]
		  ,[Prices]
		  ,[Sector],
		   [Value] --= CONVERT(numeric, CONVERT(money, [Value]))
		FROM (	
		SELECT  [Date_Code]
		  ,[Type]
		  ,[Prices]
		  ,[Sector]
		  ,[Value]
		FROM [DES_Staging].[dbo].[vw_NAT_Exp_1_1_Current]
		
		UNION ALL
		
		SELECT  [Date_Code]
		  ,[Type]
		  ,[Prices]
		  ,[Sector]
		  ,[Value]
		FROM [DES_Staging].[dbo].[vw_NAT_Exp_1_2_Constant]
		
		UNION ALL
			SELECT  [Date_Code]
		  ,[Type]
		  ,[Prices]
		  ,[Sector]
		  ,[Value]
		FROM [DES_Staging].[dbo].[vw_NAT_Exp_1_3_GrowthCurrent]

		UNION ALL
		
		SELECT  [Date_Code]
		  ,[Type]
		  ,[Prices]
		  ,[Sector]
		  ,[Value]
		FROM [vw_NAT_Exp_1_4_GrowthConstant]

		UNION ALL
		
		SELECT  [Date_Code]
		  ,[Type]
		  ,[Prices]
		  ,[Sector]
		  ,[Value]
		FROM [vw_NAT_Exp_1_5_ImplicitPriceIndex]

		UNION ALL
		
		SELECT  [Date_Code]
		  ,[Type]
		  ,[Prices]
		  ,[Sector]
		  ,[Value]
		FROM [vw_NAT_Exp_1_6_PercentShareGDPCurrent]

		UNION ALL
		
		SELECT  [Date_Code]
		  ,[Type]
		  ,[Prices]
		  ,[Sector]
		  ,[Value]
		FROM [vw_NAT_Exp_1_7_PercentShareGDPConstant]
		) A
		
		
		--DROP STG TABLE IF EXIST		
		IF OBJECT_ID('S_Fact_ESLIG_Nat_SummaryExp_STG') IS NOT NULL
		BEGIN
			DROP TABLE [S_Fact_ESLIG_Nat_SummaryExp_STG]
		END


	    SELECT *   ,
		[Date_Idx] = -1,
		[Type_Idx] = -1
	    INTO [S_Fact_ESLIG_Nat_SummaryExp_STG]
		FROM [S_Fact_ESLIG_Nat_SummaryExp]  
		

		---UPDATE DATE IDx
		update A   
	    set A.Date_Idx = B.Time_Idx  
	    from [S_Fact_ESLIG_Nat_SummaryExp_STG] A  
	    join [DES].[dbo].[Dim_Time] B on A.Date_Code = B.ActualDate  
		
		---UPDATE TYPE IDx
		update A   
	    set A.Type_Idx = B.SubSectorType_Idx  
	    from [S_Fact_ESLIG_Nat_SummaryExp_STG] A  
	    join [DES].[dbo].[Dim_Nat_SubSectorType] B on A.[Type] = B.SubSectorType_Label  


		
		TRUNCATE TABLE  [DES].[dbo].[Fact_ESLIG_NAT_SummaryExp]

		INSERT INTO [DES].[dbo].[Fact_ESLIG_NAT_SummaryExp]
           ([Time_Idx]
           ,[Type_Idx]
           ,[Prices]
           ,[Sector]
           ,[Value])
       
	    SELECT 
			  [Date_Idx],
		      [Type_Idx],
			  [Prices],
			  [Sector],
			  [Value] 
		FROM S_Fact_ESLIG_Nat_SummaryExp_STG
		WHERE Date_Idx <> -1 and ISNUMERIC([Value]) = 1
END	
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_DSS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		DCG
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_DSS] 
AS
BEGIN


TRUNCATE TABLE [DES].[dbo].[Fact_DSS];

INSERT INTO [DES].[dbo].[Fact_DSS]
SELECT DISTINCT
  c.DSS_Level7_Idx 
, b.Time_Idx
, a.Amount
FROM [DES_Staging].[dbo].[S_Fact_DSS] a 
JOIN [DES].[dbo].[Dim_Time] b ON a.Time_Code = b.ActualDate
JOIN [DES].[dbo].Dim_DSS_Sectors_Currency_DSS_Level7 c ON c.DSS_Level7_Code = a.DSS_Level7_Code
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_FSI]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		DCG
-- Create date: 09/06/2022
-- Description:	Tranfer Staging table to DES
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_FSI]
AS
BEGIN
	SET NOCOUNT ON;

--TRUNCATE TABLE [DES].[dbo].[Fact_FSI]

DELETE FROM [DES].[dbo].[Fact_FSI]
FROM [DES].[dbo].[Fact_FSI] A
JOIN [DES_Staging].[dbo].[S_Fact_FSI] B
ON  A.Time_Idx = REPLACE(B.Time_Code,'-','') 
AND a.FSICountries_Idx = b.FSICountries_Code

INSERT INTO [DES].[dbo].[Fact_FSI]
SELECT 
b.FSICountries_Idx, 
c.Time_Idx,
a.[Total regulatory capital],
a.[Tier 1 capital],
a.[Regulatory Risk-weighted assets],
a.[Nonperforming loans],
a.[NFL Total gross loans],
a.[Nonperforming loans net of provisions],
a.[Loan concentration by economic activity],
a.[Total gross loans to nonfinancial corporations],
a.[Net income before taxes],
a.[Return on Assets Total assets],
a.[Net income after taxes],
a.[Capital],
a.[Interest margin],
a.[Interest Margin Gross income],
a.[Interest Margin Noninterest expenses],
a.[Liquid assets],
a.[Liquid Assets Total assets],
a.[Short-term liabilities],
a.[Net open position in foreign exchange],
a.[Loans to Emerging and developing Asia],
a.[Loans to Advanced economies],
a.[Loans to Sub-Saharan Africa],
a.[Loans to Emerging and developing Europe],
a.[Loans to Latin America and the Caribbean],
a.[Loans to Middle East and Central Asia],
a.[Geographic distribution of total loans: Advanced economies],
a.[Geographic distribution of total loans: Emerging and developing Asia],
a.[Geographic distribution of total loans: Emerging and developing Europe],
a.[Geographic distribution of total loans: Latin America and the Caribbean],
a.[Geographic distribution of total loans: Middle East and Central Asia],
a.[Geographic distribution of total loans: Sub-Saharan Africa],
a.[Trading income],
a.[Trading Income Gross income],
a.[Personnel expenses],
a.[Personal Expenses Noninterest expenses],
a.[Customer deposits],
a.[Total (noninterbank) loans],
a.[Commercial real estate loans],
a.[Residential real estate loans],
a.[Real Estate Loans Total gross loans],
a.[TIER-1 Capital to Assets Tier 1 capital], 
a.[TIER-1 Capital to Assets Total assets]
FROM [DES_Staging].[dbo].[S_Fact_FSI] a
JOIN [DES].[dbo].[Dim_FSICountries_FSICountries] b ON b.FSICountries_Code = a.FSICountries_Code
JOIN [DES].[dbo].[Dim_Time] c ON  FORMAT (c.ActualDate, 'yyyy-MM-dd') = a.Time_Code
ORDER BY b.FSICountries_Idx

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_GrossNGDebtRatios]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Load_Fact_GrossNGDebtRatios]
AS
BEGIN
	SET NOCOUNT ON;


TRUNCATE TABLE [DES].[dbo].[Fact_Gross NG Debt Ratios]

INSERT INTO [DES].[dbo].[Fact_Gross NG Debt Ratios]
SELECT 
b.Time_Idx,
a.[Gross NG Debt],
a.GDP,
a.GNI,
a.[Cash Remittance in Peso]
FROM [DES_Staging].[dbo].[S_Fact_Gross NG Debt Ratios] a
JOIN [DES].[dbo].[Dim_Time] b ON  FORMAT (b.ActualDate, 'yyyy-MM-dd') = a.Time_Code

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_GS_Issued_Onshore]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		DCG
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_GS_Issued_Onshore] 
AS
BEGIN


TRUNCATE TABLE [DES].[dbo].[Fact_GS_Issued_Onshore];

INSERT INTO [DES].[dbo].[Fact_GS_Issued_Onshore]
SELECT 
b.Time_Idx
, a.[Total Outstanding Government Securities Issued Onshore]
, a.Banks
, a.[Bangko Sentral ng Pilipinas (based on BSP-FM reports)]
, a.[Insurance Companies]
, a.[Investment Houses]
, a.Custodians
, a.Depository
, a.[Private Corporations]
, a.[Government Corporations]
, a.[Local Government Units]
, a.[Tax-exempt Institutions]
, a.[Other residents]
, a.[Non-residents]
, a.[OS GS held by banks]
, a.[OS GS issued onshore held by the BSP %]
FROM [DES_Staging].[dbo].[S_Fact_GS_Issued_Onshore] a
LEFT JOIN [DES].[dbo].[Dim_Time] b ON a.Time_Code = b.ActualDate

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_GSOffshore]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		DCG
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_GSOffshore] 
AS
BEGIN


TRUNCATE TABLE [DES].[dbo].[Fact_GSOffshore];

INSERT INTO [DES].[dbo].[Fact_GSOffshore]
SELECT 
c.Investors_Level4_Idx
, b.Time_Idx
, a.Amount
FROM [DES_Staging].[dbo].[S_Fact_GSOffshore] a 
LEFT JOIN [DES].[dbo].[Dim_Time] b ON a.Time_Code = b.ActualDate
LEFT JOIN [DES].[dbo].Dim_Investors_Investors_Level4 c ON c.Investors_Level4_Code = a.Investors_Level4_Code
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_GSOnshore]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		DCG
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_GSOnshore] 
AS
BEGIN


TRUNCATE TABLE [DES].[dbo].[Fact_GSOnshore];

INSERT INTO [DES].[dbo].[Fact_GSOnshore]
SELECT 
b.Time_Idx
, c.OnshoreGSIssuances_Idx
, a.Amount
FROM [DES_Staging].[dbo].[S_Fact_GSOnshore] a
LEFT JOIN [DES].[dbo].[Dim_Time] b ON a.Time_Code = b.ActualDate
LEFT JOIN [DES].[dbo].[Dim_OnshoreGSIssuances_OnshoreGSIssuances] c ON a.OnshoreGSIssuances_Code = c.OnshoreGSIssuances_Code

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_HistoricalMeralco_EnergySales]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		DCG
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_HistoricalMeralco_EnergySales] 
AS
BEGIN


TRUNCATE TABLE [DES].[dbo].[Fact_HistoricalMeralco_EnergySales];

INSERT INTO [DES].[dbo].[Fact_HistoricalMeralco_EnergySales]
SELECT 
  d.Time_Idx
, c.Meralco_SalesType_Idx
, a.Meralco_EnergySalesAmount
FROM [DES_Staging].[dbo].[S_Fact_HistoricalMeralco_EnergySales] a
JOIN [DES].[dbo].[Dim_Meralco_SalesCategory_Meralco_SalesType] c ON a.Meralco_SalesType_Code = c.Meralco_SalesType_Code
JOIN [DES].[dbo].[Dim_Time] d ON a.Time_Code = d.ActualDate

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_MacroAssumptions]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		DCG
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_MacroAssumptions] 
AS
BEGIN


TRUNCATE TABLE [DES].[dbo].[Fact_MacroAssumptions];

INSERT INTO [DES].[dbo].[Fact_MacroAssumptions]
SELECT 
  b.Time_Idx
, c.MacroAssumptions_Type_Idx
, [GDP]
, [NG Surplus/-Deficit]
, [NG Surplus/-Deficit % to GDP]
, [Surplus/Deficit Projection]
, [Surplus/-Deficit % to GDP Projection]
, [CPSFP Surplus/Deficit Projection]
, [CPSFP Surplus/Deficit % to GDP Projection]
, [CPSFP (Surplus/Deficit)]
, [CPSFP Surplus/Deficit % to GDP]
FROM [DES_Staging].[dbo].[S_Fact_MacroAssumptions] a
JOIN [DES].[dbo].[Dim_Time] b ON a.Time_Code = b.ActualDate
JOIN [DES].[dbo].[Dim_MacroAssumptions_Type_MacroAssumptions_Type] c ON c.MacroAssumptions_Type_Code = a.MacroAssumptions_Type_Code
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_MERALCO_EnergySales]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		DCG
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_MERALCO_EnergySales] 
AS
BEGIN


--TRUNCATE TABLE [DES].[dbo].[Fact_MERALCO_EnergySales];
DELETE FROM [DES].[dbo].[Fact_MERALCO_EnergySales]
FROM [DES].[dbo].[Fact_MERALCO_EnergySales] A
JOIN [DES_Staging].[dbo].[S_Fact_MERALCO_EnergySales] B
ON  A.Time_Idx = REPLACE(B.Time_Code,'-','') 
AND a.Meralco_SalesType_Idx = b.Meralco_SalesType_Code


INSERT INTO [DES].[dbo].[Fact_MERALCO_EnergySales]
SELECT 
  d.Time_Idx
, c.Meralco_SalesType_Idx
, a.Meralco_EnergySalesAmount
FROM [DES_Staging].[dbo].[S_Fact_MERALCO_EnergySales] a
JOIN [DES].[dbo].[Dim_Meralco_SalesCategory_Meralco_SalesType] c ON a.Meralco_SalesType_Code = c.Meralco_SalesType_Code
JOIN [DES].[dbo].[Dim_Time] d ON a.Time_Code = d.ActualDate


END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_MERALCO_KWH_Sales_Perf]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		DCG
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_MERALCO_KWH_Sales_Perf] 
AS
BEGIN


--TRUNCATE TABLE [DES].[dbo].[Fact_MERALCO_ManufacturingCustomer];
DELETE FROM [DES].[dbo].[Fact_MERALCO_KWH_Sales_Perf]
FROM [DES].[dbo].[Fact_MERALCO_EnergySales] A
JOIN [DES_Staging].[dbo].[S_Fact_MERALCO_KWH_Sales_Perf] B
ON  A.Time_Idx = REPLACE(B.Time_Code,'-','') 
--AND a.Meralco_SalesType_Idx = b.Meralco_SalesType_Code


INSERT INTO [DES].[dbo].[Fact_MERALCO_KWH_Sales_Perf]
SELECT 
  d.Time_Idx
, c.ManufacturingCustomerType_Idx
, a.Meralco_ElectricityConsumptionAmount
FROM [DES_Staging].[dbo].[S_Fact_MERALCO_KWH_Sales_Perf] a
JOIN [DES].[dbo].[Dim_ManufacturingCustomerType_ManufacturingCustomerType] c ON a.ManufacturingCustomerType_Code = c.ManufacturingCustomerType_Code
JOIN [DES].[dbo].[Dim_Time] d ON a.Time_Code = d.ActualDate

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_NetNGDebtRatios]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Load_Fact_NetNGDebtRatios]
AS
BEGIN
	SET NOCOUNT ON;

	
	TRUNCATE TABLE [DES].[dbo].[Fact_Net NG Debt Ratio];

INSERT INTO [DES].[dbo].[Fact_Net NG Debt Ratio]
SELECT 
b.Time_Idx
, [Currency & Deposits]
, [Short-term Assets]
, [Total Financial Assets]
, [NG Debt Ratio (Net of Currency and Deposits)]
, [NG Debt Ratio (Net of Short-term Assets)]
, [NG Debt Ratio (Net of Total Financial Assets)]
, [Cash Remittance in Peso]
FROM [DES_Staging].[dbo].[S_Fact_Net NG Debt Ratio] a
JOIN [DES].[dbo].[Dim_Time] b ON  FORMAT (b.ActualDate, 'yyyy-MM-dd') = a.Time_Code

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_OFCS_CAPTIVE]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_OFCS_CAPTIVE]
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here


--- INSERT INTO STAGING FACT TABLE
INSERT INTO [S_FACT_MFSG_OFCS_CAPTIVE_CSOC]

----data for pawnshop
SELECT TRDATE,C.BNKIND,ENTITY,A.RECNO,AMOUNT,SCHNO, B.RecNo_Name, 'CAPTIVE' AS SUBSECTOR 
from [FSS].[GLSLLIB2].[NBPWNFS2] as A
Inner join des.. Dim_MFSG_Pawnshop_RecNo as B on A.RECNO = B.RecNo_Code
Inner join [FSS].[EFILS].[INS_IND] as C on A.BNKIND = C.BNKIND

union all

--- data for lending investor
SELECT TRDATE, C.BNKIND, ENTITY, A.RECNO, AMT, SCHNO, B.RecNo_Name,'CAPTIVE' AS SUBSECTOR
from [FSS].[FSRLIB2].[NBFPF00] as A
Inner join DES..[Dim_MFSG_FC_RecNo] as B on A.RECNO = B.RecNo_Code
Inner join [FSS].[EFILS].[INS_IND] as C on A.BNKIND = C.BNKIND and C.BNKIND = 26



END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_PSALM_Grid]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Load_Fact_PSALM_Grid] 
AS
BEGIN


TRUNCATE TABLE [DES].[dbo].[Fact_PSALM_Grid];

INSERT INTO [DES].[dbo].[Fact_PSALM_Grid]

SELECT 
b.Location_Idx
, d.Time_Idx
, a.[Energy Sales] 
FROM [DES_Staging].[dbo].[S_Fact_PSALM_Grid] a
JOIN [DES].[dbo].[Dim_Grid] b ON a.Location_Code = b.Location_Code
JOIN [DES].[dbo].[Dim_Time] d ON a.Time_Code = d.ActualDate

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_PSALM_PlantType]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Load_Fact_PSALM_PlantType] 
AS
BEGIN


TRUNCATE TABLE [DES].[dbo].[Fact_PSALM_PlantType];

INSERT INTO [DES].[dbo].[Fact_PSALM_PlantType]

SELECT 
b.PlantType_Idx, 
c.Time_Idx, 
a.[Energy Sales] 
FROM [DES_Staging].[dbo].[S_Fact_PSALM_PlantType] a
JOIN [DES].[dbo].[Dim_PlantType_PlantType] b ON a.PlantType_Code = b.PlantType_Code
JOIN [DES].[dbo].[Dim_Time] c ON a.Time_Code = c.ActualDate

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_PSALM_SummaryEnergySales]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Load_Fact_PSALM_SummaryEnergySales] 
AS
BEGIN


TRUNCATE TABLE [DES].[dbo].[Fact_PSALM_SummaryEnergySales];

INSERT INTO [DES].[dbo].[Fact_PSALM_SummaryEnergySales]
SELECT 
b.Location_Idx
, c.EnergySalesType_Idx
, d.Time_Idx
, a.[Energy Sales] 
FROM [DES_Staging].[dbo].[S_Fact_PSALM_SummaryEnergySales] a
JOIN [DES].[dbo].[Dim_Grid] b ON a.Location_Code = b.Location_Code
JOIN [DES].[dbo].[Dim_EnergySalesCategory_EnergySalesType] c ON a.EnergySalesType_Code = c.EnergySalesType_Code
JOIN [DES].[dbo].[Dim_Time] d ON a.Time_Code = d.ActualDate

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_SELFI]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		DCG
-- Create date: 09/06/2022
-- Description:	Tranfer Staging table to DES
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_SELFI]
AS
BEGIN
	SET NOCOUNT ON;

TRUNCATE TABLE [DES].[dbo].[Fact_SELFI]
INSERT INTO [DES].[dbo].[Fact_SELFI]
SELECT 
b.Time_Idx,
[GDP],
[NGRevenues],
[NGExpenditures],
[NGSurplus/Deficit],
[NGBorrowings(Net)],
[NGDomestic(Net)],
[NGExternal(Net)],
[Deposit/Withdrawal],
[FinancingMixDomestic],
[FinancingMixExternal],
[CPSFP(Surplus/Deficit)],
[NGODTotalDebt],
[NGODDomesticDebt],
[NGODExternalDebt],
[OPSDGDP],
[OPSDTotalDebt],
[OPSDDomesticDebt],
[OPSDForeignDebt],
[PublicSectorExternalDebt],
[PublicSectorExternalDebtGDP]
FROM [DES_Staging].[dbo].[S_Fact_SELFI] a
JOIN [DES].[dbo].[Dim_Time] b ON  b.[Year] = a.Time_Code

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Fact_TCRS]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		DCG
-- =============================================
CREATE PROCEDURE [dbo].[usp_Load_Fact_TCRS] 
AS
BEGIN


TRUNCATE TABLE [DES].[dbo].[Fact_TCRS];

INSERT INTO [DES].[dbo].[Fact_TCRS]
SELECT 
  b.Time_Idx
, i.Region_Idx
, c.BankType_Idx
, d.Industry_Idx
, e.PurposeofCredit_Idx
, f.TypeOfBorrower_Idx
, g.EconomicActivityCode_Idx
, h.TypeOfCredit_Idx
, a.Amount
FROM [DES_Staging].[dbo].[S_Fact_TCRS] a 
LEFT JOIN [DES].[dbo].[Dim_Time] b ON a.Time_Code = b.ActualDate
LEFT JOIN [DES].[dbo].Dim_BankType_BankType c ON c.BankType_Code = a.BankType_Code
LEFT JOIN [DES].[dbo].Dim_Industry_Industry d ON d.Industry_Code = a.Industry_Code
LEFT JOIN [DES].[dbo].Dim_PurposeofCredit_PurposeofCredit e ON e.PurposeofCredit_Code = a.PurposeofCredit_Code
LEFT JOIN [DES].[dbo].Dim_TypeOfBorrower_TypeOfBorrower f ON f.TypeOfBorrower_Code = a.TypeOfBorrower_Code
LEFT JOIN [DES].[dbo].Dim_EconomicActivityCode_EconomicActivityCode g ON g.EconomicActivityCode_Code = a.EconomicActivityCode_Code
LEFT JOIN [DES].[dbo].Dim_TypeOfCredit_TypeOfCredit h ON h.TypeOfCredit_Code = a.TypeOfCredit_Code
LEFT JOIN [DES].[dbo].Dim_Region_Region i ON CONCAT('PH-0',a.Region_Code) = i.Region_Code
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_FFSD_Fact_NGCOR]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Load_FFSD_Fact_NGCOR] 
as


DELETE FROM [DES].[dbo].[Fact_NGCOR]
FROM [DES].[dbo].[Fact_NGCOR] A
JOIN [DES_Staging].[dbo].[S_Fact_NGCOR] B
ON  A.Time_Idx = REPLACE(B.Time_Code,'-','') 

INSERT INTO Fact_NGCOR
SELECT 
dt.Time_Idx
, [GDP]
, [Revenues]
, [Revenue Annual Growth Rate (%)]   --: [(Revenue T - Revenue T-1) / Revenue T-1 ] x 100
, [Tax Revenues]
, [Revenues % to GDP]  
, [Non-Tax including Grants]
, [Expenditures] 
, [Expenditures Annual Growth Rate (%)]
, [Interest Payments]
, [Domestic Interest Payments]
, [Foreign Interest Payments]
, [Net Lending & Equity]
, [Surplus/(-)Deficit]
, [Surplus/(-)Deficit % to GDP)] 
, [Financing]
, [Net Domestic Borrowings]
, [Domestic (Gross)]
, [Less: Net Amortization]
, [External (Net)]
, [External (Gross)]
, [Less: Amortization]
, [Change-In-Cash]
FROM DES_Staging.dbo.S_Fact_NGCOR main 
inner join Dim_time dt on dt.Date_Code = main.Time_Code

GO
/****** Object:  StoredProcedure [dbo].[usp_Load_Insert_To_MonthlyBTRHolders_GovtSec]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Load_Insert_To_MonthlyBTRHolders_GovtSec] 
AS
BEGIN


WITH BTRHolders_GovtSec AS (
SELECT 
  (SELECT SUBSTRING([Column2], 16,4) AS [Year] FROM [DES_Staging].[dbo].[Dump_FFSD_BTRHolders_GovtSec] a WHERE [Column1] = 'PARTICULARS') AS [Year]
, (SELECT SUBSTRING([Column2], 7,3) AS [Month] FROM [DES_Staging].[dbo].[Dump_FFSD_BTRHolders_GovtSec] a WHERE [Column1] = 'PARTICULARS') AS [Month]
, (SELECT [dbo].[fn_month_name_to_number] (SUBSTRING([Column2], 7,3)) as [MonthNo] FROM [DES_Staging].[dbo].[Dump_FFSD_BTRHolders_GovtSec] a WHERE [Column1] = 'PARTICULARS') AS [MonthNo]
, [Column1] AS [Title]
, CASE WHEN [Column2] IS NULL THEN 0 ELSE [Column2] END AS Amount
FROM [DES_Staging].[dbo].[Dump_FFSD_BTRHolders_GovtSec] a
WHERE [Column1] IN 
(
  'Banks'
, 'Insurance Companies'
, 'Investment Houses'
, 'Custodians (FAO Taxable Accts)'
, 'Depository (Nominee)'
, 'Private Corporations'
, 'GOCCs'
, 'Local Government Units'
, 'Tax-Exempt Institutions'
, 'Others'
, 'of which: Non-Residents'
)

)
, BTRHolders_GovtSec_layout1 AS (
SELECT  *
FROM  
(
  SELECT *
  FROM BTRHolders_GovtSec
) AS TableToPivot 
PIVOT  
(  
  SUM(Amount)
  FOR  [Title] IN (
  [Banks]
, [Insurance Companies]
, [Investment Houses]
, [Custodians (FAO Taxable Accts)]
, [Depository (Nominee)]
, [Private Corporations]
, [GOCCs]
, [Local Government Units]
, [Tax-Exempt Institutions]
, [Others]
, [of which: Non-Residents]
)  
) AS PivotTable
)

INSERT INTO [DES_Staging].[dbo].[Monthly_BTRHolders_GovtSec]
SELECT 
  [Year]
, [Month]
, [MonthNo]
, [Banks]
, [Insurance Companies]
, [Investment Houses]
, [Custodians (FAO Taxable Accts)] AS [Custodians]
, [Depository (Nominee)] AS [Depository]
, [Private Corporations]
, [GOCCs] AS [Government Corporations]
, [Local Government Units]
, [Tax-Exempt Institutions]
, [Others] AS [Other residents]
, [of which: Non-Residents] AS [Non-Residents]
FROM BTRHolders_GovtSec_layout1

END
GO
/****** Object:  StoredProcedure [dbo].[usp_Load_MasterData]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Load_MasterData]

AS
BEGIN



	SET NOCOUNT ON;

INSERT INTO [DES].[dbo].[Dim_BankType_BankType]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_BankType_BankType]

INSERT INTO [DES].[dbo].[Dim_FSICountries_FSICountries]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_FSICountries_FSICountries]

INSERT INTO [DES].[dbo].[Dim_Industry_Industry]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_Industry_Industry]

INSERT INTO [DES].[dbo].[Dim_PurposeOfCredit_PurposeofCredit]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_PurposeOfCredit_PurposeofCredit]

INSERT INTO [DES].[dbo].[Dim_TypeOfBorrower_TypeOfBorrower]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_TypeOfBorrower_TypeOfBorrower]


INSERT INTO [DES].[dbo].[Dim_TypeOfCredit_TypeOfCredit]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_TypeOfCredit_TypeOfCredit]


ALTER TABLE [DES].[dbo].[Dim_EconomicActivityCode_EconomicActivityCode]
ALTER COLUMN [EconomicActivityCode_Name] NVARCHAR(255)

ALTER TABLE [DES].[dbo].[Dim_EconomicActivityCode_EconomicActivityCode]
ALTER COLUMN [EconomicActivityCode_Label] NVARCHAR(255)


INSERT INTO [DES].[dbo].[Dim_EconomicActivityCode_EconomicActivityCode]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_EconomicActivityCode_EconomicActivityCode]



INSERT INTO [DES].[dbo].[Dim_Region_Region]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_Region_Region]

--PSALM
INSERT INTO [DES].[dbo].[Dim_Location_Location]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_Location_Location]

INSERT INTO [DES].[dbo].[Dim_PlantType_PlantType]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_PlantType_PlantType]

INSERT INTO [DES].[dbo].[Dim_EnergySalesCategory_EnergySalesCategory]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_EnergySalesCategory_EnergySalesCategory]

INSERT INTO [DES].[dbo].[Dim_EnergySalesCategory_EnergySalesType]
SELECT a.EnergySalesType_Code, a.EnergySalesType_Name, a.EnergySalesType_Label, a.EnergySalesType_Sort, b.EnergySalesCategory_Idx 
FROM [DES_Staging].[dbo].[S_Dim_EnergySalesCategory_EnergySalesType] a
LEFT JOIN [DES].[dbo].[Dim_EnergySalesCategory_EnergySalesCategory] b ON a.EnergySalesCategory_Code = b.EnergySalesCategory_Code


-- MERALCO
INSERT INTO [DES].[dbo].[Dim_Meralco_SalesCategory_Meralco_SalesCategory]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_Meralco_SalesCategory_Meralco_SalesCategory]

INSERT INTO [DES].[dbo].[Dim_Meralco_SalesCategory_Meralco_SalesType]
SELECT a.Meralco_SalesType_Code, a.Meralco_SalesType_Name, a.Meralco_SalesType_Label, a.Meralco_SalesType_Sort, b.Meralco_SalesCategory_Idx 
FROM [DES_Staging].[dbo].[S_Dim_Meralco_SalesCategory_Meralco_SalesType] a
LEFT JOIN [DES].[dbo].[Dim_Meralco_SalesCategory_Meralco_SalesCategory] b ON a.Meralco_SalesCategory_Code = b.Meralco_SalesCategory_Code

INSERT INTO [DES].[dbo].[Dim_ManufacturingCustomerType_ManufacturingCustomerType]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_ManufacturingCustomerType_ManufacturingCustomerType]


-- MACROASSUMPTION
INSERT INTO [DES].[dbo].[Dim_MacroAssumptions_Type_MacroAssumptions_Type]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_MacroAssumptions_Type_MacroAssumptions_Type]


-- Investors
INSERT INTO [DES].[dbo].[Dim_Investors_Investors_Level1]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_Investors_Investors_Level1]

INSERT INTO [DES].[dbo].[Dim_Investors_Investors_Level2]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_Investors_Investors_Level2]

INSERT INTO [DES].[dbo].[Dim_Investors_Investors_Level3]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_Investors_Investors_Level3]

INSERT INTO [DES].[dbo].[Dim_Investors_Investors_Level4]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_Investors_Investors_Level4]

INSERT INTO [DES].[dbo].[Dim_OnshoreGSIssuances_OnshoreGSIssuances]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_OnshoreGSIssuances_OnshoreGSIssuances]

-- DSS


INSERT INTO [DES].[dbo].[Dim_DSS_Sectors_Currency_DSS_Level1]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_DSS_Sectors_Currency_DSS_Level1]


INSERT INTO [DES].[dbo].[Dim_DSS_Sectors_Currency_DSS_Level2]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_DSS_Sectors_Currency_DSS_Level2]


INSERT INTO [DES].[dbo].[Dim_DSS_Sectors_Currency_DSS_Level3]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_DSS_Sectors_Currency_DSS_Level3]


INSERT INTO [DES].[dbo].[Dim_DSS_Sectors_Currency_DSS_Level4]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_DSS_Sectors_Currency_DSS_Level4]


INSERT INTO [DES].[dbo].[Dim_DSS_Sectors_Currency_DSS_Level5]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_DSS_Sectors_Currency_DSS_Level5]


INSERT INTO [DES].[dbo].[Dim_DSS_Sectors_Currency_DSS_Level6]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_DSS_Sectors_Currency_DSS_Level6]

INSERT INTO [DES].[dbo].[Dim_DSS_Sectors_Currency_DSS_Level7]
SELECT * FROM [DES_Staging].[dbo].[S_Dim_DSS_Sectors_Currency_DSS_Level7]





END



GO
/****** Object:  StoredProcedure [dbo].[usp_Scrub_Dim_Tenor_Tenor]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Scrub_Dim_Tenor_Tenor]
as

INSERT INTO Dim_Tenor_Tenor (Tenor_Code, Tenor_Name, Tenor_Label, Tenor_Sort)
SELECT Tenor_Code, Tenor_Name, Tenor_Label, Tenor_Sort FROM DES_Staging.dbo.S_Dim_Tenor_Tenor
where not exists (select Tenor_Code, Tenor_Name, Tenor_Label, Tenor_Sort from DIM_Tenor_Tenor where Tenor_Code = DES_Staging.dbo.S_Dim_Tenor_Tenor.Tenor_Code)
order by Tenor_Sort
GO
/****** Object:  StoredProcedure [dbo].[usp_Scrub_ESLIG_Dim_YieldCurve_Tenor]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Scrub_ESLIG_Dim_YieldCurve_Tenor] 
AS

TRUNCATE TABLE [DES].dbo.Dim_YieldCurve_Tenor;

INSERT INTO [DES].dbo.Dim_YieldCurve_Tenor (Tenor_Code, Tenor_Name, Tenor_Label, Tenor_Sort)
SELECT * FROM [DES_Staging].dbo.S_Dim_YieldCurve_Tenor

GO
/****** Object:  StoredProcedure [dbo].[usp_Scrub_MFSG_Dim_NBFI]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_Scrub_MFSG_Dim_NBFI]
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

INSERT INTO  [Dim_MFSG_NBFI]
(
	[RecNo_Code],
	[RecNo_Name] ,
	[RecNo_Label] ,
	[RecNo_Sort] ,
	INDUSTRY_GROUP
)
SELECT 
		--[RecNo_Idx]
		[RecNo_Code]
      ,[RecNo_Name]
      ,[RecNo_Label]
      --,[Group_Code]
      ,[RecNo_Sort]
	  ,INDUSTRY_GROUP = 'FC'
  FROM [DES].[dbo].[Dim_MFSG_FC_RecNo]

  UNION ALL
SELECT 
		--[RecNo_Idx]
    [RecNo_Code]
      ,[RecNo_Name]
      ,[RecNo_Label]
      --,[Group_Code]
      ,[RecNo_Sort]
	  ,INDUSTRY_GROUP = 'IH'
  FROM [DES].[dbo].[Dim_MFSG_IH_RecNo]

  UNION ALL

  SELECT
  		--[RecNo_Idx]
      [RecNo_Code]
      ,[RecNo_Name]
      ,[RecNo_Label]
      --,[Group_Code]
      ,[RecNo_Sort]
	  ,INDUSTRY_GROUP = 'PAWNSHOP'
  FROM [DES].[dbo].[Dim_MFSG_Pawnshop_RecNo]

	UNION ALL

	SELECT
	--[Acct_Idx]
      [Acct_Code]
      ,[Acct_Name]
      ,[Acct_Label]
      ,[Acct_Sort]
	  ,INDUSTRY_GROUP = 'GSIS_SSS'
  FROM [DES].[dbo].[Dim_MFSG_GSISSSS]

  UNION ALL

  SELECT 
	  --Acct_Idx
      [Acct_Code]
      ,[Acct_Name]
      ,[Acct_Label]
      --,[Group_Code]
      ,[Acct_Sort]
	  ,INDUSTRY_GROUP = 'NSSLA'
  FROM [DES].[dbo].[Dim_MFSG_NSSLA_Acct]

  UNION ALL

     SELECT 
	  --[Particular_Idx]
      [Particular_Code]
      ,[Particular_Name]
      ,[Particular_Label]
      --,[Group_Code]
      ,[Particular_Sort]
	  ,INDUSTRY_GROUP = 'PIC'
  FROM [DES].[dbo].[Dim_MFSG_PIC_Particular]

END
GO
/****** Object:  StoredProcedure [dbo].[XXX_usp_Load_Conso_FFSD_CPSFP]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[XXX_usp_Load_Conso_FFSD_CPSFP] 
AS
BEGIN


--TRUNCATE TABLE [DES_Staging].[dbo].[S_Fact_SELFI];

INSERT INTO [DES_Staging].[dbo].[Conso_FFSD_CPSFP]
SELECT 
[CPSFP_Year],
12 AS CPSFP_Month,
DATEFROMPARTS (CPSFP_Year, 12, 1) AS CPSFP_Date,
[TOTAL SURPLUS+/DEFICIT-]
FROM [DES_Staging].[dbo].vw_SELFI_CPSFP

END
GO
/****** Object:  StoredProcedure [dbo].[XXX_usp_Load_Conso_FFSD_NGCOR]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[XXX_usp_Load_Conso_FFSD_NGCOR] 
AS
BEGIN


--TRUNCATE TABLE [DES_Staging].[dbo].[S_Fact_SELFI];

INSERT INTO [DES_Staging].[dbo].[Conso_FFSD_NGCOR]
SELECT 
[COR_Year],
[COR_Month],
[COR_Date],
[Revenues],
[Tax Revenues],
[BIR],
[Documentary Stamp],
[BIR Tax Expenditures],
[BOC],
[BOC Tax Expenditures],
[Other Offices],
[Non-tax Revenues],
[BTr Income],
[Fees and Charges],
[Privatization],
[Income from Malampaya],
[Other non-tax],
[Grants],
[Expenditures],
[Allotment to LGUs],
[Interest Payments],
[Tax Expenditures],
[Subsidy],
[Equity],
[Net Lending],
[NG Disbursements],
[Surplus/(-)Deficit],
[Financing],
[External (Net)],
[External (Gross)],
[Less: Amortization],
[Domestic (Net)],
[Domestic (Gross)],
[Less: Net Amortization],
[Amortization],
[of which: Redemption from BSF],
[Change-In-Cash]
FROM [DES_Staging].[dbo].vw_SELFI_NGCOR

END
GO
/****** Object:  StoredProcedure [dbo].[XXX_usp_Load_Conso_FFSD_NGOSDEBT]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[XXX_usp_Load_Conso_FFSD_NGOSDEBT] 
AS
BEGIN


--TRUNCATE TABLE [DES_Staging].[dbo].[S_Fact_SELFI];

INSERT INTO [DES_Staging].[dbo].[Conso_FFSD_NGOSDEBT]
SELECT 
[NGOSDEBT_Year],
[NGOSDEBT_Month],
[NGOSDEBT_Date],
[I. Domestic Debt],
[Domestic Loans],
[Domestic Direct],
[Domestic Agencies],
[NG Other Domestic],
[BSP Provisional Advances],
[Short-term borrowing from BSP],
[Domestic Relent],
[Domestic Assumed],
[Domestic PNB],
[Domestic DBP],
[Domestic NPC/PNPP],
[Domestic NDC],
[Debt Securities],
[II. External Debt],
[External Loans],
[External Direct],
[External Agencies],
[External Relent],
[External Assumed],
[External PNB],
[External DBP],
[External NPC/PNPP],
[External NDC],
[External PAL],
[External Debt Securities],
[T O T A L],
[Forex Rate Used]
FROM [DES_Staging].[dbo].vw_SELFI_NGOSDEBT

END
GO
/****** Object:  StoredProcedure [dbo].[XXX_usp_Load_Conso_FFSD_OPSD]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[XXX_usp_Load_Conso_FFSD_OPSD] 
AS
BEGIN


--TRUNCATE TABLE [DES_Staging].[dbo].[S_Fact_SELFI];

INSERT INTO [DES_Staging].[dbo].[Conso_FFSD_OPSD]
SELECT 
[OPSD_Year],
12 AS OPSD_Month,
DATEFROMPARTS (OPSD_Year, 12, 1) AS OPSD_Date,
[17. Total consolidated public sector debt (15-16)],
[% of GDP],
[Domestic],
[Foreign]
FROM [DES_Staging].[dbo].vw_SELFI_OPSD

END
GO
/****** Object:  StoredProcedure [dbo].[XXX_usp_Load_Conso_FFSD_PSNA]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[XXX_usp_Load_Conso_FFSD_PSNA] 
AS
BEGIN


--TRUNCATE TABLE [DES_Staging].[dbo].[S_Fact_SELFI];

INSERT INTO [DES_Staging].[dbo].[Conso_FFSD_PSNA]
SELECT 
[PSNA_Year],
12 AS PSNA_Month,
DATEFROMPARTS (PSNA_Year, 12, 1) AS PSNA_Date,
[GNI], 
[GDP]
FROM [DES_Staging].[dbo].vw_SELFI_PSNA

END
GO
/****** Object:  StoredProcedure [dbo].[XXX_usp_Load_Conso_FFSD_PublicExtDebt]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[XXX_usp_Load_Conso_FFSD_PublicExtDebt] 
AS
BEGIN


--TRUNCATE TABLE [DES_Staging].[dbo].[S_Fact_SELFI];

INSERT INTO [DES_Staging].[dbo].[Conso_FFSD_PublicExtDebt]
SELECT 
[PublicExtDebt_Year],
12 AS PublicExtDebt_Month,
DATEFROMPARTS (PublicExtDebt_Year, 12, 1) AS PublicExtDebt_Date,
[Gross National Income (GNI)], 
[Gross Domestic Product (GDP)],
[Public]
FROM [DES_Staging].[dbo].vw_PublicExtDebt

END
GO
/****** Object:  DdlTrigger [tr_ChangeTracking]    Script Date: 12/1/2023 3:41:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [tr_ChangeTracking] ON database
for create_procedure, alter_procedure, drop_procedure,create_table, alter_table, drop_table,create_function, alter_function, drop_function , create_view, alter_view
as  
SET nocount ON   
DECLARE @data xml   
SET @data = eventdata()   
INSERT INTO DES.dbo.DES_DBChangeLog   
            (   
                        databasename,   
                        eventtype,   
                        objectname,   
                        objecttype,   
                        sqlcommand,   
                        loginname,   
                        eventdate   
            )   
            VALUES   
            (   
                        @data.value('(/EVENT_INSTANCE/DatabaseName)[1]', 'varchar(256)'),   
                        @data.value('(/EVENT_INSTANCE/EventType)[1]', 'varchar(50)'),   
                        @data.value('(/EVENT_INSTANCE/ObjectName)[1]', 'varchar(256)'),   
                        @data.value('(/EVENT_INSTANCE/ObjectType)[1]', 'varchar(25)'),   
                        @data.value('(/EVENT_INSTANCE/TSQLCommand)[1]', 'varchar(max)'),   
                        @data.value('(/EVENT_INSTANCE/LoginName)[1]', 'varchar(256)'),   
                        getdate() 
			)
GO
ENABLE TRIGGER [tr_ChangeTracking] ON DATABASE
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'XXX_vw_Net NG Debt Ratios'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'XXX_vw_Net NG Debt Ratios'
GO
USE [master]
GO
ALTER DATABASE [DES] SET  READ_WRITE 
GO
