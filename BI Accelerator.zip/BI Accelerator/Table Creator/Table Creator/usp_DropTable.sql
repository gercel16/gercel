

CREATE PROC [dbo].[usp_DropTables]
AS

DECLARE @SQL varchar(max)
,@TableName varchar(100)
,@FieldName varchar(100)
,@DataType varchar(100)


DECLARE table_cursor CURSOR FOR
SELECT DISTINCT TableName = REPLACE(TableName,' ','')  
FROM TableCreator

OPEN table_cursor   
FETCH NEXT FROM table_cursor INTO @TableName

WHILE @@FETCH_STATUS = 0   
BEGIN  

	SELECT @SQL = ' DROP TABLE [dbo].[' + @TableName +']'

	EXEC (@SQL)

	FETCH NEXT FROM table_cursor INTO @TableName
END   

CLOSE table_cursor   
DEALLOCATE table_cursor 
