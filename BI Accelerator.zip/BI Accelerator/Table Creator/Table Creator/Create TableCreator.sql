
CREATE TABLE [dbo].[TableCreator](
	[TableName] [varchar](100) NULL,
	[FieldName] [varchar](100) NULL,
	[DataType] [varchar](100) NULL
) ON [PRIMARY]
GO


