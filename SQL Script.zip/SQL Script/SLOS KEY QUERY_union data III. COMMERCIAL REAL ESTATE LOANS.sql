---------III. COMMERCIAL REAL ESTATE LOANS-----------------

	select * from (select *,ROW_NUMBER()over (order by ID) as row  
		from [dbo].[vw_Dump_MFSG_SLOS]) temp
		where  row >=600 and row <=609

-----------------------STEP 1---------------------------------------------------------------------
		select 
		(SELECT SUBSTRING((SELECT [COLUMN1] FROM [vw_Dump_MFSG_SLOS] WHERE ID = 7),9,2)) AS 'QUARTER'
		,(SELECT SUBSTRING((SELECT [COLUMN1] FROM [vw_Dump_MFSG_SLOS] WHERE ID = 7),12,4)) AS 'YEAR'
		,*
		,ROW_NUMBER()over (order by ID) as row  
		into #tempROwRead
		from [dbo].[vw_Dump_MFSG_SLOS]
		
		--select * from #tempROwRead
		-- 	where  row =687  
-----------------------STEP 2---------------------------------------------------------------------
---QUESTION 19.-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '19.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T1' -- 1 - Tightened considerably
			,CASE WHEN [column4] <> '' then [column4] end 'T2' -- 2 - Tightened somewhat
			,CASE WHEN [column5] <> '' then [column5] end 'T3' -- 3 - Remained basically unchanged
			,CASE WHEN [column6] <> '' then [column6] end 'T4' -- 4 - Eased somewhat
			,CASE WHEN [column7] <> '' then [column7] end 'T5' -- 5 - Eased considerably	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R1'-- 1 - Tightened considerably
			,CASE WHEN [column9] <> '' then [column9] end 'R2'-- 2 - Tightened somewhat
			,CASE WHEN [column10] <> '' then [column10] end 'R3'-- 3 - Remained basically unchanged
			,CASE WHEN [column11] <> '' then [column11] end 'R4'-- 4 - Eased somewhat
			,CASE WHEN [column12] <> '' then [column12] end 'R5'-- 5 - Eased considerably	
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A1'-- 1 - Tightened considerably
			,CASE WHEN [column14] <> '' then [column14] end 'A2'-- 2 - Tightened somewhat
			,CASE WHEN [column15] <> '' then [column15] end 'A3'-- 3 - Remained basically unchanged
			,CASE WHEN [column16] <> '' then [column16] end 'A4'-- 4 - Eased somewhat
			,CASE WHEN [column17] <> '' then [column17] end 'A5'-- 5 - Eased considerably	
			
		--INTO #Question19
		FROM #tempROwRead
		where  row >=587 and row <=593
		AND [COLUMN2] <> ''

		--drop table #Question19
---QUESTION 20.1-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '20.1'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'
				
		INTO #Question20_1
		FROM #tempROwRead
		where  row >=600 and row <=609
		AND [COLUMN2] <> ''
		--DROP TABLE Question


---QUESTION 20.2-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '20.2'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'				
		INTO #Question20_2
		FROM #tempROwRead
		where  row >=613 and row <=622
		AND [COLUMN2] <> ''


---QUESTION 20.3-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '20.3'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question20_3
		FROM #tempROwRead
		where  row >=626 and row <=635
		AND [COLUMN2] <> ''

---QUESTION 21-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '21.'
		,'QUESTION_TYPE' = 'CREDIT STANDARD'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question21
		FROM #tempROwRead
		where  row >=639 and row <=643
		AND [COLUMN2] <> ''

---QUESTION 22.1-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '22.1'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question22_1
		FROM #tempROwRead
		where  row >=650 and row <=659
		AND [COLUMN2] <> ''

---QUESTION 22.2-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '22.2'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question22_2
		FROM #tempROwRead
		where  row >=663 and row <=672
		AND [COLUMN2] <> ''

---QUESTION 22.3-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '22.3'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question22_3
		FROM #tempROwRead
		where  row >=676 and row <=685
		AND [COLUMN2] <> ''

---QUESTION 23-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '23'
		,'QUESTION_TYPE' = 'FACTORS'
		,[column2] = 'Loan-to-value ratio (in percent):'
		--,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			--,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_OVERALL'
			,CASE WHEN [column5] <> '' then [column5] end 'T_1'
			,CASE WHEN [column6] <> '' then [column6] end 'T_2'
			,CASE WHEN [column7] <> '' then [column7] end 'T_3'	
			,'T_4' = null
			--COUNT RESPONSE----
			--,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_OVERALL'
			,CASE WHEN [column10] <> '' then [column10] end 'R_1'
			,CASE WHEN [column11] <> '' then [column11] end 'R_2'
			,CASE WHEN [column12] <> '' then [column12] end 'R_3'
			,'R_4' = null
			--AVERAGE--
			--,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_OVERALL'
			,CASE WHEN [column15] <> '' then [column15] end 'A_1'
			,CASE WHEN [column16] <> '' then [column16] end 'A_2'
			,CASE WHEN [column17] <> '' then [column17] end 'A_3'	
			,'A_4' = null

		INTO #Question23
		FROM #tempROwRead
		--where  row >=687 and row <=685
		where  row =687 
		--AND [COLUMN2] <> ''

		--DROP TABLE #Question22_3

---QUESTION 24-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '24'
		,'QUESTION_TYPE' = 'CREDIT STANDARD'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question24
		FROM #tempROwRead
		where  row >=689 and row <=694
		AND [COLUMN2] <> ''

---QUESTION 25-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '25'
		,'QUESTION_TYPE' = 'CREDIT STANDARD'
		,[column2] = 'Q-o-Q change in loan-to-value ratio:'
		--,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			--,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_OVERALL'
			,CASE WHEN [column5] <> '' then [column5] end 'T_1'
			,CASE WHEN [column6] <> '' then [column6] end 'T_2'
			,CASE WHEN [column7] <> '' then [column7] end 'T_3'	
			,'T_4' = null
			--COUNT RESPONSE----
			--,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_OVERALL'
			,CASE WHEN [column10] <> '' then [column10] end 'R_1'
			,CASE WHEN [column11] <> '' then [column11] end 'R_2'
			,CASE WHEN [column12] <> '' then [column12] end 'R_3'
			,'R_4' = null
			--AVERAGE--
			--,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_OVERALL'
			,CASE WHEN [column15] <> '' then [column15] end 'A_1'
			,CASE WHEN [column16] <> '' then [column16] end 'A_2'
			,CASE WHEN [column17] <> '' then [column17] end 'A_3'	
			,'A_4' = null
		INTO #Question25
		FROM #tempROwRead
		--where  row >=687 and row <=685
		where  row =695
		--AND [COLUMN2] <> ''

---QUESTION 26-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '26'
		,'QUESTION_TYPE' = 'CREDIT STANDARD'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question26
		FROM #tempROwRead
		where  row >=697 and row <=702
		AND [COLUMN2] <> ''

---QUESTION 27.1-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '27.1'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question27_1
		FROM #tempROwRead
		where  row >=709 and row <=717
		AND [COLUMN2] <> ''

---QUESTION 27.2-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '27.2'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question27_2
		FROM #tempROwRead
		where  row >=721 and row <=729
		AND [COLUMN2] <> ''


---QUESTION 27.3-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '27.3'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question27_3
		FROM #tempROwRead
		where  row >=733 and row <=741
		AND [COLUMN2] <> ''

---QUESTION 28-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '28'
		,'QUESTION_TYPE' = 'CREDIT STANDARD'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question28
		FROM #tempROwRead
		where  row >=744 and row <=749
		AND [COLUMN2] <> ''

---QUESTION 29.1-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '29.1'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question29_1
		FROM #tempROwRead
		where  row >=768 and row <=776
		AND [COLUMN2] <> ''

---QUESTION 29.2-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '29.2'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		INTO #Question29_2
		FROM #tempROwRead
		where  row >=768 and row <=776
		AND [COLUMN2] <> ''

---QUESTION 29.3-----------------------------------------------------------------------	
		SELECT ID 
		,[YEAR]
		,[QUARTER]
		,'QUESTION_CODE' = '29.3'
		,'QUESTION_TYPE' = 'FACTORS'
		,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
		--,CASE WHEN [column3] <> '' then [column3] end 'T_Value'
		--,CASE WHEN [column8] <> '' then [column8] end 'R_Value'
		--,CASE WHEN [column13] <> '' then [column13] end 'A_Value'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_1'
			,CASE WHEN [column5] <> '' then [column5] end 'T_2'
			,CASE WHEN [column6] <> '' then [column6] end 'T_3'
			,CASE WHEN [column7] <> '' then [column7] end 'T_4'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_1'
			,CASE WHEN [column10] <> '' then [column10] end 'R_2'
			,CASE WHEN [column11] <> '' then [column11] end 'R_3'
			,CASE WHEN [column12] <> '' then [column12] end 'R_4'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_1'
			,CASE WHEN [column15] <> '' then [column15] end 'A_2'
			,CASE WHEN [column16] <> '' then [column16] end 'A_3'
			,CASE WHEN [column17] <> '' then [column17] end 'A_4'	
			
		--INTO #Question29_3
		FROM #tempROwRead
		where  row >=780 and row <=788
		AND [COLUMN2] <> ''

-----------------------STEP 3---------------------------------------------------------------------

	--SELECT * 
	--INTO #COMERCIALLOANS
	--FROM #Question19
	--	UNION ALL
	SELECT * 
	INTO #COMERCIALLOANS
	FROM #Question20_1
		UNION ALL
	SELECT * FROM #Question20_2
		UNION ALL
	SELECT * FROM #Question20_3
		UNION ALL
	SELECT * FROM #Question21
		UNION ALL
	SELECT * FROM #Question22_1
		UNION ALL
	SELECT * FROM #Question22_2
		UNION ALL
	SELECT * FROM #Question22_3
		UNION ALL
	SELECT * FROM #Question23
		UNION ALL
	SELECT * FROM #Question24
		UNION ALL
	SELECT * FROM	#Question25
		UNION ALL
	SELECT * FROM #Question26
		UNION ALL
	SELECT * FROM #Question27_1
		UNION ALL
	SELECT * FROM #Question27_2
		UNION ALL
	SELECT * FROM #Question27_3
		UNION ALL
	SELECT * FROM #Question28
		UNION ALL
	SELECT * FROM #Question29_1
		UNION ALL
	SELECT * FROM #Question29_2
		UNION ALL
	SELECT * FROM #Question29_3
	
	


	SELECT * from #COMERCIALLOANS
-----------------------STEP 4---------------------------------------------------------------------
--QUESTION 20 - 29
	SELECT [YEAR],
		[QUARTER],
		'TIME_CODE' = [YEAR] + '-' + [QUARTER],
		[QUESTION_CODE],
		[QUESTION_TYPE],
		[QUESTION_CATEGORY],
		COMERCIALLOAN_TYPE,
		[Values] 
	--INTO #QTEMPTABLE1
	FROM #COMERCIALLOANS
	unpivot
	(
	[Values] FOR COMERCIALLOAN_TYPE IN (T_OVERALL,
								--T_1,
								--T_2,
								--T_3,
								--T_4,
								R_OVERALL,
								--R_1,
								--R_2,
								--R_3,
								--R_4,
								A_OVERALL
								--A_1,
								--A_2,
								--A_3,
								--A_4
								)
	) as unpCREL

-------------------------------
select * from #Question19
--QUESTION 19
	SELECT [YEAR],
		[QUARTER],
		'TIME_CODE' = [YEAR] + '-' + [QUARTER],
		[QUESTION_CODE],
		[QUESTION_TYPE],
		[QUESTION_CATEGORY],
		COMERCIALLOAN_TYPE,
		[Values] 
	INTO #QTEMPTABLE2
	FROM #Question19
	unpivot
	(
	[Values] FOR COMERCIALLOAN_TYPE IN (T1,
								T2,
								T3,
								T4,
								T5,
								R1,
								R2,
								R3,
								R4,
								R5,
								A1,
								A2,
								A3,
								A4,
								A5
								)
	) as unpCREL
-----------------------STEP 5---------------------------------------------------------------------
SELECT * 
INTO #QSTEMPSTORAGE
FROM #QTEMPTABLE1
UNION ALL
SELECT * FROM #QTEMPTABLE2

-----------------------STEP 6 TIMEDIM---------------------------------------------------------------------
	SELECT B.Time_Idx,
	A.YEAR, 
	A.QUARTER,
	A.QUESTION_CODE, 
	A.QUESTION_TYPE,
	A.QUESTION_CATEGORY,
	A.COMERCIALLOAN_TYPE,
	--[Values]
	CONVERT(DECIMAL(18,2), REPLACE([Values], ',', '')) [VALUE] 
	INTO #QSTEMPSTORAGEFIN
	FROM #QSTEMPSTORAGE A
	JOIN (
        SELECT 
            MAX(Time_Idx) Time_Idx,
            Quarter_Name
        FROM EDW.dbo.Dim_Time_1
        GROUP BY Quarter_Name
    )B
    ON A.TIME_CODE = B.Quarter_Name


-----------------------STEP  INSERT TO QUESTIONNAIRE 1 TABLE-------------------------------------
SELECT * FROM #QSTEMPSTORAGE

--INSERT INTO  [dbo].[Dump_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS]
--		([TIME_CODE]
--		,[YEAR]
--		,[QUARTER]
--		,[QUESTION_CODE]
--		,[QUESTION_TYPE]
--		,[QUESTION_CATEGORY]
--		,[COMMERCIALLOAN_TYPE]
--		,[VALUES])
--SELECT * 
--FROM #QSTEMPSTORAGEFIN 

-----------------------STEP  INSERT TO QUESTIONNAIRE 1 TABLE-------------------------------------