select * from edw.[dbo].[Fact_MFSG_NBFI] 



select Time_idx,
		NBFIBankKind_Idx,
		Particular_Type,
		Amount
from edw.[dbo].[Fact_MFSG_NBFI]

--------------------------------------------------
SELECT * FROM [EDW_Staging].[dbo].[Dump_MFSG_STATBUL_TOTRES_BANKS_Temp]
Select * from TEST.[dbo].[TOTRES_Banks]

select * from  [dbo].[Dump_MFSG_STATBUL_TOTRES_BANKS_Temp]
select * from  [Test].[dbo].[TOTRES_Banks]

--INSERT INTO [EDW_Staging].[dbo].[Dump_MFSG_STATBUL_TOTRES_BANKS_Temp]
--		(
--		[Date]
--      ,[IndustryCode]
--      ,[InstitutionName]
--	  ,[SALN_type]
--      ,[Values]
--		)
--SELECT [Time]
--      ,[Institutions]
--      ,[InstitutionName]
--	  ,[SALN_type]
--      ,[Values]
-- FROM [Test].[dbo].[TOTRES_Banks]



