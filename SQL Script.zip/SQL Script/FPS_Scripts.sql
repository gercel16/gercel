



-------------------------------------------------------------
select * from [dbo].[S_Fact_MFSG_NBFI]
sELECT DISTINCT NBFIBankKind_Name FROM EDW.[dbo].[Dim_NBFIBankKind]
Select * from edw.[dbo].[Dim_NBFIParticular]
sELECT * FROM [dbo].[S_Fact_MFSG_STATBUL_BANKSBALANCESHEET] 
sELECT * FROM EDW.[dbo].[Dim_STATBUL_BanksParticularAccount] 

-------1 CENTRAL BANKS-------------------------------------------------
Select	B.TIME_IDX
		,A.[GROUP_TYPE]
		,CONVERT(DECIMAL(18,2), REPLACE(A.[values], ',', '')) AMOUNT
		,A.[PFS_TYPE]
		--SUM(A.[VALUES])
INTO #TempStorageFPS
from [dbo].[Dump_MFSG_STATBUL_FPS_BSPAL_Temp] A
JOIN EDW.[dbo].[Dim_Time_1] B
ON A.[DATE] = B.Date_Code
--------------------------------------------
UNION ALL

-------2 BANKS------------------------------
SELECT	A.Time_Idx
		,B.BankParticularAccount_Type
		,A.[Value]
		--,C.IndustryGroup
		,D.PFSParticularName
		--SUM(A.[VALUE])
FROM [dbo].[S_Fact_MFSG_STATBUL_BANKSBALANCESHEET] A
JOIN EDW.[dbo].[Dim_STATBUL_BanksParticularAccount] B
ON a.BankParticularAccount_Idx = b.BankParticularAccount_Idx
JOIN EDW.[dbo].[Dim_STATBUL_Industry] C
ON A.Industry_idx = C.Industry_Idx
JOIN [Test].[dbo].[PFSParticular] D
ON C.IndustryGroup = D.PFSParticularDesc
 --where b.IndustryGroup_Code = 'UKBs'
-------------------------------------------
UNION ALL
-------3 NBFIs------------------------------------

SELECT	 A.Time_idx
		,C.Particular_Type
		,A.Amount
		--,B.NBFIBankKind_Name
		,E.PFSParticularName
		--SUM(A.[AMOUNT])
		--,A.Particular_Group
FROM [dbo].[S_Fact_MFSG_NBFI] A
JOIN EDW.[dbo].[Dim_NBFIBankKind] B
ON A.BankIndustry_idx = B.NBFIBankKind_Idx
join EDW.[dbo].[Dim_NBFIParticular] C
ON A.NBFIParticular_Idx = C.NBFIParticular_Idx
--join EDW.[dbo].[Dim_STATBUL_StatementType] D
--ON C.NBFIParticular_Idx = [StatementType_Idx]
Join [Test].[dbo].[PFSParticular] E
ON B.NBFIBankKind_Name = E.PFSParticularDesc

--WHERE B.NBFIBankKind_Name = 'AUTHORIZED AGENT BANKS (AAB)' and C.Particular_Type = 'Assets'
-------------------------------------------
--drop table #TempStorageFPS

SELECT  *
FROM #TempStorageFPS  
where group_type = 'Assets'
ORDER BY PFS_TYPE ASC

Select * from EDW.[dbo].[Dim_STATBUL_StatementType]



SELECT A.time_idx, A.group_type, A.Amount, A.Pfs_type 
--,B.statementName ,B.[StatementParticular]
FROM #TempStorageFPS A
left join EDW.[dbo].[Dim_STATBUL_StatementType] B
ON A.PFS_TYPE = B.[StatementParticular]
AND A.Group_type = B.statementName
where A.pfs_type = 'AAB Forex Corporations'
order by  A.pfs_type asc



SELECT * FROM #TempStorageFPS
where pfs_type = 'AAB Forex Corporations'
order by  pfs_type asc
