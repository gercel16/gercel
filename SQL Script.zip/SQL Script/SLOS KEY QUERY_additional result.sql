
SELECT *
       FROM [dbo].[Dump_MFSG_SLOS_REMARKS]


		select * from (select *,ROW_NUMBER()over (order by ID) as row  
		from [dbo].[vw_Dump_MFSG_SLOS_ADDITIONAL_RESULT]
		) temp

		select  *,ROW_NUMBER()over (order by ID) as row 
		from [dbo].[vw_Dump_MFSG_SLOS_ADDITIONAL_RESULT]
		
	

	--(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_CCC_CSOC where ID = 2),26,3))  AS MONTH,

	--DROP TABLE #tempROwRead

-----------------------STEP 1---------------------------------------------------------------------
		select 
		(SELECT SUBSTRING((SELECT [COLUMN1] FROM [vw_Dump_MFSG_SLOS] WHERE ID = 7),9,2)) AS 'QUARTER'
		,(SELECT SUBSTRING((SELECT [COLUMN1] FROM [vw_Dump_MFSG_SLOS] WHERE ID = 7),12,4)) AS 'YEAR'		
		,ROW_NUMBER()over (order by ID) as [ROW]  
		,[COLUMN1]
		,[COLUMN2]
		--into #tempROwRead
		from [dbo].[vw_Dump_MFSG_SLOS_ADDITIONAL_RESULT]
		WHERE [COLUMN2] IS NOT null

-----------------------STEP 1---------------------------------------------------------------------
		--select *
		--from #tempROwRead
		--ORDER BY ID ASC

		--select *
		--from #tempROwRead
		--where  row >=22 and row <=42
		--ORDER BY ID ASC
		
		--,Case when [MONTH] <> '' then [MANUFACTURING_RAW] end 'Manufacturing'

-----------------------STEP 2---------------------------------------------------------------------

SELECT * FROM #tempROwRead
---QUESTION LVT.-----------------------------------------------------------------------

		SELECT  
			[YEAR]
			,[QUARTER]
			,'RESPONSECODE' = 'LVT'
			--LVT----
			,CASE WHEN [column1] <> '' then [column1] end 'ASSET_SIZE'
			,CASE WHEN [column2] <> '' then [column2] end 'NO_BANK_RESPONSE'
		INTO #LVT
		FROM #tempROwRead
		where  row >=7 and row <=16
		AND [COLUMN2] <> ''

-----------------------STEP 3---------------------------------------------------------------------
	
	SELECT * 
	INTO #TEMPTABLE
	FROM #LVT
		UNION ALL
	SELECT * FROM #TC
		UNION ALL
	SELECT * FROM #LMME

	SELECT * FROM #TEMPTABLE
---------------------STEP 3--------------------------------------------------------------------
SELECT * 
	FROM #TEMPTABLE

	SELECT [YEAR],
		[QUARTER],
		'TIME_CODE' = [YEAR] + '-' + [QUARTER],
		RESPONSECODE,
		ASSET_SIZE,
		CONVERT(DECIMAL(18,2), REPLACE([NO_BANK_RESPONSE], ',', '')) [VALUE] 
	INTO #QTEMPTABLE1
	FROM #TEMPTABLE

--------------------------------------------------------------------------------------

	SELECT B.Time_Idx,
	A.YEAR, 
	A.QUARTER,
	A.RESPONSECODE, 
	A.ASSET_SIZE,
	A.[VALUE] 
	--INTO #QTEMPSAD
	FROM #QTEMPTABLE1 A
	JOIN (
        SELECT 
            MAX(Time_Idx) Time_Idx,
            Quarter_Name
        FROM EDW.dbo.Dim_Time_1
        GROUP BY Quarter_Name
    )B
    ON A.TIME_CODE = B.Quarter_Name

-----------------------STEP  INSERT TO QUESTIONNAIRE 1 TABLE-------------------------------------
SELECT * FROM #QSTEMPSTORAGE

INSERT INTO [S_Fact_MFSG_SLOS_ADDITIONAL_RESULTS] 
		([Time_idx]
		,[RESPONSECODE]
		,[ASSET_SIZE]
		,[Values])

SELECT  Time_idx
		,RESPONSECODE
		,ASSET_SIZE
		,[VALUE]
FROM #QTEMPSAD 

-----------------------STEP  INSERT TO QUESTIONNAIRE 1 TABLE-------------------------------------


