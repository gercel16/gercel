USE [EDW_Staging]
GO

/****** Object:  Table [dbo].[S_Fact_ESLIG_Poverty]    Script Date: 12/28/2022 1:51:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[S_Fact_ESLIG_Poverty](
	[Province_Name] [nvarchar](max) NOT NULL,
	[Values] [numeric](18, 2) NULL,
	[Time_Code] [nvarchar](20) NULL,
	[ReportName] [nvarchar](200) NULL,
	[Province_Code] [nvarchar](20) NULL,
	[PovertyCode_Idx] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


