select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_FC_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_FC_CSOC where ID = 2),25,3))  AS MONTH,
	'FC_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_FC_CSOC where ID = 2),25,3)))	
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_FC_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_FC_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 