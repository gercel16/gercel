
---FOR UPDATE CHECKING
select * from [dbo].[S_Fact_ESLIG_PMI] A
join  [EDW].[dbo].[Fact_ESLIG_PMI] B
on A.Time_Code = B.Time_IDx

--FOR INSERT CHECKING
select * from [dbo].[S_Fact_ESLIG_PMI] A
left join  [EDW].[dbo].[Fact_ESLIG_PMI] B
on A.Time_Code = B.Time_IDx
where B.Time_IDx is null

--LOAD UPDATE SCRIPTS----
update B
set B.[Manufacturing] = A.[Manufacturing], B.[Composite] = A.[Composite]
	, B.[RetailWholesale] = A.[RetailWholesale], B.[Services] = A.[Services]
from [dbo].[S_Fact_ESLIG_PMI] A
join  [EDW].[dbo].[Fact_ESLIG_PMI] B
on A.Time_Code = B.Time_IDx

--LOAD INSERT SCRIPTS
insert into [EDW].[dbo].[Fact_ESLIG_PMI] 
select A.*  from [dbo].[S_Fact_ESLIG_PMI] A
left join  [EDW].[dbo].[Fact_ESLIG_PMI] B
on A.Time_Code = B.Time_IDx
where B.Time_IDx is null

-----------------------------------------------------------

select * from [dbo].[S_Fact_ESLIG_PMI_SPGLobal] A
join  [EDW].[dbo].[Fact_ESLIG_PMI_SPGlobal] B
on A.[Time_Idx] = B.Time_IDx

select * from [dbo].[S_Fact_ESLIG_PMI_SPGLobal] A
left join  [EDW].[dbo].[Fact_ESLIG_PMI_SPGlobal] B
on A.[Time_Idx] = B.Time_IDx
where B.Time_IDx is null

UPDATE B
set B.[Time_Idx] = A.[Time_Idx]
	,B.[value] = A.[Value]
from [dbo].[S_Fact_ESLIG_PMI_SPGLobal] A
join  [EDW].[dbo].[Fact_ESLIG_PMI_SPGlobal] B
on A.[Time_Idx] = B.Time_IDx


insert into [EDW].[dbo].[Fact_ESLIG_PMI_SPGlobal] 
select A.*  from [dbo].[S_Fact_ESLIG_PMI_SPGLobal] A
left join  [EDW].[dbo].[Fact_ESLIG_PMI_SPGlobal] B
on A.Time_IDx = B.Time_IDx
where B.Time_IDx is null



