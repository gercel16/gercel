		TRUNCATE TABLE [EDW].[dbo].[Fact_MFSG_STATBUL_TAB1_47]
		
		SELECT * 
		FROM [EDW_Staging].[dbo].[S_Fact_MFSG_STATBUL_UKB_TAB1.47] A
		JOIN [EDW].[dbo].[Fact_MFSG_STATBUL_TAB1_47] B
		ON A.[Time_Idx] = B.[Time_idx]
		AND A.[DepositAcountType_idx] = B.[DepositAcountType_idx]



		SELECT  
			A.[Time_Idx]
			,A.[DepositAcountType_idx]
			,A.[Industry_Code]
			,A.[Bank_Code]
			,A.[Sched_No]
			,A.[Value]
		FROM [EDW_Staging].[dbo].[S_Fact_MFSG_STATBUL_UKB_TAB1.47] A
		LEFT JOIN [EDW].[dbo].[Fact_MFSG_STATBUL_TAB1_47] B
		ON A.[Time_Idx] = B.[Time_idx]
		AND A.[DepositAcountType_idx] = B.[DepositAcountType_idx]
		WHERE B.[Time_idx] IS NULL



		INSERT INTO [EDW].[dbo].[Fact_MFSG_STATBUL_TAB1_47]
		SELECT  
			A.[Time_Idx]
			,A.[DepositAcountType_idx]
			,A.[Industry_Code]
			,A.[Bank_Code]
			,A.[Sched_No]
			,A.[Value]
		FROM [EDW_Staging].[dbo].[S_Fact_MFSG_STATBUL_UKB_TAB1.47] A
		LEFT JOIN [EDW].[dbo].[Fact_MFSG_STATBUL_TAB1_47] B
		ON A.[Time_Idx] = B.[Time_idx]
		AND A.[DepositAcountType_idx] = B.[DepositAcountType_idx]
		WHERE B.[Time_idx] IS NULL


		UPDATE B
		SET B.[Time_Idx] = A.[Time_Idx]
			,B.[DepositAcountType_idx] = A.[DepositAcountType_idx]
			,B.[Industry_Code] = A.[Industry_Code]
			,B.[Bank_Code] = A.[Bank_Code]
			,B.[Sched_No] = A.[Sched_No]
			,B.[Value] = A.[Value]
		FROM [EDW_Staging].[dbo].[S_Fact_MFSG_STATBUL_UKB_TAB1.47] A
		JOIN [EDW].[dbo].[Fact_MFSG_STATBUL_TAB1_47] B
		ON A.[Time_Idx] = B.[Time_idx]
		AND A.[DepositAcountType_idx] = B.[DepositAcountType_idx]