/****** Script for SelectTopNRows command from SSMS  ******/
SELECT *
  FROM [DES_Staging].[dbo].[SSIS_Properties] where ReportName = 'OFCS'

  --update [SSIS_Properties] set TableName = 'Dump_MFSG_OFCS_SST_IC_BS' where  ID = 1084 and ReportName = 'OFCS'


  select * from [dbo].[Dump_MFSG_OFCS_SST_GCG_BS]
    select * from [dbo].[Dump_MFSG_OFCS_SST_GCG_IS]
	--drop table #TempTableIC_BS
--1-------------------------------------------------------------------------------------------------------
select ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS ID, * 
into #Temp_BS_GCG
from [Dump_MFSG_OFCS_SST_GCG_BS]

--2--------------------------------------------------------------------------------------------------------

  -- GCG
  --cleaning BS GCG
SELECT  CONCAT(column4, column5,column6,column7,column8,column9,column10,column11) AS AccountDesc, 
'DomesticCurrency' = column12,
'ForeignCurrencyUSD' = column13,
'ForeignCurrrencyPESO_EQ' = column14,
'TOTAL PESO EQUIVALENT' = column15,
ID
into #TempTableIC_BS
FROM #Temp_BS_GCG
--where column15 <> ''
order by ID asc, AccountDesc OFFSET 6 ROWS

select * from #TempTableIC_BS

--drop table #TempTableIC_BS
---------------------------------------------------------------------------------------------
 DROP TABLE #GCG_BS

Select AccountDesc,
case
when  LTRIM(RTRIM([DomesticCurrency])) = '-' then NULL
	--WHEN ISNUMERIC([DomesticCurrency]) = 1 THEN [DomesticCurrency]  		
		ELSE [DomesticCurrency]
		end as  'In Domestic Currency',
case
when  ltrim(rtrim([ForeignCurrencyUSD])) = '-' then NULL 
	--WHEN ISNUMERIC([ForeignCurrencyUSD]) = 1 THEN [ForeignCurrencyUSD]  		
		ELSE [ForeignCurrencyUSD]
		end as  'Foreign Currency USD',
case
--when  LTRIM (RTRIM( [ForeignCurrrencyPESO_EQ])) = '               -   ' then '0.0' 
when  LTRIM (RTRIM( [ForeignCurrrencyPESO_EQ])) = '-' then NULL 
	--WHEN ISNUMERIC([ForeignCurrrencyPESO_EQ]) = 1 THEN [ForeignCurrrencyPESO_EQ]  		
		ELSE [ForeignCurrrencyPESO_EQ]
		end as  'Foreign Currrency PESO Equivalent',
case
--when  [TOTAL PESO EQUIVALENT] = '                                     -   ' then '0.0' 
when LTRIM(rtrim( [TOTAL PESO EQUIVALENT])) = '-' then NULL
	--WHEN ISNUMERIC([TOTAL PESO EQUIVALENT]) = 1 THEN [TOTAL PESO EQUIVALENT]  		
		ELSE [TOTAL PESO EQUIVALENT]
		end as  'TOTAL PESO EQUIVALENT'
into #GCG_BS
 from #TempTableIC_BS

 --3---------------------------------------------------------------------------------------------------

select AccountDesc,
Domestic_Currency = cast([In Domestic Currency] as int)
,Foreign_currency_USD = cast([Foreign Currency USD] as int)
,Foreign_currency_PesoEquivalent = cast([Foreign Currrency PESO Equivalent] as int)
,Total_Peso_Equivalent = cast([TOTAL PESO EQUIVALENT] as int)
from #GCG_BS 


-------------------------------------------------------------------------------------------------------

 select * from [dbo].[Dump_MFSG_OFCS_SST_GCG_IS]
  --cleaning IS
SELECT  CONCAT(column2, column3) AS AccountDesc, 
'INCOME/EXPENSE' = column6
--into #TempTableIC_IS
FROM [dbo].[Dump_MFSG_OFCS_SST_GCG_IS]
where column6 <> ''
order by ID asc, AccountDesc OFFSET 1 ROWS


select *
from #TempTableIC_BS


select * from [dbo].[Dump_MFSG_OFCS_SST_IC_BS]

select CONCAT(column4, column5,column6,column7,column8,column9,column10,column11) AS AccountDesc,
'IDC' = column12,
'FC_USD' = column13,
'FC_PE' = column14,
'Tot_PE' = column15
from [dbo].[Dump_MFSG_OFCS_SST_IC_BS]

select * from [dbo].[Dump_MFSG_OFCS_SST_IC_LIFE_IS]
select * from [dbo].[Dump_MFSG_OFCS_SST_IC_NONLIFE_IS]

