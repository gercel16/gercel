
SELECT *
       FROM [dbo].[vw_Dump_MFSG_SLOS_REMARKS]


		select * from (select *,ROW_NUMBER()over (order by ID) as row  
		from [dbo].[vw_Dump_MFSG_SLOS_REMARKS]
		) temp

		select  *,ROW_NUMBER()over (order by ID) as row 
		from [dbo].[vw_Dump_MFSG_SLOS_REMARKS]	

	

	--(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_CCC_CSOC where ID = 2),26,3))  AS MONTH,

	--DROP TABLE #tempROwRead

-----------------------STEP 1---------------------------------------------------------------------
		select 
		--ID
		--,ROW_NUMBER()over (order by ID) as [ROW] , 
		(SELECT SUBSTRING((SELECT ITEM FROM [vw_Dump_MFSG_SLOS_REMARKS] WHERE ID = 1),1,2)) AS 'QUARTER'
		,(SELECT SUBSTRING((SELECT ITEM FROM [vw_Dump_MFSG_SLOS_REMARKS] WHERE ID = 1),4,4)) AS 'YEAR'		
		,ITEM
		,SUB_ITEM
		,BANK_NAME
		,REMARKS
		into #TEMPTABLE
		from [dbo].[vw_Dump_MFSG_SLOS_REMARKS]
		WHERE BANK_NAME <> ''
		 order by ID OFFSET 1 ROWS

-----------------------STEP 2---------------------------------------------------------------------

--SELECT * FROM #tempROwRead
-----QUESTION LVT.-----------------------------------------------------------------------

--		SELECT  
--			[YEAR]
--			,[QUARTER]
--			,'RESPONSECODE' = 'LVT'
--			--LVT----
--			,CASE WHEN [column1] <> '' then [column1] end 'ASSET_SIZE'
--			,CASE WHEN [column2] <> '' then [column2] end 'NO_BANK_RESPONSE'
--		INTO #LVT
--		FROM #tempROwRead
--		where  row >=7 and row <=16
--		AND [COLUMN2] <> ''

-------------------------STEP 3---------------------------------------------------------------------
	
--	SELECT * 
--	INTO #TEMPTABLE
--	FROM #LVT
--		UNION ALL
--	SELECT * FROM #TC
--		UNION ALL
--	SELECT * FROM #LMME

--	SELECT * FROM #TEMPTABLE
---------------------STEP 3--------------------------------------------------------------------
SELECT * 
	FROM #TEMPTABLE

-------------------------------------------------------------------------------

	SELECT [YEAR],
		[QUARTER],
		'TIME_CODE' = [YEAR] + '-' + [QUARTER],
		ITEM,
		SUB_ITEM,
		BANK_NAME,
		REMARKS
	INTO #QTEMPTABLE1
	FROM #TEMPTABLE

--------------------------------------------------------------------------------------

	SELECT B.Time_Idx,
	--A.YEAR, 
	--A.QUARTER,
		A.ITEM,
		A.SUB_ITEM,
		A.BANK_NAME,
		A.REMARKS
	INTO #TEMPREMARK
	FROM #QTEMPTABLE1 A
	JOIN (
        SELECT 
            MAX(Time_Idx) Time_Idx,
            Quarter_Name
        FROM EDW.dbo.Dim_Time_1
        GROUP BY Quarter_Name
    )B
    ON A.TIME_CODE = B.Quarter_Name

-------------------------------------------------------------------------------------------------

INSERT INTO [dbo].[S_Fact_MFSG_SLOS_REMARKS]
		([Time_idx],
		[ITEM_CODE],
		[SUB_ITEM],
		[BANK_NAME],
		[REMARK])

SELECT  Time_idx
		,ITEM
		,SUB_ITEM
		,BANK_NAME
		,REMARKS
FROM #TEMPREMARK 



