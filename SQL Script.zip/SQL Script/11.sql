---A. FROM NBFIs
----------1 GET THE  BANKS KIND OF NBFIs------------
		SELECT A.Time_idx,
				B.[NBFIBankKind_Name],
				A.Particular_Type,
				A.Amount
		--INTO #TempStorageNBFI
		FROM edw.[dbo].[Fact_MFSG_NBFI] A
		JOIN EDW.[dbo].[Dim_NBFIBankKind] B
		ON A.NBFIBankKind_Idx = B.NBFIBankKind_Idx

-----------2 GET THE INSTITUTION TYPE BASE ON BANK KINDS-----
		SELECT A.Time_idx,
				A.[NBFIBankKind_Name],
				B.[PFSParticularGroup],
				A.Particular_Type,
				A.Amount
		--INTO #TempStorageNBFI2
		FROM #TempStorageNBFI A
		JOIN EDW.[dbo].[Dim_STATBUL_PFSParticular] B
		ON A.[NBFIBankKind_Name] = B.[PFSParticularDesc]

---B. FROM BANKS INSTITUTION
---------1 GET THE BANK GROUP KINDS AND TIME IDX---------
		SELECT	B.Time_Idx,
				--[date],
				--A.[IndustryCode],
				A.[InstitutionName],
				A.[SALN_type],
				A.[Values]
		--INTO #TempStorageBANKS
		FROM [EDW_Staging].[dbo].[Dump_MFSG_STATBUL_TOTRES_BANKS_Temp] A
		join [EDW].[dbo].[Dim_Time_1] B
		ON A.[Date] = B.Date_Code
		ORDER BY A.[Date] ASC

--------------2 GET THE INDUSTRYGROUPING TYPE----------------------
		SELECT	A.Time_Idx,
				A.[InstitutionName],
				B.[IndustryGroup_Name],
				A.[SALN_type],
				A.[Values]
		--INTO #TempStorageBANKS2
		FROM #TempStorageBANKS A
		JOIN EDW.[dbo].[Dim_STATBUL_Industry] B
		ON A.[InstitutionName] = B.[IndustryName]

--------------3 GET THE INSTITUTIONS TYPE----------------------
		SELECT	A.Time_Idx,
				--A.[InstitutionName],
				--A.[IndustryGroup_Name],
				B.PFSParticularDesc,
				B.[PFSParticularGroup],
				A.[SALN_Type],
				A.[Values]
		INTO #TempStorageBANKS3
		FROM #TempStorageBANKS2 A
		LEFT JOIN EDW.[dbo].[Dim_STATBUL_PFSParticular] B
		ON A.[IndustryGroup_Name] = B.[PFSParticularSubGroup1]

		--drop table #TempStorageBANKS3
----------------------------------------------------------------
--drop table #TempStorageINSTITUTION
----C. COMBINING OF RESULT OF NBFIs and BANK INSTITUTION
		SELECT Time_idx,
			'InstitutionType' = NBFIBankKind_Name,
			'InstitutionGroup' = PFSParticularGroup,
			'ParticularType' = Particular_Type,
			'Value' = Amount
		INTO #TempStorageINSTITUTION
		FROM #TempStorageNBFI2
		union all
		SELECT * 
		FROM #TempStorageBANKS3

----------------------------------------------------------------
----D. Get the dimension Idx

		SELECT A.Time_Idx,
				C.[Institution_Idx],
				B.PFSParticular_idx,
				B.[PFSParticularName],
				--C.[InstitutionName],
				D.[SALN_Idx],
				--D.[SALNType],
				--A.InstitutionType,
				--A.InstitutionGroup,
				--A.ParticularType,
				A.[Value]	
				--B.PFSParticularCode,

				--C.[Institution_Idx],
				--C.[InstitutionGroup]
		--INTO #TempStorageINSTITUTION2
		FROM [dbo].#TempStorageINSTITUTION A
		LEFT JOIN [EDW].[dbo].[Dim_STATBUL_PFSParticular] B
		ON A.InstitutionType = B.PFSParticularDesc
		JOIN EDW.[dbo].[Dim_STATBUL_Institution] C
		ON A.InstitutionGroup = C.[InstitutionGroup]
		JOIN EDW.[dbo].[Dim_SALNType] D
		ON A.ParticularType = D.[SALNType]
		--drop table #TempStorageINSTITUTION2
-----------------------------------------------------------------
---E. GETTING THE CENTRAL BANKS VALUE----

	SELECT A.Time_Idx 
			,D.[Institution_Idx]
			,D.[InstitutionName]
			--,B.PFSParticular_Idx
			,C.[SALN_Idx]
			,A.[Value]
	--INTO #TempStorageCB
	FROM EDW.[dbo].[Fact_MFSG_STATBUL_PFS] A
	JOIN edw.[dbo].[Dim_STATBUL_PFSParticular] B
	ON A.PFS_Type = B.[PFSParticularName]
	JOIN EDW.[dbo].[Dim_SALNType] C
	ON A.SALN_Type = C.[SALNCode]
	JOIN EDW.[dbo].[Dim_STATBUL_Institution] D
	ON A.PFS_Type = D.[InstitutionName]
	--WHERE PFS_Type = 'Central Bank'

---------------------------------------------------------------
---- F. COMBINE VALUE OF CENTRAL BANKS AND OTHER INSTITUTION
	select	
	[Time_Idx],
			[Institution_Idx],
			[PFSParticular_Idx],
			[SALN_Idx],
			[Value]
	--INTO #TempStorageTOTRES
	FROM #TempStorageCB
	UNION ALL
	SELECT 
			[Time_Idx],
			[Institution_Idx],
			[PFSParticular_Idx],
			[SALN_Idx],
			[Value]
	FROM #TempStorageINSTITUTION2

----------------------------------------------------------------
--G. INSERT INTO STAGING TABLE------------------
		INSERT INTO [EDW_Staging].[dbo].[S_Fact_MFSG_STATBUL_TOTRES]
			([Time_Idx],
			[Institution_Idx],
			[PFSParticular_Idx],
			[SALN_Idx],
			[Value]
			)
		SELECT 
			Time_Idx,
			[Institution_Idx],
			[PFSParticular_Idx],
			[SALN_Idx],
			[Value]
		FROM #TempStorageTOTRES