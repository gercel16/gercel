	
	DECLARE @CASH numeric(18,2) -- CASH
	DECLARE @COCI numeric(18,2) -- Checks and other Cash Items
	DECLARE @DCB numeric(18,2) -- Due from BSP
	DECLARE @DFB numeric(18,2) -- Due from Banks
	DECLARE @LD numeric(18,2) -- Loans and Discounts
	DECLARE @INV numeric(18,2) -- Investments in Bonds and Securities
	DECLARE @BHFF numeric (18,2) -- Real Property, Furniture, Fixture, and Equipment
	DECLARE @ROPOA numeric (18,2) --Real and Other Properties Owned or Acquired
	DECLARE @OA numeric (18,2)  -- Other Assetts
	DECLARE @BP numeric(18,2) --Bills Payable'
	DECLARE @OL numeric(18,2) -- Other Liabilities
	DECLARE @CS numeric(18,2) --Capital Stock
	DECLARE @SRUP numeric(18,2) --Surplus, Reserves and Undivided Profits
	DECLARE @TA numeric(18,2) -- Total Assets
	DECLARE @TL numeric(18,2) -- Total Liabilities
	DECLARE @TNW numeric(18,2) -- Total Net WOrth
	DECLARE @TLNW numeric(18,2) -- Total Liabilities  and Net Worth
	DECLARE @LPR numeric(18,2) -- Legal Policy Reserves
	DECLARE @TIME_CODE int -- TIMECODE

	-----------------------------------TEMP Storage----------------------------------

		create  table #TempStore (
		[ID] [int] IDENTITY(1,1) NOT NULL
		, Particular nvarchar(210)
		, AMOUNT numeric(18,2)
		,Time_Code int,
		ReportName nvarchar (210)
		)

	------------------------------------TIMECODE---------------------------------
	 --select * from [dbo].[S_Fact_MFSG_NBFIs]

set @TIME_CODE = (select top 1 t1.Time_Code from [dbo].[S_Fact_MFSG_NBFIs] T1
				join [dbo].[S_Fact_MFSG_NBFIs] T2
				on T1.Time_Code = T2.Time_Code
				where T1.NBFIsReport in ('Tab 2.2','Tab 2.4') 
				and T2.NBFIsReport in ('Tab 2.2','Tab 2.4')
				)

	---------------------------------------------------------------------
	---------------------------Getting for values------------------
	

 --output1

set @CASH = (
		Select sum ([Value]) as 'CASH'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('CASH')
		--and NBFIsReport in ('19','20')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)

--INSERT
insert into #TempStore (Particular,AMOUNT, Time_Code,ReportName)
Values ('CASH', @CASH, @TIME_CODE,'NBFI')


--output2
set @COCI = (
		Select sum ([Value]) as 'Checks and other Cash Items'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Checks and other Cash Items')
		and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)


--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Checks and other Cash Items', @COCI, @TIME_CODE,'NBFI')


--output3
set @DCB = (
		Select sum ([value]) as 'Due from BSP'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Due from BSP')
		and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)

--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Due from BSP', @DCB, @TIME_CODE,'NBFI')


--output4
set @DFB = (
		Select sum ([value]) as 'Due from Banks'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Due from Banks')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)
 

--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Due from Banks', @DFB, @TIME_CODE,'NBFI')

--output5
set @LD = (
		Select sum ([value]) as 'Loans and Discounts'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Loans and Discounts')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)

--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Loans and Discounts', @LD, @TIME_CODE,'NBFI')

--output6
set @INV = (
		Select sum ([value]) as 'Investments in Bonds and Securities'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Investments in Bonds and Securities')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)

--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Investments in Bonds and Securities', @INV, @TIME_CODE,'NBFI')

--output7 
Set @BHFF = (
		Select sum ([value]) as 'Real Property, Furniture, Fixture, and Equipment'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Real Property, Furniture, Fixture, and Equipment')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULARR
		)


--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Real Property, Furniture, Fixture, and Equipment', @BHFF, @TIME_CODE,'NBFI')

--output8 

Set @ROPOA = (
		Select sum ([value]) as 'Real and Other Properties Owned or Acquired'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Real and Other Properties Owned or Acquired')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)

--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Real and Other Properties Owned or Acquired', @ROPOA, @TIME_CODE,'NBFI')


--output9 
set @OA = (
		Select sum ([value]) as 'Other Assets'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Other Assets')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)

--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Other Assets', @OA, @TIME_CODE,'NBFI')

--output10 
set @BP = (
		Select sum ([value]) as 'Bills Payable'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Bills Payable')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)

insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Bills Payable', @BP, @TIME_CODE,'NBFI')

--output11 
set @OL = (
		Select sum ([value]) as 'Other Liabilities'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Other Liabilities')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)

--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Other Liabilities', @OL, @TIME_CODE,'NBFI')

--output12
Set @CS = (
		Select sum ([value]) as 'Capital Stock'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Capital Stock') 
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)

--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
Values ('Capital Stock', @CS, @TIME_CODE,'NBFI')

--output13 
Set @SRUP = (
		Select sum ([value]) as 'Surplus, Reserves and Undivided Profits'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Surplus, Reserves and Undivided Profits')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)


		--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Surplus, Reserves and Undivided Profits', @SRUP, @TIME_CODE,'NBFI')

		--Output14 (Total)
Set @TA = (
		Select sum ([value]) as 'Total Assets'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Total Assets')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)


		--INSERT
		insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Assets', @TA, @TIME_CODE,'NBFI')


		--Output15 (Total)
Set @TL = (
		Select sum ([value]) as 'Total Liabilities'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Total Liabilities')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)


		--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Liabilities', @TL, @TIME_CODE,'NBFI')

		--Output16 (total)
Set @TNW = (
		Select sum ([value]) as 'Total Net Worth'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Total Net Worth')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULARR
		)


		--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Net Worth', @TNW, @TIME_CODE,'NBFI')

		--Output17 (total)
Set @TLNW = (
		Select sum ([value]) as 'Total Liabilities and Net Worth'  from [S_Fact_MFSG_NBFIs]  
		where PARTICULAR in ('Total Liabilities and Net Worth')
		 and NBFIsReport in ('Tab 2.2','Tab 2.4') 
		group by Time_Code ,PARTICULAR
		--group by PARTICULAR
		)
		--INSERT
insert into #TempStore (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Liabilities and Net Worth', @TLNW, @TIME_CODE,'NBFI')

--select * from #TempStore

--drop table #TempStore

-------------INSERTING to Staging ALL table------------------

--insert into [EDW_Staging].[dbo].[S_Fact_MFSG_NBFIs_STG_ALL] ([Particular],[Value],[NBFIsReport],[Time_Code])
--(Select Particular,AMOUNT,ReportName,Time_Code from #TempStoreNBwQB_CSOC )


-------------------------------------Insert in Stg Fact NBFIs--------------------------------

insert into [EDW_Staging].[dbo].S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
(Select Particular,AMOUNT,Time_Code,'Tab 2.1' from #TempStore) 