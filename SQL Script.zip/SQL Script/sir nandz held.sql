INSERT INTO [dbo].[SSIS_Properties]
           ([FolderPath]
           ,[ErrorPath]
           ,[DestinationPath]
           ,[LogPath]
           ,[TableName]
           ,[FileName]
           ,[StartReadingFromRow]
           ,[StartColumn]
           ,[EndColumn]
           ,[EndColumnCount]
           ,[SheetNametoLoad]
           ,[SchemaName]
		   ,[Group]
		   ,[Active]
		   ,[ReportName]
		   ,[LoaderToUse])
     VALUES
           ('C:\SSIS\OFCS\Input'
           ,'C:\SSIS\OFCS\Error'
           ,'C:\SSIS\OFCS\Processed'
           ,'C:\SSIS\OFCS\Logs'
           ,'Dump_MFSG_OFCS_SST_GCG' --table name
           ,'Bridgetable' -- file name
           ,'1' -- start row
           ,'A' -- start col
           ,'N' --end col
           ,'50' --number of row
           ,'GCG' --sheet name
           ,'dbo'
		   ,'MSD2'
		   ,1
		   ,'OFCS'
		   ,1)
		   
		 --  select * from [dbo].[Dump_ESLIG_Capita_Food_Threshold]
		 --  select * from [dbo].[Dump_ESLIG_Capita_Poverty_Threshold]
		 --  select * from [dbo].[Dump_ESLIG_Poverty_Incidence]

		   select * from [dbo].[SSIS_Properties]  where  ReportName = 'OFCS'
		   order by id desc

		

		 --update [SSIS_Properties] set SheetNametoLoad = 'tab7' where [FileName] = '01 input 1D Tab7 1st Semester Poverty Incidence'