-------------------------------------------------------------------1
Select * into #tempTable1 from (
		   Select 
		   case when [Column1] <> '' then [Column1] else '0' end Location,
		   case when [Column1] <> '' then [Column2] else '0' end 'Value_1',
		   '2018' as year

		   from [dbo].[Dump_ESLIG_Capita_Food_Threshold] where [Column1] <>'' and [Column2] <> '' 
	
union all
		   Select 
		   case when [Column1] <> '' then [Column1] else '0' end Location,
		   case when [Column1] <> '' then [Column3] else '0' end 'Value_1',
		   '2021' as year
		   from [dbo].[Dump_ESLIG_Capita_Food_Threshold] where [Column1] <>'' and [Column2] <> ''
		   ) as temp
		   
Select * from #tempTable1 
---------------------------------------------------------------------2
select * into  #tempTable2 from (Select replace(replace(replace(replace(location, ' a/b/', ''), ' b/', ''), ' a/', ''),'*','') as N_Location
,Value_1 , [year]
from #tempTable1 where Value_1 <> '' and Location != 'Region/Province') as temp2

select * from #tempTable2
--------------------------------------------------------------------