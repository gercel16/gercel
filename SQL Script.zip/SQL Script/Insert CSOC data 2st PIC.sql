  --Select * from  [Dump_MFSG_NBFIs_AssetLiabilties_PIC] 
  --where ID= 1

--Consolidated Balance Sheet of Life  Insurers, 2019 (in billion pesos)

--LIFE
--(select SUBSTRING((Select column1 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),47,4))  

  Select 
	CASE When Column1 <> '' then Column1 end 'PARTICULAR',
	REC = '',
	'AMOUNT' =  
			CASE 
			WHEN [Column4] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column4]) = 1 THEN [Column4]    
			
		ELSE '0.0' 
		end 	
	,
	(select SUBSTRING((Select column1 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),47,4)) as YEAR,
	(select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2),26,3))  AS MONTH,
	'LIFE' as CSOC_REPORT,
	Time_code = (Select top 1 Time_Idx from [EDW].[dbo].[Dim_Time] 
	where year like (
	select SUBSTRING((Select column1 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),47,4))
	)

FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
where [column1] <> ''  and [Column4] <> ''
 order by ID OFFSET 1 ROWS


--Consolidated Balance Sheet of Non-life Companies and Professional Reinsurer, 2019 (in billion pesos)
--NON-LIFE 


  Select
	CASE When Column6 <> '' then Column6 end 'PARTICULAR',
	REC = '',
	'AMOUNT' =  
			CASE 
			WHEN [Column12] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column12]) = 1 THEN [Column4]    
			
		ELSE '0.0' 
		end 
	,
	(select SUBSTRING((Select column6 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),78,4)) as YEAR,
	(select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2),26,3))  AS MONTH,
	'NON-LIFE' as CSOC_REPORT,
	Time_code = (Select top 1 Time_Idx from [EDW].[dbo].[Dim_Time] 
	where year like (
	select SUBSTRING((Select column6 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),78,4))
	)

FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
where [column6] <> ''  and [Column12] <> ''


--	(select SUBSTRING((Select column6 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),78,4)) as YEAR,