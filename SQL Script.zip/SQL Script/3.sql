	
	SELECT	 A.Time_idx
			,C.Particular_Type
			,A.Amount
			,E.PFSParticularName
			--SUM(A.[AMOUNT])
	FROM [dbo].[S_Fact_MFSG_NBFI] A
	JOIN EDW.[dbo].[Dim_NBFIBankKind] B
	ON A.BankIndustry_idx = B.NBFIBankKind_Idx
	join EDW.[dbo].[Dim_NBFIParticular] C
	ON A.NBFIParticular_Idx = C.NBFIParticular_Idx
	Join [Test].[dbo].[PFSParticular] E
	ON B.NBFIBankKind_Name = E.PFSParticularDesc
	where pfsparticularname = 'Non-Stock Savings and Loan Associations'
	and C.Particular_Type = 'Assets'
	and Time_idx like '2021%'

	select * from [S_Fact_MFSG_NBFI]
	where  Time_idx like '2021%'
	and BankIndustry_idx = 15
	and Particular_Type = 'Assets'


---------CHECKING  NBFIs---------------------------------
	SELECT	
			--A.Time_idx
			--,C.Particular_Type
			--,A.Amount
			--,E.PFSParticularName
			--,[NBFIBankKind_Name]
			SUM(A.[AMOUNT]),
			NBFIBankKind_Name
	FROM [dbo].[S_Fact_MFSG_NBFI] A
	JOIN EDW.[dbo].[Dim_NBFIBankKind] B
	ON A.BankIndustry_idx = B.NBFIBankKind_Idx
	join EDW.[dbo].[Dim_NBFIParticular] C
	ON A.NBFIParticular_Idx = C.NBFIParticular_Idx
	Join [Test].[dbo].[PFSParticular] E
	ON B.NBFIBankKind_Name = E.PFSParticularDesc
	where pfsparticularname = 'Private Insurance Companies'
	and c.Particular_Type = 'Net Worth'
	group by NBFIBankKind_Name
	--and Time_idx like '2021%'

---------------CHECKING CB-----------------------------
Select	
		--B.TIME_IDX
--		,A.[GROUP_TYPE]
--		,CONVERT(DECIMAL(18,2), REPLACE(A.[values], ',', '')) AMOUNT
--		,A.[PFS_TYPE]
		SUM(A.[VALUES])
		,A.PFS_TYPE
		,a.GROUP_TYPE
--INTO #TempStorageFPS
from [dbo].[Dump_MFSG_STATBUL_FPS_BSPAL_Temp] A
JOIN EDW.[dbo].[Dim_Time_1] B
ON A.[DATE] = B.Date_Code
where b.TIME_IDX like '2021%'
group by a.PFS_TYPE, a.GROUP_TYPE



SELECT	
		--	A.Time_Idx
		--,B.BankParticularAccount_Type
		--,A.[Value]
		----,C.IndustryGroup
		--,D.PFSParticularName
		SUM(A.[VALUE]),
		D.PFSParticularName,
		B.BankParticularAccount_Type
FROM [dbo].[S_Fact_MFSG_STATBUL_BANKSBALANCESHEET] A
JOIN EDW.[dbo].[Dim_STATBUL_BanksParticularAccount] B
ON a.BankParticularAccount_Idx = b.BankParticularAccount_Idx
JOIN EDW.[dbo].[Dim_STATBUL_Industry] C
ON A.Industry_idx = C.Industry_Idx
JOIN [Test].[dbo].[PFSParticular] D
ON C.IndustryGroup = D.PFSParticularDesc
where a.TIME_IDX like '2021%'
group by D.PFSParticularName,B.BankParticularAccount_Type
order by B.BankParticularAccount_Type asc
