
select * from [Dump_ESLIG_POVERTY_Capita_Food_Threshold]

--------------------------------------------------------------------------

				DECLARE @CFYr1 varchar(50)
				DECLARE @CFYr2 varchar(50)
				DECLARE @CFYr3 varchar(50)
				DECLARE @CFYr1_S varchar(50)
				DECLARE @CFYr2_S varchar(50)
				DECLARE @CFYr3_S varchar(50)
				
				set @CFYr1 = (Select top 1 [Column2] from [Dump_ESLIG_POVERTY_Capita_Food_Threshold] where Column2 like '20%')
				set @CFYr2 = (Select top 1 [Column3] from [Dump_ESLIG_POVERTY_Capita_Food_Threshold] where Column3 like '20%')
				set @CFYr3 = (Select top 1 [Column4] from [Dump_ESLIG_POVERTY_Capita_Food_Threshold] where Column4 like '20%')

				--select @Yr1,@Yr2,@Yr3

				set @CFYr1_S = (select SUBSTRING(@CFYr1,1,4)  AS substringDate);
				set @CFYr2_S = (select SUBSTRING(@CFYr2,1,4)  AS substringDate);
				set @CFYr3_S = (select SUBSTRING(@CFYr3,1,4)  AS substringDate);
	
					   Select 
					   case when [Column1] <> '' then [Column1] else '0' end Location,
					   case when [Column1] <> '' then [Column2] else '0' end 'Value_1'
					   ,@CFYr1_S as Year
			into #tempTable1
					   from [dbo].[Dump_ESLIG_POVERTY_Capita_Food_Threshold] 
					   where [Column1] <>'' and [Column2] <> ''  and [Column1] != 'Region/Province' 

				union all
					   Select 
					   case when [Column1] <> '' then [Column1] else '0' end Location,
					   case when [Column1] <> '' then [Column3] else '0' end 'Value_1',
					   @CFYr2_S as Year
					   from [dbo].[Dump_ESLIG_POVERTY_Capita_Food_Threshold] 
					   where [Column1] <>'' and [Column2] <> '' and [Column1] != 'Region/Province' 
					   --) as temp
				union all
						Select 
					   case when [Column1] <> '' then [Column1] else '0' end Location,
					   case when [Column1] <> '' then [Column4] else '0' end 'Value_1'
					   ,@CFYr3_S as Year
					   from [dbo].[Dump_ESLIG_POVERTY_Capita_Food_Threshold] 
					   where [Column1] <>'' and [Column2] <> '' and [Column1] != 'Region/Province' 
	
	
-----------------------------
					--select * into  #tempTable2 from (
					Select replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(location, ' a/b/', '')
							, ' b/', ''), ' a/', ''),'*',''),' 1/, 2/',''),', c/',''),' 2/,, d/',''),' 2/,',''),', d/',''),' 1/,',''),' 1/',''),'  c/',''),',,',''),',','') as N_Location
						,(select replace(Value_1, ',','.')) as value
						, [YEAR]
						, 'PovertyReport' = 'Capita Food Threshold'
					--into  #tempTableCFT
					from #tempTable1 where Value_1 <> '' and Location != 'Region/Province'
					--) as temp2

	--------------------------------

--------------------------------------------------------------
---- Capita Poverty Threshold
--------------------------------------------------------------

			--BEGIN		
				DECLARE @CPYr1 varchar(50)
				DECLARE @CPYr2 varchar(50)
				DECLARE @CPYr3 varchar(50)
				DECLARE @CPYr1_S varchar(50)
				DECLARE @CPYr2_S varchar(50)
				DECLARE @CPYr3_S varchar(50)

				set @CPYr1 = (Select top 1 [Column2] from [Dump_ESLIG_POVERTY_Capita_Poverty_Threshold] where Column2 like '20%')
				set @CPYr2 = (Select top 1 [Column3] from [Dump_ESLIG_POVERTY_Capita_Poverty_Threshold] where Column3 like '20%')
				set @CPYr3 = (Select top 1 [Column4] from [Dump_ESLIG_POVERTY_Capita_Poverty_Threshold] where Column4 like '20%')
				 
				 
				set @CPYr1_S = (select SUBSTRING(@CPYr1,1,4)  AS substringDate);
				set @CPYr2_S = (select SUBSTRING(@CPYr2,1,4)  AS substringDate);
				set @CPYr3_S = (select SUBSTRING(@CPYr3,1,4)  AS substringDate);

				--select @CPYr1_S,@CPYr2_S,@CPYr3_S
						
					   Select 
					   case when [Column1] <> '' then [Column1] else '0' end Location,
					   case when [Column1] <> '' then [Column2] else '0' end 'Value_1',
					   @CPYr1_S as Year
			  into #tempTable3
					   from [dbo].[Dump_ESLIG_POVERTY_Capita_Poverty_Threshold] 
					   where [Column1] <>'' and [Column2] <> ''  and [Column1] != 'Region/Province' 
		
				union all
					   Select 
					   case when [Column1] <> '' then [Column1] else '0' end Location,
					   case when [Column1] <> '' then [Column3] else '0' end 'Value_1',
					   @CPYr2_S as Year
					   from [dbo].[Dump_ESLIG_POVERTY_Capita_Poverty_Threshold] 
					   where [Column1] <>'' and [Column2] <> '' and [Column1] != 'Region/Province' 
					   --) as temp						   
				union all
					   Select 
					   case when [Column1] <> '' then [Column1] else '0' end Location,
					   case when [Column1] <> '' then [Column4] else '0' end 'Value_1',
					   @CPYr2_S as Year
					   from [dbo].[Dump_ESLIG_POVERTY_Capita_Poverty_Threshold] 
					   where [Column1] <>'' and [Column2] <> '' and [Column1] != 'Region/Province' 
					   --) as temp	

	-----------------------------
	
					Select replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(location, ' a/b/', '')
							, ' b/', ''), ' a/', ''),'*',''),' 1/, 2/',''),', c/',''),' 2/,, d/',''),' 2/,',''),', d/',''),' 1/,',''),' 1/',''),'  c/',''),',,',''),',',''),' 2/','') as N_Location
						,(select replace(Value_1, ',','.')) as value
						, [YEAR]
						, 'PovertyReport' = 'Capita Poverty Threshold'
					--into  #tempTableCPT
					from #tempTable3 where Value_1 <> '' and Location != 'Region/Province'
	
	----------------------------
--------------------------------------------------------------
---- Poverty Incidence Percent
--------------------------------------------------------------
select * from [Dump_ESLIG_POVERTY_Poverty_Incidence]

			--BEGIN	
				DECLARE @PIYr1 varchar(50)
				DECLARE @PIYr2 varchar(50)
				DECLARE @PIYr3 varchar(50)
				DECLARE @PIYr1_S varchar(50)
				DECLARE @PIYr2_S varchar(50)
				DECLARE @PIYr3_S varchar(50)

				set @PIYr1 = (Select top 1 [Column2] from [Dump_ESLIG_POVERTY_Poverty_Incidence] where Column2 like '20%')
				set @PIYr2 = (Select top 1 [Column3] from [Dump_ESLIG_POVERTY_Poverty_Incidence] where Column3 like '20%')
				set @PIYr3 = (Select top 1 [Column4] from [Dump_ESLIG_POVERTY_Poverty_Incidence] where Column4 like '20%')
				 
				 
				set @PIYr1_S = (select SUBSTRING(@PIYr1,1,4)  AS substringDate);
				set @PIYr2_S = (select SUBSTRING(@PIYr2,1,4)  AS substringDate);
				set @PIYr3_S = (select SUBSTRING(@PIYr3,1,4)  AS substringDate);	


							   Select 
							   case when [Column1] <> '' then [Column1] else '0' end Location,
							   case when [Column1] <> '' then [Column5] else '0' end 'Value_1',
							   @PIYr1_S as Year
							   into #tempTable5
							   from [dbo].[Dump_ESLIG_POVERTY_Poverty_Incidence] where [Column1] <>'' and [Column4] <> ''  and [Column1] != 'Major Island Group' 
						
					union all
							   Select 
							   case when [Column1] <> '' then [Column1] else '0' end Location,
							   case when [Column1] <> '' then [Column6] else '0' end 'Value_1',
							   @PIYr2_S as Year
							   from [dbo].[Dump_ESLIG_POVERTY_Poverty_Incidence] where [Column1] <>'' and [Column4] <> '' and [Column1] != 'Major Island Group' 
					
					union all
							   Select 
							   case when [Column1] <> '' then [Column1] else '0' end Location,
							   case when [Column1] <> '' then [Column7] else '0' end 'Value_1',
							   @PIYr2_S as Year
							   from [dbo].[Dump_ESLIG_POVERTY_Poverty_Incidence] where [Column1] <>'' and [Column4] <> '' and [Column1] != 'Major Island Group' 
			


	-----------------------------
					--select * into  #tempTable6 from (
					Select replace(replace(replace(replace(location, ' a/b/', ''), ' b/', ''), ' a/', ''),'*','') as N_Location
						,(select replace(Value_1, ',','.')) as value
						, [year]
						, 'PovertyReport' = 'Poverty Incidence Percent'
					--into  #tempTablePIP
					from #tempTable5 where Value_1 <> '' and Location != 'Region/Province'
					--) as temp2
	----------------------------
					--insert into #TempTableF (Province_Code,Time_Code,PovertyIncidenceinPercent)
					--Select N_Location,[YEAR],[value]
					--From #tempTable6
-----------------------------------
 -- union all the report

 Select * 
 into #PovertyIndicator
 from #tempTableCFT
 union all
 Select * 
 from  #tempTableCPT
 union all
 Select * 
 from #tempTablePIP


--------------------------------------
--JOINING DIMENSION------------------
--PROVINCE--
 select A.N_Location
		,A.[value]
		,Time_idx = A.Year + '-01-01'
		,A.PovertyReport

		,B.Province_Idx
INTO #PovertyIndicator2
from #PovertyIndicator A
 left join [DES].[dbo].[Dim_Location_Province] B
 ON A.N_Location = [Province_Name]

-- -- TIME IDX AND POVERTY INDICATOR

select A.N_Location
		,A.[value]	
		,B.Time_idx		
		,A.PovertyReport
		,A.Province_Idx 
		,[PovertyCode_Idx]
INTO #PovertyIndicator3
from #PovertyIndicator2 A
JOIN [DES].[dbo].[Dim_Time] B
ON A.Time_idx = B.Date_Code
JOIN [DES].[dbo].[Dim_ESLIG_PovertyIndicator] C
ON  A.PovertyReport = C.[PovertyCode]

-----------
--TRANFER DATA INTO SCRUB--------

INSERT INTO DES_Staging.[dbo].[S_Fact_ESLIG_Poverty] 
		(
		[Province_Name],
		[Values],
		[Time_Code],
		[ReportName],
		[Province_Code],
		[PovertyCode_Idx]
		)
SELECT 
		N_Location,
		[value],
		Time_idx,
		PovertyReport,
		Province_Idx ,
		[PovertyCode_Idx]
FROM #PovertyIndicator3 

END
