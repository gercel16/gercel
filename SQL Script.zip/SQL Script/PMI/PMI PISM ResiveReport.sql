
select * into #temptable from (
Select ID, [Month]
		,'DATE' = (SELECT LEFT([Month],3) AS [Month] )
		,'SYEAR' = (Select RIGHT([Month],2) as [YEAR] )
		,[Manufacturing], [RetailsWholeSales], [Services], [composite]
		,'PMI Report' = 'PMI Raw Data Series'
	from [dbo].[Dump_ESLIG_PMI_PISM_RevisedReportRawDataSeries]

	union all

Select ID, [Month]
		,'DATE' = (SELECT LEFT([Month],3) AS [Month] )
		,'SYEAR' = (Select RIGHT([Month],2) as [YEAR] )
		,[Manufacturing], [RetailsWholeSales], [Services], [composite]
		,'PMI Report' = 'PMI Seasonally AdjustedData Set'
	from [dbo].[Dump_ESLIG_PMI_PISM_RevisedSeasonallyAdjustedData]
	) as Temp


select * from #temptable

Select * into #Dim_Time from (
SELECT RIGHT(Year,2) as [SYEAR] , *
FROM [EDW].[dbo].[Dim_Time]) as DimTime


Select T1.[Month], T2.Time_Idx, T1.Manufacturing,T1.RetailsWholeSales, T1.[Services] , T1.Composite, T1.[PMI Report] from #temptable T1
inner join
#Dim_Time T2
on T1.DATE = T2.MonthShortName and T1.SYEAR = T2.SYEAR 
where T2.DayofMonth = 1
order by T1.[PMI Report], T2.Time_Idx asc