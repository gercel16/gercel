Select * from [dbo].[Dump_ESLIG_PMI_PISM_FlashReport]

----------------1st Insert trim date in temp table to get month and year----------------
Select * into #TempPMIFlasReport from (
SELECT  LEFT([date],3) AS [Month] , RIGHT([date],4) as [YEAR] ,*
FROM [Dump_ESLIG_PMI_PISM_FlashReport]) as FR


--------------------2nd join the created temp table to  Dim time-------------------------
select * into #tempCHCK from (
Select T1.ID, T2.Time_Idx,T1.Sector,T1.IndexValues,T1.Direction,T1.RateofChange from #TempPMIFlasReport T1 
inner join
[EDW].[dbo].[Dim_Time] T2
on T1.Month = T2.MonthShortName and T1.YEAR = T2.Year
where T2.DayofMonth = 1
--order by T2.Time_Idx asc
) as test
----------------------------------------------------------------------------------------------
--Select * from [EDW].[dbo].[Dim_Time]


--select * from #TempPMIFlasReport

select * from #tempCHCK

Select ID,Time_Idx,Direction, RateofChange
	,MAX(CASE When ([Sector] = 'composite') then [IndexValues] else null end) as 'composite'
	,MAX(CASE When ([Sector] = 'manufacturing') then [IndexValues] else null end) as 'manufacturing'
	,MAX(CASE When ([Sector] = 'retail/wholesale') then [IndexValues] else null end) as 'retail/wholesale'
	,MAX(CASE When ([Sector] = 'services') then [IndexValues] else null end) as 'services'
	from #tempCHCK
	where Sector != ''
	group by Time_Idx,ID,Direction, RateofChange

	select * from [dbo].[S_Fact_ESLIG_PMI]