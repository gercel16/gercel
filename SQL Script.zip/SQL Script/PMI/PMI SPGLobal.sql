
truncate table[dbo].[S_Fact_ESLIG_PMI_SPGLobal]

select * into #TempTableSPGLobal from (
Select ID, [DATE]
		,'MONTH' = (SELECT LEFT([DATE],3) AS [Month] )
		,'SYEAR' = (Select RIGHT([DATE],4) as [YEAR] )
		,[Value]
		from [dbo].[Dump_ESLIG_PMI_SP_Global_Phi_Manufacturing]
		) as SPGLobal
	
-----------------------------------------------------------------------------------
--converting the date. ----

Select * into #TempSPG from (
Select T2.Time_Idx,T1.MONTH,T1.SYEAR, T1.[Value] from #TempTableSPGLobal T1
inner join 
[EDW].[dbo].Dim_Time T2
on T1.MONTH = t2.MonthShortName and T1.SYEAR = T2.Year
where  T2.DayofMonth = 1
) as SPG


insert into [dbo].[S_Fact_ESLIG_PMI_SPGLobal] ([Value],[Time_Idx])
select CONVERT(DECIMAL(18,2), REPLACE([Value], '', '')) [Value], [Time_Idx]
from #TempSPG











