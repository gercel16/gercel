

Select * from [dbo].[Dump_ESLIG_PMI_PISM_BSP_Overall_DataSeries]

Select  * into  #TempTableOverall from (
	Select ID,Column2,
		'DATE' = (SELECT LEFT(column2,3) AS [Month] )
		,'SYEAR' = (Select RIGHT(column2,2) as [YEAR] )
		,Case when column2 <> '' then column3 end 'Manufacturing'
		,case when column4 <> '' then column4 end 'RetailWholeSale'
		,case when column5 <> '' then column5 end 'Services'
		,case when column6 <> '' then column6 end 'Composite'
		,'PMI Report' = 'PMI Raw Data Series'

		from [dbo].[Dump_ESLIG_PMI_PISM_BSP_Overall_DataSeries]
		--order by ID OFFSET 2 ROWS
		
union all

Select ID,Column2,
		'DATE' = (SELECT LEFT(column2,3) AS [Month] )
		,'SYEAR' = (Select RIGHT(column2,2) as [YEAR] )
		,Case when column8 <> '' then column8 end 'Manufacturing'
		,case when column9 <> '' then column9 end 'RetailWholeSale'
		,case when column10 <> '' then column10 end 'Services'
		,case when column11 <> '' then column11 end 'Composite'
		,'PMI Report' = 'PMI Seasonally-Adjusted Data Series'

		from [dbo].[Dump_ESLIG_PMI_PISM_BSP_Overall_DataSeries]
		order by ID OFFSET 4 ROWS
		) as overall
	 
	 --drop table #TempTableOverall
-----------2nd get reference for the date value from time dimension---------
Select * into #Dim_Time from (
SELECT RIGHT(Year,2) as [SYEAR] , *
FROM [EDW].[dbo].[Dim_Time]) as DimTime
----------------------------------------------------------------------------

---------------3rd get the time Idx and join to the data table to get the value date-------------------
Select * into #TempTest from (
Select  T2.Month ,T2.Time_Idx ,T1.Manufacturing, T1.RetailWholeSale, T1.[Services], T1.Composite,T1.[PMI Report]
from #TempTableOverall T1 
inner join
#Dim_Time T2
on T1.DATE = T2.MonthShortName and T1.SYEAR = T2.SYEAR
where T2.DayofMonth = 1
--order by T1.[PMI Report], T2.Time_Idx asc
) as temp

select * from #TempTest
drop table #TempTest

----------------------------------------------------------------------------------------------------------

insert into [dbo].[S_Fact_ESLIG_PMI] ( [Manufacturing],[RetailWholesale],[Services],[Composite],[Time_Code])   

Select   CONVERT(DECIMAL(18,2), REPLACE(Manufacturing, '', '')) manufacturing ,  CONVERT(DECIMAL(18,2), REPLACE(RetailWholeSale, '', '')) RetailWholeSale
		,CONVERT(DECIMAL(18,2), REPLACE([Services], '', '')) [Services], CONVERT(DECIMAL(18,2), REPLACE(Composite, '', '')) composite, Time_Idx
--Select T1.Manufacturing, T1.RetailWholeSale, T1.[Services], T1.Composite,T2.Time_Idx
--Select   CONVERT(DECIMAL(18,2), REPLACE(Manufacturing, '', '')) manufacturing ,  Time_Idx
from #TempTest 

select ISNUMERIC(RetailWholeSale)  From #TempTest 


----------------------------------------------------------------------------------------------------------

select * into #TempTableSPGLobal from (
Select ID, [DATE]
		,'MONTH' = (SELECT LEFT([DATE],3) AS [Month] )
		,'SYEAR' = (Select RIGHT([DATE],4) as [YEAR] )
		,[Value]
		from [dbo].[Dump_ESLIG_PMI_SP_Global_Phi_Manufacturing]
		) as SPGLobal

	
--Select * from #TempTableSPGLobal
--Select * from [EDW].[dbo].Dim_Time

Select * into #TempSPG from (
Select T2.Time_Idx,T1.MONTH,T1.SYEAR, T1.[Value] from #TempTableSPGLobal T1
inner join 
[EDW].[dbo].Dim_Time T2
on T1.MONTH = t2.MonthShortName and T1.SYEAR = T2.Year
where  T2.DayofMonth = 1
) as SPG












