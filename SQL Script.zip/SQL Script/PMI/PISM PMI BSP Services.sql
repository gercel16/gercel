
Select * from [dbo].[Dump_ESLIG_PMI_PISM_BSP_Services_DataSeries]

Select * into #tempTableService from (
Select ID,Column2
	,'DATE' = (SELECT LEFT(column2,3) AS [Month] )
	,'SYEAR' = (Select RIGHT(column2,2) as [YEAR] )
	,case when column2 <> '' then column3 end 'ServicesOverall'
	,case when column2 <> '' then column4 end 'BusinessActivity'
	,case when column2 <> '' then column5 end 'NewOrders'
	,case when column2 <> '' then column6 end 'OutstandingBusiness'
	,case when column2 <> '' then column7 end 'PriceCharge'
	,case when column2 <> '' then column8 end 'AverageOperatingCosts'
	,case when column2 <> '' then column9 end 'Employment'
	,'PMI Report' = 'PMI Services Raw Data Series'

	from [dbo].[Dump_ESLIG_PMI_PISM_BSP_Services_DataSeries]
	--order by ID OFFSET 2 ROWS

	union all

Select ID,column2
	,'DATE' = (SELECT LEFT(column2,3) AS [Month] )
	,'SYEAR' = (Select RIGHT(column2,2) as [YEAR] )
	,case when column2 <> '' then column11 end 'ServicesOverall'
	,case when column2 <> '' then column12 end 'BusinessActivity'
	,case when column2 <> '' then column13 end 'NewOrders'
	,case when column2 <> '' then column14 end 'OutstandingBusiness'
	,case when column2 <> '' then column15 end 'PriceCharge'
	,case when column2 <> '' then column16 end 'AverageOperatingCosts'
	,case when column2 <> '' then column17 end 'Employment'
	,'PMI Report' = 'PMI Services Seasonally-Adjusted Data Series'


	from [dbo].[Dump_ESLIG_PMI_PISM_BSP_Services_DataSeries]
	order by ID OFFSET 2 ROWS
	) as Serv


	select * from #tempTableService
-----------2nd get reference for the date value from time dimension---------
Select * into #Dim_Time from (
SELECT RIGHT(Year,2) as [SYEAR] , *
FROM [EDW].[dbo].[Dim_Time]) as DimTime
----------------------------------------------------------------------------

---------------3rd get the time Idx and join to the data table to get the value date-------------------
Select  T2.Month ,T2.Time_Idx ,T1.[ServicesOverall], T1.[BusinessActivity], T1.NewOrders, T1.Employment, T1.[OutstandingBusiness], T1.PriceCharge,
T1.[AverageOperatingCosts], T1.[Employment],T1.[PMI Report]
from #tempTableService T1 
inner join
#Dim_Time T2
on T1.DATE = T2.MonthShortName and T1.SYEAR = T2.SYEAR
where T2.DayofMonth = 1
order by T1.[PMI Report], T2.Time_Idx asc	
----------------------------------------------------------------------------------------------------------






