

------------1st Get the Value and Date reference---------------
select * into #TempPMIManufacturing from (
Select ID,Column2,
		'DATE' = (SELECT LEFT(column2,3) AS [Month] )
		,'SYEAR' = (Select RIGHT(column2,2) as [YEAR] )
		,Case when column3 <> '' then column3 end 'Manufacturing Overall'
		,case when column4 <> '' then column4 end 'New Orders'
		,case when column5 <> '' then column5 end 'Production'
		,case when column6 <> '' then column6 end 'Employment'
		,case when column7 <> '' then column7 end 'Supplier Deliveries'
		,case when column8 <> '' then column8 end 'Inventories'
		,case when column2 <> '' then column9 end 'Ave Price Charge'
		,case when column2 <> '' then column10 end 'Production Cost'
		,'PMI Report' = 'PISM PMI Manufacturing Raw Data Series'

		from  [dbo].[Dump_ESLIG_PMI_PISM_BSP_Manufacturing_DataSeries]
		where column2 <> ''
		--order by ID OFFSET 1 ROWS 
		) as manu
--------------------------------------------------------------------------------

-----------2nd get reference for the date value from time dimension---------
Select * into #Dim_Time from (
SELECT RIGHT(Year,2) as [SYEAR] , *
FROM [EDW].[dbo].[Dim_Time]) as DimTime
----------------------------------------------------------------------------

---------------3rd get the time Idx and join to the data table to get the value date-------------------
Select  T2.Month ,T2.Time_Idx ,T1.[Manufacturing Overall],T1.[New Orders], T1.Production, T1.Employment, T1.[Supplier Deliveries], T1.Inventories,
T1.[Ave Price Charge], T1.[Production Cost],T1.[PMI Report]
from #TempPMIManufacturing T1 
inner join
#Dim_Time T2
on T1.DATE = T2.MonthShortName and T1.SYEAR = T2.SYEAR
where T2.DayofMonth = 1
order by T2.Time_Idx asc	
----------------------------------------------------------------------------------------------------------

--Select * from #TempPMIManufacturing

--drop table #TempPMIManufacturing

Select * from [EDW].[dbo].[Dim_Time]

--select * from #Dim_Time
--select * from #TempPMIManufacturing
--SELECT count(column2) from #TempPMIManufacturing

Select * from #TempPMIManufacturing T1  
inner join 
[EDW].[dbo].[Dim_Time]  T2
on T1.DATE = T2.MonthShortName



SELECT  LEFT(column2,3) AS [Month] , RIGHT(column2,2) as [YEAR] 
FROM [Dump_ESLIG_PMI_PISM_BSP_Manufacturing_DataSeries]