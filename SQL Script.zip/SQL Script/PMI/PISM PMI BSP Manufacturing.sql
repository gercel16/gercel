Select * from [dbo].[Dump_ESLIG_PMI_PISM_BSP_Manufacturing_DataSeries]

select SUBSTRING((Select column2 from  [Dump_ESLIG_PMI_PISM_BSP_Manufacturing_DataSeries] where ID = 2),1,3)



select * into #TempTableManufacturing from (
	Select ID,Column2
		,'DATE' = (SELECT LEFT(column2,3) AS [Month] )
		,'SYEAR' = (Select RIGHT(column2,2) as [YEAR] )
		,Case when column3 <> '' then column3 end 'Manufacturing Overall'
		,case when column4 <> '' then column4 end 'New Orders'
		,case when column5 <> '' then column5 end 'Production'
		,case when column6 <> '' then column6 end 'Employment'
		,case when column7 <> '' then column7 end 'Supplier Deliveries'
		,case when column8 <> '' then column8 end 'Inventories'
		,case when column2 <> '' then column9 end 'Ave Price Charge'
		,case when column2 <> '' then column10 end 'Production Cost'
		,'PMI Report' = 'PISM PMI Manufacturing Raw Data Series'

		from  [dbo].[Dump_ESLIG_PMI_PISM_BSP_Manufacturing_DataSeries]
		where column2 <> ''
		--order by ID OFFSET 1 ROWS

Union all

	Select ID,Column2
		,'DATE' = (SELECT LEFT(column2,3) AS [Month] )
		,'SYEAR' = (Select RIGHT(column2,2) as [YEAR] )
		,Case when column12 <> '' then column12 end 'Manufacturing Overall'
		,case when column13 <> '' then column13 end 'New Orders'
		,case when column14 <> '' then column14 end 'Production'
		,case when column15 <> '' then column15 end 'Employment'
		,case when column16 <> '' then column16 end 'Supplier Deliveries'
		,case when column17 <> '' then column17 end 'Inventories'
		,case when column3 <> '' then column18 end 'Ave Price Charge'
		,case when column3 <> '' then column19 end 'Production Cost'
		,'PMI Report' = 'PMI Manufacturing Seasonally-Adjusted Data Series'

		from  [dbo].[Dump_ESLIG_PMI_PISM_BSP_Manufacturing_DataSeries]
		order by ID OFFSET 1 ROWS
		) as Manufacture

		select * from #TempTableManufacturing
		--drop table #TempTableManufacturing

-----------2nd get reference for the date value from time dimension---------
Select * into #Dim_Time from (
SELECT RIGHT(Year,2) as [SYEAR] , left([MonthName],3) as [SMONTH] ,*
FROM [EDW].[dbo].[Dim_Time]
) as DimTime


----------------------------------------------------------------------------

---------------3rd get the time Idx and join to the data table to get the value date-------------------
Select  T2.Month ,T2.Time_Idx ,T1.[Manufacturing Overall],T1.[New Orders], T1.Production, T1.Employment, T1.[Supplier Deliveries], T1.Inventories,
T1.[Ave Price Charge], T1.[Production Cost],T1.[PMI Report]
from #TempTableManufacturing T1 
inner join
#Dim_Time T2
on T1.DATE = T2.MonthShortName and T1.SYEAR = T2.SYEAR 
and T1.DATE = T2.SMONTH
where T2.DayofMonth = 1
and T1.[PMI Report] = 'PMI Manufacturing Seasonally-Adjusted Data Series'
order by T1.[PMI Report], T2.Time_Idx asc	

----------------------------------------------------------------------------------------------------------

insert into [dbo].[S_Fact_ESLIG_PMI] ( [Time_Code],[Manufacturing],[RetailWholesale],[Services],[Composite])
select 



