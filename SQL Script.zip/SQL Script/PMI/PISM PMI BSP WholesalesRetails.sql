Select * from [dbo].[Dump_ESLIG_PMI_PISM_BSP_RetailWholesales_DataSeries]

Select * into #tempWholeSales from (
	Select ID,column2
	,'DATE' = (SELECT LEFT(column2,3) AS [Month] )
	,'SYEAR' = (Select RIGHT(column2,2) as [YEAR] )
	,case when column2 <> '' then column3 end 'RetailWholeSalesOverall'
	,case when column2 <> '' then column4 end 'Purchases'
	,case when column2 <> '' then column5 end 'SalesRevenues'
	,case when column2 <> '' then column6 end 'Employment'
	,case when column2 <> '' then column7 end 'SupplierDeliveries'
	,case when column2 <> '' then column8 end 'Inventories'
	,case when column2 <> '' then column9 end 'PriceChange'
	,case when column2 <> '' then column10 end 'ProductionCost'
	,'PMI Report' = 'PMI Retail-Wholesale Raw Data Series'

	from [dbo].[Dump_ESLIG_PMI_PISM_BSP_RetailWholesales_DataSeries]
	--order by ID OFFSET 2 ROWS

	union all

Select ID,column2
	,'DATE' = (SELECT LEFT(column2,3) AS [Month] )
	,'SYEAR' = (Select RIGHT(column2,2) as [YEAR] )
	,case when column2 <> '' then Column12 end 'RetailWholeSalesOverall'
	,case when column2 <> '' then column13 end 'Purchases'
	,case when column2 <> '' then column14 end 'SalesRevenues'
	,case when column2 <> '' then column15 end 'Employment'
	,case when column2 <> '' then column16 end 'SupplierDeliveries'
	,case when column2 <> '' then column17 end 'Inventories'
	,case when column2 <> '' then column18 end 'PriceChange'
	,case when column2 <> '' then column19 end 'ProductionCost'
	,'PMI Report' = 'PMI Retail-Wholesale Seasonally-Adjusted Data Series'

	from [dbo].[Dump_ESLIG_PMI_PISM_BSP_RetailWholesales_DataSeries]
	order by ID OFFSET 2 ROWS
	) as Whols


-----------2nd get reference for the date value from time dimension---------
Select * into #Dim_Time from (
SELECT RIGHT(Year,2) as [SYEAR] , *
FROM [EDW].[dbo].[Dim_Time]) as DimTime

select * from #tempWholeSales
---------------3rd get the time Idx and join to the data table to get the value date-------------------
Select  T2.Month ,T2.Time_Idx ,T1.RetailWholeSalesOverall, T1.Purchases, T1.SalesRevenues, T1.SupplierDeliveries, T1.Inventories, T1.PriceChange,
T1.ProductionCost, T1.[PMI Report]
from #tempWholeSales T1 
inner join
#Dim_Time T2
on T1.DATE = T2.MonthShortName and T1.SYEAR = T2.SYEAR
where T2.DayofMonth = 1
order by T1.[PMI Report], T2.Time_Idx asc	


