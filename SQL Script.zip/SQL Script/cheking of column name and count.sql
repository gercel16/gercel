SELECT count(*) as No_of_Column FROM information_schema.columns 
WHERE table_name ='SelectedPerformanceIndicator';


SELECT *  FROM information_schema.columns 
WHERE table_name ='SelectedPerformanceIndicator';
