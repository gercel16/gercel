/****** Script for SelectTopNRows command from SSMS  ******/
SELECT *
  FROM [dbo].[Dim_NBFIParticular]

  select * 
  from [dbo].[Dim_NBFIBankKind]

  -------------  PFS  Government Non-Bank Financial Intermediaries ------------
  select * from [dbo].[Fact_MFSG_NBFI]
	where NBFIBankKind_Idx in  (16,20)


  select * from [dbo].[Fact_MFSG_NBFI]
	where NBFIBankKind_Idx in  (9,10,11,12,13,14)



	Select * from [dbo].[Fact_MFSG_NBFI]
	Select * from [dbo].[Fact_MFSG_STATBUL_TAB1_51_52_53_BS]



	Select * from [Fact_MFSG_NBFI] A
	Join [dbo].[Fact_MFSG_STATBUL_TAB1_51_52_53_BS] B
	on A.Time_idx = B.Time_idx




