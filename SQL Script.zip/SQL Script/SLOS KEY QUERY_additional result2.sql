-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_SCRUB_MFSG_SLOS_REMARKS 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here


-----------------------STEP 1---------------------------------------------------------------------
-- EXTRACT THE DATE REFERENCE FROM THE FILE AND GET THE DATA
		select 
		--ID
		--,ROW_NUMBER()over (order by ID) as [ROW] , 
		(SELECT SUBSTRING((SELECT ITEM FROM [vw_Dump_MFSG_SLOS_REMARKS] WHERE ID = 1),1,2)) AS 'QUARTER'
		,(SELECT SUBSTRING((SELECT ITEM FROM [vw_Dump_MFSG_SLOS_REMARKS] WHERE ID = 1),4,4)) AS 'YEAR'		
		,ITEM
		,SUB_ITEM
		,BANK_NAME
		,REMARKS
		into #TEMPTABLE
		from [dbo].[vw_Dump_MFSG_SLOS_REMARKS]
		WHERE BANK_NAME <> ''
		 order by ID OFFSET 1 ROWS

-----------------------STEP 2---------------------------------------------------------------------
-- FORMATING THE DATE TO BE ATTACHED ON THE  TIME DIMENSION

	SELECT [YEAR],
		[QUARTER],
		'TIME_CODE' = [YEAR] + '-' + [QUARTER],
		ITEM,
		SUB_ITEM,
		BANK_NAME,
		REMARKS
	INTO #TEMPTABLE1
	FROM #TEMPTABLE

-----------------------STEP 3---------------------------------------------------------------------
-- COMBINING THE TIME TO THE TIME DIMENSION
		SELECT B.Time_Idx,
		--A.YEAR, 
		--A.QUARTER,
			A.ITEM,
			A.SUB_ITEM,
			A.BANK_NAME,
			A.REMARKS
		INTO #TEMPREMARK
		FROM #QTEMPTABLE1 A
		JOIN (
			SELECT  -- GETTING ONLY LASTDAY OF QUARTER
				MAX(Time_Idx) Time_Idx,
				Quarter_Name
			FROM EDW.dbo.Dim_Time_1
			GROUP BY Quarter_Name
		)B
		ON A.TIME_CODE = B.Quarter_Name


-----------------------STEP 4---------------------------------------------------------------------
-- INSERTING DATA TO THE STAGING FACT TABLE

INSERT INTO [dbo].[S_Fact_MFSG_SLOS_REMARKS]
		([Time_idx],
		[ITEM_CODE],
		[SUB_ITEM],
		[BANK_NAME],
		[REMARK])

SELECT  Time_idx
		,ITEM
		,SUB_ITEM
		,BANK_NAME
		,REMARKS
FROM #TEMPREMARK 

END
GO
