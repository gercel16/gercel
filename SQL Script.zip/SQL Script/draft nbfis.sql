Select * from [dbo].[Dump_MFSG_NBFIs_FSRLIB2_NBFPF00] where BNKIND = 26

Select ID, [TRDATE], [BNKIND],
case when [TRDATE] <> '' then RECNO  end 'REC',
case when [TRDATE] <> '' then [desc] end 'Particular',
CONVERT(DECIMAL(18,2), REPLACE(AMT, ',', '')) AMOUNT

from [dbo].[Dump_MFSG_NBFIs_FSRLIB2_NBFPF00] where BNKIND = 22

	--(select RIGHT((Select [TRDATE] from  [Dump_MFSG_NBFIs_FSRLIB2_NBFPF00] where ID = 2), 4)) ,
	--(select SUBSTRING((Select [TRDATE] from  [Dump_MFSG_NBFIs_FSRLIB2_NBFPF00] where ID = 2),1,2))  
		
--select * from [EDW].[dbo].[Dim_Time] A.

Select * into #TempStorage from (
select ID,
	TRDATE,BNKIND,RECNO,
	CONVERT(DECIMAL(18,2), REPLACE(AMT, ',', '')) AMOUNT,
	'Particular' = [DESC],
	'TIME_IDX' = (select RIGHT((Select [TRDATE] from  [Dump_MFSG_NBFIs_FSRLIB2_NBFPF00] where ID = 2), 4)) + 
				(select SUBSTRING((Select [TRDATE] from  [Dump_MFSG_NBFIs_FSRLIB2_NBFPF00] where ID = 2),1,2)) + '01'
	from  [dbo].[Dump_MFSG_NBFIs_FSRLIB2_NBFPF00] ) as Temp




	--select ISNUMERIC(AMOUNT) from #TempStorage where AMOUNT = 0
	--	select ISNUMERIC(RECNO) from [Dump_MFSG_NBFIs_FSRLIB2_NBFPF00] where RECNO = 0

--select * from #TempStorage



	create  table #TempComp (
		[ID] [int] IDENTITY(1,1) NOT NULL
		, Particular nvarchar(210)
		, AMOUNT numeric(18,2)
		,Time_Code int,
		ReportName nvarchar (210))

	
	-------------------------------------------------------------------

	DECLARE @CASH numeric(18,2) -- CASH
	DECLARE @COCI numeric(18,2) -- Checks and other Cash Items
	DECLARE @DCB numeric(18,2) -- Due from BSP
	DECLARE @DFB numeric(18,2) -- Due from Banks
	DECLARE @LD numeric(18,2) -- Loans and Discounts
	DECLARE @INV numeric(18,2) -- Investments in Bonds and Securities
	DECLARE @BHFF numeric (18,2) -- Real Property, Furniture, Fixture, and Equipment
	DECLARE @ROPOA numeric (18,2) --Real and Other Properties Owned or Acquired
	DECLARE @OA numeric (18,2)  -- Other Assetts
	DECLARE @BP numeric(18,2) --Bills Payable'
	DECLARE @OL numeric(18,2) -- Other Liabilities
	DECLARE @CS numeric(18,2) --Capital Stock
	DECLARE @SRUP numeric(18,2) --Surplus, Reserves and Undivided Profits
	DECLARE @TA numeric(18,2) -- Total Assets
	DECLARE @TL numeric(18,2) -- Total Liabilities
	DECLARE @TNW numeric(18,2) -- Total Net WOrth
	DECLARE @TLNW numeric(18,2) -- Total Liabilities  and Net Worth
	DECLARE @TIME_CODE int -- TIMECODE

	--------------------------------------------------------------------

	Set @TIME_CODE = (Select top 1 tIME_IDX from #TempStorage )

	--select @TIME_CODE

	--Output 1
	set @CASH = (
		Select sum (AMOUNT)/1000 as 'CASH'  from   #TempStorage
		where Particular in ('1. Cash on Hand')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)

	--INSERT
	insert into #TempComp (Particular,AMOUNT, Time_Code,ReportName)
	Values ('CASH', @CASH, @TIME_CODE,'20')


	--Output 2
	set @COCI = (
		Select sum (AMOUNT)/1000 as 'Checks and other Cash Items'  from #TempStorage  
		where Particular in ('2. Checks and Cash items')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)

	--INSERT
	insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
	Values ('Checks and other Cash Items', @COCI, @TIME_CODE,'20')

	--Output 3
	set @DCB = (
		Select sum (AMOUNT)/1000 as 'Due from BSP'  from #TempStorage  
		where Particular in ('3. Due from BSP-Reserves')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)

	--INSERT
	insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
	Values ('Due from BSP', @COCI, @TIME_CODE,'20')
	

	--output4
	set @DFB = (
		Select sum (AMOUNT)/1000 as 'Due from Banks'  from #TempStorage  
		where Particular in ('4. Deposits in Banks')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)

	--INSERT
	insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
	Values ('Due from Banks', @DFB, @TIME_CODE,'20')

	--output5
	set @LD = (
			Select sum (AMOUNT)/1000 as 'Loans and Discounts'  from #TempStorage  
			where Particular in ('5. Loans / Receivables','6. Trading Account Securities-Loans')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)

	--INSERT
	insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
	Values ('Loans and Discounts', @LD, @TIME_CODE,'20')


	--output6
	set @INV = (
			Select sum (AMOUNT)/1000 as 'Investments in Bonds and Securities'  from #TempStorage  
			where PARTICULAR in ('8. Trading Account Securities-Investment','9. Trading Account Securities-Equity'
			,'10. Available For Sale Securities (ASS)','11. Investment in Bonds & Other Debt Ints'
			,'12. Equity Investment in Allied / Non-Allied')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)
		
	--INSERT
	insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
	Values ('Investments in Bonds and Securities', @INV, @TIME_CODE,'20')

	--output7 
	Set @BHFF = (
			Select sum (AMOUNT)/1000 as 'Real Property, Furniture, Fixture, and Equipment'  from #TempStorage  
			where PARTICULAR in ('16. Real Property, Furniture, Fixtures & Equipment')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)


	--INSERT
	insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
	Values ('Real Property, Furniture, Fixture, and Equipment', @BHFF, @TIME_CODE,'20')


	--output8 
create  table #TempVal (
[ID] [int] IDENTITY(1,1) NOT NULL,
Val1 numeric(18,2)
)

--update #tempTableFCwoQB_CSOC2 set Amount = 320 where  PARTICULAR in ('17. Real and Other Pro. Owned or Acquired')
--Value 1 
insert into #TempVal 
			Select sum (AMOUNT) as 'Val1' from #TempStorage  
			where PARTICULAR in ('17. Real and Other Pro. Owned or Acquired')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		

--Value 2


insert into #TempVal 
			Select sum (AMOUNT) as 'Val2' from #TempStorage  
			where PARTICULAR in ('Less: Allowance for Prob. Lossess') and recno = '172'
		and BNKIND = 20
		group by [TRDATE], BNKIND
		
	
--select * from #TempVal
Set @ROPOA = (
		SELECT(T1.Val1 - T2.Val1) /1000 AS 'Real and Other Properties Owned or Acquired'
		FROM  #TempVal T1 CROSS JOIN
			  #TempVal T2
		WHERE T1.ID = 1 AND t2.id = 2)

--INSERT
insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
Values ('Real and Other Properties Owned or Acquired', @ROPOA, @TIME_CODE,'20')

-- drop table after inserting the values on the fact table
drop table #TempVal


--output9 
set @OA = (
		Select sum (AMOUNT)/1000 as 'Other Assets'  from #TempStorage  
		where PARTICULAR in ('13. Equip. & Other Properties for Lease','14. Real Estate for Sale / Lease'
		,'15. Due from Head Office / Branches','Sales Contract Receivables'
		,'Account Receivables (Net)','Accrued Interest Receivables (Net)'
		,'c. Deferred Income Tax','d. Others')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)

--INSERT
insert into #TempComp(Particular,AMOUNT,Time_Code,ReportName)
Values ('Other Assets', @OA, @TIME_CODE,'20')


--output10 
set @BP = (
		Select sum (AMOUNT)/1000 as 'Bills Payable'  from #TempStorage  
		where PARTICULAR in ('19. Bills Payable','23. Bonds Payable')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)

insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
Values ('Bills Payable', @BP, @TIME_CODE,'20')


--output11 
set @OL = (
		Select sum (AMOUNT)/1000 as 'Other Liabilities'  from #TempStorage  
		where PARTICULAR in ('20. Dealers Reserve','21. Deposit Lease Contract'
		,'22. Due to Head Office / Branches','24. Accrued Taxes and Other Expenses'
		,'25. Unearned Income & Other Def. Credits','26. Other Liabilities')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)

--INSERT
insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
Values ('Other Liabilities', @OL, @TIME_CODE,'20')


--output12
Set @CS = (
		Select sum (AMOUNT)/1000 as 'Capital Stock'  from #TempStorage  
		where PARTICULAR in ('27. Capital Stock') 
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)

--INSERT
insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
Values ('Capital Stock', @CS, @TIME_CODE,'20')

--output13 
Set @SRUP = (
		Select sum (AMOUNT)/1000 as 'Surplus, Reserves and Undivided Profits'  from #TempStorage  
		where PARTICULAR in ('Less: Allowance for Probable Lossess','Less: Allowance for Probable Lossess'
		,'7. General Loan Loss Provision (Circ. 164)','Less: Allowance for Prob. Lossess-IBODI'
		,'Less: Allowance for Prob. Lossess','28. Retained Earnings'
		,'29. Profit and Loss Summary','30. Net Unrealized Gains / Lossess on SAS'
		,'31. Appraisal Increment Reserve') 
		and RECNO in ('61','78','79','113','121','320','330','340','350')
		and BNKIND = 20
		group by [TRDATE], BNKIND
		)

		--INSERT
insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Surplus, Reserves and Undivided Profits', @SRUP, @TIME_CODE,'20')


		--Output14 (Total)
Set @TA = (@CASH + @COCI + @DCB + @DFB + @LD + @INV + @BHFF + @ROPOA + @OA )
		Select @TA

		--INSERT
		insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Assets', @TA, @TIME_CODE,'20')

		--Output15 (Total)
		Set @TL = (@BP + @OL)

		--INSERT
insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Liabilities', @TL, @TIME_CODE,'20')

		--Output16 (total)
		Set @TNW = (@CS + @SRUP)

		--INSERT
insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Net Worth', @TNW, @TIME_CODE,'20')

		--Output17 (total)
		Set @TLNW = (@TL + @TNW)

		--INSERT
insert into #TempComp (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Liabilities and Net Worth', @TLNW, @TIME_CODE,'20')

select * from #TempComp

--insert into [EDW_Staging].[dbo].[S_Fact_MFSG_NBFIs_STG_ALL] ([Particular],[Value],[NBFIsReport],[Time_Code])
--(Select Particular,AMOUNT,ReportName,Time_Code from #TempComp )






		--drop table #TempStorage