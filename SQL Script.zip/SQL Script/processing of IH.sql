---- IH_CSOC

Select * into #tempTableIH_CSOC From(
select ID,
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_IH_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_IH_CSOC where ID = 2),25,3))  AS MONTH,
	'IH_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_IH_CSOC] where ID = 2),25,3)))	
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_IH_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_IH_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS ) as IH_CSOC


Select * from #tempTableIH_CSOC

	select * into #tempTableIH_CSOC2 from  (
	Select CONVERT(DECIMAL(18,2), REPLACE(AMOUNT, ',', '')) AMOUNT,  PARTICULAR, ID,
	REC, [YEAR], [MONTH], CSOC_REPORT, TIME_CODE from #tempTableIH_CSOC) as TT

	Select * from #tempTableIH_CSOC2


	DECLARE @CASH numeric(18,2) -- CASH
	DECLARE @COCI numeric(18,2) -- Checks and other Cash Items
	DECLARE @DCB numeric(18,2) -- Due from BSP
	DECLARE @DFB numeric(18,2) -- Due from Banks
	DECLARE @LD numeric(18,2) -- Loans and Discounts
	DECLARE @INV numeric(18,2) -- Investments in Bonds and Securities
	DECLARE @BHFF numeric (18,2) -- Real Property, Furniture, Fixture, and Equipment
	DECLARE @ROPOA numeric (18,2) --Real and Other Properties Owned or Acquired
	DECLARE @QA numeric (18,2)  -- Other Assetts
	DECLARE @BP numeric(18,2) --Bills Payable'
	DECLARE @OL numeric(18,2) -- Other Liabilities
	DECLARE @CS numeric(18,2) --Capital Stock
	DECLARE @SRUP numeric(18,2) --Surplus, Reserves and Undivided Profits
	DECLARE @TA numeric(18,2) -- Total Assets
	DECLARE @TL numeric(18,2) -- Total Liabilities
	DECLARE @TNW numeric(18,2) -- Total Net WOrth
	DECLARE @TLNW numeric(18,2) -- Total Liabilities  and Net Worth
	DECLARE @TIME_CODE int -- TIMECODE



		create  table #TempStoreIH_CSOC (
		[ID] [int] IDENTITY(1,1) NOT NULL
		, Particular nvarchar(210)
		, AMOUNT numeric(18,2)
		,Time_Code int,
		ReportName nvarchar (210)
		)


Set @TIME_CODE = (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_IH_CSOC] where ID = 2),25,3)))	
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_IH_CSOC where ID = 2), 4)) )
--select @TIME_CODE
--output1

set @CASH = (
		Select sum (AMOUNT)/1000 as 'CASH'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('1. Cash on Hand')
		group by [Year], [month])

--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT, Time_Code,ReportName)
Values ('CASH', @CASH, @TIME_CODE,'IH')



--output2
set @COCI = (
		Select sum (AMOUNT)/1000 as 'Checks and other Cash Items'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('2. Checks and Cash items')
		group by [Year], [month])

--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Checks and other Cash Items', @COCI, @TIME_CODE,'IH')

--output3
set @DCB = (
		Select sum (AMOUNT)/1000 as 'Due from BSP'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('3. Due from BSP-Reserves')
		group by [Year], [month])

--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Due from BSP', @DCB, @TIME_CODE,'IH')

--output4
set @DFB = (
		Select sum (AMOUNT)/1000 as 'Due from Banks'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('4. Deposits in Banks')
		group by [Year], [month])

--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Due from Banks', @DFB, @TIME_CODE,'IH')

--output5
set @LD = (
		Select sum (AMOUNT)/1000 as 'Loans and Discounts'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('5. Loans / Receivables','d. Priv. Debt Sec. / Commercial Papers (CPs) Purchased')
		group by [Year], [month])

--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Loans and Discounts', @LD, @TIME_CODE,'IH')

--output6
set @INV = (
		Select sum (AMOUNT)/1000 as 'Investments in Bonds and Securities'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('8. Trading Account Securities-Investments','9. Trading Account Securities-Equity'
		,'10. Available for Sale Securities (ASS)','11. Investment in Bonds & Other Debt Instruments'
		,'12. Equity Investments in Allied/Non-Allied Undertakings')
		group by [Year], [month])

--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Investments in Bonds and Securities', @INV, @TIME_CODE,'IH')

--output7 
Set @BHFF = (
		Select sum (AMOUNT)/1000 as 'Real Property, Furniture, Fixture, and Equipment'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('16. Real Property, Furniture, Fixtures & Equipment')
		group by [Year], [month])


--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Real Property, Furniture, Fixture, and Equipment', @BHFF, @TIME_CODE,'IH')

--output8 
create  table #TempVal (
[ID] [int] IDENTITY(1,1) NOT NULL,
Val1 numeric(18,2)
)

--update #tempTableIH_CSOC2 set Amount = 320 where  PARTICULAR in ('17. Real and Other Pro. Owned or Acquired')
--Value 1 
insert into #TempVal 
			Select sum (AMOUNT) as 'Val1' from #tempTableIH_CSOC2  
			where PARTICULAR in ('17. Real and Other Pro. Owned or Acquired')
			group by [Year], [month]

--Value 2
insert into #TempVal 
			Select sum (AMOUNT) as 'Val2' from #tempTableIH_CSOC2  
			where PARTICULAR in ('Less: Allowance for Probable Losses') and ID = 66
			group by [Year], [month]

--select * from #TempVal
Set @ROPOA = (
		SELECT(T1.Val1 - T2.Val1) /1000 AS 'Real and Other Properties Owned or Acquired'
		FROM  #TempVal T1 CROSS JOIN
			  #TempVal T2
		WHERE T1.ID = 1 AND t2.id = 2)

--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Real and Other Properties Owned or Acquired', @ROPOA, @TIME_CODE,'IH')

-- drop table afterinserting the values on the fact table
drop table #TempVal


--output9 
set @QA = (
		Select sum (AMOUNT)/1000 as 'Other Assets'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('13. Equip. & Other Properties for Lease','14. Real Estate for Sale / Lease'
		,'15. Due from Head Office / Branches','Sales Contract Receivables'
		,'Accounts Receivable (Net)','b. Accrued Interest Receivables'
		, 'Allowance for Uncollectible Interest','c. Deferred Income Tax','d. Others')
		group by [Year], [month])

--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Other Assets', @QA, @TIME_CODE,'IH')

--output10 
set @BP = (
		Select sum (AMOUNT)/1000 as 'Bills Payable'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('19. Bills Payable','23. Bonds Payable')
		group by [Year], [month])

insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Bills Payable', @BP, @TIME_CODE,'IH')

--output11 
set @OL = (
		Select sum (AMOUNT)/1000 as 'Other Liabilities'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('20. Dealers Reserve','21. Deposit Lease Contract'
		,'22. Due to Head Office/Branches','24. Accrued Taxes and Other Expenses'
		,'25. Unearned Income and Other Deferred Credits','26. Other Liabilities')
		group by [Year], [month])

--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Other Liabilities', @OL, @TIME_CODE,'IH')

--output12
Set @CS = (
		Select sum (AMOUNT)/1000 as 'Capital Stock'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('27. Capital Stock') 
		group by [Year], [month])

--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Capital Stock', @CS, @TIME_CODE,'IH')

--output13 
Set @SRUP = (
		Select sum (AMOUNT)/1000 as 'Surplus, Reserves and Undivided Profits'  from #tempTableIH_CSOC2  
		where PARTICULAR in ('28. Retained Earnings','29. Profit and Loss Summary'
		,'30. Net Unrealized Gains / Losses on SAS','31. Appraisal Increment Reserve'
		,'7. General Loan Loss Provision (Cir. 164)','Less: Allowance for Probable Losses-IBODI'
		,'Less: Allowance for Probable Losses') and ID in (22,59)
		group by [Year], [month])

		--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Surplus, Reserves and Undivided Profits', @SRUP, @TIME_CODE,'IH')

		--Output14 (Total)
Set @TA = (@CASH + @COCI + @DCB + @DFB + @LD + @INV + @BHFF + @ROPOA + @QA )
		Select @TA

		--INSERT
		insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Assets', @TA, @TIME_CODE,'IH')

		--Output15 (Total)
		Set @TL = (@BP + @OL)

		--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Liabilities', @TL, @TIME_CODE,'IH')

		--Output16 (total)
		Set @TNW = (@CS + @SRUP)

		--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Net Worth', @TNW, @TIME_CODE,'IH')

		--Output17 (total)
		Set @TLNW = (@TL + @TNW)

		--INSERT
insert into #TempStoreIH_CSOC (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Liabilities and Net Worth', @TLNW, @TIME_CODE,'IH')







