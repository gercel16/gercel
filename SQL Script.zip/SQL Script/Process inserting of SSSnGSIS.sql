drop table #TempTableSSS_GSIS
drop table #TempTableSSS_GSIS2
drop table #TempStoreGOVT

Select * into #TempTableSSS_GSIS from (
select ID,
case
	When Column1 <> '' Then Column1 end 'PARTICULAR',
	REC = '',
	'AMOUNT' =  
			CASE 
			WHEN [Column2] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column2]) = 1 THEN [Column2]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_GNBFI_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_GNBFI_CSOC where ID = 2),26,3))  AS MONTH,
	'SSS_GSIS' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_GNBFI_CSOC] where ID = 2),26,3)))	 
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_GNBFI_CSOC where ID = 2), 4))  
					
					)
	from [dbo].[Dump_MFSG_NBFIs_AssetLiabilites_GSIS_SSS]

	where [column1] <> '' and [Column2] <> '' and ID between 83 and 103 )  as GOVT
	--order by ID OFFSET 0 ROWS 


	Select * from  #TempTableSSS_GSIS


select * into #TempTableSSS_GSIS2 from  (
Select CONVERT(DECIMAL(18,2), REPLACE(REPLACE(AMOUNT, ',', ''),'-','')) AMOUNT,  PARTICULAR, ID,
REC, [YEAR], [MONTH], CSOC_REPORT, TIME_CODE from #TempTableSSS_GSIS
where PARTICULAR <> 'Check') as TT

--select * from #tempTableSSS_GSIS2
--select * from #TempStoreGOVT

	create  table #TempStoreGOVT (
		[ID] [int] IDENTITY(1,1) NOT NULL
		, Particular nvarchar(210)
		, AMOUNT numeric(18,2)
		,Time_Code int,
		ReportName nvarchar (210)
		)

SET IDENTITY_INSERT #TempStoreGOVT ON

	insert into #TempStoreGOVT (ID, Particular,AMOUNT,Time_Code,ReportName)
	 (Select ID, PARTICULAR,AMOUNT,Time_Code,CSOC_REPORT 
	 from #tempTableSSS_GSIS2 )

SET IDENTITY_INSERT #TempStoreGOVT OFF 
 
update #TempStoreGOVT  set Particular = 'Due from Banks'
where Particular = 'Due from Banks (Cash and Cash Equivalents)'

update #TempStoreGOVT  set Particular = 'Investments in Bonds and Securities'
where Particular = 'Investment in Bonds and Securities'

update #TempStoreGOVT  set Particular = 'Real Property, Furniture, Fixture, and Equipment'
where Particular = 'Real Property Furniture, Fixture and Equiptment'

update #TempStoreGOVT  set Particular = 'Surplus, Reserves and Undivided Profits'
where Particular = 'Surplus reserves and Undivided Profits'

----------Insert in Staging ALL---------

--SET IDENTITY_INSERT #TempStoreGOVT ON
insert into [EDW_Staging].[dbo].[S_Fact_MFSG_NBFIs_STG_ALL] ([Particular],[Value],[NBFIsReport],[Time_Code])
(Select Particular,AMOUNT,ReportName,Time_Code from #TempStoreGOVT )
--SET IDENTITY_INSERT #TempStoreGOVT OFF

--drop table #TempTableSSS_GSIS2
--drop table #TempStoreGOVT

