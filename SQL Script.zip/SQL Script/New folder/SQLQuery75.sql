USE [EDW]
GO

ALTER TABLE [dbo].[Dim_Location_Region]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Location_Region__MajorIslandGroup_Idx]
FOREIGN KEY([MajorIslandGroup_Idx])
REFERENCES [dbo].[Dim_Location_MajorIslandGroup] ([MajorIslandGroup_Idx])
GO

ALTER TABLE [dbo].[Dim_Location_Region] CHECK CONSTRAINT [FK_Dim_Location_Region__MajorIslandGroup_Idx]
GO


