USE [EDW]
GO

/****** Object:  Table [dbo].[Fact_ESLIG_PMI_PISM]    Script Date: 12/28/2022 11:35:18 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Fact_ESLIG_PMI_PISM](
	[Sector_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[PMI_Values] [numeric](18, 2) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Fact_ESLIG_PMI_PISM]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PMI_PISM_Sector] FOREIGN KEY([Sector_Idx])
REFERENCES [dbo].[Dim_PMISector] ([Sector_Idx])
GO

ALTER TABLE [dbo].[Fact_ESLIG_PMI_PISM] CHECK CONSTRAINT [FK_Fact_PMI_PISM_Sector]
GO

ALTER TABLE [dbo].[Fact_ESLIG_PMI_PISM]  WITH CHECK ADD  CONSTRAINT [FK_Fact_PMI_PISM_Time_Time] FOREIGN KEY([Time_Idx])
REFERENCES [dbo].[Dim_Time] ([Time_Idx])
GO

ALTER TABLE [dbo].[Fact_ESLIG_PMI_PISM] CHECK CONSTRAINT [FK_Fact_PMI_PISM_Time_Time]
GO


