USE [EDW_Staging]
GO

/****** Object:  Table [dbo].[Fact_S_ESLIG_PMI_PISM]    Script Date: 12/28/2022 11:33:26 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Fact_S_ESLIG_PMI_PISM](
	[Sector_Idx] [int] NOT NULL,
	[Time_Idx] [int] NOT NULL,
	[PMI_Values] [numeric](18, 2) NULL
) ON [PRIMARY]
GO


