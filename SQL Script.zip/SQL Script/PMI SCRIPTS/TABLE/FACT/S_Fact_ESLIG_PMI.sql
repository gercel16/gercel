USE [EDW_Staging]
GO

/****** Object:  Table [dbo].[S_Fact_ESLIG_PMI]    Script Date: 12/28/2022 11:34:36 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[S_Fact_ESLIG_PMI](
	[Manufacturing] [numeric](18, 2) NULL,
	[RetailWholesale] [numeric](18, 2) NULL,
	[Services] [numeric](18, 2) NULL,
	[Composite] [numeric](18, 2) NULL,
	[Time_Code] [int] NOT NULL
) ON [PRIMARY]
GO


