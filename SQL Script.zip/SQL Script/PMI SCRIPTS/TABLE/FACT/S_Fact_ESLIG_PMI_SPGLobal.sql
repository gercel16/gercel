USE [EDW_Staging]
GO

/****** Object:  Table [dbo].[S_Fact_ESLIG_PMI_SPGLobal]    Script Date: 12/28/2022 11:34:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[S_Fact_ESLIG_PMI_SPGLobal](
	[Value] [numeric](18, 2) NULL,
	[Time_Idx] [int] NOT NULL
) ON [PRIMARY]
GO


