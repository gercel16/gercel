USE [EDW_Staging]
GO

/****** Object:  Table [dbo].[Dump_ESLIG_PMI_SP_Global_Phi_Manufacturing]    Script Date: 12/28/2022 11:24:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Dump_ESLIG_PMI_SP_Global_Phi_Manufacturing](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Date] [nvarchar](max) NOT NULL,
	[Value] [nvarchar](max) NOT NULL,
	[Column3] [nvarchar](max) NOT NULL,
	[Column4] [nvarchar](max) NOT NULL,
	[Column5] [nvarchar](max) NOT NULL,
	[Column6] [nvarchar](max) NOT NULL,
	[Column7] [nvarchar](max) NOT NULL,
	[Column8] [nvarchar](max) NOT NULL,
	[Column9] [nvarchar](max) NOT NULL,
	[Column10] [nvarchar](max) NOT NULL,
	[Column11] [nvarchar](max) NOT NULL,
	[Column12] [nvarchar](max) NOT NULL,
	[Column13] [nvarchar](max) NOT NULL,
	[Column14] [nvarchar](max) NOT NULL,
	[Column15] [nvarchar](max) NOT NULL,
	[Column16] [nvarchar](max) NOT NULL,
	[Column17] [nvarchar](max) NOT NULL,
	[Column18] [nvarchar](max) NOT NULL,
	[Column19] [nvarchar](max) NOT NULL,
	[Column20] [nvarchar](max) NOT NULL,
	[Column21] [nvarchar](max) NOT NULL,
	[Column22] [nvarchar](max) NOT NULL,
	[Column23] [nvarchar](max) NOT NULL,
	[Column24] [nvarchar](max) NOT NULL,
	[Column25] [nvarchar](max) NOT NULL,
	[Column26] [nvarchar](max) NOT NULL,
	[Column27] [nvarchar](max) NOT NULL,
	[Column28] [nvarchar](max) NOT NULL,
	[Column29] [nvarchar](max) NOT NULL,
	[Column30] [nvarchar](max) NOT NULL,
	[Column31] [nvarchar](max) NOT NULL,
	[Column32] [nvarchar](max) NOT NULL,
	[Column33] [nvarchar](max) NOT NULL,
	[Column34] [nvarchar](max) NOT NULL,
	[Column35] [nvarchar](max) NOT NULL,
	[Column36] [nvarchar](max) NOT NULL,
	[Column37] [nvarchar](max) NOT NULL,
	[Column38] [nvarchar](max) NOT NULL,
	[Column39] [nvarchar](max) NOT NULL,
	[Column40] [nvarchar](max) NOT NULL,
	[Column41] [nvarchar](max) NOT NULL,
	[Column42] [nvarchar](max) NOT NULL,
	[Column43] [nvarchar](max) NOT NULL,
	[Column44] [nvarchar](max) NOT NULL,
	[Column45] [nvarchar](max) NOT NULL,
	[Column46] [nvarchar](max) NOT NULL,
	[Column47] [nvarchar](max) NOT NULL,
	[Column48] [nvarchar](max) NOT NULL,
	[Column49] [nvarchar](max) NOT NULL,
	[Column50] [nvarchar](max) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


