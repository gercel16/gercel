USE [EDW_Staging]
GO

/****** Object:  Table [dbo].[Dump_ESLIG_PMI_PISM_BSP_Manufacturing_DataSeries]    Script Date: 12/28/2022 11:30:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Dump_ESLIG_PMI_PISM_BSP_Manufacturing_DataSeries](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[YEAR] [nvarchar](max) NOT NULL,
	[DATE] [nvarchar](max) NOT NULL,
	[Manufacturing_raw] [nvarchar](max) NOT NULL,
	[NewOrders_raw] [nvarchar](max) NOT NULL,
	[Production_raw] [nvarchar](max) NOT NULL,
	[Employment_raw] [nvarchar](max) NOT NULL,
	[SupplierDeliveries_raw] [nvarchar](max) NOT NULL,
	[Inventories_raw] [nvarchar](max) NOT NULL,
	[AvePriceCharge_raw] [nvarchar](max) NOT NULL,
	[ProductionCost_raw] [nvarchar](max) NOT NULL,
	[Column11] [nvarchar](max) NOT NULL,
	[Manufacturing_adjusted] [nvarchar](max) NOT NULL,
	[NewOrders_adjusted] [nvarchar](max) NOT NULL,
	[Production_adjusted] [nvarchar](max) NOT NULL,
	[Employment_adjusted] [nvarchar](max) NOT NULL,
	[SupplierDeliveries_adjusted] [nvarchar](max) NOT NULL,
	[Inventories_Adjusted] [nvarchar](max) NOT NULL,
	[AvePriceCharge_Adjusted] [nvarchar](max) NOT NULL,
	[ProductionCost_Adjusted] [nvarchar](max) NOT NULL,
	[Column20] [nvarchar](max) NOT NULL,
	[Column21] [nvarchar](max) NOT NULL,
	[Column22] [nvarchar](max) NOT NULL,
	[Column23] [nvarchar](max) NOT NULL,
	[Column24] [nvarchar](max) NOT NULL,
	[Column25] [nvarchar](max) NOT NULL,
	[Column26] [nvarchar](max) NOT NULL,
	[Column27] [nvarchar](max) NOT NULL,
	[Column28] [nvarchar](max) NOT NULL,
	[Column29] [nvarchar](max) NOT NULL,
	[Column30] [nvarchar](max) NOT NULL,
	[Column31] [nvarchar](max) NOT NULL,
	[Column32] [nvarchar](max) NOT NULL,
	[Column33] [nvarchar](max) NOT NULL,
	[Column34] [nvarchar](max) NOT NULL,
	[Column35] [nvarchar](max) NOT NULL,
	[Column36] [nvarchar](max) NOT NULL,
	[Column37] [nvarchar](max) NOT NULL,
	[Column38] [nvarchar](max) NOT NULL,
	[Column39] [nvarchar](max) NOT NULL,
	[Column40] [nvarchar](max) NOT NULL,
	[Column41] [nvarchar](max) NOT NULL,
	[Column42] [nvarchar](max) NOT NULL,
	[Column43] [nvarchar](max) NOT NULL,
	[Column44] [nvarchar](max) NOT NULL,
	[Column45] [nvarchar](max) NOT NULL,
	[Column46] [nvarchar](max) NOT NULL,
	[Column47] [nvarchar](max) NOT NULL,
	[Column48] [nvarchar](max) NOT NULL,
	[Column49] [nvarchar](max) NOT NULL,
	[Column50] [nvarchar](max) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


