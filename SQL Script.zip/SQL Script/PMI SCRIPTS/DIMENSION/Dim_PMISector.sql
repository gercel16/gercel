USE [EDW]
GO

/****** Object:  Table [dbo].[Dim_PMISector]    Script Date: 12/28/2022 11:39:20 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Dim_PMISector](
	[Sector_Idx] [int] IDENTITY(1,1) NOT NULL,
	[Sector_Code] [nvarchar](50) NOT NULL,
	[Sector_Name] [nvarchar](150) NOT NULL,
	[Sector_Label] [nvarchar](150) NULL,
	[Sector_Sort] [int] NULL,
 CONSTRAINT [PK_Dim_SectorType] PRIMARY KEY CLUSTERED 
(
	[Sector_Idx] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


