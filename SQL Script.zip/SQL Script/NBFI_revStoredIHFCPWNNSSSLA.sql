 select ID,
	TRDATE
	,BNKIND as 'BANKINDUSTRY'
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE(AMT, ',', '')) AMOUNT
	,'Particular' = [DESC]
	,'Particular_code' = [DESC] + 'IH'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME) 
	,'Table' = 'IH'
	into #TempStorage

	from [dbo].[Dump_MFSG_NBFIs_FSRLIB2_NBFPF00]

	union 

select ID,
	TRDATE
	,BNKIND as 'BANKINDUSTRY'
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE(AMT, ',', '')) AMOUNT,
	'Particular' = [DESC]
	,'Particular_code' = [DESC] + 'FC'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
	,'Table' = 'FC'
	from [dbo].[Dump_MFSG_NBFIs_FSRLIB2_NBFPI00]

	select ID,
	TRDATE
	,BANKINDUSTRY
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE([AMOUNT], ',', '')) AMOUNT
	,Particular
	,Particular_code
	,DATE_CODE
	,[Table]
	into #TempStorage1
	from #TempStorage

	SELECT 
	 DATE_CODE
	,BANKINDUSTRY
	,Particular
	,Particular_code
	,'AMOUNT' = sum (AMOUNT)/1000  
	INTO #TempStorage2
	FROM #TempStorage 
	GROUP BY Particular,DATE_CODE,BANKINDUSTRY,Particular_code

	SELECT 
	B.Time_idx
	,C.[NBFIParticular_Idx]
	,C.[Particular_Group]
	,C.[Particular_Type]
	,A.BANKINDUSTRY
	,A.Particular 
	,A.AMOUNT
	INTO #TempIHFC
	FROM #TempStorage2 A
	LEFT OUTER JOIN [EDW_DIM_Standard].[dbo].[Dim_Time] B
	ON A.DATE_CODE = B.Date_Code
	LEFT OUTER JOIN  [EDW].[dbo].[Dim_NBFIParticular] C
	ON A.Particular_code = C.[Particular_Code]

	--------------------------------------------------------------
	select ID,
	TRDATE
	,'PAWNSHOP' as 'BANKINDUSTRY' 
	,'0' as RECNO
	,SCHNO
	,'AMOUNT' = 
		CASE 
			WHEN AMOUNT = '.' THEN '0.0' 
			WHEN ISNUMERIC(AMOUNT) = 1 THEN AMOUNT  		
		ELSE '0.0'
		end
	--,CONVERT(DECIMAL(18,2), REPLACE(AMOUNT, ',', '')) AMOUNT
	,'Particular' = [DETAIL1]
	,'Particular_code' = [DETAIL1] + 'PAWNSHOP'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
	,'Table' = 'PAWNSHOP'
	into #TempStorageA	

	from[dbo].[Dump_MFSG_NBFIs_PAWNSHOP_GLSLLIB2_NBPWNFS2]

	union

	select ID,
	TRDATE
	,'NSSLA' as 'BANKINDUSTRY' 
	,'0' as RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE([TOTAMT], ',', '')) AMOUNT,
	'Particular' = [DETAIL1]
	,'Particular_code' = [DETAIL1] + 'NSSLA'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
	,'Table' = 'NSSLA'
	from [dbo].[Dump_MFSG_NBFIs_FRPNSSLA_BS]

	select ID,
	TRDATE
	,BANKINDUSTRY
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE([AMOUNT], ',', '')) AMOUNT
	,Particular
	,Particular_code
	,DATE_CODE
	,[Table]
	into #TempStorageB
	from #TempStorageA

		SELECT 
	 DATE_CODE
	,BANKINDUSTRY
	,Particular
	,Particular_code
	,AMOUNT = sum (AMOUNT)/1000000  
	INTO #TempStorageC
	FROM #TempStorageB
	GROUP BY Particular,DATE_CODE,BANKINDUSTRY,Particular_code

	SELECT 
	B.Time_idx
	,C.[NBFIParticular_Idx]
	,C.[Particular_Group]
	,C.[Particular_Type]
	,A.BANKINDUSTRY
	,A.Particular 
	,A.AMOUNT
	Into #TempNSSLAPAWNSHOP
	FROM #TempStorageC A
	LEFT OUTER JOIN [EDW_DIM_Standard].[dbo].[Dim_Time] B
	ON A.DATE_CODE = B.Date_Code
	LEFT OUTER JOIN  [EDW].[dbo].[Dim_NBFIParticular] C
	ON A.Particular_code = C.[Particular_Code]

	--1283
	--224

	Select * from #TempIHFC
	union all
	Select * from #TempNSSLAPAWNSHOP

-------------combine the IHFC, PAWNSHOP and NSSLA-------------------
	--Select * 
	--into #NBFIs
	--from #TempIHFC
	--union
	--Select * from #TempNSSLAPAWNSHOP
	--order by Particular_group

	-------------- to lest the amount need to subtract--------------

	Select * from #NBFIs where BANKINDUSTRY = 'NSSLA'
	and Particular in ('Less: Loan Discount','Less: Other Deferred Credits')

	update  #NBFIs 
	set AMOUNT = AMOUNT * -1
	where BANKINDUSTRY = 'NSSLA'
	and Particular in ('Less: Loan Discount','Less: Other Deferred Credits')


	 -----------------------------------------------------------------
	 Select 
