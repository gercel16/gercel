  -- select * from [dbo].[Dump_ESLIG_Capita_Food_Threshold]
-------------------------------------------------------------------1


 Select top 1 [Column2] from  [dbo].[Dump_ESLIG_Capita_Poverty_Threshold] where Column2 like '20%'
  Select top 1 [Column3] from [dbo].[Dump_ESLIG_Capita_Poverty_Threshold] where Column3 like '20%'

DECLARE @Yr1 varchar(50) =  '2018'
DECLARE @Yr2 varchar(50) = '2021'
-- @Yr1 = (Select [Column2] from [Dump_ESLIG_Capita_Food_Threshold] where Column2 like '20%')

--Drop table #tempTable1
--Drop table #tempTable2

Select * into #tempTable1 from (
		   Select 
		   case when [Column1] <> '' then [Column1] else '0' end Location,
		   case when [Column1] <> '' then [Column2] else '0' end 'Value_1',
		   @Yr1 as year
		 --  into #tempTable
		   from [dbo].[Dump_ESLIG_Capita_Poverty_Threshold] where [Column1] <>'' and [Column2] <> ''  and [Column1] != 'Region/Province' 
		  -- Select * from #tempTable
union all
		   Select 
		   case when [Column1] <> '' then [Column1] else '0' end Location,
		   case when [Column1] <> '' then [Column3] else '0' end 'Value_1',
		   @Yr2 as year
		   from [dbo].[Dump_ESLIG_Capita_Poverty_Threshold] where [Column1] <>'' and [Column2] <> '' and [Column1] != 'Region/Province' 
		   ) as temp
		   		   
		   Select * from #tempTable1 
---------------------------------------------------------------------2



select * into  #tempTable2 from (Select replace(replace(replace(replace(location, ' a/b/', ''), ' b/', ''), ' a/', ''),'*','') as N_Location
,(select replace(Value_1, ',','.')) as value
, [year]
from #tempTable1 where Value_1 <> '' and Location != 'Region/Province') as temp2

select * from #tempTable2

--------------------------------------------------------------------3

-- drop table #TempTable2
-- drop table #TempTable1

--DECLARE @Value numeric(18,2) = 

select CONVERT(numeric(38,2),(select replace(Value_1, ',','.'))) as Value_1
from #tempTable1

select [Value], CONVERT(numeric(38,2),[Value]) as converted_val 
from #tempTable2

select ISNULL(TRY_CONVERT(numeric(18,2),[Value_1]),0.0) as [Value]
from #tempTable1

select * from #tempTable2

select N_Location, LEN(N_location) from #tempTable2 where LEN(N_location) > 50

select LEN(N_location) from #tempTable2
--------------------------------------------------------------------4

--TRUNCATE TABLE [S_Fact_Poverty]

insert into [dbo].[S_Fact_Poverty] (City_Code,Time_Code,PerCapitaPovertyThresholdinPesos)
Select N_Location,[YEAR],[value]
From #tempTable2

select * from S_Fact_Poverty where PerCapitaFoodThresholdinPesos <> ''
