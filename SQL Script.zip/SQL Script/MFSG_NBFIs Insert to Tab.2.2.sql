	DECLARE @CASH numeric(18,2) -- CASH
	DECLARE @COCI numeric(18,2) -- Checks and other Cash Items
	DECLARE @DCB numeric(18,2) -- Due from BSP
	DECLARE @DFB numeric(18,2) -- Due from Banks
	DECLARE @LD numeric(18,2) -- Loans and Discounts
	DECLARE @INV numeric(18,2) -- Investments in Bonds and Securities
	DECLARE @BHFF numeric (18,2) -- Real Property, Furniture, Fixture, and Equipment
	DECLARE @ROPOA numeric (18,2) --Real and Other Properties Owned or Acquired
	DECLARE @OA numeric (18,2)  -- Other Assetts
	DECLARE @BP numeric(18,2) --Bills Payable'
	DECLARE @OL numeric(18,2) -- Other Liabilities
	DECLARE @CS numeric(18,2) --Capital Stock
	DECLARE @SRUP numeric(18,2) --Surplus, Reserves and Undivided Profits
	DECLARE @TA numeric(18,2) -- Total Assets
	DECLARE @TL numeric(18,2) -- Total Liabilities
	DECLARE @TNW numeric(18,2) -- Total Net WOrth
	DECLARE @TLNW numeric(18,2) -- Total Liabilities  and Net Worth
	DECLARE @TIME_CODE int -- TIMECODE

--truncate table S_Fact_MFSG_NBFIs

--select * from [S_Fact_MFSG_NBFIs_STG_ALL]




-------------------------------------------------------------------------------------

Set @TIME_CODE =  (Select top 1  TIME_CODE from [S_Fact_MFSG_NBFIs_STG_ALL] 
where  [NBFIsReport] in ('SSS_GSIS','GNBFI'))

--select @TIME_CODE

-------------------------------------------------------------------------------------

--CASH
set @CASH = (
	Select sum (value) as 'CASH'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('CASH') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('CASH', @CASH, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------
--Checks and other Cash Items
Set @COCI =(	Select sum (value) as 'COCI'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Checks and other Cash Items')  and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Checks and other Cash Items', @COCI, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Due from BSP
Set @DCB = (Select sum (value) as 'DCB'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Due from BSP') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Due from BSP', @DCB, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Due from Banks
Set @DFB = (Select sum (value) as 'DFB'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Due from Banks') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Due from Banks', @DFB, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Loans and Discounts
Set @LD = (	Select sum (value) as 'LD'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Loans and Discounts') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Loans and Discounts', @LD, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Investments in Bonds and Securities
Set @INV =	(Select sum (value) as 'INV'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Investments in Bonds and Securities') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Investments in Bonds and Securities', @INV, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Real Property, Furniture, Fixture, and Equipment
Set @BHFF = (Select sum (value) as 'BHFF'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Real Property, Furniture, Fixture, and Equipment') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Real Property, Furniture, Fixture, and Equipment', @BHFF, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Real and Other Properties Owned or Acquired
Set @ROPOA = (Select sum (value) as 'ROPOA'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Real and Other Properties Owned or Acquired') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Real and Other Properties Owned or Acquired', @ROPOA, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Other Assets
Set @OA = (	Select sum (value) as 'OA'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Other Assets') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Other Assets', @OA, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Bills Payable
Set @BP	=(Select sum (value) as 'BP'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Bills Payable') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Bills Payable', @BP, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Other Liabilities
Set @OL = (	Select sum (value) as 'OL'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Other Liabilities') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Other Liabilities', @OL, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Capital Stock
Set @CS	= (Select sum (value) as 'CS'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Capital Stock') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Capital Stock', @CS, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Surplus, Reserves and Undivided Profits
Set @SRUP = (Select sum (value) as 'SRUP'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Surplus, Reserves and Undivided Profits') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Surplus, Reserves and Undivided Profits', @SRUP, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------


--Total Assets
Set @TA = (Select sum (value) as 'TA'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Total Assets') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Total Assets', @TA, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Total Liabilities
Set @TL = (Select sum (value) as 'TL'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Total Liabilities') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Total Liabilities', @TL, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Total Net Worth
Set @TNW = (Select sum (value) as 'TNW'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Total Net Worth') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Total Net Worth', @TNW, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

--Total Liabilities and Net Worth
set @TLNW = (Select sum (value) as 'TLNW'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Total Liabilities and Net Worth') and [NBFIsReport] in ('SSS_GSIS','GNBFI')
		group by [Time_Code] , [Particular]
		)

--INSERT
insert into S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
Values ('Total Liabilities and Net Worth', @TLNW, @TIME_CODE,'Tab 2.2')
-------------------------------------------------------------------------------------

Select * from S_Fact_MFSG_NBFIs
		--Select * from [dbo].[S_Fact_MFSG_NBFIs_STG_ALL]
		--	where PARTICULAR in ('Total Liabilities and Net Worth') and [NBFIsReport] in ('SSS_GSIS','GNBFI')



