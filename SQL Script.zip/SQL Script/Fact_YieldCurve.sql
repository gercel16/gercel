USE [EDW]
GO

/****** Object:  StoredProcedure [dbo].[INS_DIM_TENOR_TENOR]    Script Date: 09/12/2022 1:44:30 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[INS_FACT_YIELDCURVE] 
as

INSERT INTO Fact_YieldCurve (Time_Idx, Tenor_Idx, BVALRate, BVALRateDiff)
SELECT dt.Time_Idx, dtt.Tenor_Idx, BVALRate, BVALRateDiff FROM EDW_Staging.dbo.S_Fact_YieldCurve main 
inner join Dim_Tenor_Tenor dtt on dtt.Tenor_Code = main.Tenor_Code
inner join Dim_time dt on dt.Time_Idx = main.Time_Code
where not exists (select Time_Idx, Tenor_Idx, BVALRate, BVALRateDiff from Fact_YieldCurve 
where Time_idx = main.Time_Code
and Tenor_Idx = dtt.Tenor_Idx)





GO
