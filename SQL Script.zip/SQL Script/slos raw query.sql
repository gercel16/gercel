SELECT distinct [ENTERPRISESLOAN_TYPE]
FROM [dbo].[S_Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]

select distinct [HOUSEHOLDLOAN_TYPE] 
from [dbo].[S_Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS]

select DISTINCT  [COMMERCIALLOAN_TYPE]
from [dbo].[S_Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS]

select * 
from [dbo].[S_Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS]

SELECT *
FROM [dbo].[S_Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]

SELECT * FROM TEST.[dbo].[SLOS_MarketEnterpriseType]

SELECT * FROM [S_Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES] A
JOIN TEST.[dbo].[SLOS_MarketEnterpriseType] B
ON A.[ENTERPRISESLOAN_TYPE] =  B.MarketCode



insert into edw.[dbo].[Dim_SLOS_MarketEnterpriseType]
([MarketCode],
[MarketName],
[MarketDesc],
[MarkertSort],
[MarketSortSub],
[QuestionCategoryCode]
)

select  
[MarketCode],
[MarketName],
[MarketDesc],
[MarkertSort],
[MarketSortSub],
[QuestionCategoryCode]
from [dbo].[S_Dim_SLOS_MarketEnterpriceType]

select count([MarketCode])
from TEST.[dbo].[SLOS_MarketEnterpriseType]


insert into [dbo].[S_Dim_SLOS_Question]
([QuestionCode],
[QuestionName],
[QuestionDesc],
[QuestionCategoryCode],
[QuestionCategorySort]
)

select [QuestionCode],
[QuestionName],
[QuestionDesc],
[QuestionCategoryCode],
[QuestionCategorySort]
from test.dbo.SLOS_Question



insert into [dbo].[S_Dim_SLOS_CreditStandard_Factors]
([CreditStandardFactorsCode],
[CreditStandardFactorsName],
[CreditStandardFactorsDesc],
[CreditStandardFactorsSort]
)

select * from test.[dbo].[SLOS_CreditStandard_Factors]


insert into edw.[dbo].[Dim_SLOS_Question]
     ( [QuestionCode]
      ,[QuestionName]
      ,[QuestionDesc]
      ,[QuestionCategoryCode]
      ,[QuestionCategorySort])

select * from [dbo].[S_Dim_SLOS_Question]

select * from edw.[dbo].[Dim_SLOS_Question]

select * from test.[dbo].[Question_Type]
select * from edw.[dbo].[Dim_SLOS_QuestionType]

INSERT INTO EDW.[dbo].[Dim_SLOS_QuestionType]
(
[QuestionTypeCode],
[QuestionTypeName],
[QuestionTypeDesc],
[QuestionTypeSort]
)select * from test.[dbo].[Question_Type]


SELECT * FROM TEST.DBO.SLOSQuestionnaire_Category
SELECT * FROM edw.[dbo].[Dim_SLOS_QuestionnaireCategory]

INSERT INTO EDW.[dbo].[Dim_SLOS_QuestionnaireCategory]
(
[QuestionnaireCategoryCode],
[QuestionnaireID],
[QuestionnaireCategory],
[QuestionnaireName],
[QuestionTypeSort]
)SELECT * FROM TEST.DBO.SLOSQuestionnaire_Category

	--UPDATE B
	--	SET B.TIME_IDX = A.Time_Idx,
	--		B.INSTITUTION_IDX = A.INSTITUTION_IDX,
	--		B.[PFSParticular_Idx] = A.[PFSParticular_Idx],
	--		B.SALN_IDX = A.SALN_IDX,
	--		B.[VALUE] = A.[Value]
	--	FROM [EDW_Staging].[dbo].[S_Fact_MFSG_STATBUL_TOTRES] A
	--	JOIN [EDW].[dbo].[Fact_MFSG_STATBUL_TOTRES] B
	--	ON A.Time_Idx = B.Time_Idx
	--	AND A.INSTITUTION_IDX = B.INSTITUTION_IDX
	--	AND A.SALN_IDX = B.SALN_IDX

select * from [dbo].[S_Dim_SLOS_CreditStandard_Factors] A
join [EDW].[dbo].[Dim_SLOS_CreditStandard_Factors] B
on A.[CreditStandardFactorsCode] = B.[CreditStandardFactorsCode]
AND A.[CreditStandardFactorsName] = B.[CreditStandardFactorsName]


--UPDATE B
--SET
--	B.[CreditStandardFactorsSort] = A.[CreditStandardFactorsSort]
--from [dbo].[S_Dim_SLOS_CreditStandard_Factors] A
--join [EDW].[dbo].[Dim_SLOS_CreditStandard_Factors] B
--on A.[CreditStandardFactorsCode] = B.[CreditStandardFactorsCode]
--AND A.[CreditStandardFactorsName] = B.[CreditStandardFactorsName]

SELECT * FROM [EDW].[dbo].[Dim_SLOS_CreditStandard_Factors]
