select * from Test.dbo.SLOS_Question


insert into [dbo].[S_Dim_SLOS_Question] 
([QuestionCode],
	[QuestionName],
	[QuestionDesc],
	[QuestionCategoryCode],
	[QuestionCategorySort])

select * from Test.dbo.SLOS_Question