

	-------------------------------------------------------
	-------1 CENTRAL BANKS--------------------------------
	Select	B.TIME_IDX
			,A.[GROUP_TYPE]
			,CONVERT(DECIMAL(18,2), REPLACE(A.[values], ',', '')) AMOUNT
			,A.[PFS_TYPE]
			--SUM(A.[VALUES])
	--INTO #TempStorageFPS
	from [dbo].[Dump_MFSG_STATBUL_FPS_BSPAL_Temp] A
	JOIN EDW.[dbo].[Dim_Time_1] B
	ON A.[DATE] = B.Date_Code

	-------------------------------------------------------
	UNION ALL
	-------2 BANKS-----------------------------------------
	SELECT	A.Time_Idx
			,B.BankParticularAccount_Type
			,A.[Value]
			--,C.IndustryGroup
			,D.PFSParticularName
			--SUM(A.[VALUE])
	FROM [dbo].[S_Fact_MFSG_STATBUL_BANKSBALANCESHEET] A
	JOIN EDW.[dbo].[Dim_STATBUL_BanksParticularAccount] B
	ON a.BankParticularAccount_Idx = b.BankParticularAccount_Idx
	JOIN EDW.[dbo].[Dim_STATBUL_Industry] C
	ON A.Industry_idx = C.Industry_Idx
	JOIN [Test].[dbo].[PFSParticular] D
	ON C.IndustryGroup = D.PFSParticularDesc

	--------------------------------------------------------
	UNION ALL
	-------3 NBFIs------------------------------------------

	SELECT	 A.Time_idx
			,C.Particular_Type
			,A.Amount
			,E.PFSParticularName
			--SUM(A.[AMOUNT])
	FROM [dbo].[S_Fact_MFSG_NBFI] A
	JOIN EDW.[dbo].[Dim_NBFIBankKind] B
	ON A.BankIndustry_idx = B.NBFIBankKind_Idx
	join EDW.[dbo].[Dim_NBFIParticular] C
	ON A.NBFIParticular_Idx = C.NBFIParticular_Idx
	Join [Test].[dbo].[PFSParticular] E
	ON B.NBFIBankKind_Name = E.PFSParticularDesc

	-------------------------------------------------------
	-------4 combine the dimension-------------------------
	SELECT A.time_idx, A.group_type, A.Amount, A.Pfs_type 
	--,B.statementName ,B.[StatementParticular]
	INTO #TempStorageFPS1
	FROM #TempStorageFPS A
	left join EDW.[dbo].[Dim_STATBUL_StatementType] B
	ON A.PFS_TYPE = B.[StatementParticular]
	AND A.Group_type = B.statementName

	------------------------------------------------------
	------------------------------------------------------
	---------Insert Into Staging Fact table---------------
	SELECT * FROM #TempStorageFPS1

	SELECT sum(amount) FROM #TempStorageFPS1


	INSERT INTO [EDW_Staging].[dbo].[S_Fact_MFSG_PFS] 
			([Time_idx]
			,[SALN_type]
			,[Value]
			,[PFSIndustryType]
			)
	SELECT TIME_IDX
			,GROUP_TYPE
			,AMOUNT
			,PFS_TYPE
	FROM #TempStorageFPS1


	--SELECT * FROM [EDW].[dbo].[Fact_MFSG_STATBUL_PFS]
	--SELECT * FROM [EDW_Staging].[dbo].[S_Fact_MFSG_PFS] 