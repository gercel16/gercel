/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [InstitutionCode]
      ,[InstitutionName]
      ,[InstitutionLevel]
      ,[InstitutionGroup]
      ,[InstitutionSort]
  FROM [Test].[dbo].[Institution]

  SELECT * 
  FROM [EDW].[dbo].[Dim_STATBUL_Institution]

  INSERT INTO [EDW].[dbo].[Dim_STATBUL_Institution] 
  (	[InstitutionCode]
      ,[InstitutionName]
      ,[InstitutionLevel]
      ,[InstitutionGroup]
      ,[InstitutionSort]
  )
  SELECT [InstitutionCode]
      ,[InstitutionName]
      ,[InstitutionLevel]
      ,[InstitutionGroup]
      ,[InstitutionSort]
  FROM [Test].[dbo].[Institution]