---------1---------------
drop table #TempStorage

--- Convert Amount to numeric

select ID,
	TRDATE
	,BNKIND as 'BANKINDUSTRY'
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE(AMT, ',', '')) AMOUNT
	,'Particular' = [DESC]
	,'Particular_code' = [DESC] + 'IH'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME) 
	,'Table' = 'IH'
	into #TempStorage

	from [dbo].[Dump_MFSG_NBFIs_FSRLIB2_NBFPF00]

	union 

select ID,
	TRDATE
	,BNKIND as 'BANKINDUSTRY'
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE(AMT, ',', '')) AMOUNT,
	'Particular' = [DESC]
	,'Particular_code' = [DESC] + 'FC'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
	,'Table' = 'FC'
	from [dbo].[Dump_MFSG_NBFIs_FSRLIB2_NBFPI00]

--	union

--select ID,
--	TRDATE
--	,'0' as 'BANKINDUSTRY' 
--	,'0' as RECNO
--	,SCHNO
--	,CONVERT(DECIMAL(18,2), REPLACE([TOTAMT], ',', '')) AMOUNT,
--	'Particular' = [DETAIL1]
--	,'Particular_code' = [DETAIL1] + 'NSSLA'
--	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
--	,'Table' = 'NSSLA'
--	from [dbo].[Dump_MFSG_NBFIs_FRPNSSLA_BS]

	GO


select distinct(Particular), [table] from #TempStorage
order by [Table]
--------2-----------------------------------------------
--1283
-- DIVIDE AMOUNT TO 1000 IH and FC

DROP TABLE #TempStorage1

	SELECT 
	 DATE_CODE
	,BANKINDUSTRY
	,Particular
	,Particular_code
	,'AMOUNT' = sum (AMOUNT)/1000  
	INTO #TempStorage1
	FROM #TempStorage 
	GROUP BY Particular,DATE_CODE,BANKINDUSTRY,Particular_code

	SELECT * FROM #TempStorage1
GO
----------4----------------------------------------
--Data consolidation of NSSLA
drop table #TempStorage2

--select ID,
--	TRDATE
--	,'NSSLA' as 'BANKINDUSTRY' 
--	,'0' as RECNO
--	,SCHNO
--	,CONVERT(DECIMAL(18,2), REPLACE([TOTAMT], ',', '')) AMOUNT,
--	'Particular' = [DETAIL1]
--	,'Particular_code' = [DETAIL1] + 'NSSLA'
--	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
--	,'Table' = 'NSSLA'
--	into #TempStorage2
--	from [dbo].[Dump_MFSG_NBFIs_FRPNSSLA_BS]
------------3----------------------------------------
---- DIVIDE AMOUNT TO 1000000 NSLLA

--DROP TABLE #TempStorage3

--	SELECT 
--	 DATE_CODE
--	,BANKINDUSTRY
--	,Particular
--	,Particular_code
--	,'AMOUNT' = sum (AMOUNT)/1000000  
--	INTO #TempStorage3
--	FROM #TempStorage2 
--	GROUP BY Particular,DATE_CODE,BANKINDUSTRY,Particular_code

	select * from #TempStorage3
----------4------------------------------------------
Select * from #TempStorage1 A left outer join #TempStorage3 B



-----------------------------------------------------
--Connect to Dimension 

--SELECT * FROM #TempStorage1

	SELECT 
	B.Time_idx
	,C.[NBFIParticular_Idx]
	,C.[Particular_Group]
	,C.[Particular_Type]
	,A.BANKINDUSTRY
	,A.Particular 
	,A.AMOUNT
	FROM #TempStorage1 A
	LEFT OUTER JOIN [EDW_DIM_Standard].[dbo].[Dim_Time] B
	ON A.DATE_CODE = B.Date_Code
	LEFT OUTER JOIN  [EDW].[dbo].[Dim_NBFIParticular] C
	ON A.Particular_code = C.[Particular_Code]
	--LEFT OUTER JOIN [EDW].[dbo].[Dim_NBFIBankKind] D
	--ON A.BANKINDUSTRY = D.[NBFIBankKind_Code]
	--where C.[Particular_Group] = 'null'

	--GROUP BY A.Particular,A.DATE_CODE,A.BANKINDUSTRY



	SELECT * FROM #TempStorage1

---------4---------------------------------



----------3--------------------------------------------
