/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Time_idx]
      ,[BankParticularAccount_Idx]
      ,[Industry_idx]
      ,[Bank_Code]
      ,[Sched_No]
      ,[RecNo]
      ,[Value]
  FROM [EDW].[dbo].[Fact_MFSG_STATBUL_TAB1_51_52_53_BS]