   select * from [dbo].[Dump_ESLIG_Capita_Food_Threshold]
		   select * from [dbo].[Dump_ESLIG_Capita_Poverty_Threshold]
		   select * from [dbo].[Dump_ESLIG_Poverty_Incidence]

		   select * from [dbo].[Dump_ESLIG_Capita_Food_Threshold] where [Column2] <> '' and [column4] <> ''
		   select * from [dbo].[Dump_ESLIG_Capita_Food_Threshold] where  [column4] <> ''

		   Select case when [Column1] <> '' then [Column1] else '0' end Location,
		   case when [Column1] <> '' then [Column2] else '0' end '2018',
		    case when [Column1] <> '' then [Column3] else '0' end '2020'
		   from [dbo].[Dump_ESLIG_Capita_Food_Threshold] where [Column1] <>''

-------------------------------------------------------------------1
Select * into #tempTable1 from (
		   Select 
		   case when [Column1] <> '' then [Column1] else '0' end Location,
		   case when [Column1] <> '' then [Column2] else '0' end 'Value_1',
		   '2018' as year
		 --  into #tempTable
		   from [dbo].[Dump_ESLIG_Capita_Food_Threshold] where [Column1] <>'' and [Column2] <> '' 
		  -- Select * from #tempTable
union all
		   Select 
		   case when [Column1] <> '' then [Column1] else '0' end Location,
		   case when [Column1] <> '' then [Column3] else '0' end 'Value_1',
		   '2021' as year
		   from [dbo].[Dump_ESLIG_Capita_Food_Threshold] where [Column1] <>'' and [Column2] <> ''
		   ) as temp
		   
Select * from #tempTable1 
---------------------------------------------------------------------2


select * into  #tempTable2 from (Select replace(replace(replace(replace(location, ' a/b/', ''), ' b/', ''), ' a/', ''),'*','') as N_Location
,(select replace(Value_1, ',','.')) as value
, [year]
from #tempTable1 where Value_1 <> '' and Location != 'Region/Province') as temp2

select * from #tempTable2

--------------------------------------------------------------------3

-- drop table #TempTable2
-- drop table #TempTable1
select [value], CONVERT(numeric(38,2),[value]) as converted_val 
from #tempTable2

--------------------------------------------------------------------4

insert into [dbo].[S_Fact_Poverty] (City_Code,Time_Code,PerCapitaFoodThresholdinPesos)
Select N_Location,[YEAR],[value]
From #tempTable2

