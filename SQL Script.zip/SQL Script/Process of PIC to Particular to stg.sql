	DECLARE @CASH numeric(18,2) -- CASH
	DECLARE @COCI numeric(18,2) -- Checks and other Cash Items
	DECLARE @DCB numeric(18,2) -- Due from BSP
	DECLARE @DFB numeric(18,2) -- Due from Banks
	DECLARE @LD numeric(18,2) -- Loans and Discounts
	DECLARE @INV numeric(18,2) -- Investments in Bonds and Securities
	DECLARE @BHFF numeric (18,2) -- Real Property, Furniture, Fixture, and Equipment
	DECLARE @ROPOA numeric (18,2) --Real and Other Properties Owned or Acquired
	DECLARE @OA numeric (18,2)  -- Other Assetts
	DECLARE @BP numeric(18,2) --Bills Payable'
	DECLARE @OL numeric(18,2) -- Other Liabilities
	DECLARE @CS numeric(18,2) --Capital Stock
	DECLARE @SRUP numeric(18,2) --Surplus, Reserves and Undivided Profits
	DECLARE @TA numeric(18,2) -- Total Assets
	DECLARE @TL numeric(18,2) -- Total Liabilities
	DECLARE @TNW numeric(18,2) -- Total Net WOrth
	DECLARE @TLNW numeric(18,2) -- Total Liabilities  and Net Worth
		DECLARE @LPR numeric(18,2) -- Legal Policy Reserves
	DECLARE @TIME_CODE int -- TIMECODE


	Select * into #tempTablePIC from (
		  Select Id,
			CASE When Column1 <> '' then Column1 end 'PARTICULAR',
			REC = '',
			'AMOUNT' =  
					CASE 
					WHEN [Column4] = '.' THEN '0.0' 
					WHEN ISNUMERIC([Column4]) = 1 THEN [Column4]    
			
				ELSE '0.0' 
				end 	
			,
			(select SUBSTRING((Select column1 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),47,4)) as YEAR,
			(select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2),26,3))  AS MONTH,
			'LIFE' as CSOC_REPORT,
			Time_code = (Select top 1 Time_Idx from [EDW].[dbo].[Dim_Time] 
			where year like (
			select SUBSTRING((Select column1 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),47,4))
			)

	FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
	where [column1] <> ''  and [Column4] <> ''
	order by ID OFFSET 1 ROWS

union all 

	Select id,
		CASE When Column6 <> '' then Column6 end 'PARTICULAR',
		REC = '',
		'AMOUNT' =  
				CASE 
				WHEN [Column12] = '.' THEN '0.0' 
				WHEN ISNUMERIC([Column12]) = 1 THEN [Column12]    
			
			ELSE '0.0' 
			end 
		,
		(select SUBSTRING((Select column6 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),78,4)) as YEAR,
		(select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2),26,3))  AS MONTH,
		'NON-LIFE' as CSOC_REPORT,
		Time_code = (Select top 1 Time_Idx from [EDW].[dbo].[Dim_Time] 
		where year like (
		select SUBSTRING((Select column6 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),78,4))
		)

	FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
	where [column6] <> ''  and [Column12] <> ''

) as temp


select * into #TempPIC from  ( 
Select CONVERT(DECIMAL(18,2), REPLACE(AMOUNT, ',', '')) AMOUNT, ID, PARTICULAR,
REC, [YEAR], [MONTH], CSOC_REPORT, TIME_CODE from #tempTablePIC) as TT



--select * from #TempPIC 
------------------------------------------------------------------------------------------
Set @TIME_CODE =  (Select top 1  TIME_CODE from #TempPIC 
where  CSOC_REPORT like '%LIFE%')

------------------------------------------------------------------------------------------
		create  table #TempStorePIC (
		[ID] [int] IDENTITY(1,1) NOT NULL
		, Particular nvarchar(210)
		, AMOUNT numeric(18,2)
		,Time_Code int,
		ReportName nvarchar (210)
		)
------------------------------------------------------------------------------------------
			-- Output 1
			---
Set @CASH = (Select sum (AMOUNT) as 'CASH'  from #TempPIC  
			where PARTICULAR in ('Cash on Hand & in Banks','Cash on Hand & in Banks')
			group by [Year], [month]
			)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('CASH', @CASH, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------
			--output 2
Set @LD	 = (Select sum (AMOUNT) as 'Loans and Discounts'  from #TempPIC  
			where PARTICULAR in ('Loans and Receivables','Loans and Receivables')
			group by [Year], [month] 
			)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Loans and Discounts', @LD, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

			--output3
Set @INV = (Select sum (AMOUNT) as 'Investments in Bonds and Securities'   from #TempPIC  
			where PARTICULAR in ('Financial Assets at FVPL','Financial Assets at FVPL'
			,'Held-to-Maturity (HTM) Investments','Held-to-Maturity (HTM) Investments'
			,'Available for Sale (AFS) Financial Assets','Available for Sale (AFS) Financial Assets'
			,'Investments in Subsidiaries, Associates and Joint Ventures','Investments in Subsidiaries, Associates and Joint Ventures'
			,'Segregated Fund Assets','Segregated Fund Assets'
			,'Derivative Assets Held for Hedging','Derivative Assets Held for Hedging')
			group by [Year], [month]
			)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Investments in Bonds and Securities', @INV, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

			--output4
Set @BHFF = (Select sum (AMOUNT) as 'Real Property, Furniture, Fixture, and Equipment'  from #TempPIC  
			where PARTICULAR in ('Investment Property','Investment Property'
			,'Property and Equipment','Property and Equipment')
			group by [Year], [month]
			)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Real Property, Furniture, Fixture, and Equipment', @BHFF, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

			--output5
Set @OA =   (Select sum (AMOUNT) as 'Other Assets'  from #TempPIC  
			where PARTICULAR in ('Investments Income Due and Accrued','Investments Income Due and Accrued'
			,'Accounts Receivables','Accounts Receivables'
			,'Premiums Due and Uncollected','Premiums Due and Uncollected'
			,'Due From Ceding Companies, net','Due From Ceding Companies, net'
			,'Funds Held by Ceding Companies, net','Funds Held by Ceding Companies, net'
			,'Amounts Recoverable from Reinsurers, net','Amounts Recoverable from Reinsurers, net'
			,'Security Fund Contribution','Security Fund Contribution'
			,'Other Assets','Other Assets'
			,'Premiums Receivable, net','Premiums Receivable, net'
			,'Loss Reserve Withheld by Ceding Companies, net','Amounts Recoverable from Reinsurers, net'
			,'Other Reins. Accts. Receivable, net','Surety Losses Recoverable'
			,'Investments Income Due and Accrued','Accounts Receivable')
			group by [Year], [month]
			)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Other Assets', @OA, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

			--output6
Set @BP =   (Select sum (AMOUNT) as 'Bills Payable'  from #TempPIC  
			where PARTICULAR in ('Accounts/Notes Payable','Notes Payable','Notes Payable')
			group by [Year], [month]
			)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Bills Payable', @BP, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

			--output7
Set @LPR =   (Select sum (AMOUNT) as 'Legal Policy Reserves'  from #TempPIC  
			where PARTICULAR in ('Legal Policy Reserves','Claims Liabilities','Premium Liabilities')
			group by [Year], [month]
			)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Legal Policy Reserves', @LPR, @TIME_CODE,'PIC')

------------------------------------------------------------------------------------------

			--output8
set @OL	=	(Select sum (AMOUNT) as 'Other Liabilities'  from #TempPIC  
			where PARTICULAR in ('Policy & Contract Claims/Maturities and Surrenders Payables'
			,'Due to Reinsurers','Due to Reinsurers'
			,'Premium Liabilities','Segregated Funds Liabilities'
			,'Funds Held for Reinsurers','Funds Held for Reinsurers'
			,'Life Insurance/ Applicants/ Remittances Unapplied Deposits','Premium Deposit Fund'
			,'Premium Received in Advance','Policyholders Dividend Due & Unpaid/ Accumulation'
			,'Commissions  Payable','Return Premiums Payable','Return Premiums Payable'
			,'Taxes Payable','Deposit for Real Estate Under Contract of Sell'
			,'Dividends Payable','Dividends Payable'
			,'Pension Obligation','Accrual for Long-term Employee Benefits'
			,'Accrued Expenses','Accrued Expenses'
			,'Derivative Liabilities Held for Hedging','Derivative Liabilities Held for Hedging'
			,'Other Liabilities','Other Liabilities'
			,'Commissions Payable','Taxes/Licenses Payable'
			,'Deposit for Real Estate under Contract to Sell','Cash Collaterals'
			,'Account Payable','Financial Liabilities at Fair Value Through Profit and Loss')
			group by [Year], [month]
			)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Other Liabilities', @OL, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

			--output9
set @CS	 =  (Select sum (AMOUNT) as 'Capital Stock'  from #TempPIC  
			where PARTICULAR in ('Paid-Up Capital/Statutory Deposits','Paid-Up Capital/Statutory Deposits'
			,'Capital Stock Subscribed','Capital Stock Subscribed'
			,'Capital Paid-In Capital Excess of Par','Deposit for  Future Subscription','Capital Paid in Excess of Par'
			,'Cost of Share-Based Payment','Cost of Share-Based Payment'
			,'Treasury stock','Treasury stock'
			,'Paid-Up Capital/Statutory Deposits','Paid-Up Capital/Statutory Deposits'
			,'Capital Stock Subscribed','Capital Stock Subscribed'
			,'Cost of Share-Based Payment','Cost of Share-Based Payment'
			,'Treasury Stock','Treasury Stock')
			group by [Year], [month]
			)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Capital Stock', @CS, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

			--output10
Set @SRUP = (Select sum (AMOUNT) as 'Surplus, Reserves and Undivided Profits'  from #TempPIC  
			where PARTICULAR in ('Statutory Deposit','Contributed Surplus'
			,'Contingency Surplus/Home Office Inward Remittances','Retained Earnings/ Home Account Office'
			,'Reserve Accounts','Reserve Accounts'
			,'Remeasurement Gains(losses) on Retirement Pension Asset (Obligation)','Contributed Surplus/Home Office Inward Remittances'
			,'Contingency Surplus','Retained Earnings/Home Office Account'
			,'Total Reserve Accounts','Remeasurement Gains(Losses) on Retirement, Pension Asset (Obligation)')
			group by [Year], [month]
			)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Surplus, Reserves and Undivided Profits', @SRUP, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

			--Output11
Set @TA   = (@CASH + @LD + @INV + @BHFF + @OA)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Total Assets', @TA, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

Set @TL  = (@BP + @LPR + @OL)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Total Liabilities', @TL, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

Set @TNW = (@CS + @SRUP)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Total Net Worth', @TNW, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------

Set @TLNW = (@TL + @TNW)

insert into #TempStorePIC (Particular,AMOUNT, Time_Code,ReportName)
Values ('Total Liabilities and Net Worth', @TLNW, @TIME_CODE,'PIC')

-----------------------------------------------------------------------------------------
--drop table #TempPIC
--drop table #TempStorePIC
--drop table #tempTablePIC

-----------------------------------Insert in Stg Fact Table ALL---------------------------------

insert into [EDW_Staging].[dbo].[S_Fact_MFSG_NBFIs_STG_ALL] ([Particular],[Value],[NBFIsReport],[Time_Code])
(Select Particular,AMOUNT,ReportName,Time_Code from #TempStorePIC) 

-------------------------------------------------------------------------------------------------
-----------------------------------Insert in Stg Fact Table NBFIs--------------------------------

insert into [EDW_Staging].[dbo].S_Fact_MFSG_NBFIs (Particular,[Value], Time_Code,[NBFIsReport])
(Select Particular,AMOUNT,Time_Code,'Tab 2.5' from #TempStorePIC) 



--select * from #TempStorePIC