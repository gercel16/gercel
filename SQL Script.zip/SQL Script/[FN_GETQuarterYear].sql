USE [EDW_Staging]
GO

/****** Object:  UserDefinedFunction [dbo].[FN_GETQuarterYear]    Script Date: 09/08/2022 4:12:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [dbo].[FN_GETQuarterYear](@Column varchar(500))  
RETURNS nvarchar(100)
AS
BEGIN
    RETURN
        CASE 
             WHEN @Column = 'Column3'  THEN (SELECT Column3 + '-03-31' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column4'  THEN (SELECT Column3 + '-06-30' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column5'  THEN (SELECT Column3 + '-09-30' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column6'  THEN (SELECT Column3 + '-12-31' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 
			 WHEN @Column = 'Column7'  THEN (SELECT Column7 + '-12-31' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column8'  THEN (SELECT Column7 + '-06-30' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column9'  THEN (SELECT Column7 + '-09-30' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column10'  THEN (SELECT Column7 + '-12-31' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 
			 WHEN @Column = 'Column11'  THEN (SELECT Column11 + '-03-31' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column12'  THEN (SELECT Column11 + '-06-30' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column13'  THEN (SELECT Column11 + '-09-30' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column14'  THEN (SELECT Column11 + '-12-31' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 
			 WHEN @Column = 'Column15'  THEN (SELECT Column15 + '-03-31' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column16'  THEN (SELECT Column15 + '-06-30' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column17'  THEN (SELECT Column15 + '-09-30' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column18'  THEN (SELECT Column15 + '-12-31' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
				 
			 WHEN @Column = 'Column19'  THEN (SELECT Column19 + '-03-31' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column20'  THEN (SELECT Column19 + '-06-30' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column21'  THEN (SELECT Column19 + '-09-30' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column22'  THEN (SELECT Column19 + '-12-31' from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			
			 WHEN @Column = 'Column23'  THEN (SELECT Column23 from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column24'  THEN (SELECT Column23 from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column25'  THEN (SELECT Column23 from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 WHEN @Column = 'Column26'  THEN (SELECT Column23 from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
			 
			 --WHEN @Column = 'Column27'  THEN (SELECT Column27 from [Dump_ESLIG_InlandCommercialFisheries_VolumeProduction] where ID =2 )
            ELSE '1970'
        END 
END
GO


