/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Time_idx]
      ,[RESPONSECODE]
      ,[ASSET_SIZE]
      ,[Values]
	--INTO  #TEMP1
  FROM [EDW_Staging].[dbo].[S_Fact_MFSG_SLOS_ADDITIONAL_RESULTS] A
  --JOIN EDW.[dbo].[Dim_SLOS_LVT] B
  --ON A.[RESPONSECODE] = B.[LVTGROUP]
  JOIN EDW.[dbo].[Dim_SLOS_AssetSizeType] C
  ON A.[RESPONSECODE] = C.[AssetSizeGroup]

  SELECT TOP (1000) [Time_idx]
      ,[RESPONSECODE]
      ,[ASSET_SIZE]
      ,[Values]
	INTO  #TEMP2
  FROM [EDW_Staging].[dbo].[S_Fact_MFSG_SLOS_ADDITIONAL_RESULTS] A
  JOIN EDW.[dbo].[Dim_SLOS_LVT] B
  ON A.[RESPONSECODE] = B.[LVTGROUP]

  SELECT * FROM #TEMP1
  UNION ALL
  SELECT * FROM #TEMP2

  insert into [EDW].[dbo].[Dim_SLOS_AssetSize_LVT]
  (
[ASSETTYPE_LVTCode],
[ASSETTYPE_LVTName],
[ASSETTYPE_LVTNameDesc],
[ASSETTYPE_LVTGroup],
[ASSETTYPE_LVTSort]
  )
  select * from TEST.[dbo].[Dim_SLOS_AssetSize_LVT]