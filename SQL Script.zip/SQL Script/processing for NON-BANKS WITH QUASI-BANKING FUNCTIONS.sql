	------------------------------------------
	----Table transaction for the Table 2.6 (NON-BANKS WITH QUASI-BANKING FUNCTIONS)---
	------------------------------------------
	
	
	DECLARE @CASH numeric(18,2) -- CASH
	DECLARE @COCI numeric(18,2) -- Checks and other Cash Items
	DECLARE @DCB numeric(18,2) -- Due from BSP
	DECLARE @DFB numeric(18,2) -- Due from Banks
	DECLARE @LD numeric(18,2) -- Loans and Discounts
	DECLARE @INV numeric(18,2) -- Investments in Bonds and Securities
	DECLARE @BHFF numeric (18,2) -- Real Property, Furniture, Fixture, and Equipment
	DECLARE @ROPOA numeric (18,2) --Real and Other Properties Owned or Acquired
	DECLARE @OA numeric (18,2)  -- Other Assetts
	DECLARE @BP numeric(18,2) --Bills Payable'
	DECLARE @OL numeric(18,2) -- Other Liabilities
	DECLARE @CS numeric(18,2) --Capital Stock
	DECLARE @SRUP numeric(18,2) --Surplus, Reserves and Undivided Profits
	DECLARE @TA numeric(18,2) -- Total Assets
	DECLARE @TL numeric(18,2) -- Total Liabilities
	DECLARE @TNW numeric(18,2) -- Total Net WOrth
	DECLARE @TLNW numeric(18,2) -- Total Liabilities  and Net Worth
	DECLARE @LPR numeric(18,2) -- Legal Policy Reserves
	DECLARE @TIME_CODE int -- TIMECODE

	---------------------------------------------------------------------

		create  table #TempStoreNBwQB_CSOC (
		[ID] [int] IDENTITY(1,1) NOT NULL
		, Particular nvarchar(210)
		, AMOUNT numeric(18,2)
		,Time_Code int,
		ReportName nvarchar (210)
		)

	---------------------------------------------------------------------

set @TIME_CODE = (select top 1 t1.Time_Code from [S_Fact_MFSG_NBFIs_STG_ALL] T1
				join [S_Fact_MFSG_NBFIs_STG_ALL] T2
				on T1.Time_Code = T2.Time_Code
				where T1.NBFIsReport in ('IHwQB','FCwQB') and T2.NBFIsReport in ('IHwQB','FCwQB'))

	---------------------------------------------------------------------
	---------------------------Getting for values------------------

 --Select * from  [dbo].[S_Fact_MFSG_NBFIs_STG_ALL] where NBFIsReport in ('IHwQB','FCwQB')
 --Select * from  [dbo].[S_Fact_MFSG_NBFIs_STG_ALL] where NBFIsReport in ('IHwQB','FCwQB') and Particular = 'CASH'

 --output1
 	DECLARE @CASH numeric(18,2) -- CASH
set @CASH = (
		Select sum ([Value]) as 'CASH'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('CASH')
		and NBFIsReport in ('IHwQB','FCwQB')
		)


--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT, Time_Code,ReportName)
Values ('CASH', @CASH, @TIME_CODE,'NBwQB')

select * from #TempStoreNBwQB_CSOC

--output2
set @COCI = (
		Select sum ([Value]) as 'Checks and other Cash Items'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Checks and other Cash Items')
		and NBFIsReport in ('IHwQB','FCwQB')
		)

--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Checks and other Cash Items', @COCI, @TIME_CODE,'NBwQB')

--output3
set @DCB = (
		Select sum ([value]) as 'Due from BSP'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Due from BSP')
		and NBFIsReport in ('IHwQB','FCwQB')
		)

--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Due from BSP', @DCB, @TIME_CODE,'NBwQB')

--output4
set @DFB = (
		Select sum ([value]) as 'Due from Banks'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Due from Banks')
		and NBFIsReport in ('IHwQB','FCwQB')
		)
  --Select * from  [dbo].[S_Fact_MFSG_NBFIs_STG_ALL] where NBFIsReport in ('IHwQB','FCwQB') and Particular = 'Due from Banks'

--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Due from Banks', @DFB, @TIME_CODE,'NBwQB')

--output5
set @LD = (
		Select sum ([value]) as 'Loans and Discounts'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Loans and Discounts')
		and NBFIsReport in ('IHwQB','FCwQB')
		)

--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Loans and Discounts', @LD, @TIME_CODE,'NBwQB')

--output6
set @INV = (
		Select sum ([value]) as 'Investments in Bonds and Securities'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Investments in Bonds and Securities')
		and NBFIsReport in ('IHwQB','FCwQB')
		)
	--Select * from  [dbo].[S_Fact_MFSG_NBFIs_STG_ALL] where NBFIsReport in ('IHwQB','FCwQB') and Particular = 'Investments in Bonds and Securities'	
--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Investments in Bonds and Securities', @INV, @TIME_CODE,'NBwQB')

--output7 
Set @BHFF = (
		Select sum ([value]) as 'Real Property, Furniture, Fixture, and Equipment'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Real Property, Furniture, Fixture, and Equipment')
		and NBFIsReport in ('IHwQB','FCwQB')
		)


--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Real Property, Furniture, Fixture, and Equipment', @BHFF, @TIME_CODE,'NBwQB')

--output8 

Set @ROPOA = (
		Select sum ([value]) as 'Real and Other Properties Owned or Acquired'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Real and Other Properties Owned or Acquired')
		and NBFIsReport in ('IHwQB','FCwQB')
		)

--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Real and Other Properties Owned or Acquired', @ROPOA, @TIME_CODE,'NBwQB')


--output9 
set @OA = (
		Select sum ([value]) as 'Other Assets'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Other Assets')
		and NBFIsReport in ('IHwQB','FCwQB')
		)

--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Other Assets', @OA, @TIME_CODE,'NBwQB')

--output10 
set @BP = (
		Select sum ([value]) as 'Bills Payable'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Bills Payable')
		and NBFIsReport in ('IHwQB','FCwQB')
		)

insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Bills Payable', @BP, @TIME_CODE,'NBwQB')

--output11 
set @OL = (
		Select sum ([value]) as 'Other Liabilities'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Other Liabilities')
		and NBFIsReport in ('IHwQB','FCwQB')
		)
	--Select * from  [dbo].[S_Fact_MFSG_NBFIs_STG_ALL] where NBFIsReport in ('IHwQB','FCwQB') and Particular = 'Other Liabilities'	

--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Other Liabilities', @OL, @TIME_CODE,'NBwQB')

--output12
Set @CS = (
		Select sum ([value]) as 'Capital Stock'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Capital Stock') 
		and NBFIsReport in ('IHwQB','FCwQB')
		)

--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
Values ('Capital Stock', @CS, @TIME_CODE,'NBwQB')

--output13 
Set @SRUP = (
		Select sum ([value]) as 'Surplus, Reserves and Undivided Profits'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Surplus, Reserves and Undivided Profits')
		and NBFIsReport in ('IHwQB','FCwQB')
		)
--Select * from  [dbo].[S_Fact_MFSG_NBFIs_STG_ALL] where NBFIsReport in ('IHwQB','FCwQB') and Particular = 'Surplus, Reserves and Undivided Profits'	

		--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Surplus, Reserves and Undivided Profits', @SRUP, @TIME_CODE,'NBwQB')

		--Output14 (Total)
Set @TA = (
		Select sum ([value]) as 'Total Assets'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Total Assets')
		and NBFIsReport in ('IHwQB','FCwQB')
		)

--Select * from  [dbo].[S_Fact_MFSG_NBFIs_STG_ALL] where NBFIsReport in ('IHwQB','FCwQB') and Particular = 'Total Assets'	

		--INSERT
		insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Assets', @TA, @TIME_CODE,'NBwQB')



		--Output15 (Total)
Set @TL = (
		Select sum ([value]) as 'Total Liabilities'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Total Liabilities')
		and NBFIsReport in ('IHwQB','FCwQB')
		)

--Select * from  [dbo].[S_Fact_MFSG_NBFIs_STG_ALL] where NBFIsReport in ('IHwQB','FCwQB') and Particular = 'Total Liabilities'

		--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Liabilities', @TL, @TIME_CODE,'NBwQB')

		--Output16 (total)
Set @TNW = (
		Select sum ([value]) as 'Total Net Worth'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Total Net Worth')
		and NBFIsReport in ('IHwQB','FCwQB')
		)

--Select * from  [dbo].[S_Fact_MFSG_NBFIs_STG_ALL] where NBFIsReport in ('IHwQB','FCwQB') and Particular = 'Total Net Worth'


		--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Net Worth', @TNW, @TIME_CODE,'NBwQB')

		--Output17 (total)
Set @TLNW = (
		Select sum ([value]) as 'Total Liabilities and Net Worth'  from [S_Fact_MFSG_NBFIs_STG_ALL]  
		where PARTICULAR in ('Total Liabilities and Net Worth')
		and NBFIsReport in ('IHwQB','FCwQB')
		)
		--INSERT
insert into #TempStoreNBwQB_CSOC (Particular,AMOUNT,Time_Code,ReportName)
		Values ('Total Liabilities and Net Worth', @TLNW, @TIME_CODE,'NBwQB')