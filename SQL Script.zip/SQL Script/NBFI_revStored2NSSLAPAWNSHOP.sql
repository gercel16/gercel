
--------1-----------------------------------------------------
--consolidation per particular
drop table #TempStorage

select ID,
	TRDATE
	,'PAWNSHOP' as 'BANKINDUSTRY' 
	,'0' as RECNO
	,SCHNO
	,'AMOUNT' = 
		CASE 
			WHEN AMOUNT = '.' THEN '0.0' 
			WHEN ISNUMERIC(AMOUNT) = 1 THEN AMOUNT  		
		ELSE '0.0'
		end
	--,CONVERT(DECIMAL(18,2), REPLACE(AMOUNT, ',', '')) AMOUNT
	,'Particular' = [DETAIL1]
	,'Particular_code' = [DETAIL1] + 'PAWNSHOP'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
	,'Table' = 'PAWNSHOP'
	into #TempStorage	

	from[dbo].[Dump_MFSG_NBFIs_PAWNSHOP_GLSLLIB2_NBPWNFS2]

	union

	select ID,
	TRDATE
	,'NSSLA' as 'BANKINDUSTRY' 
	,'0' as RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE([TOTAMT], ',', '')) AMOUNT,
	'Particular' = [DETAIL1]
	,'Particular_code' = [DETAIL1] + 'NSSLA'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
	,'Table' = 'NSSLA'
	from [dbo].[Dump_MFSG_NBFIs_FRPNSSLA_BS]

	------------------------------------------------------------------------
	-- converting the Amount to numeric
	drop table #TempStorage1


	select ID,
	TRDATE
	,BANKINDUSTRY
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE([AMOUNT], ',', '')) AMOUNT
	,Particular
	,Particular_code
	,DATE_CODE
	,[Table]
	into #TempStorage1
	from #TempStorage

	------------------------------------------------------------------------
	--- divide to 1000000
	Select * from #TempStorage1

	--drop table #TempStorage2

	SELECT 
	 DATE_CODE
	,BANKINDUSTRY
	,Particular
	,Particular_code
	,AMOUNT = sum (AMOUNT)/1000000  
	INTO #TempStorage2
	FROM #TempStorage1
	GROUP BY Particular,DATE_CODE,BANKINDUSTRY,Particular_code

	select * from #TempStorage2

	-----------------------------------------------------------
	--Join the dimension
	SELECT 
	B.Time_idx
	,C.[NBFIParticular_Idx]
	,C.[Particular_Group]
	,C.[Particular_Type]
	,A.BANKINDUSTRY
	,A.Particular 
	,A.AMOUNT
	FROM #TempStorage2 A
	LEFT OUTER JOIN [EDW_DIM_Standard].[dbo].[Dim_Time] B
	ON A.DATE_CODE = B.Date_Code
	LEFT OUTER JOIN  [EDW].[dbo].[Dim_NBFIParticular] C
	ON A.Particular_code = C.[Particular_Code]



	--select ID,
	--TRDATE
	--,'0' as 'BANKINDUSTRY' 
	--,'0' as RECNO
	--,SCHNO
	--,CONVERT(DECIMAL(18,2), REPLACE([TOTAMT], ',', '')) AMOUNT,
	--'Particular' = [DETAIL1]
	--,'Particular_code' = [DETAIL1] + 'NSSLA'
	--,'DATE_CODE' = CAST(TRDATE AS DATETIME)
	--,'Table' = 'NSSLA'
	----into #TempStorage2
	--from [dbo].[Dump_MFSG_NBFIs_FRPNSSLA_BS]
