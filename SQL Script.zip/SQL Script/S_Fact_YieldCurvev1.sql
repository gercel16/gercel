USE [EDW_Staging]
GO

/****** Object:  StoredProcedure [dbo].[INS_S_FACT_YIELCURVE]    Script Date: 09/13/2022 11:28:21 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

alter PROCEDURE [dbo].[INS_S_FACT_YIELCURVE] 
as
TRUNCATE TABLE S_Fact_YieldCurve;

insert into S_Fact_YieldCurve
SELECT dt.Time_Idx, Tenor_Code, BVALRate, BVALRateDiff from (
select (SELECT  top 1 cast(REPLACE(RIGHT(Column1,22),'.','') as date) AS DATE FROM EDW_SOURCE.dbo.[Dump_ESLIG_YieldCurve]) as Date, 
Column1 AS Tenor_Code, CAST(Column2 AS DECIMAL(7,4) ) as BVALRate, CAST(Column2 AS DECIMAL(7,4) ) - CAST(Column3 AS DECIMAL(7,4) ) AS BVALRateDiff
from EDW_SOURCE.dbo.[Dump_ESLIG_YieldCurve]
where Column2 is not null and Column2 <>'') main
inner join EDW.dbo.DIM_TIME dt on CAST(dt.ActualDate as date) = main.Date

GO


