SELECT TOP (1000) [Manufacturing]
      ,[RetailWholesale]
      ,[Services]
      ,[Composite]
      ,[Time_Code]
  FROM [EDW_Staging].[dbo].[S_Fact_ESLIG_PMI]


---------------------------1----------------------------
Select * into #TempSPG from (
select [Value] as 'SPGlobal', Time_Idx  from [dbo].[S_Fact_ESLIG_PMI_SPGLobal] ) as SPG

--select * from #TempSPG
--select * from [S_Fact_ESLIG_PMI_SPGLobal]

----------------------------2--------------------------
Select * into #TempPMISPG from (
select * from  [S_Fact_ESLIG_PMI] A
full join #TempSPG B
on A.Time_code = B.Time_Idx

) as PMI


------------3----------------
 Select * into #TempPMISPGStorage from (
		Select *
		from ( Select
			[Manufacturing]
			  ,[RetailWholesale]
			  ,[Services]
			  ,[Composite]
			  ,[SPGlobal]
			  ,[Time_Code]
		  FROM #TempPMISPG

		) PVT

		unpivot
		(
		 [PMIvalues] FOR  Sectors IN   
			  ([Manufacturing]
			  ,[RetailWholesale]
			  ,[Services]
			  ,[Composite]
			  ,[SPGlobal]
			  )
		) as UNPVT

		) as PMISPG



--insert into [Test3].[dbo].[Fact_ESLIG_PMI_PISM] ([Sector_Idx],[Time_Idx],[PMI_Values])
--Select Sector_Idx ,Time_code, [values] from #TempPMI


select * from #TempPMISPGStorage


-------------------------4--------------------------------

insert into [Test3].[dbo].[Fact_ESLIG_PMI_PISM] ([Sector_Idx],[Time_Idx],[PMI_Values])
Select  B.Sector_Idx, A.time_Code, A.PMIvalues  from #TempPMISPGStorage A 
join [Test3].[dbo].[Dim_PMISector] B
on A.Sectors = B.Sector_Code


------------------------------------------------------------------------
Select * from [EDW].[dbo].[Fact_ESLIG_PMI_PISM]
Select * from  [Test3].[dbo].[Fact_ESLIG_PMI_PISM]




--select * from #TempTable 

--select * from #TempPMISPGStorage

--select count(Time_code) from #TempPMISPGStorage
--select count(Time_Code) from #TempPMISPG


--select * from #TempPMISPGStorage

--drop table #TempTable

















