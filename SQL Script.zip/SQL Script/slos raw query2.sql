select * from [dbo].[S_Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]

select * from [edw].[dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]

------------1------------
INSERT INTO [edw].[dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES]
(
[Time_Idx],
[Question_Idx],
[QuestionType_Idx],
[CreditStandardFactors_Idx],
[Market_Idx],
[I_Values]
)
select 
TIME_CODE,
QUESTION_CODE,
QUESTION_TYPE,
QUESTION_CATEGORY,
ENTERPRISESLOAN_TYPE,
[VALUES]
from [dbo].[S_Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES] 


SELECT * FROM [EDW_Staging].[dbo].[S_Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES] A
JOIN [edw].[dbo].[Fact_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES] B
ON A.TIME_CODE = B.[Time_Idx]





---------3--------------------
INSERT INTO [edw].[dbo].Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS
(
[Time_Idx],
[Question_Idx],
[QuestionType_Idx],
[CreditStandardFactors_Idx],
[Market_Idx],
[I_Values]
)
select 
TIME_CODE,
QUESTION_CODE,
QUESTION_TYPE,
QUESTION_CATEGORY,
COMMERCIALLOAN_TYPE,
[VALUES]
from [dbo].S_Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS 


SELECT * FROM [EDW_Staging].[dbo].S_Fact_MFSG_SLOS_COMMERCIAL_REAL_ESTATE_LOANS 

-------------2-------------------
INSERT INTO [edw].[dbo].[Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS]
(
[Time_Idx],
[Question_Idx],
[QuestionType_Idx],
[CreditStandardFactors_Idx],
[Market_Idx],
[I_Values]
)
select 
TIME_CODE,
QUESTION_CODE,
QUESTION_TYPE,
QUESTION_CATEGORY,
HOUSEHOLDLOAN_TYPE,
[VALUES]
from [dbo].[S_Fact_MFSG_SLOS_LOANS_TO_HOUSEHOLDS] 