--------------------------------------------------------------
---- Capita Food Threshold
--------------------------------------------------------------

			--BEGIN			 
				--Select * into #tempTable1 from (
				DECLARE @Yr1 varchar(50)
				DECLARE @Yr1_S varchar(50)
				DECLARE @Yr2 varchar(50)
				set @Yr1 = (Select top 1 [Column2] from [Dump_ESLIG_Capita_Food_Threshold] where Column2 like '20%')
				set @Yr2 = (Select top 1 [Column3] from [Dump_ESLIG_Capita_Food_Threshold] where Column3 like '20%')
				set @Yr1_S = (select SUBSTRING(@Yr1,1,4)  AS substringDate);
					   Select 
					   case when [Column1] <> '' then [Column1] else '0' end Location,
					   case when [Column1] <> '' then [Column2] else '0' end 'Value_1',
					   @Yr1_S as Year
					into #tempTable1
					   from [dbo].[Dump_ESLIG_Capita_Food_Threshold] where [Column1] <>'' and [Column2] <> ''  and [Column1] != 'Region/Province' 
					  -- Select * from #tempTable
				union all
					   Select 
					   case when [Column1] <> '' then [Column1] else '0' end Location,
					   case when [Column1] <> '' then [Column3] else '0' end 'Value_1',
					   @Yr2 as Year
					   from [dbo].[Dump_ESLIG_Capita_Food_Threshold] where [Column1] <>'' and [Column2] <> '' and [Column1] != 'Region/Province' 
					   --) as temp
	--drop table #tempTable2
	-----------------------------
					--select * into  #tempTable2 from (
					Select replace(replace(replace(replace(location, ' a/b/', ''), ' b/', ''), ' a/', ''),'*','') as N_Location
						,(select replace(Value_1, ',','.')) as value
						, [YEAR]
						, 'PovertyReport' = 'Capita Food Threshold'
					into  #tempTableCFT
					from #tempTable1 where Value_1 <> '' and Location != 'Region/Province'
					--) as temp2

	--------------------------------

--------------------------------------------------------------
---- Capita Poverty Threshold
--------------------------------------------------------------

			--BEGIN		
 DECLARE @Yr3 varchar(50)
 DECLARE @Yr4 varchar(50)
 DECLARE @Yr3_S varchar(50)
  Set @Yr3 = (Select top 1 [Column2] from [Dump_ESLIG_Capita_Poverty_Threshold] where Column2 like '20%')
  set @Yr4 = (Select top 1 [Column3] from [Dump_ESLIG_Capita_Poverty_Threshold] where Column3 like '20%')
  set @Yr3_S = (select SUBSTRING(@Yr3,1,4)  AS substringDate);

				--Select * into #tempTable3 from (
					   Select 
					   case when [Column1] <> '' then [Column1] else '0' end Location,
					   case when [Column1] <> '' then [Column2] else '0' end 'Value_1',
					   @Yr3_S as Year
					   into #tempTable3
					   from [dbo].[Dump_ESLIG_Capita_Poverty_Threshold] where [Column1] <>'' and [Column2] <> ''  and [Column1] != 'Region/Province' 
					  -- Select * from #tempTable
				union all
					   Select 
					   case when [Column1] <> '' then [Column1] else '0' end Location,
					   case when [Column1] <> '' then [Column3] else '0' end 'Value_1',
					   @Yr4 as Year
					   from [dbo].[Dump_ESLIG_Capita_Poverty_Threshold] where [Column1] <>'' and [Column2] <> '' and [Column1] != 'Region/Province' 
					   --) as temp		   		   
	-----------------------------
					--select * into  #tempTable4 from (
					Select replace(replace(replace(replace(location, ' a/b/', ''), ' b/', ''), ' a/', ''),'*','') as N_Location
						,(select replace(Value_1, ',','.')) as value
						, [year]
						, 'PovertyReport' = 'Capita Poverty Threshold'
					into  #tempTableCPT
					from #tempTable3 where Value_1 <> '' and Location != 'Region/Province'
					--) as temp2
	----------------------------
--------------------------------------------------------------
---- Poverty Incidence Percent
--------------------------------------------------------------

			--BEGIN	
	
 DECLARE @Yr5 varchar(50)
 DECLARE @Yr6 varchar(50)	
 DECLARE @Yr5_S varchar(50)
  Set @Yr5 = (Select top 1 [Column4] from [Dump_ESLIG_Poverty_Incidence] where Column4 like '20%')
  set @Yr6 = (Select top 1 [Column5] from [Dump_ESLIG_Poverty_Incidence] where Column5 like '20%')
  set @Yr5_S = (select SUBSTRING(@Yr5,1,4)  AS substringDate);

					--Select * into #tempTable5 from (
							   Select 
							   case when [Column1] <> '' then [Column1] else '0' end Location,
							   case when [Column1] <> '' then [Column4] else '0' end 'Value_1',
							   @Yr5_S as Year
							   into #tempTable5
							   from [dbo].[Dump_ESLIG_Poverty_Incidence] where [Column1] <>'' and [Column4] <> ''  and [Column1] != 'Major Island Group' 
							  -- Select * from #tempTable
					union all
							   Select 
							   case when [Column1] <> '' then [Column1] else '0' end Location,
							   case when [Column1] <> '' then [Column5] else '0' end 'Value_1',
							   @Yr6 as Year
							   from [dbo].[Dump_ESLIG_Poverty_Incidence] where [Column1] <>'' and [Column4] <> '' and [Column1] != 'Major Island Group' 
							   --) as temp		   		   
	-----------------------------
					--select * into  #tempTable6 from (
					Select replace(replace(replace(replace(location, ' a/b/', ''), ' b/', ''), ' a/', ''),'*','') as N_Location
						,(select replace(Value_1, ',','.')) as value
						, [year]
						, 'PovertyReport' = 'Poverty Incidence Percent'
					into  #tempTablePIP
					from #tempTable5 where Value_1 <> '' and Location != 'Region/Province'
					--) as temp2
	----------------------------
					--insert into #TempTableF (Province_Code,Time_Code,PovertyIncidenceinPercent)
					--Select N_Location,[YEAR],[value]
					--From #tempTable6
-----------------------------------
 -- union all the report

 Select * 
 into #PovertyIndicator
 from #tempTableCFT
 union all
 Select * 
 from  #tempTableCPT
 union all
 Select * 
 from #tempTablePIP


--------------------------------------
--JOINING DIMENSION------------------
--PROVINCE--
 select A.N_Location
		,A.[value]
		,Time_idx = A.Year + '-01-01'
		,A.PovertyReport

		,B.Province_Idx
INTO #PovertyIndicator2
from #PovertyIndicator A
 left join EDW.[dbo].[Dim_Location_Province] B
 ON A.N_Location = [Province_Name]

-- -- TIME IDX AND POVERTY INDICATOR

select A.N_Location
		,A.[value]	
		,B.Time_idx		
		,A.PovertyReport
		,A.Province_Idx 
		,[PovertyCode_Idx]
INTO #PovertyIndicator3
from #PovertyIndicator2 A
JOIN EDW.[dbo].[Dim_Time_1] B
ON A.Time_idx = B.Date_Code
JOIN EDW.[dbo].[Dim_ESLIG_PovertyIndicator] C
ON  A.PovertyReport = C.[PovertyCode]

-----------
--TRANFER DATA INTO SCRUB--------

INSERT INTO EDW_Staging.[dbo].[S_Fact_ESLIG_Poverty] 
		(
		[Province_Name],
		[Values],
		[Time_Code],
		[ReportName],
		[Province_Code],
		[PovertyCode_Idx]
		)
SELECT 
		N_Location,
		[value],
		Time_idx,
		PovertyReport,
		Province_Idx ,
		[PovertyCode_Idx]
FROM #PovertyIndicator3 

------------------load SCRIPTS
SELECT * FROM EDW.[dbo].[Fact_ESLIG_POVERTYINDICATOR]
SELECT * FROM EDW_Staging.[dbo].[S_Fact_ESLIG_Poverty] 



INSERT INTO EDW.[dbo].[Fact_ESLIG_POVERTYINDICATOR]
(
[Province_Name]
,[Values]
,[Time_Idx]
,[PovertyCode_Idx]
,[Province_Code]
)

SELECT [Province_Name]
		,[Values]
		,[TIME_Code]
		,[PovertyCode_Idx]
		,[province_code]
FROM EDW_Staging.[dbo].[S_Fact_ESLIG_Poverty]









