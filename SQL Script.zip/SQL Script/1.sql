	
------------------Creating Temp Table for process Banks
drop table #TempStorage

	create  table #TempStorage (
		[ID] [int] IDENTITY(1,1) NOT NULL
		, INDUSTRY_CODE nvarchar(210)
		, BKCODE nvarchar(10)
		, [BRANCH] nvarchar(10)
		, [SCHNO] nvarchar(10)
		, [BOOK] nvarchar(10)
		, [ACCT] nvarchar(10)
		, RECNO nvarchar(10)
		,DATE_CODE datetime
		,AMOUNT numeric(18,2)
		,SELECTED_ACCOUNT nvarchar(210))

-----------PROCESS THE DATA  CONVERT TIME AND AMOUNT TO NUMERIC UKBs----------------------

drop table #TempStorage

	INSERT INTO #TempStorage 
		( INDUSTRY_CODE
			,BKCODE
			,[BRANCH]
			,[SCHNO]
			,[BOOK]
			,[ACCT]
			,RECNO
			,DATE_CODE
			,AMOUNT
			,SELECTED_ACCOUNT)	
		SELECT 
		  --[TRDATE]
		  'INDUSTRY_CODE' = [INDCODE]
		  ,[BKCODE]
		  ,[BRANCH]
		  ,[SCHNO]
		  ,[BOOK]
		  ,[ACCT]
		  --,[TOTAMT]
		  ,'RECNO' = '0'
		  ,'DATE_CODE' = TRY_CAST([TRDATE] AS DATETIME)
		  ,CONVERT(DECIMAL(18,2), REPLACE([TOTAMT], ',', '')) AMOUNT
		  ,'SELECTED_ACCOUNT' = DETAIL1 + 'UKBs'
		--INTO #TempStorageUKBs
		FROM  [dbo].[Dump_MFSG_STATBUL_BankBalanceSheet]
		where [INDCODE] in (1,2)


-----------PROCESS THE DATA  CONVERT TIME AND AMOUNT TO NUMERIC TBs----------------------
	INSERT INTO #TempStorage 
		( INDUSTRY_CODE
			,BKCODE
			,[BRANCH]
			,[SCHNO]
			,[BOOK]
			,[ACCT]
			,RECNO
			,DATE_CODE
			,AMOUNT
			,SELECTED_ACCOUNT)	
		Select
		  --[TRDATE]
		  'INDUSTRY_CODE' = [INDCODE]
		  ,[BKCODE]
		  ,[BRANCH]
		  ,[SCHNO]
		  ,[BOOK]
		  ,[ACCT]
		  --,[TOTAMT]
		  ,'RECNO' = '0'
		  ,'DATE_CODE' = TRY_CAST([TRDATE] AS DATETIME)
		  ,CONVERT(DECIMAL(18,2), REPLACE([TOTAMT], ',', '')) AMOUNT
		  ,'SELECTED_ACCOUNT' = DETAIL1 + 'TBs'
		--INTO #TempStorage
		FROM  [dbo].[Dump_MFSG_STATBUL_BankBalanceSheet]
		where [INDCODE] in (3)

	-----------PROCESS THE DATA  CONVERT TIME AND AMOUNT TO NUMERIC RCBs----------------------
		INSERT INTO #TempStorage 
		( INDUSTRY_CODE
			,BKCODE
			,[BRANCH]
			,[SCHNO]
			,[BOOK]
			,[ACCT]
			,RECNO
			,DATE_CODE
			,AMOUNT
			,SELECTED_ACCOUNT)	
		SELECT 
		  --[TRDATE]
		  'INDUSTRY_CODE' = [INDCODE]
		  ,[BKCODE]
		  ,[BRANCH]
		  ,[SCHNO]
		  ,[BOOK]
		  ,[ACCT]
		  --,[TOTAMT]
		  ,'RECNO' = '0'
		  ,'DATE_CODE' = TRY_CAST([TRDATE] AS DATETIME)
		  ,CONVERT(DECIMAL(18,2), REPLACE([TOTAMT], ',', '')) AMOUNT
		  ,'SELECTED_ACCOUNT' = DETAIL1 + 'RCBs'
		--INTO #TempStorage
		FROM  [dbo].[Dump_MFSG_STATBUL_BankBalanceSheet]
		where [INDCODE] in (4,5)

	--------------------------------------------------------------------------------------
	-----------JOIN THE VALUES TO THE DIMENSION ------------------------------------------

	drop table  #TempStorage1

	SELECT B.Time_Idx
			,C.[BankParticularAccount_Idx]
			,D.Industry_idx
			,A.INDUSTRY_CODE
			,A.BKCODE
			,A.RECNO
			,A.SCHNO
			,A.AMOUNT
	--INTO #TempStorage1
	FROM #TempStorage A
	LEFT OUTER JOIN [EDW].[dbo].[Dim_Time_1] B
	ON A.DATE_CODE = B.[Date_Code]
	LEFT OUTER JOIN [EDW].[dbo].[Dim_STATBUL_BanksParticularAccount] C
	ON A.SELECTED_ACCOUNT = C.BankParticularAccount_Code
	LEFT JOIN [EDW].[dbo].[Dim_STATBUL_Industry] D
	ON A.INDUSTRY_CODE = D.[IndustryCode]

	select * from #TempStorage1
	---------------------------------------------------------------------------------------
	-----------INSERT DATA PROCESS DATA ON THE STAGING-------------------------------------

	--	INSERT INTO [EDW_Staging].[dbo].[S_Fact_MFSG_STATBUL_BANKSBALANCESHEET]
	--		([Time_Idx]
	--		,[BankParticularAccount_Idx]
	--		,[Industry_idx]
	--		,[Bank_Code]
	--		,[RecNo]
	--		,[Sched_No]
	--		,[Value]
	--		)
	--SELECT	Time_Idx
	--		,[BankParticularAccount_Idx]
	--		,[Industry_idx]
	--		,[BKCODE]
	--		,[RECNO]
	--		,[SCHNO]
	--		,[AMOUNT]
	--FROM #TempStorage1


	select * from [dbo].[S_Fact_MFSG_STATBUL_BANKSBALANCESHEET]