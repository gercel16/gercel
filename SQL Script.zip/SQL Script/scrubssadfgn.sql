		SELECT DISTINCT
		[Code] = REPLACE(Column1,'.',''),
		[Name] = REPLACE(Column1,'.',''),
		[Label] = REPLACE(Column1,'.',''),
		[Sort] = 0
		from [dbo].[Dump_ESLIG_CPIB30_OpenStat_2M4ABB30] where Column2 not in ('') and Column1 not in ('')

		SELECT DISTINCT
		[Code] = REPLACE(Column2,'.',''),
		[Name] = REPLACE(Column2,'.',''),
		[Label] = REPLACE(Column2,'.',''),
		[Sort] = 0
		from [dbo].[Dump_ESLIG_CPIB30_OpenStat_2M4ABB30] where Column2 not in ('','TOTAL')
		

		SELECT DISTINCT
		[Code] = replace(REPLACE(Column2,'.',''),' ',''),
		[Name] = REPLACE(Column2,'.',''),
		[Label] = REPLACE(Column2,'.',''),
		[Sort] = 0
		from [dbo].[Dump_ESLIG_CPIB30_OpenStat_2M4ABB30] where Column2 not in ('','TOTAL'
		,'ALL ITEMS'
		,'FOOD AND NON-ALCOHOLIC BEVERAGES'
		,'OTHER VEGETABLE-BASED TOBACCO PRODUCTS'
		,'NON-FOOD'
		,'CLOTHING AND FOOTWEAR'
		,'HOUSING, WATER, ELECTRICITY, GAS AND OTHER FUELS'
		,'FURNISHINGS, HOUSEHOLD EQUIPMENT AND ROUTINE HOUSEHOLD MAINTENANCE'
		,'HEALTH'
		,'TRANSPORT'
		,'COMMUNICATION'
		,'RECREATION AND CULTURE'
		,'EDUCATION'
		,'RESTAURANTS AND MISCELLANEOUS GOODS AND SERVICES'
		,' EDUCATION'
		)


		SELECT DISTINCT
		[Code] = Replace(REPLACE(Column2,'.',''),' ',''),
		[Name] = REPLACE(Column2,'.',''),
		[Label] = REPLACE(Column2,'.',''),
		[Sort] = 0
		from [dbo].[Dump_ESLIG_CPIB30_OpenStat_2M4ABB30] where Column2  in (
		'ALL ITEMS'
		,'FOOD AND NON-ALCOHOLIC BEVERAGES'
		,'OTHER VEGETABLE-BASED TOBACCO PRODUCTS'
		,'NON-FOOD'
		,'CLOTHING AND FOOTWEAR'
		,'HOUSING, WATER, ELECTRICITY, GAS AND OTHER FUELS'
		,'FURNISHINGS, HOUSEHOLD EQUIPMENT AND ROUTINE HOUSEHOLD MAINTENANCE'
		,'HEALTH'
		,'TRANSPORT'
		,'COMMUNICATION'
		,'RECREATION AND CULTURE'
		,'EDUCATION'
		,'RESTAURANTS AND MISCELLANEOUS GOODS AND SERVICES'
		,' EDUCATION'
		)
		and Column2 not in ('','Total')
	