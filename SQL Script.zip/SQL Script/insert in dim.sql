
SET IDENTITY_INSERT [Dim_PMISector] ON

insert into [dbo].[Dim_PMISector] ([Sector_Idx],[Sector_Code], [Sector_Name],[Sector_Label],[Sector_Sort] )
values ( 4, 'Composite', 'Composite', 'Composite', 0)

SET IDENTITY_INSERT [Dim_PMISector] OFF