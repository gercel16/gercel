/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [PFSParticularCode]
      ,[PFSParticularName]
      ,[PFSParticularDesc]
      ,[PFSParticularLevel]
      ,[PFSParticularGroup]
      ,[PFSParticularSubGroup]
      ,[PFSCode]
      ,[PFSParticularSort]
  FROM [Test].[dbo].[PFSParticular]

  Select * from [EDW].[dbo].[Dim_STATBUL_PFSParticular]

  ------------------------- INSERT FPSParticular-------

		INSERT INTO [EDW].[dbo].[Dim_STATBUL_PFSParticular] 
			([PFSParticularCode]
			  ,[PFSParticularName]
			  ,[PFSParticularDesc]
			  ,[PFSParticularLevel]
			  ,[PFSParticularGroup]
			  ,[PFSParticularSubGroup]
			  ,[PFSCode]
			  ,[PFSParticularSort]
			)
		Select [PFSParticularCode]
			  ,[PFSParticularName]
			  ,[PFSParticularDesc]
			  ,[PFSParticularLevel]
			  ,[PFSParticularGroup]
			  ,[PFSParticularSubGroup]
			  ,[PFSCode]
			  ,[PFSParticularSort]
		FROM [Test].[dbo].[PFSParticular]