select * from [dbo].[S_Dim_Location_MajorIslandGroup]
select * from [dbo].[S_Dim_Location_Region]
select * from [dbo].[S_Dim_Location_Province]

select * from [EDW_2].[dbo].[Fact_Poverty]
