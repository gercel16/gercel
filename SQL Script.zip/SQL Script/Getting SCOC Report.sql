--CSOC
-------------------------------------------------------------------------------------------------------
select ID,
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	case when [Column1] <> '' then [Column3]  end 'AMOUNT',
	(select RIGHT((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2),26,3))  AS MONTH,
	'AAB_FOREX_CSOC' as CSOC_REPORT
	
	from [dbo].[Dump_MFSG_NBFIs_AAB_FOREX_CSOC]
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 


	select ID,
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	case when [Column1] <> '' then [Column3]  end 'AMOUNT',
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_CCC_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_CCC_CSOC where ID = 2),26,3))  AS MONTH,
	'CCC_CSOC' as CSOC_REPORT
	
	from [dbo].Dump_MFSG_NBFIs_CCC_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 
	
---GSIS and SSS
-------------------------------------------------------------------------------------------------------

SELECT *
  FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilites_GSIS_SSS]

Select ID ,
	CASE When Column1 <> '' then Column1 end 'PARTICULAR',
	CASE When Column1 <> '' then Column2 end 'AMOUNT',
	'GSIS_SSS' as CSOC_REPORT

	 FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilites_GSIS_SSS]
	 where [column1] <> ''  and [Column2] <> ''
	 order by ID OFFSET 1 ROWS 

---PIC
--------------------------------------------------------------------------------------------------
SELECT *
  FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]


  Select ID ,
	CASE When Column1 <> '' then Column1 end 'PARTICULAR',
	CASE When Column1 <> '' then Column4 end 'AMOUNT',
	'IC' as CSOC_REPORT
FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
where [column1] <> ''  and [Column4] <> ''
 order by ID OFFSET 1 ROWS

 
  Select ID ,
	CASE When Column6 <> '' then Column6 end 'PARTICULAR',
	CASE When Column6 <> '' then Column12 end 'AMOUNT',
	'IC' as CSOC_REPORT
FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
where [column6] <> ''  and [Column12] <> ''

