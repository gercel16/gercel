/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Subdivision category]
      ,[3166-2 code]
      ,[Subdivision name]
      ,[Region Code]
      ,[Language code]
      ,[Romanization system]
      ,[Parent subdivision]
  FROM [Test].[dbo].[Sheet3$]

  
  select * from [EDW_2_Staging].[dbo].[S_Dim_Location_Province]

  --insert into[dbo].[S_Dim_Location_Province] ([Province_Code],[Province_Name],[Province_Sort],[Region_Code])
  --values ([3166-2 code],[Subdivision name],,[Region Code],[Parent subdivision])
  --from [Test].[dbo].[Sheet3$]