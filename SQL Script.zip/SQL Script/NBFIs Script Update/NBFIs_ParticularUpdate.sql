   update [DES].[dbo].[Dim_NBFIParticular] 
   set  [Particular_Sort] = '15',
	[Particular_Group_code] = 'ol',
	[Particular_Group] = 'Other Liabilities',
	[Particular_Type] = 'Liabilities'
	where [Table] = 'PIC'
	--and NBFIParticular_Idx = '1174'
	and [Particular_Code] = 'Policy & Contract Claims/Maturities and Surrenders PayablesPIC'

	update [DES].[dbo].[Dim_NBFIParticular] 
	set  [Particular_Sort] = '15',
	[Particular_Group_code] = 'ol',
	[Particular_Group] = 'Other Liabilities',
	[Particular_Type] = 'Liabilities'
	where [Table] = 'PIC'
	and [Particular_Code] = 'Due to ReinsurersPIC'

	update [DES].[dbo].[Dim_NBFIParticular] 
	set  [Particular_Sort] = '15',
	[Particular_Group_code] = 'ol',
	[Particular_Group] = 'Other Liabilities',
	[Particular_Type] = 'Liabilities'
	where [Table] = 'PIC'
	and [Particular_Code] = 'Funds Held for ReinsurersPIC'

	update [DES].[dbo].[Dim_NBFIParticular] 
	set  [Particular_Sort] = '15',
	[Particular_Group_code] = 'ol',
	[Particular_Group] = 'Other Liabilities',
	[Particular_Type] = 'Liabilities'
	where [Table] = 'PIC'
	and [Particular_Code] = 'Life Insurance/ Applicants/ Remittances Unapplied DepositsPIC'

	update [DES].[dbo].[Dim_NBFIParticular] 
	set  [Particular_Sort] = '15',
	[Particular_Group_code] = 'ol',
	[Particular_Group] = 'Other Liabilities',
	[Particular_Type] = 'Liabilities'
	where [Table] = 'PIC'
	and [Particular_Code] = 'Segregated Funds LiabilitiesPIC'