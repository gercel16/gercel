/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Manufacturing]
      ,[RetailWholesale]
      ,[Services]
      ,[Composite]
      ,[Time_Code]
  FROM [EDW_Staging].[dbo].[S_Fact_ESLIG_PMI]

------------1----------------
 Select * into #TempTable from (
		Select *
		from ( Select
			[Manufacturing]
			  ,[RetailWholesale]
			  ,[Services]
			  ,[Composite]
			  ,[Time_Code]
		  FROM [EDW_Staging].[dbo].[S_Fact_ESLIG_PMI] 

		) pvt

		unpivot
		(
		 [values] FOR  Sectors IN   
			  ([Manufacturing]
			  ,[RetailWholesale]
			  ,[Services]
			  ,[Composite])
		) as unvip
		) as tempt1

select * from #TempTable

----------------2--------------
Select * into #TempPMI from (
Select  A.Time_code, A.[values], B.Sector_Idx, A.Sectors from #TempTable A 
join [Test3].[dbo].[Dim_PMISector] B
on A.Sectors = B.Sector_Code
) as PMIvalues

select *  from #TempPMI

----------------3-----------------
Select * into #TempSPG from (
select * , 'SPGSectors' = 'SPGlobal' from [dbo].[S_Fact_ESLIG_PMI_SPGLobal]) as SPG


---------------4-----------------------
Select * into #TempPMISPG from (
Select * from #TempPMI T1 
full join #TempSPG T2
on T1.Time_code = T2.Time_idx
) as PMISPG


Select * from #TempPMISPG

-------------------6------------------

 Select * into #TempPMISPGFin from (
		Select *
		from ( 
			Select
				[Values]
				  ,[Value]
				  ,[Time_code]
			  FROM #TempPMISPG 

			) pvt

			unpivot
			(
			 [PMIvalues] FOR  PMISectors IN   
				  ([Values]
				  ,[Value]
				  )
			) as unvip

		) as tempt1

select * from #TempPMISPGFin

drop table #TempPMISPGFin


insert into [Test3].[dbo].[Fact_ESLIG_PMI_PISM] ([Sector_Idx],[Time_Idx],[PMI_Values])
Select Sector_Idx ,Time_code, [values] from #TempPMI


