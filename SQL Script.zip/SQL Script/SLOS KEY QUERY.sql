/****** Script for SelectTopNRows command from SSMS  ******/
SELECT *
       FROM [EDW_Staging].[dbo].[Dump_MFSG_SLOS]


		select * from (select *,ROW_NUMBER()over (order by ID) as row  
		from [dbo].[vw_Dump_MFSG_SLOS]) temp
		where  row >=9 and row <=15
	
		select *,ROW_NUMBER()over (order by ID) as row  
		into #tempROwRead
		from [dbo].[vw_Dump_MFSG_SLOS]


		select *
		from #tempROwRead
		where  row >=9 and row <=15
		
		--,Case when [MONTH] <> '' then [MANUFACTURING_RAW] end 'Manufacturing'

		SELECT 
			 CASE WHEN [Column2] <> '' then [Column2] end 'CHANGE_CREDIT_STANDARD'
			,CASE WHEN [column3] <> '' then [column3] end 'OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'TOP CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'LARGE MIDDLE MARKET ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'SMALL AND MEDIUM ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'MICRO ENTERPRISES'
		FROM #tempROwRead
		where  row >=9 and row <=15
		AND [COLUMN2] <> ''

