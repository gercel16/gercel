
select * FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC] 


-----------------------------------------
---combine the particular table of lie and non life
		  Select Id,
			CASE When [LIFEPARTICULAR] <> '' then [LIFEPARTICULAR] end 'PARTICULAR',
			REC = '',
			'AMOUNT' =  
					CASE 
					WHEN [LIFETOTAL] = '.' THEN '0.0' 
					WHEN ISNUMERIC([LIFETOTAL]) = 1 THEN [LIFETOTAL]    			
				ELSE '0.0' 
				end 	
			,'Time_code' = (select SUBSTRING((Select [LIFEPARTICULAR] from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),47,4))  + '12' + '01'
			,'LIFE' as CSOC_REPORT
	--INTO #TempstorageAA
	FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
	where [LIFEPARTICULAR] <> ''  and [LIFETOTAL] <> ''
	--order by ID OFFSET 1 ROWS
union all 
	Select id,
		CASE When [NONLIFEPARTICULAR] <> '' then [NONLIFEPARTICULAR] end 'PARTICULAR',
		REC = '',
		'AMOUNT' =  
				CASE 
				WHEN [NONLIFETOTAL] = '.' THEN '0.0' 
				WHEN ISNUMERIC([NONLIFETOTAL]) = 1 THEN [NONLIFETOTAL]    			
			ELSE '0.0' 
			end 
		,'Time_code' = (select SUBSTRING((Select [NONLIFEPARTICULAR] from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),78,4))  + '12' + '01'
		,'NON-LIFE' as CSOC_REPORT
	FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
	where [NONLIFEPARTICULAR] <> '' and [NONLIFETOTAL] <> ''

-------------------------------------------------------------------------------------
	SELECT ID,
	Time_Code
	, Csoc_report as 'BANKINDUSTRY' 
	,'0' as RECNO
	,'0' as SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE(AMOUNT, ',', '')) AMOUNT,
	'Particular' = PARTICULAR
	,'Particular_code' = PARTICULAR + 'PIC'
	,'DATE_CODE' = CAST(Time_Code AS DATETIME)
	,'Table' = 'PIC'
	INTO #TempstorageAB
	from #TempstorageAA
---------------------------------------------------------------------------

	SELECT 
	B.Time_idx
	,C.[NBFIParticular_Idx]
	,C.[Particular_Group]
	,C.[Particular_Type]
	,A.BANKINDUSTRY
	,A.Particular 
	,A.AMOUNT
	--Into #TempNSSLAPAWNSHOP
	FROM #TempStorageAB A
	LEFT OUTER JOIN [EDW_DIM_Standard].[dbo].[Dim_Time] B
	ON A.DATE_CODE = B.Date_Code
	LEFT OUTER JOIN  [EDW].[dbo].[Dim_NBFIParticular] C
	ON A.Particular_code = C.[Particular_Code]

---------------------------------------------------------------------------
	




