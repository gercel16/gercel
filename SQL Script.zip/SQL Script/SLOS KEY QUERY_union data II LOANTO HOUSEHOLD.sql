-------------------II. LOANS TO HOUSEHOLDS---------------------------------

SELECT *
       FROM [EDW_Staging].[dbo].[Dump_MFSG_SLOS]

------------------------STEP 1-----------------------------------------------------------
		select 
		(SELECT SUBSTRING((SELECT [COLUMN1] FROM [vw_Dump_MFSG_SLOS] WHERE ID = 7),9,2)) AS 'QUARTER'
		,(SELECT SUBSTRING((SELECT [COLUMN1] FROM [vw_Dump_MFSG_SLOS] WHERE ID = 7),12,4)) AS 'YEAR'
		,*
		,ROW_NUMBER()over (order by ID) as row  
		into #tempROwRead
		from [dbo].[vw_Dump_MFSG_SLOS]

------------------------STEP 1-----------------------------------------------------------
-------------------------------------------------------
------------------------STEP 2-----------------------------------------------------------
---QUESTION 10.-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '10'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question10
		FROM #tempROwRead
		where  row >=346 and row <=351
		AND [COLUMN2] <> ''

---QUESTION 11.1-----------------------------------------------------------------------
--DROP TABLE #Question11_1
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '11.1'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question11_1
		FROM #tempROwRead
		where  row >=358 and row <=368
		AND [COLUMN2] <> ''

---QUESTION 11.2-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '11.2'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question11_2
		FROM #tempROwRead
		where  row >=372 and row <=382
		AND [COLUMN2] <> ''

---QUESTION 11.3-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '11.3'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question11_3
		FROM #tempROwRead
		where  row >=386 and row <=396
		AND [COLUMN2] <> ''

---QUESTION 12 a-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '12.a'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question12_a
		FROM #tempROwRead
		where  row >=400 and row <=404
		AND [COLUMN2] <> ''

---QUESTION 12 b-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '12.b'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question12_b
		FROM #tempROwRead
		where  row >=406 and row <=410
		AND [COLUMN2] <> ''

---QUESTION 12 c-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '12.c'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question12_c
		FROM #tempROwRead
		where  row >=412 and row <=416
		AND [COLUMN2] <> ''

---QUESTION 12 d-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '12.d'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question12_d
		FROM #tempROwRead
		where  row >=418 and row <=422
		AND [COLUMN2] <> ''

---QUESTION 12 e-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '12.e'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question12_e
		FROM #tempROwRead
		where  row >=424 and row <=428
		AND [COLUMN2] <> ''

---QUESTION 12 f-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '12.f'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question12_f
		FROM #tempROwRead
		where  row >=431 and row <=435
		AND [COLUMN2] <> ''

---QUESTION 12 g-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '12.g'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question12_g
		FROM #tempROwRead
		where  row >=437 and row <=441
		AND [COLUMN2] <> ''

---QUESTION 13-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '13.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question13
		FROM #tempROwRead
		where  row >=444 and row <=448
		AND [COLUMN2] <> ''

---QUESTION 14.1 ----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '14.1'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question14_1
		FROM #tempROwRead
		where  row >=456 and row <=466
		AND [COLUMN2] <> ''

---QUESTION 14.2-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '14.2'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question14_2
		FROM #tempROwRead
		where  row >=470 and row <=479
		AND [COLUMN2] <> ''

---QUESTION 14.3-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '14.3'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question14_3
		FROM #tempROwRead
		where  row >=484 and row <=493
		AND [COLUMN2] <> ''

---QUESTION 15.-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '15.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question15
		FROM #tempROwRead
		where  row >=497 and row <=501
		AND [COLUMN2] <> ''

---QUESTION 16.1-----------------------------------------------------------------------
--drop table #Question15
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '16.1'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question16_1
		FROM #tempROwRead
		where  row >=510 and row <=516
		AND [COLUMN2] <> ''

---QUESTION 16.2-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '16.2'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question16_2
		FROM #tempROwRead
		where  row >=520 and row <=526
		AND [COLUMN2] <> ''

---QUESTION 16.3-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '16.3'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question16_3
		FROM #tempROwRead
		where  row >=531 and row <=537
		AND [COLUMN2] <> ''


---QUESTION 17-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '17.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question17
		FROM #tempROwRead
		where  row >=541 and row <=545
		AND [COLUMN2] <> ''

---QUESTION 18.1-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '18.1'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question18_1
		FROM #tempROwRead
		where  row >=552 and row <=559
		AND [COLUMN2] <> ''

---QUESTION 18.2-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '18.2'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question18_2
		FROM #tempROwRead
		where  row >=563 and row <=570
		AND [COLUMN2] <> ''

---QUESTION 18.3-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '18.3'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_Housing_Loans'
			,CASE WHEN [column5] <> '' then [column5] end 'T_Credit_Card_Loans'
			,CASE WHEN [column6] <> '' then [column6] end 'T_Auto_Loans'
			,CASE WHEN [column7] <> '' then [column7] end 'T_Personal_Salary_Loans'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_Housing_Loans'
			,CASE WHEN [column10] <> '' then [column10] end 'R_Credit_Card_Loans'
			,CASE WHEN [column11] <> '' then [column11] end 'R_Auto_Loans'
			,CASE WHEN [column12] <> '' then [column12] end 'R_Personal_Salary_Loans'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_Housing_Loans'
			,CASE WHEN [column15] <> '' then [column15] end 'A_Credit_Card_Loans'
			,CASE WHEN [column16] <> '' then [column16] end 'A_Auto_Loans'
			,CASE WHEN [column17] <> '' then [column17] end 'A_Personal_Salary_Loans'

		INTO #Question18_3
		FROM #tempROwRead
		where  row >=574 and row <=581
		AND [COLUMN2] <> ''
		
------------------------STEP 2-----------------------------------------------------------
-------------------------------
-----------------------STEP 3---------------------------------------------------------------------
	
	SELECT * 
	INTO #LTHOUSEHOLDS
	FROM #Question10
		UNION ALL
	SELECT * FROM #Question11_1
		UNION ALL
	SELECT * FROM #Question11_2
		UNION ALL
	SELECT * FROM #Question11_3
		UNION ALL
	SELECT * FROM #Question12_a
		UNION ALL
	SELECT * FROM #Question12_b
		UNION ALL
	SELECT * FROM #Question12_c
		UNION ALL
	SELECT * FROM #Question12_d
		UNION ALL
	SELECT * FROM #Question12_e
		UNION ALL
	SELECT * FROM #Question12_f
		UNION ALL
	SELECT * FROM #Question12_g
		UNION ALL
	SELECT * FROM #Question13
		UNION ALL
	SELECT * FROM #Question14_1
		UNION ALL
	SELECT * FROM #Question14_2
		UNION ALL
	SELECT * FROM #Question14_3
		UNION ALL
	SELECT * FROM #Question15
		UNION ALL
	SELECT * FROM #Question16_1
		UNION ALL
	SELECT * FROM #Question16_2
		UNION ALL
	SELECT * FROM #Question16_3
		UNION ALL
	SELECT * FROM #Question17
		UNION ALL
	SELECT * FROM #Question18_1
		UNION ALL
	SELECT * FROM #Question18_2
		UNION ALL
	SELECT * FROM #Question18_3

-----------------------STEP 3--------------------------------------------------------------------

SELECT * FROM #LTHOUSEHOLDS

-----------------------STEP 4---------------------------------------------------------------------
--DROP TABLE #QTEMPTABLE

	SELECT [YEAR],
		[QUARTER],
		'TIME_CODE' = [YEAR] + '-' + [QUARTER],
		[QUESTION_CODE],
		[QUESTION_TYPE],
		[QUESTION_CATEGORY],
		HOUSEHOLDLOAN_TYPE,
		[Values] 
	INTO #QTEMPTABLE
	FROM #LTHOUSEHOLDS
	unpivot
	(
	[Values] FOR HOUSEHOLDLOAN_TYPE IN (T_OVERALL,
								T_Housing_Loans,
								T_Credit_Card_Loans,
								T_Auto_Loans,
								T_Personal_Salary_Loans,
								R_OVERALL,
								R_Housing_Loans,
								R_Credit_Card_Loans,
								R_Auto_Loans,
								R_Personal_Salary_Loans,
								A_OVERALL,
								A_Housing_Loans,
								A_Credit_Card_Loans,
								A_Auto_Loans,
								A_Personal_Salary_Loans
								)
	) as unpHOUSE
-----------------------STEP 4---------------------------------------------------------------------

-----------------------STEP 5 TIMEDIM---------------------------------------------------------------------
	SELECT B.Time_Idx,
	A.YEAR, 
	A.QUARTER,
	A.QUESTION_CODE, 
	A.QUESTION_TYPE,
	A.QUESTION_CATEGORY,
	A.HOUSEHOLDLOAN_TYPE,
	--[Values]
	CONVERT(DECIMAL(18,2), REPLACE([Values], ',', '')) [VALUE] 
	INTO #QSTEMPSTORAGE
	FROM #QTEMPTABLE A
	JOIN (
        SELECT 
            MAX(Time_Idx) Time_Idx,
            Quarter_Name
        FROM EDW.dbo.Dim_Time_1
        GROUP BY Quarter_Name
    )B
    ON A.TIME_CODE = B.Quarter_Name
-----------------------STEP 5 TIMEDIM---------------------------------------------------------------------

-----------------------STEP  INSERT TO QUESTIONNAIRE 2 TABLE-------------------------------------
SELECT * FROM #QSTEMPSTORAGE

INSERT INTO  [dbo].[Dump_MFSG_SLOS_LOANS_TO_HOUSEHOLDS]
		([TIME_CODE]
		,[YEAR]
		,[QUARTER]
		,[QUESTION_CODE]
		,[QUESTION_TYPE]
		,[QUESTION_CATEGORY]
		,HOUSEHOLDLOAN_TYPE
		,[VALUES])
SELECT * 
FROM #QSTEMPSTORAGE 

-----------------------STEP  INSERT TO QUESTIONNAIRE 2 TABLE-------------------------------------




