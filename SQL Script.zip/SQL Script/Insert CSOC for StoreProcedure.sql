
 ---- AAB_FOREX_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2),26,3))  AS MONTH,
	'AAB_FOREX_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2),26,3)))	
					and T2.Year = 
					(select RIGHT((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2), 4)) )
	
	from [dbo].[Dump_MFSG_NBFIs_AAB_FOREX_CSOC]
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 

 ---- CCC_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_CCC_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_CCC_CSOC where ID = 2),26,3))  AS MONTH,
	'CCC_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_CCC_CSOC where ID = 2),26,3)))	
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_CCC_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_CCC_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 

 ---- FC_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_FC_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_FC_CSOC where ID = 2),25,3))  AS MONTH,
	'FC_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_FC_CSOC where ID = 2),25,3)))	
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_FC_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_FC_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 

 ---- FCwoQB_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_FCwoQB_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_FCwoQB_CSOC where ID = 2),26,3))  AS MONTH,
	'FCwoQB_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_FCwoQB_CSOC where ID = 2),26,3)))	
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_FCwoQB_CSOC where ID = 2), 4)) )
					
	from [dbo].Dump_MFSG_NBFIs_FCwoQB_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 


---- SDB_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_SDB_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_SDB_CSOC where ID = 2),26,3))  AS MONTH,
	'PWN_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_SDB_CSOC where ID = 2),26,3)))	
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_SDB_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_SDB_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 


---- GNBFI_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column3]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column2] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column2]) = 1 THEN [Column2]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_GNBFI_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_GNBFI_CSOC where ID = 2),26,3))  AS MONTH,
	'GNBFI_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_GNBFI_CSOC where ID = 2),26,3)))	 
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_GNBFI_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_GNBFI_CSOC
	where [column1] <> '' and [Column2] <> '' --and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 

---- IC_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_IC_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_IC_CSOC where ID = 2),26,3))  AS MONTH,
	'IC_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_IC_CSOC where ID = 2),26,3)))	
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_IC_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_IC_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 

---- IH_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_IH_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_IH_CSOC where ID = 2),25,3))  AS MONTH,
	'IH_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_IH_CSOC where ID = 2),25,3)) )	
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_IH_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_IH_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 


---- IHwoQB_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_IHwoQB_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_IHwoQB_CSOC where ID = 2),26,3))  AS MONTH,
	'IHwoQB_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_IHwoQB_CSOC where ID = 2),26,3)) )	
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_IHwoQB_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_IHwoQB_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 

---- LI_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end 
	,
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_LI_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_LI_CSOC where ID = 2),26,3))  AS MONTH,
	'LI_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_LI_CSOC where ID = 2),26,3)) )	 
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_PWN_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_LI_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 


---- PWN_CSOC
Insert into [dbo].[S_Fact_MFSG_NBFIs_stg]
select 
	Case When [column1] <> '' then [column1]  end 'PARTICULAR',
	case when [Column1] <> '' then [Column2]  end 'REC',
	--case when [Column1] <> '' then [Column3]  end 'AMOUNT',
	'AMOUNT' =  
			CASE 
			WHEN [Column3] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column3]) = 1 THEN [Column3]    
			
		ELSE '0.0' 
		end , 	
	(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_PWN_CSOC where ID = 2), 4)) as YEAR,
	(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_PWN_CSOC where ID = 2),23,3))  AS MONTH,
	'PWN_CSOC' as CSOC_REPORT,
	Time_Code =  (select top 1 T2.Time_Idx from [dbo].[S_Time_Matrix] T1
					inner join [EDW].[dbo].[Dim_Time] T2
					on T1.[MonthValue] = T2.Month 
					where T1.[MonthValue] = 
						(Select [MonthValue] from [dbo].[S_Time_Matrix] 
						where [MonthShortName] = (select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_PWN_CSOC where ID = 2),23,3)) )	 
					and T2.Year = 
					(select RIGHT((Select column1 from  Dump_MFSG_NBFIs_PWN_CSOC where ID = 2), 4)) )
	
	from [dbo].Dump_MFSG_NBFIs_PWN_CSOC
	where [column1] <> '' and [Column2] <> '' and [Column3] <> '' 
	order by ID OFFSET 1 ROWS 


--BS_LIFE
INSERT into [dbo].[S_Fact_MFSG_NBFIs_stg]
  Select 
	CASE When Column1 <> '' then Column1 end 'PARTICULAR',
	REC = '',
	'AMOUNT' =  
			CASE 
			WHEN [Column4] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column4]) = 1 THEN [Column4]    
			
		ELSE '0.0' 
		end 	
	,
	(select SUBSTRING((Select column1 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),47,4)) as YEAR,
	(select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2),26,3))  AS MONTH,
	'LIFE' as CSOC_REPORT,
	Time_code = (Select top 1 Time_Idx from [EDW].[dbo].[Dim_Time] 
	where year like (
	select SUBSTRING((Select column1 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),47,4))
	)

	FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
	where [column1] <> ''  and [Column4] <> ''
	 order by ID OFFSET 1 ROWS

--BS_NON-LIFE 
INSERT into [dbo].[S_Fact_MFSG_NBFIs_stg]
  Select
	CASE When Column6 <> '' then Column6 end 'PARTICULAR',
	REC = '',
	'AMOUNT' =  
			CASE 
			WHEN [Column12] = '.' THEN '0.0' 
			WHEN ISNUMERIC([Column12]) = 1 THEN [Column12]    
			
		ELSE '0.0' 
		end 
	,
	(select SUBSTRING((Select column6 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),78,4)) as YEAR,
	(select SUBSTRING((Select column1 from  [Dump_MFSG_NBFIs_AAB_FOREX_CSOC] where ID = 2),26,3))  AS MONTH,
	'NON-LIFE' as CSOC_REPORT,
	Time_code = (Select top 1 Time_Idx from [EDW].[dbo].[Dim_Time] 
	where year like (
	select SUBSTRING((Select column6 from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),78,4))
	)

FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
where [column6] <> ''  and [Column12] <> ''




