 -----------------------------IH and FC-------------------------------
 -----1--------------------------------
 -----Converting Amount to numeric and combine the table of IH and FC---

 --drop table #TempStorage

 select ID,
	TRDATE
	,BNKIND as 'BANKINDUSTRY'
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE(AMT, ',', '')) AMOUNT
	,'Particular' = [DESC]
	,'Particular_code' = [DESC] + 'IH'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME) 
	,'Table' = 'IH'
	into #TempStorage

	from [dbo].[Dump_MFSG_NBFIs_FSRLIB2_NBFPF00]

	union 

select ID,
	TRDATE
	,BNKIND as 'BANKINDUSTRY'
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE(AMT, ',', '')) AMOUNT,
	'Particular' = [DESC]
	,'Particular_code' = [DESC] + 'FC'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
	,'Table' = 'FC'
	from [dbo].[Dump_MFSG_NBFIs_FSRLIB2_NBFPI00]

-------------remove the character  value of the amount

--drop table #TempStorage1

	select ID,
	TRDATE
	,BANKINDUSTRY
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE([AMOUNT], ',', '')) AMOUNT
	,Particular
	,Particular_code
	,DATE_CODE
	,[Table]
	into #TempStorage1
	from #TempStorage

--------------- Dividing the all particular Value to the  1000 for IH and FC----
	--drop table #TempStorage2
	SELECT 
	 DATE_CODE
	,BANKINDUSTRY
	,Particular
	,Particular_code
	,'AMOUNT' = sum (AMOUNT)/1000  
	INTO #TempStorage2
	FROM #TempStorage 
	GROUP BY Particular,DATE_CODE,BANKINDUSTRY,Particular_code

--------------- connecting the  value to the dimension---------------------------
--drop table #TempIHFC
	SELECT 
	B.Time_idx
	,C.[NBFIParticular_Idx]
	,C.[Particular_Group]
	,C.[Particular_Type]
	,A.BANKINDUSTRY
	,A.Particular 
	,A.AMOUNT
	INTO #TempIHFC
	FROM #TempStorage2 A
	LEFT OUTER JOIN [EDW_DIM_Standard].[dbo].[Dim_Time] B
	ON A.DATE_CODE = B.Date_Code
	LEFT OUTER JOIN  [EDW].[dbo].[Dim_NBFIParticular] C
	ON A.Particular_code = C.[Particular_Code]

--------------------------------------------------------------------
--------------------------------------------------------------------
-----------Converting Amount to numeric and combine the NSSLA and PAWNSHOP------
	--drop table #TempStorageA

	select ID,
	TRDATE
	,'PAWNSHOP' as 'BANKINDUSTRY' 
	,'0' as RECNO
	,SCHNO
	,'AMOUNT' = 
		CASE 
			WHEN AMOUNT = '.' THEN '0.0' 
			WHEN ISNUMERIC(AMOUNT) = 1 THEN AMOUNT  		
		ELSE '0.0'
		end
	--,CONVERT(DECIMAL(18,2), REPLACE(AMOUNT, ',', '')) AMOUNT
	,'Particular' = [DETAIL1]
	,'Particular_code' = [DETAIL1] + 'PAWNSHOP'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
	,'Table' = 'PAWNSHOP'
	into #TempStorageA	

	from[dbo].[Dump_MFSG_NBFIs_PAWNSHOP_GLSLLIB2_NBPWNFS2]

	union

	select ID,
	TRDATE
	,'NSSLA' as 'BANKINDUSTRY' 
	,'0' as RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE([TOTAMT], ',', '')) AMOUNT,
	'Particular' = [DETAIL1]
	,'Particular_code' = [DETAIL1] + 'NSSLA'
	,'DATE_CODE' = CAST(TRDATE AS DATETIME)
	,'Table' = 'NSSLA'
	from [dbo].[Dump_MFSG_NBFIs_FRPNSSLA_BS]

	-----------remove the character  value of the amount---

	--drop table #TempStorageB

	select ID,
	TRDATE
	,BANKINDUSTRY
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE([AMOUNT], ',', '')) AMOUNT
	,Particular
	,Particular_code
	,DATE_CODE
	,[Table]
	into #TempStorageB
	from #TempStorageA

	
--------------- Dividing the all particular Value to the  1000000 for PAWNSHOP and NSSLA ----
	--drop table #TempStorageC

	SELECT 
	 DATE_CODE
	,BANKINDUSTRY
	,Particular
	,Particular_code
	,AMOUNT = sum (AMOUNT)/1000000  
	INTO #TempStorageC
	FROM #TempStorageB
	GROUP BY Particular,DATE_CODE,BANKINDUSTRY,Particular_code



------------- Connecting value to the dimension-----------
	SELECT 
	B.Time_idx
	,C.[NBFIParticular_Idx]
	,C.[Particular_Group]
	,C.[Particular_Type]
	,A.BANKINDUSTRY
	,A.Particular 
	,A.AMOUNT
	Into #TempNSSLAPAWNSHOP
	FROM #TempStorageC A
	LEFT OUTER JOIN [EDW_DIM_Standard].[dbo].[Dim_Time] B
	ON A.DATE_CODE = B.Date_Code
	LEFT OUTER JOIN  [EDW].[dbo].[Dim_NBFIParticular] C
	ON A.Particular_code = C.[Particular_Code]

--------------------------------------------------------------------
-------------------------PIC----------------------------------------
---combine the particular table of lie and non life
--drop table #TempstorageAA

		  Select Id,
			CASE When [LIFEPARTICULAR] <> '' then [LIFEPARTICULAR] end 'PARTICULAR',
			REC = '',
			'AMOUNT' =  
					CASE 
					WHEN [LIFETOTAL] = '.' THEN '0.0' 
					WHEN ISNUMERIC([LIFETOTAL]) = 1 THEN [LIFETOTAL]    			
				ELSE '0.0' 
				end 	
			,'Time_code' = (select SUBSTRING((Select [LIFEPARTICULAR] from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),47,4))  + '12' + '01'
			,'LIFE' as CSOC_REPORT
	INTO #TempstorageAA
	FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
	where [LIFEPARTICULAR] <> ''  and [LIFETOTAL] <> ''
	--order by ID OFFSET 1 ROWS
union all 
	Select id,
		CASE When [NONLIFEPARTICULAR] <> '' then [NONLIFEPARTICULAR] end 'PARTICULAR',
		REC = '',
		'AMOUNT' =  
				CASE 
				WHEN [NONLIFETOTAL] = '.' THEN '0.0' 
				WHEN ISNUMERIC([NONLIFETOTAL]) = 1 THEN [NONLIFETOTAL]    			
			ELSE '0.0' 
			end 
		,'Time_code' = (select SUBSTRING((Select [NONLIFEPARTICULAR] from [Dump_MFSG_NBFIs_AssetLiabilties_PIC]  where ID = 1),78,4))  + '12' + '01'
		,'NON-LIFE' as CSOC_REPORT
	FROM [EDW_Staging].[dbo].[Dump_MFSG_NBFIs_AssetLiabilties_PIC]
	where [NONLIFEPARTICULAR] <> '' and [NONLIFETOTAL] <> ''

-------------- remove the character value of the amount and arrange for combining-------------
--drop table #TempstorageAB

	SELECT ID,
	Time_Code
	, Csoc_report as 'BANKINDUSTRY' 
	,'0' as RECNO
	,'0' as SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE(AMOUNT, ',', '')) AMOUNT,
	'Particular' = PARTICULAR
	,'Particular_code' = PARTICULAR + 'PIC'
	,'DATE_CODE' = CAST(Time_Code AS DATETIME)
	,'Table' = 'PIC'
	INTO #TempstorageAB
	from #TempstorageAA

------------------connecting PIC to Dimension---------------------------
--drop table #TempPIC

	SELECT 
	B.Time_idx
	,C.[NBFIParticular_Idx]
	,C.[Particular_Group]
	,C.[Particular_Type]
	,A.BANKINDUSTRY
	,A.Particular 
	,A.AMOUNT
	Into #TempPIC
	FROM #TempStorageAB A
	LEFT OUTER JOIN [EDW_DIM_Standard].[dbo].[Dim_Time] B
	ON A.DATE_CODE = B.Date_Code
	LEFT OUTER JOIN  [EDW].[dbo].[Dim_NBFIParticular] C
	ON A.Particular_code = C.[Particular_Code]	
	LEFT OUTER JOIN [EDW].[dbo].[Dim_NBFIBankKind] D
	ON A.BANKINDUSTRY = D.[NBFIBankKind_Code]
---------------------------------------------------------------------------
---------------------------------------------------------------------------
---------------SSS AND GSIS CONSOLIDATION----------------------------------
--drop table #TempStorageSG

select ID,
case
	When Column1 <> '' Then Column1 end 'PARTICULAR',
	REC = '',
	'AMOUNT' =  
			CASE 
			WHEN [Column2] = '                                        -   ' THEN '0.0' 
			WHEN ISNUMERIC([Column2]) = 1 THEN [Column2]    
			
		ELSE '0.0' 
		end 
	,'Time_code' = (select RIGHT((Select column1 from  [dbo].[Dump_MFSG_NBFIs_AssetLiabilites_GSIS_SSS] where ID = 2), 4)) + '12' + '01'
	,'SSS_GSIS' as CSOC_REPORT	
	into #TempStorageSG
	from [dbo].[Dump_MFSG_NBFIs_AssetLiabilites_GSIS_SSS]
	where [column1] <> '' and [Column2] <> '' and ID between 83 and 103 

	---------------------FORMATING THE RESULT ------------------------------
	--DROP TABLE #TempStorageSG1

	--Select * from #TempStorageSG

	select ID,
	Time_code
	,CSOC_REPORT as 'BANKINDUSTRY'
	,'0' as RECNO
	,'0' as SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE(AMOUNT, ',', '')) AMOUNT,
	'Particular' = PARTICULAR
	,'Particular_code' = PARTICULAR + 'SSS_GSIS'
	,'DATE_CODE' = CAST(Time_code AS DATETIME)
	,'Table' = 'SSS_GSIS'
	into #TempStorageSG1
	from [dbo].#TempStorageSG

	SELECT * FROM #TempStorageSG1
---------------REMOVING CHARTER TO VALUES AND CONVERTING TO NUMERIC----------------------

	--DROP TABLE #TempStorageSG2

	select ID,
	Time_code
	,BANKINDUSTRY
	,RECNO
	,SCHNO
	,CONVERT(DECIMAL(18,2), REPLACE([AMOUNT], ',', '')) AMOUNT
	,Particular
	,Particular_code
	,DATE_CODE
	,[Table]
	into #TempStorageSG2
	from #TempStorageSG1

	----------------------------------------------------
	SELECT 
	B.Time_idx
	,C.[NBFIParticular_Idx]
	,C.[Particular_Group]
	,C.[Particular_Type]
	,A.BANKINDUSTRY
	,D.NBFIBankKind_idx
	,A.Particular 
	,A.AMOUNT
	Into #TempSSS_GSIS
	FROM #TempStorageSG2 A
	LEFT  JOIN [EDW_DIM_Standard].[dbo].[Dim_Time] B
	ON A.DATE_CODE = B.Date_Code
	LEFT  JOIN  [EDW].[dbo].[Dim_NBFIParticular] C
	ON A.Particular_code = C.[Particular_Code]	LEFT  JOIN [EDW].[dbo].[Dim_NBFIBankKind] D
	ON A.BANKINDUSTRY = D.[NBFIBankKind_Code]


---------------------------------------------------------------------------
--Combine the PIC, NSSLA , PAWNSHOP and FC and IH and SSS_GSIS-------------
--drop table #NBFIs

	Select * 
	Into #NBFIs
	from #TempIHFC
	union all
	Select * 
	from #TempNSSLAPAWNSHOP
	union all
	Select * 
	from #TempPIC
	union all
	Select * 
	from  #TempSSS_GSIS
	

-----------------------------------------------------------------------
-----------------------------------------------------------------------
----------checking only------------
	--Select * 
	--into #NBFIs
	--from #TempIHFC
	--union
	--Select * from #TempNSSLAPAWNSHOP
	--order by Particular_group

	-------------- To lest the amount need that to subtract for specific Industry Particular --------------
	Select * from #NBFIs where BANKINDUSTRY = 'NSSLA'
	and Particular in ('Less: Loan Discount','Less: Other Deferred Credits','Less: Accumulated Depreciation'
						,'10. Real and Other Properties Acquired (ROPA)','Less: SCR Discount'
						,'Less: SCR - Other Deferred Credits','Less: Accumulated Amortization')
	and Particular_group in ('Real Property, Furniture, Fixture, and Equipment','Loans and Discounts'
							,'Real and Other Properties Owned or Acquired','Other Assets')

	update  #NBFIs 
	set AMOUNT = AMOUNT * -1
	where BANKINDUSTRY = 'NSSLA'
	and Particular in ('Less: Loan Discount','Less: Other Deferred Credits','Less: Accumulated Depreciation'
						,'10. Real and Other Properties Acquired (ROPA)','Less: SCR Discount'
						,'Less: SCR - Other Deferred Credits','Less: Accumulated Amortization')
	and Particular_group in ('Real Property, Furniture, Fixture, and Equipment','Loans and Discounts'
							,'Real and Other Properties Owned or Acquired','Other Assets')

	----------------------------------------------------------------------------------------------------------
	Select * from #NBFIs where BANKINDUSTRY = 'PAWNSHOP'
	and Particular in ('b.  Drawing account')
	and Particular_group in ('Capital Stock')

	update  #NBFIs 
	set AMOUNT = AMOUNT * -1
	where BANKINDUSTRY = 'PAWNSHOP'
	and Particular in ('b.  Drawing account')
	and Particular_group in ('Capital Stock')


	Select * from #NBFIs

