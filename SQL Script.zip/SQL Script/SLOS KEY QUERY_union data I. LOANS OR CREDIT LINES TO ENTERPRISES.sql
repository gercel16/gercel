

-----------------I. LOANS OR CREDIT LINES TO ENTERPRISES-----------------------
--SELECT *
--       FROM [EDW_Staging].[dbo].[Dump_MFSG_SLOS]


		--select * from (select *,ROW_NUMBER()over (order by ID) as row  
		--from [dbo].[vw_Dump_MFSG_SLOS]) temp
		--where  row >=9 and row <=15
	

	--(select SUBSTRING((Select column1 from  Dump_MFSG_NBFIs_CCC_CSOC where ID = 2),26,3))  AS MONTH,

	--DROP TABLE #tempROwRead

-----------------------STEP 1---------------------------------------------------------------------
		select 
		(SELECT SUBSTRING((SELECT [COLUMN1] FROM [vw_Dump_MFSG_SLOS] WHERE ID = 7),9,2)) AS 'QUARTER'
		,(SELECT SUBSTRING((SELECT [COLUMN1] FROM [vw_Dump_MFSG_SLOS] WHERE ID = 7),12,4)) AS 'YEAR'
		,*
		,ROW_NUMBER()over (order by ID) as row  
		into #tempROwRead
		from [dbo].[vw_Dump_MFSG_SLOS]

-----------------------STEP 1---------------------------------------------------------------------
		--select *
		--from #tempROwRead
		--ORDER BY ID ASC

		--select *
		--from #tempROwRead
		--where  row >=22 and row <=42
		--ORDER BY ID ASC
		
		--,Case when [MONTH] <> '' then [MANUFACTURING_RAW] end 'Manufacturing'

-----------------------STEP 2---------------------------------------------------------------------
---QUESTION 1.b.-----------------------------------------------------------------------
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '1.b.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
				
		INTO #Question1b
		FROM #tempROwRead
		where  row >=9 and row <=15
		AND [COLUMN2] <> ''

		--drop table #Question1b

---QUESTION 2.1.-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '2.1.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
					
		INTO #Question2_1
		FROM #tempROwRead
		where  row >=22 and row <=42
		AND [COLUMN2] <> ''



---QUESTION 2.2.-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '2.2.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
			
		INTO #Question2_2
		FROM #tempROwRead
		where  row >=47 and row <=67
		AND [COLUMN2] <> ''



---QUESTION 2.3.-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '2.3.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
			
		INTO #Question2_3
		FROM #tempROwRead
		where  row >=72 and row <=92
		AND [COLUMN2] <> ''


---QUESTION 3.a-----------------------------------------------------------------------
--drop table #Question3_b

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '3.a.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
					
		INTO #Question3_a
		FROM #tempROwRead
		where  row >=97 and row <=102 
		AND [COLUMN2] <> ''



---QUESTION 3.b-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '3.b.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
					
		INTO #Question3_b
		FROM #tempROwRead
		where  row >=104 and row <=109
		AND [COLUMN2] <> ''



---QUESTION 3.c-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '3.c.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
					
		INTO #Question3_c
		FROM #tempROwRead
		where  row >=111 and row <=116
		AND [COLUMN2] <> ''


---QUESTION 3.d-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '3.d.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
					
		INTO #Question3_d
		FROM #tempROwRead
		where  row >=118 and row <=123
		AND [COLUMN2] <> ''



---QUESTION 3.e-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '3.e.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
						
		INTO #Question3_e
		FROM #tempROwRead
		where  row >=125 and row <=130
		AND [COLUMN2] <> ''



---QUESTION 3.f-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '3.f.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
					
		INTO #Question3_f
		FROM #tempROwRead
		where  row >=132 and row <=137
		AND [COLUMN2] <> ''




---QUESTION 3.g-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '3.g.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
					
		INTO #Question3_g
		FROM #tempROwRead
		where  row >=139 and row <=144
		AND [COLUMN2] <> ''



---QUESTION 4.-----------------------------------------------------------------------
--drop table #Question4
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '4.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
					
		INTO #Question4
		FROM #tempROwRead
		where  row >=148 and row <=153
		AND [COLUMN2] <> ''


		
---QUESTION 5.1.-----------------------------------------------------------------------
--drop table #Question5_1
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '5.1.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
				
		INTO #Question5_1
		FROM #tempROwRead
		where  row >=160 and row <=180
		AND [COLUMN2] <> ''

		--SELECT * FROM #Question5_1

---QUESTION 5.2.-----------------------------------------------------------------------
--drop table #Question5_1
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '5.2.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
				
		INTO #Question5_2
		FROM #tempROwRead
		where  row >=185 and row <=205
		AND [COLUMN2] <> ''

		--SELECT * FROM #Question5_1

---QUESTION 5.3.-----------------------------------------------------------------------
--drop table #Question5_1
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '5.3.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
			
		INTO #Question5_3
		FROM #tempROwRead
		where  row >=210 and row <=230
		AND [COLUMN2] <> ''

		--SELECT * FROM #Question5_1

---QUESTION 6.-----------------------------------------------------------------------
--drop table #Question6
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '6.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
				
		INTO #Question6
		FROM #tempROwRead
		where  row >=235 and row <=241
		AND [COLUMN2] <> ''

		--SELECT * FROM #Question5_1

---QUESTION 7.1.-----------------------------------------------------------------------
--drop table #Question6
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '7.1.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
				
		INTO #Question7_1
		FROM #tempROwRead
		where  row >=248 and row <=258
		AND [COLUMN2] <> ''

		--SELECT * FROM #Question7_1
		
		
---QUESTION 7.2.-----------------------------------------------------------------------
--drop table #Question6
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '7.2.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
				
		INTO #Question7_2
		FROM #tempROwRead
		where  row >=262 and row <=272
		AND [COLUMN2] <> ''

		--SELECT * FROM #Question7_2

---QUESTION 7.3.-----------------------------------------------------------------------
--drop table #Question6
		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '7.3.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
			
		INTO #Question7_3
		FROM #tempROwRead
		where  row >=276 and row <=286
		AND [COLUMN2] <> ''

		--SELECT * FROM #Question7_3

---QUESTION 8.-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '8.'
			,'QUESTION_TYPE' = 'CREDIT STANDARD'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
			
		INTO #Question8
		FROM #tempROwRead
		where  row >=289 and row <=295
		AND [COLUMN2] <> ''

		--SELECT * FROM #Question7_3

---QUESTION 9.1.-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '9.1.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
				
		INTO #Question9_1
		FROM #tempROwRead
		where  row >=302 and row <=312
		AND [COLUMN2] <> ''

		--SELECT * FROM #Question9_1


---QUESTION 9.2.-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '9.2.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
			
		INTO #Question9_2
		FROM #tempROwRead
		where  row >=316 and row <=326
		AND [COLUMN2] <> ''

		--SELECT * FROM #Question9_1

---QUESTION 9.3.-----------------------------------------------------------------------

		SELECT ID 
			,[YEAR]
			,[QUARTER]
			,'QUESTION_CODE' = '9.3.'
			,'QUESTION_TYPE' = 'FACTORS'
			,CASE WHEN [Column2] <> '' then [Column2] end 'QUESTION_CATEGORY'
			--TOTAL RESPONSE----
			,CASE WHEN [column3] <> '' then [column3] end 'T_OVERALL'
			,CASE WHEN [column4] <> '' then [column4] end 'T_TOP_CORPORATION'
			,CASE WHEN [column5] <> '' then [column5] end 'T_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column6] <> '' then [column6] end 'T_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column7] <> '' then [column7] end 'T_MICRO_ENTERPRISES'	
			--COUNT RESPONSE----
			,CASE WHEN [column8] <> '' then [column8] end 'R_OVERALL'
			,CASE WHEN [column9] <> '' then [column9] end 'R_TOP_CORPORATION'
			,CASE WHEN [column10] <> '' then [column10] end 'R_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column11] <> '' then [column11] end 'R_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column12] <> '' then [column12] end 'R_MICRO_ENTERPRISES'
			--AVERAGE--
			,CASE WHEN [column13] <> '' then [column13] end 'A_OVERALL'
			,CASE WHEN [column14] <> '' then [column14] end 'A_TOP_CORPORATION'
			,CASE WHEN [column15] <> '' then [column15] end 'A_LARGE_MIDDLE_MARKET_ENTERPRISES'
			,CASE WHEN [column16] <> '' then [column16] end 'A_SMALL_AND_MEDIUM_ENTERPRISES'
			,CASE WHEN [column17] <> '' then [column17] end 'A_MICRO_ENTERPRISES'
			
		INTO #Question9_3
		FROM #tempROwRead
		where  row >=330 and row <=340
		AND [COLUMN2] <> ''

-----------------------STEP 2---------------------------------------------------------------------
-----------------------STEP 3---------------------------------------------------------------------
	
	SELECT * 
	INTO #LCLENTERPRISES
	FROM #Question1b
		UNION ALL
	SELECT * FROM #Question2_1
		UNION ALL
	SELECT * FROM #Question2_2
		UNION ALL
	SELECT * FROM #Question2_3
		UNION ALL
	SELECT * FROM #Question3_a
		UNION ALL
	SELECT * FROM #Question3_b
		UNION ALL
	SELECT * FROM #Question3_c
		UNION ALL
	SELECT * FROM #Question3_d
		UNION ALL
	SELECT * FROM #Question3_e
		UNION ALL
	SELECT * FROM #Question3_f
		UNION ALL
	SELECT * FROM #Question3_g
		UNION ALL
	SELECT * FROM #Question4
		UNION ALL
	SELECT * FROM #Question5_1
		UNION ALL
	SELECT * FROM #Question5_2
		UNION ALL
	SELECT * FROM #Question5_3
		UNION ALL
	SELECT * FROM #Question6
		UNION ALL
	SELECT * FROM #Question7_1
		UNION ALL
	SELECT * FROM #Question7_2
		UNION ALL
	SELECT * FROM #Question7_3
		UNION ALL
	SELECT * FROM #Question8
		UNION ALL
	SELECT * FROM #Question9_1
		UNION ALL
	SELECT * FROM #Question9_2
		UNION ALL
	SELECT * FROM #Question9_3

-----------------------STEP 3---------------------------------------------------------------------

	select * from #LCLENTERPRISES

-----------------------STEP 4---------------------------------------------------------------------
--DROP TABLE #QTEMPTABLE

	SELECT [YEAR],
		[QUARTER],
		'TIME_CODE' = [YEAR] + '-' + [QUARTER],
		[QUESTION_CODE],
		[QUESTION_TYPE],
		[QUESTION_CATEGORY],
		ENTERPRISESLOAN_TYPE,
		[Values] 
	--INTO #QTEMPTABLE
	FROM #LCLENTERPRISES
	unpivot
	(
	[Values] FOR ENTERPRISESLOAN_TYPE IN (T_OVERALL,
								T_TOP_CORPORATION,
								T_LARGE_MIDDLE_MARKET_ENTERPRISES,
								T_SMALL_AND_MEDIUM_ENTERPRISES,
								T_MICRO_ENTERPRISES,
								R_OVERALL,
								R_TOP_CORPORATION,
								R_LARGE_MIDDLE_MARKET_ENTERPRISES,
								R_SMALL_AND_MEDIUM_ENTERPRISES,
								R_MICRO_ENTERPRISES,
								A_OVERALL,
								A_TOP_CORPORATION,
								A_LARGE_MIDDLE_MARKET_ENTERPRISES,
								A_SMALL_AND_MEDIUM_ENTERPRISES,
								A_MICRO_ENTERPRISES
								)
	) as unpLCL


	------------
	SELECT * --,CONVERT(DECIMAL(18,2), REPLACE([values], ',', '')) AMOUNT
	FROM #QTEMPTABLE
-----------------------STEP 4---------------------------------------------------------------------

	--SELECT * ,CONVERT(DECIMAL(18,2), REPLACE([values], ',', '')) AMOUNT, DATECODE = [YEAR] + '-' + [QUARTER]
	--FROM #QTEMPTABLE

-----------------------STEP 5 TIMEDIM---------------------------------------------------------------------
	SELECT B.Time_Idx,
	A.YEAR, 
	A.QUARTER,
	A.QUESTION_CODE, 
	A.QUESTION_TYPE,
	A.QUESTION_CATEGORY,
	A.ENTERPRISESLOAN_TYPE,
	--[Values]
	CONVERT(DECIMAL(18,2), REPLACE([Values], ',', '')) [VALUE] 
	INTO #QSTEMPSTORAGE
	FROM #QTEMPTABLE A
	JOIN (
        SELECT 
            MAX(Time_Idx) Time_Idx,
            Quarter_Name
        FROM EDW.dbo.Dim_Time_1
        GROUP BY Quarter_Name
    )B
    ON A.TIME_CODE = B.Quarter_Name

-----------------------STEP  INSERT TO QUESTIONNAIRE 1 TABLE-------------------------------------
SELECT * FROM #QSTEMPSTORAGE

INSERT INTO [Dump_MFSG_SLOS_LOANS_OR_CREDIT_LINES_TO_ENTERPRISES] 
		([TIME_CODE]
		,[YEAR]
		,[QUARTER]
		,[QUESTION_CODE]
		,[QUESTION_TYPE]
		,[QUESTION_CATEGORY]
		,[MARKET_TYPE]
		,[VALUES])
SELECT * 
FROM #QSTEMPSTORAGE 

-----------------------STEP  INSERT TO QUESTIONNAIRE 1 TABLE-------------------------------------


