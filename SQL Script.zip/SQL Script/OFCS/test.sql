---1---------------------------------------------------------
select ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS ID, * 
into #Temp_BS_GCG
from [Dump_MFSG_OFCS_SST_GCG_BS]

--select * from #Temp_BS_GCG order by id asc
---2---------------------------------------------------------
--drop table #TempTableIC_BS
--SELECT
--CAST(GETDATE() AS DATE) AS Created_Date

SELECT  
CAST(GETDATE() AS DATE) AS Created_Date,
ID,
CONCAT(column4, column5,column6,column7,column8,column9,column10,column11) AS AccountDesc, 
'DomesticCurrency' = column12,
'ForeignCurrencyUSD' = column13,
'ForeignCurrrencyPESO_EQ' = column14,
'TOTAL PESO EQUIVALENT' = column15
--into #TempTableIC_BS
FROM #Temp_BS_GCG
--where column15 <> ''
order by ID asc, 
AccountDesc OFFSET 7 ROWS

---3--------------------------------------------------------
Select ID, AccountDesc,
case
when  LTRIM(RTRIM([DomesticCurrency])) = '-' then NULL 
	 WHEN ISNUMERIC([DomesticCurrency]) = '' then null
		ELSE [DomesticCurrency]
		end as  'In Domestic Currency',
case
when  ltrim(rtrim([ForeignCurrencyUSD])) = '-' then NULL  
	WHEN ISNUMERIC([ForeignCurrencyUSD]) = '' then null
		ELSE [ForeignCurrencyUSD]
		end as  'Foreign Currency USD',
case
when  LTRIM (RTRIM( [ForeignCurrrencyPESO_EQ])) = '-' then NULL 
	WHEN ISNUMERIC([ForeignCurrrencyPESO_EQ]) = '' then null
		ELSE [ForeignCurrrencyPESO_EQ]
		end as  'Foreign Currrency PESO Equivalent',
case
when LTRIM(rtrim( [TOTAL PESO EQUIVALENT])) = '-' then NULL	
	WHEN ISNUMERIC([TOTAL PESO EQUIVALENT]) = '' then null
		ELSE [TOTAL PESO EQUIVALENT]
		end as  'TOTAL PESO EQUIVALENT'
into #GCG_BS
 from #TempTableIC_BS
 order by id asc


---4------------------------------------------------------------------------
 select ID
		,AccountDesc
		,Replace(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([In Domestic Currency], '                                  ', ''), ' ',''),'.',''),',',''),'(',''),')',''),'','')  as 'IDC'
		,REPLACE(REPLACE(REPLACE(REPLACE([Foreign Currency USD], '                                  ', ''), ' ',''),'.',''),',','')  as 'FCU'
		,REPLACE(REPLACE(REPLACE(REPLACE([Foreign Currrency PESO Equivalent], '                                  ', ''), ' ',''),'.',''),',','')  as 'FCPE'
		,REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([TOTAL PESO EQUIVALENT], '                                  ', ''), ' ',''),'.',''),',',''),'(',''),')','')  as 'TPE'
  INTO #GCG_BS_T1
  from #GCG_BS



  select * from #GCG_BS_T1
---5-------------------------------------------------------
	select AccountDesc,
	Domestic_Currency = cast([IDC] as numeric)
	,Foreign_currency_USD = cast([FCU] as numeric)
	,Foreign_currency_PesoEquivalent = cast([FCPE] as numeric)
	,Total_Peso_Equivalent = cast([TPE] as numeric)
	,'SST_TYPE' = 'GCG'
	,'COMPANY_NAME' = ''
	 INTO ##GCG_BS_T2
	from #GCG_BS_T1
	where AccountDesc <> ''


	INSERT INTO S_Fact_MFSG_OFCS_EXTERAL_SST VALUES(
	AccountDesc,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	SST_TYPE,
	[COMPANY_NAME])

	SELECT 
	AccountDesc,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	SST_TYPE,
	[COMPANY_NAME]
	FROM ##GCG_BS_T2

