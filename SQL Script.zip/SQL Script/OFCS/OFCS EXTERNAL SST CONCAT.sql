select [Ref_RowNum],datecode,
AccountDesc = AccountDesc + ' Domestic'
,[Value] = Domestic_Currency
,SST_TYPE
--into testtable
from [S_Fact_MFSG_OFCS_EXTERAL_SST]

UNION ALL

select 
[Ref_RowNum],datecode,
AccountDesc + ' Foreign'
,[Value] = Foreign_Currency_USD
,SST_TYPE
from [S_Fact_MFSG_OFCS_EXTERAL_SST]

select * from [S_Fact_MFSG_OFCS_EXTERAL_SST]

drop table testtable

select * from testtable where sst_type = 'GCG'
order by ref_rownum asc

select * from [dbo].[Dump_MFSG_OFCS_FRPTI_TRUST]