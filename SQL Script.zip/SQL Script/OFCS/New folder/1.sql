USE [DES_Staging]
GO

/****** Object:  Table [dbo].[S_Fact_MFSG_OFCS_EXTERAL_SST]    Script Date: 04/05/2023 5:38:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[S_Fact_MFSG_OFCS_EXTERAL_SST_STG](
	[DATECODE] [nvarchar](10) NULL,
	[AccountDesc] [nvarchar](max) NOT NULL,
	[Domestic_Currency] [numeric](18, 0) NULL,
	[Foreign_currency_USD] [numeric](18, 0) NULL,
	[Foreign_currency_PesoEquivalent] [numeric](18, 0) NULL,
	[Total_Peso_Equivalent] [numeric](18, 0) NULL,
	[SST_TYPE] [varchar](50) NOT NULL,
	[COMPANY_NAME] [varchar](100) NOT NULL,
	[Ref_RowNum] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


