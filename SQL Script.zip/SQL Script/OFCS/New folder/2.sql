SELECT *
  FROM [DES_Staging].[dbo].[SST_TEST_GCG]
  WHERE X = 'CONSOLIDATED BALANCE SHEET REPORT FORM FOR GOVERNMENT-OWNED OR -CONTROLLED CORPORATIONS'

---- GETTING THE DATE------
select F19 
from [dbo].[SST_TEST_MAIN]
where F19 like '%/%'


select  *
from [dbo].[SST_TEST_MAIN]


select 
		'IC' = [LEGEND:],
		'GCG' = [DO NOT DELETE THESE CELLS],
		'SEC' = [F3],
		'PREVIOUS 4SR' = [F4],
		'CURRENT 4SR' = [F5],
		'TRUST' = [F8],
		'FSI ACCOUNT' = [F9],
		'BS ACCOUNT' = [F10],
		'ACCOUNT' = CONCAT([F19],[F20],[F21],[F22],[F23],[F24],[F25],[CONSO BRIDGE ACTUAL VALUES (col_index_num)]),
		'In Domestic Currency' = [10],
		'Foreign Currency (in USD)' = [11],
		'Foreign Currency (Peso Equivalent)-AV ACTUAL' = [12],
		'TOTAL PESO EQUIVALENT-AV ACTUAL' = [13],
		'Foreign Currency (Peso Equivalent)-CV CONVERTED' = [F31],
		'TOTAL PESO EQUIVALENT-CV' = [F32],
		'CATEGORY' = [F33],
		'INSTRUMENT' = [F34],
		'BALANCESHEET ACCOUNT' = [F35],
		'ECONOMIC SECTOR' = [F36],
		'FSI ACCOUNT EQUI' = [F37],
		'BS ACCOUNT EQUI' = [F38]
--INTO #TEMPMAIN
FROM [dbo].[SST_TEST_MAIN]
ORDER BY IC ASC



select 
		'ID' = SUBSTRING([LEGEND:], 5, 5),	
		'IC' = [LEGEND:],
		'GCG' = [DO NOT DELETE THESE CELLS],
		'SEC' = [F3],
		'CURRENT 4SR' = [F5],
		'ACCOUNT' = CONCAT([F19],[F20],[F21],[F22],[F23],[F24],[F25],[CONSO BRIDGE ACTUAL VALUES (col_index_num)])
--INTO #TEMPMAIN
FROM [dbo].[SST_TEST_MAIN]
ORDER BY IC ASC


SELECT * 
FROM #TEMPMAIN
WHERE ACCOUNT <> ''

SELECT *
  FROM [DES_Staging].[dbo].[SST_TEST_GCG]
  WHERE X = 'CONSOLIDATED BALANCE SHEET REPORT FORM FOR GOVERNMENT-OWNED OR -CONTROLLED CORPORATIONS'

---- GETTING THE DATE------
select F19 
from [dbo].[SST_TEST_MAIN]
where F19 like '%/%'


select  *
from [dbo].[SST_TEST_MAIN]


select 
		'IC' = [LEGEND:],
		'GCG' = [DO NOT DELETE THESE CELLS],
		'SEC' = [F3],
		'PREVIOUS 4SR' = [F4],
		'CURRENT 4SR' = [F5],
		'TRUST' = [F8],
		'FSI ACCOUNT' = [F9],
		'BS ACCOUNT' = [F10],
		'ACCOUNT' = CONCAT([F19],[F20],[F21],[F22],[F23],[F24],[F25],[CONSO BRIDGE ACTUAL VALUES (col_index_num)]),
		'In Domestic Currency' = [10],
		'Foreign Currency (in USD)' = [11],
		'Foreign Currency (Peso Equivalent)-AV ACTUAL' = [12],
		'TOTAL PESO EQUIVALENT-AV ACTUAL' = [13],
		'Foreign Currency (Peso Equivalent)-CV CONVERTED' = [F31],
		'TOTAL PESO EQUIVALENT-CV' = [F32],
		'CATEGORY' = [F33],
		'INSTRUMENT' = [F34],
		'BALANCESHEET ACCOUNT' = [F35],
		'ECONOMIC SECTOR' = [F36],
		'FSI ACCOUNT EQUI' = [F37],
		'BS ACCOUNT EQUI' = [F38]
--INTO #TEMPMAIN
FROM [dbo].[SST_TEST_MAIN]
ORDER BY IC ASC


SELECT IC,
		GCG,
		SEC,
		[CURRENT 4SR],
		ACCOUNT,
		[In Domestic Currency],
		[Foreign Currency (in USD)],
		[Foreign Currency (Peso Equivalent)-CV CONVERTED],
		[TOTAL PESO EQUIVALENT-CV]
INTO #TEMPMAIN2
FROM #TEMPMAIN
where ID > 24
order by ID asc

