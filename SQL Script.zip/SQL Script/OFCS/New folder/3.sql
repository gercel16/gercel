-------------------------------------------------------------
-----GCG-----------------------------------------------------
---1---------------------------------------------------------
select ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS ID, * 
into #Temp_BS_GCG
from [Dump_MFSG_OFCS_SST_GCG_BS]



--select * from #Temp_BS_GCG order by id asc
---2---------------------------------------------------------
--drop table #TempTableIC_BS
--SELECT
--CAST(GETDATE() AS DATE) AS Created_Date GCG_4Q2021_COMPANY1

SELECT  
--CAST(GETDATE() AS DATE) AS Created_Date,
'AccountDesc' = CONCAT(column6, column7,column8,column9,column10,column11,column12,column13), 
'DomesticCurrency' = column14,
'ForeignCurrencyUSD' = column15,
'ForeignCurrrencyPESO_EQ' = column16,
'TOTAL PESO EQUIVALENT' = column17
into #TempTableGCG_BS_sub
FROM #Temp_BS_GCG
--where column15 <> ''
order by ID asc, 
AccountDesc OFFSET 7 ROWS



-----------------------------------------------------------

select ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS ID,* 
into #TempTableGCG_BS
from #TempTableGCG_BS_sub



---3--------------------------------------------------------
Select ID, 
--Created_Date, 
AccountDesc,
case
when  LTRIM(RTRIM([DomesticCurrency])) = '-' then NULL 
	 WHEN ISNUMERIC([DomesticCurrency]) = '' then null
		ELSE [DomesticCurrency]
		end as  'In Domestic Currency',
case
when  ltrim(rtrim([ForeignCurrencyUSD])) = '-' then NULL  
	WHEN ISNUMERIC([ForeignCurrencyUSD]) = '' then null
		ELSE [ForeignCurrencyUSD]
		end as  'Foreign Currency USD',
case
when  LTRIM (RTRIM( [ForeignCurrrencyPESO_EQ])) = '-' then NULL 
	WHEN ISNUMERIC([ForeignCurrrencyPESO_EQ]) = '' then null
		ELSE [ForeignCurrrencyPESO_EQ]
		end as  'Foreign Currrency PESO Equivalent',
case
when LTRIM(rtrim( [TOTAL PESO EQUIVALENT])) = '-' then NULL	
	WHEN ISNUMERIC([TOTAL PESO EQUIVALENT]) = '' then null
		ELSE [TOTAL PESO EQUIVALENT]
		end as  'TOTAL PESO EQUIVALENT'
into #GCG_BS
 from #TempTableGCG_BS
 order by id asc


---4------------------------------------------------------------------------
 select ID,
 --Created_Date,
		AccountDesc
		,REPLACE([In Domestic Currency],',','')  as 'IDC'
		,REPLACE([Foreign Currency USD],',','')  as 'FCU'
		,REPLACE([Foreign Currrency PESO Equivalent],',','')  as 'FCPE'
		,REPLACE([TOTAL PESO EQUIVALENT],',','')  as 'TPE'
  INTO #GCG_BS_T1
  from #GCG_BS

---5-------------------------------------------------------
	--select 
	--Created_Date,
	--AccountDesc,
	--Domestic_Currency = cast([IDC] as numeric)
	--,Foreign_currency_USD = cast([FCU] as numeric)
	--,Foreign_currency_PesoEquivalent = cast([FCPE] as numeric)
	--,Total_Peso_Equivalent = cast([TPE] as numeric)
	--,'SST_TYPE' = 'GCG'
	--,'COMPANY_NAME' = ''
	-- INTO #GCG_BS_T2
	--from #GCG_BS_T1
	--where AccountDesc <> ''

	select ID,
	--Created_Date,
	AccountDesc,
	Domestic_Currency = cast([IDC] as numeric(18,0))
	,Foreign_currency_USD = cast([FCU] as numeric(18,0))
	,Foreign_currency_PesoEquivalent = cast([FCPE] as numeric(18,0))
	,Total_Peso_Equivalent = cast([TPE] as numeric(18,0))
	,'SST_TYPE' = 'GCG'
	,'COMPANY_NAME' = ''
	 INTO #GCG_BS_T2
	from #GCG_BS_T1
	--where AccountDesc <> '' 
	--where ISNUMERIC ([In Domestic Currency]) = 1
	--and [In Domestic Currency] is not null
	
---6-------------------------------------------------------
	INSERT INTO  [dbo].[S_Fact_MFSG_OFCS_EXTERAL_SST] (
	DATECODE,
	AccountDesc,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	SST_TYPE,
	[COMPANY_NAME],
	[Ref_RowNum])
	SELECT 
	Created_Date,
	AccountDesc,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	SST_TYPE,
	[COMPANY_NAME],
	ID
	FROM #GCG_BS_T2

--------------------------------------------------------------
----LIFE AND NONLIFE------------------------------------------
---1----------------------------------------------------------
select ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS ID, * 
into #Temp_BS_IC
from [dbo].[Dump_MFSG_OFCS_SST_IC_BS]

---2---------------------------------------------------------

SELECT  
CAST(GETDATE() AS DATE) AS Created_Date,
ID,
'AccountDesc' = CONCAT(column4, column5,column6,column7,column8,column9,column10,column11), 
'DomesticCurrency' = column12,
'ForeignCurrencyUSD' = column13,
'ForeignCurrrencyPESO_EQ' = column14,
'TOTAL PESO EQUIVALENT' = column15
into #TempTableIC_BS
FROM #Temp_BS_IC
--where column15 <> ''
order by ID asc, 
AccountDesc OFFSET 7 ROWS


---3--------------------------------------------------------
Select ID,  Created_Date, AccountDesc,
case
when  LTRIM(RTRIM([DomesticCurrency])) = '-' then NULL 
	 WHEN ISNUMERIC([DomesticCurrency]) = '' then null
		ELSE [DomesticCurrency]
		end as  'In Domestic Currency',
case
when  ltrim(rtrim([ForeignCurrencyUSD])) = '-' then NULL  
	WHEN ISNUMERIC([ForeignCurrencyUSD]) = '' then null
		ELSE [ForeignCurrencyUSD]
		end as  'Foreign Currency USD',
case
when  LTRIM (RTRIM( [ForeignCurrrencyPESO_EQ])) = '-' then NULL 
	WHEN ISNUMERIC([ForeignCurrrencyPESO_EQ]) = '' then null
		ELSE [ForeignCurrrencyPESO_EQ]
		end as  'Foreign Currrency PESO Equivalent',
case
when LTRIM(rtrim( [TOTAL PESO EQUIVALENT])) = '-' then NULL	
	WHEN ISNUMERIC([TOTAL PESO EQUIVALENT]) = '' then null
		ELSE [TOTAL PESO EQUIVALENT]
		end as  'TOTAL PESO EQUIVALENT'
into #IC_BS
 from #TempTableIC_BS
 order by id asc

 ---4------------------------------------------------------------------------
 --select ID,Created_Date
	--	,AccountDesc
	--	,Replace(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([In Domestic Currency], '                                  ', ''), ' ',''),'.',''),',',''),'(',''),')',''),'','')  as 'IDC'
	--	,Replace(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([In Domestic Currency], '                                  ', ''), ' ',''),'.',''),',',''),'(',''),')',''),'','')  as 'IDC'
	--	,REPLACE(REPLACE(REPLACE(REPLACE([Foreign Currency USD], '                                  ', ''), ' ',''),'.',''),',','')  as 'FCU'
	--	,REPLACE(REPLACE(REPLACE(REPLACE([Foreign Currrency PESO Equivalent], '                                  ', ''), ' ',''),'.',''),',','')  as 'FCPE'
	--	,REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([TOTAL PESO EQUIVALENT], '                                  ', ''), ' ',''),'.',''),',',''),'(',''),')','')  as 'TPE'
 -- INTO #IC_BS_T1
 -- from #IC_BS


   select ID,Created_Date
		,AccountDesc
		,REPLACE([In Domestic Currency],',','')  as 'IDC'
		,REPLACE([Foreign Currency USD],',','')  as 'FCU'
		,REPLACE([Foreign Currrency PESO Equivalent],',','')  as 'FCPE'
		,REPLACE([TOTAL PESO EQUIVALENT],',','')  as 'TPE'
  INTO #IC_BS_T1
  from #IC_BS

  ---5-------------------------------------------------------
	select ID,
	Created_Date,
	AccountDesc,
	Domestic_Currency = cast([IDC] as numeric(18,0))
	,Foreign_currency_USD = cast([FCU] as numeric(18,0))
	,Foreign_currency_PesoEquivalent = cast([FCPE] as numeric(18,0))
	,Total_Peso_Equivalent = cast([TPE] as numeric(18,0))
	,'SST_TYPE' = 'IC'
	,'COMPANY_NAME' = ''
	 INTO #IC_BS_T2
	from #IC_BS_T1
	where AccountDesc <> ''

---6-------------------------------------------------------

	INSERT INTO  [dbo].[S_Fact_MFSG_OFCS_EXTERAL_SST] (
	DATECODE,
	AccountDesc,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	SST_TYPE,
	[COMPANY_NAME],
	[Ref_RowNum])

	SELECT 
	Created_Date,
	AccountDesc,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	SST_TYPE,
	[COMPANY_NAME],
	ID
	FROM #IC_BS_T2

--------------------------------------------------------------
----SEC-------------------------------------------------------
---1----------------------------------------------------------
select ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS ID, * 
into #Temp_BS_SEC
from [dbo].[Dump_MFSG_OFCS_SST_SEC_BS]

---2---------------------------------------------------------

SELECT  
CAST(GETDATE() AS DATE) AS Created_Date,
ID,
'AccountDesc' = CONCAT(column4, column5,column6,column7,column8,column9,column10,column11),
'DomesticCurrency' = column12,
'ForeignCurrencyUSD' = column13,
'ForeignCurrrencyPESO_EQ' = column14,
'TOTAL PESO EQUIVALENT' = column15
into #TempTableSEC_BS
FROM #Temp_BS_SEC
--where column15 <> ''
order by ID asc, 
AccountDesc OFFSET 7 ROWS


---3--------------------------------------------------------
Select ID,  Created_Date, AccountDesc,
case
when  LTRIM(RTRIM([DomesticCurrency])) = '-' then NULL 
	 WHEN ISNUMERIC([DomesticCurrency]) = '' then null
		ELSE [DomesticCurrency]
		end as  'In Domestic Currency',
case
when  ltrim(rtrim([ForeignCurrencyUSD])) = '-' then NULL  
	WHEN ISNUMERIC([ForeignCurrencyUSD]) = '' then null
		ELSE [ForeignCurrencyUSD]
		end as  'Foreign Currency USD',
case
when  LTRIM (RTRIM( [ForeignCurrrencyPESO_EQ])) = '-' then NULL 
	WHEN ISNUMERIC([ForeignCurrrencyPESO_EQ]) = '' then null
		ELSE [ForeignCurrrencyPESO_EQ]
		end as  'Foreign Currrency PESO Equivalent',
case
when LTRIM(rtrim( [TOTAL PESO EQUIVALENT])) = '-' then NULL	
	WHEN ISNUMERIC([TOTAL PESO EQUIVALENT]) = '' then null
		ELSE [TOTAL PESO EQUIVALENT]
		end as  'TOTAL PESO EQUIVALENT'
into #SEC_BS
 from #TempTableSEC_BS
 order by id asc

 ---4------------------------------------------------------------------------
   select ID,Created_Date
		,AccountDesc
		,REPLACE([In Domestic Currency],',','')  as 'IDC'
		,REPLACE([Foreign Currency USD],',','')  as 'FCU'
		,REPLACE([Foreign Currrency PESO Equivalent],',','')  as 'FCPE'
		,REPLACE([TOTAL PESO EQUIVALENT],',','')  as 'TPE'
	INTO #SEC_BS_T1
  from #SEC_BS

  ---5-------------------------------------------------------
	select ID,
	Created_Date,
	AccountDesc,
	Domestic_Currency = cast([IDC] as numeric(18,0))
	,Foreign_currency_USD = cast([FCU] as numeric(18,0))
	,Foreign_currency_PesoEquivalent = cast([FCPE] as numeric(18,0))
	,Total_Peso_Equivalent = cast([TPE] as numeric(18,0))
	,'SST_TYPE' = 'SEC'
	,'COMPANY_NAME' = ''
	 INTO #SEC_BS_T2
	from #SEC_BS_T1
	where AccountDesc <> ''

---6-------------------------------------------------------

	INSERT INTO  [dbo].[S_Fact_MFSG_OFCS_EXTERAL_SST] (
	DATECODE,
	AccountDesc,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	SST_TYPE,
	[COMPANY_NAME],
	[Ref_RowNum])

	SELECT 
	Created_Date,
	AccountDesc,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	SST_TYPE,
	[COMPANY_NAME],
	ID
	FROM #SEC_BS_T2

--------------------------------------------------------------
----PRENEED-------------------------------------------------------
---1----------------------------------------------------------
select ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS ID, * 
into #Temp_BS_PRENEED
from [dbo].[Dump_MFSG_OFCS_SST_PRENEED_BS]

---2---------------------------------------------------------

SELECT  
CAST(GETDATE() AS DATE) AS Created_Date,
ID,
'AccountDesc' = CONCAT(column4, column5,column6,column7,column8,column9,column10,column11),
'DomesticCurrency' = column12,
'ForeignCurrencyUSD' = column13,
'ForeignCurrrencyPESO_EQ' = column14,
'TOTAL PESO EQUIVALENT' = column15
into #TempTablePRENEED_BS
FROM #Temp_BS_PRENEED
--where column15 <> ''
order by ID asc, 
AccountDesc OFFSET 7 ROWS


---3--------------------------------------------------------
Select ID,  Created_Date, AccountDesc,
case
when  LTRIM(RTRIM([DomesticCurrency])) = '-' then NULL 
	 WHEN ISNUMERIC([DomesticCurrency]) = '' then null
		ELSE [DomesticCurrency]
		end as  'In Domestic Currency',
case
when  ltrim(rtrim([ForeignCurrencyUSD])) = '-' then NULL  
	WHEN ISNUMERIC([ForeignCurrencyUSD]) = '' then null
		ELSE [ForeignCurrencyUSD]
		end as  'Foreign Currency USD',
case
when  LTRIM (RTRIM( [ForeignCurrrencyPESO_EQ])) = '-' then NULL 
	WHEN ISNUMERIC([ForeignCurrrencyPESO_EQ]) = '' then null
		ELSE [ForeignCurrrencyPESO_EQ]
		end as  'Foreign Currrency PESO Equivalent',
case
when LTRIM(rtrim( [TOTAL PESO EQUIVALENT])) = '-' then NULL	
	WHEN ISNUMERIC([TOTAL PESO EQUIVALENT]) = '' then null
		ELSE [TOTAL PESO EQUIVALENT]
		end as  'TOTAL PESO EQUIVALENT'
into #PRENNED_BS
 from #TempTablePRENEED_BS
 order by id asc

 ---4------------------------------------------------------------------------
   select ID,Created_Date
		,AccountDesc
		,REPLACE([In Domestic Currency],',','')  as 'IDC'
		,REPLACE([Foreign Currency USD],',','')  as 'FCU'
		,REPLACE([Foreign Currrency PESO Equivalent],',','')  as 'FCPE'
		,REPLACE([TOTAL PESO EQUIVALENT],',','')  as 'TPE'
	INTO #PRENEED_BS_T1
  from #PRENNED_BS

  ---5-------------------------------------------------------
	select ID,
	Created_Date,
	AccountDesc,
	Domestic_Currency = cast([IDC] as numeric(18,0))
	,Foreign_currency_USD = cast([FCU] as numeric(18,0))
	,Foreign_currency_PesoEquivalent = cast([FCPE] as numeric(18,0))
	,Total_Peso_Equivalent = cast([TPE] as numeric(18,0))
	,'SST_TYPE' = 'PRENEED'
	,'COMPANY_NAME' = ''
	 INTO #PRENEED_BS_T2
	from #PRENEED_BS_T1
	where AccountDesc <> ''

---6-------------------------------------------------------

	INSERT INTO  [dbo].[S_Fact_MFSG_OFCS_EXTERAL_SST] (
	DATECODE,
	AccountDesc,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	SST_TYPE,
	[COMPANY_NAME],
	[Ref_RowNum])

	SELECT 
	Created_Date,
	AccountDesc,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	SST_TYPE,
	[COMPANY_NAME],
	ID
	FROM #PRENEED_BS_T2

--------------------------------------------------------------
----
