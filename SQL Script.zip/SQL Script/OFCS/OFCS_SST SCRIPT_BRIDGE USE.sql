/****** Script for SelectTopNRows command from SSMS  ******/


----------------------------------------------------------------
SELECT *
FROM [dbo].[SST_TEST_GCG]
WHERE [LOOKUP FOR MAIN] LIKE 'GCG%'
---------------------------------------------------------------
--- DATE 

DECLARE @DATE

select F19 
from [dbo].[SST_TEST_MAIN]
where F19 like '%/%'

---------------------------------------------------------------
---------------------------------------------------------------
---------------------------------------------------------------
---MAIN-------------------------------------------------------
select 
		'ID' = SUBSTRING([LEGEND:], 5, 5),	
		'IC' = [LEGEND:],
		'GCG' = [DO NOT DELETE THESE CELLS],
		'SEC' = [F3],
		'CURRENT 4SR' = [F5],
		'ACCOUNT' = CONCAT([F19],[F20],[F21],[F22],[F23],[F24],[F25],[CONSO BRIDGE ACTUAL VALUES (col_index_num)])
INTO #TEMPMAIN
FROM [dbo].[SST_TEST_MAIN]
ORDER BY IC ASC


SELECT * 
INTO #MAINLOOKUP
FROM #TEMPMAIN
WHERE ACCOUNT <> ''




---GCG----------------------------------------------------------
--------1------------------
SELECT DISTINCT
	'DATE' = (select TOP 1 F19 from [dbo].[SST_TEST_MAIN] where F19 like '%/%'),
	'NO' = SUBSTRING([LOOKUP FOR MAIN], 5, 5),
	'CATEGORY' = CATEGORY,
	'INSTRUMENT'= [INSTRUMENT],
	'BS ACCOUNT' = [BALANCE SHEET ACCOUNT],
	'ECONOMIC SECTOR' = [Economic Sector],
	 [HH DEBT],
	'CODE' = [LOOKUP FOR MAIN],
	'ACCOUNT' = CONCAT([x],[x1],[x2],[x3],[x4],[x5],[x6],[x7]),
	'IDC' = [Total DC],
	'FCU' = [Total FC-USD],
	'FCPE' = [Total FC-Peso],
	'TPE' = [Total Peso Equivalent]
INTO #TEMPGCG
FROM [dbo].[SST_TEST_GCG]
WHERE [LOOKUP FOR MAIN] LIKE 'GCG%'

--DROP TABLE #TEMPGCG

--------2------------------
Select 'ID' = cast([NO] as INT),
	'DATE' = CAST([DATE] AS DATE),
	--[NO],
	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT],
	[CODE],
	[ACCOUNT],
case
when  LTRIM(RTRIM(IDC)) = '-' then NULL 
	 WHEN ISNUMERIC(IDC) = '' then null
		ELSE IDC
		end as  'IDC',
case
when  ltrim(rtrim(FCU)) = '-' then NULL  
	WHEN ISNUMERIC(FCU) = '' then null
		ELSE FCU
		end as  'FCU',
case
when  LTRIM (RTRIM( FCPE)) = '-' then NULL 
	WHEN ISNUMERIC(FCPE) = '' then null
		ELSE FCPE
		end as  'FCPE',
case
when LTRIM(rtrim( TPE)) = '-' then NULL	
	WHEN ISNUMERIC(TPE) = '' then null
		ELSE TPE
		end as  'TPE'
INTO #TEMPGCG1
FROM #TEMPGCG
WHERE ACCOUNT IS NOT NULL
ORDER BY [NO] ASC

--DROP TABLE #TEMPGCG1
-------3-------------------
 select ID,
 --Created_Date,
	[DATE],
 	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT],
	[CODE],
	[ACCOUNT],
		REPLACE(IDC,',','')  as 'IDC',
		REPLACE(FCU,',','')  as 'FCU',
		REPLACE(FCPE,',','')  as 'FCPE',
		REPLACE(TPE,',','')  as 'TPE'

	--'In Domestic Currency' = [Total DC],
	--'Foreign Currency (in USD)' = [Total FC-USD],
	--'Foreign Currency (Peso Equivalent)' = [Total FC-Peso],
	--'TOTAL PESO EQUIVALENT' = [Total Peso Equivalent]
  INTO #TEMPGCG2
  from #TEMPGCG1
  ORDER BY ID ASC


  --DROP TABLE #TEMPGCG2
  -----------------------------

   SELECT ID, [ACCOUNT],[FCU],
   ISNUMERIC([IDC])
   FROM #TEMPGCG2
   WHERE ID = 1
   ;
-------4-------------------
SELECT ID,
	[DATE],
	'GROUP NAME' = SUBSTRING([CODE], 1, 3),
	[CODE],
	[ACCOUNT],
  	'IDC' = cast([IDC] as numeric(18,0)),
	'FCU' = cast([FCU] as numeric(18,0)),
	'FCPE' = cast([FCPE] as numeric(18,0)),
	'TPE' = cast([TPE] as numeric(18,0)),
	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT]
INTO #TEMPGCG3
FROM #TEMPGCG2
ORDER BY ID ASC

--DROP TABLE #TEMPGCG3
-------5---------------------------------------------------------
---INSERT STAGING----

SELECT 
	[DATE]
	[GROUP NAME],
	[CODE],
	[ACCOUNT],
	[IDC],
	[FCU],
	[FCPE],
	[TPE],
	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT]
FROM #TEMPGCG3

SELECT	
		B.[DATE],
		A.ACCOUNT,
		B.ACCOUNT,
		B.CODE,
		B.[GROUP NAME],
		A.[CURRENT 4SR],
		B.[IDC],
		B.[FCU],
		B.[FCPE],
		B.[TPE]
FROM #MAINLOOKUP A
JOIN #TEMPGCG3 B
ON A.ACCOUNT = B.ACCOUNT
--WHERE A.[CURRENT 4SR] = 'ofcs_currency_domestic'
--WHERE A.GCG = 'GCG.1'
--ON A.GCG = B.CODE

---------------------------------------------------------------
---------------------------------------------------------------
---IC----------------------------------------------------------

SELECT * 
FROM [dbo].[SST_TEST_IC]

----1---------------------------------------------
SELECT DISTINCT
	'DATE' = (select TOP 1 F19 from [dbo].[SST_TEST_MAIN] where F19 like '%/%'),
	'NO' = SUBSTRING([LOOKUP FOR MAIN], 4, 5),
	'CATEGORY' = CATEGORY,
	'INSTRUMENT'= [INSTRUMENT],
	'BS ACCOUNT' = [BALANCE SHEET ACCOUNT],
	'ECONOMIC SECTOR' = [Economic Sector],
	 [HH DEBT],
	'CODE' = [LOOKUP FOR MAIN],
	'ACCOUNT' = CONCAT([x],[x1],[x2],[x3],[x4],[x5],[x6],[x7]),
	'IDC' = [Total DC],
	'FCU' = [Total FC-USD],
	'FCPE' = [Total FC-Peso],
	'TPE' = [Total Peso Equivalent]
INTO #TEMPIC
FROM [dbo].[SST_TEST_IC]
WHERE [LOOKUP FOR MAIN] LIKE 'IC%'

--DROP TABLE #TEMPIC

----2---------------------------------------------
Select 
'ID' = cast([NO] as INT),
	'DATE' = CAST([DATE] AS DATE),
	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT],
	[CODE],
	[ACCOUNT],
case
when  LTRIM(RTRIM(IDC)) = '-' then NULL 
	 WHEN ISNUMERIC(IDC) = '' then null
		ELSE IDC
		end as  'IDC',
case
when  ltrim(rtrim(FCU)) = '-' then NULL  
	WHEN ISNUMERIC(FCU) = '' then null
		ELSE FCU
		end as  'FCU',
case
when  LTRIM (RTRIM( FCPE)) = '-' then NULL 
	WHEN ISNUMERIC(FCPE) = '' then null
		ELSE FCPE
		end as  'FCPE',
case
when LTRIM(rtrim( TPE)) = '-' then NULL	
	WHEN ISNUMERIC(TPE) = '' then null
		ELSE TPE
		end as  'TPE'
INTO #TEMPIC1
FROM #TEMPIC
WHERE ACCOUNT IS NOT NULL
ORDER BY [NO] ASC

----3---------------------------------------------
 select ID,
 --Created_Date,
 [DATE],
 	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT],
	[CODE],
	[ACCOUNT],
		REPLACE(IDC,',','')  as 'IDC',
		REPLACE(FCU,',','')  as 'FCU',
		REPLACE(FCPE,',','')  as 'FCPE',
		REPLACE(TPE,',','')  as 'TPE'

  INTO #TEMPIC2
  from #TEMPIC1
  ORDER BY ID ASC

  SELECT * 
  FROM #TEMPIC2
  --drop table #TEMPIC2
----4---------------------------------------------
SELECT ID,
	[DATE],
	'GROUP NAME' = SUBSTRING([CODE], 1, 2),
	[CODE],
	[ACCOUNT],
  	'IDC' = cast([IDC] as numeric(18,0)),
	'FCU' = cast([FCU] as numeric(18,0)),
	'FCPE' = cast([FCPE] as numeric(18,0)),
	'TPE' = cast([TPE] as numeric(18,0)),
	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT]
INTO #TEMPIC3
FROM #TEMPIC2
ORDER BY ID ASC

--DROP TABLE #TEMPIC3
----5---------------------------------------------
------INSERT TO THE STAGING-----------------------
--NOTE: CREATE STAGING----------------------------
SELECT 
	[DATE],
	[GROUP NAME],
	[CODE],
	[ACCOUNT],
	[IDC],
	[FCU],
	[FCPE],
	[TPE],
	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT]
FROM #TEMPIC3

---------------------------------------------------------------
---------------------------------------------------------------
---SEC----------------------------------------------------------

----1---------------------------------------------
SELECT DISTINCT
	'DATE' = (select TOP 1 F19 from [dbo].[SST_TEST_MAIN] where F19 like '%/%'),
	'NO' = SUBSTRING([LOOKUP FOR MAIN], 5, 5),
	'CATEGORY' = CATEGORY,
	'INSTRUMENT'= [INSTRUMENT],
	'BS ACCOUNT' = [BALANCE SHEET ACCOUNT],
	'ECONOMIC SECTOR' = [Economic Sector],
	 [HH DEBT],
	'CODE' = [LOOKUP FOR MAIN],
	'ACCOUNT' = CONCAT([x],[x1],[x2],[x3],[x4],[x5],[x6],[x7]),
	'IDC' = [Total DC],
	'FCU' = [Total FC-USD],
	'FCPE' = [Total FC-Peso],
	'TPE' = [Total Peso Equivalent]
INTO #TEMPSEC
FROM [dbo].[SST_TEST_SEC]
WHERE [LOOKUP FOR MAIN] LIKE 'SEC%'

--DROP TABLE #TEMPIC

----2---------------------------------------------
Select 
'ID' = cast([NO] as INT),
	'DATE' = CAST([DATE] AS DATE),
	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT],
	[CODE],
	[ACCOUNT],
case
when  LTRIM(RTRIM(IDC)) = '-' then NULL 
	 WHEN ISNUMERIC(IDC) = '' then null
		ELSE IDC
		end as  'IDC',
case
when  ltrim(rtrim(FCU)) = '-' then NULL  
	WHEN ISNUMERIC(FCU) = '' then null
		ELSE FCU
		end as  'FCU',
case
when  LTRIM (RTRIM( FCPE)) = '-' then NULL 
	WHEN ISNUMERIC(FCPE) = '' then null
		ELSE FCPE
		end as  'FCPE',
case
when LTRIM(rtrim( TPE)) = '-' then NULL	
	WHEN ISNUMERIC(TPE) = '' then null
		ELSE TPE
		end as  'TPE'
INTO #TEMPSEC1
FROM #TEMPSEC
WHERE ACCOUNT IS NOT NULL
ORDER BY [NO] ASC

--SELECT * FROM #TEMPSEC1
----3---------------------------------------------
 select ID,
 [DATE],
 --Created_Date,
 	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT],
	[CODE],
	[ACCOUNT],
		REPLACE(IDC,',','')  as 'IDC',
		REPLACE(FCU,',','')  as 'FCU',
		REPLACE(FCPE,',','')  as 'FCPE',
		REPLACE(TPE,',','')  as 'TPE'

  INTO #TEMPSEC2
  from #TEMPSEC1
  ORDER BY ID ASC
  --drop table #TEMPSEC2
----4---------------------------------------------
SELECT ID,
	[DATE],
	'GROUP NAME' = SUBSTRING([CODE], 1, 3),
	[CODE],
	[ACCOUNT],
  	'IDC' = cast([IDC] as numeric(18,0)),
	'FCU' = cast([FCU] as numeric(18,0)),
	'FCPE' = cast([FCPE] as numeric(18,0)),
	'TPE' = cast([TPE] as numeric(18,0)),
	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT]
INTO #TEMPSEC3
FROM #TEMPSEC2
ORDER BY ID ASC

----5---------------------------------------------
------INSERT TO THE STAGING-----------------------
--NOTE: CREATE STAGING----------------------------
SELECT 
	[DATE],
	[GROUP NAME],
	[CODE],
	[ACCOUNT],
	[IDC],
	[FCU],
	[FCPE],
	[TPE],
	[CATEGORY],
	[INSTRUMENT],
	[BS ACCOUNT],
	[ECONOMIC SECTOR],
	[HH DEBT]
FROM #TEMPSEC3

----------------------------------------------------
--- staging fact table to staging fact table


select * 
into #SST
from #TEMPGCG3
union all
select * 
from  #TEMPIC3
union all
select * 
from #TEMPSEC3

select * from #MAINLOOKUP
where ID is not null


select ID, IC, [CURRENT 4SR],ACCOUNT
into #SSTMAIN
from #MAINLOOKUP
union all
select ID, GCG, [CURRENT 4SR],ACCOUNT
from #MAINLOOKUP
union all
select ID, SEC, [CURRENT 4SR],ACCOUNT
from #MAINLOOKUP

select a.DATE,a.[GROUP NAME],a.IDC,a.FCU,a.FCPE,a.TPE,b.[CURRENT 4SR] from #SST A
join
#SSTMAIN B
on A.CODE = b.IC