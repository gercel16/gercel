--drop table #TempTableIC_BS_sub

select * from [dbo].[Dump_MFSG_OFCS_SST_IC_BS]

-----------------0-------------------------------- IC
TRUNCATE TABLE [S_FACT_SST_IC_BC]

------------------1-------------------------------IC
SELECT  ID,
'AccountDesc' = CONCAT(column4, column5,column6,column7,column8,column9,column10,column11), 
'DomesticCurrency' = column12,
'ForeignCurrencyUSD' = column13,
'ForeignCurrrencyPESO_EQ' = column14,
'TOTAL PESO EQUIVALENT' = column15,
'FILENAME' = COLUMN50
into #TempTableIC_BS_sub
FROM [Dump_MFSG_OFCS_SST_IC_BS]
where COLUMN50 = 'IC_NL_4Q2021_CompanyNLS.xlsx'
order by ID asc 

-------------2-----------------------------------------------IC
delete #TempTableIC_BS_sub 
where ID < 7 

--SELECT * FROM #TempTableIC_BS_sub ORDER BY id ASC
-------------3-----------------------------------------------IC
update #TempTableIC_BS_sub set ID =  ID - 6

-------------4-----------------------------------------------IC
--select ROW_NUMBER() OVER(ORDER BY (SELECT ID)) AS ID2,* 
--into #TempTableGCG_BS
--from #TempTableGCG_BS_sub
--where ID > 6
--order by ID asc

SELECT * FROM #TempTableIC_BS_sub
ORDER BY  ID ASC

-------------4-----------------------------------------------IC
--DROP TABLE #GCG_BS
Select ID
,[FILENAME]
,AccountDesc,
case
when  LTRIM(RTRIM([DomesticCurrency])) = '-' then NULL 
	 WHEN ISNUMERIC([DomesticCurrency]) = '' then null
		ELSE [DomesticCurrency]
		end as  'In Domestic Currency',
case
when  ltrim(rtrim([ForeignCurrencyUSD])) = '-' then NULL  
	WHEN ISNUMERIC([ForeignCurrencyUSD]) = '' then null
		ELSE [ForeignCurrencyUSD]
		end as  'Foreign Currency USD',
case
when  LTRIM (RTRIM( [ForeignCurrrencyPESO_EQ])) = '-' then NULL 
	WHEN ISNUMERIC([ForeignCurrrencyPESO_EQ]) = '' then null
		ELSE [ForeignCurrrencyPESO_EQ]
		end as  'Foreign Currrency PESO Equivalent',
case
when LTRIM(rtrim( [TOTAL PESO EQUIVALENT])) = '-' then NULL	
	WHEN ISNUMERIC([TOTAL PESO EQUIVALENT]) = '' then null
		ELSE [TOTAL PESO EQUIVALENT]
		end as  'TOTAL PESO EQUIVALENT'
into #IC_BS
 from #TempTableIC_BS_sub
 order by id asc

 SELECT * FROM #IC_BS
------------5---------------------------------------------IC
  select ID,
 --Created_Date,   ---'IC_NL_4Q2021_CompanyNLS.xlsx'
		AccountDesc
		,REPLACE([In Domestic Currency],',','')  as 'IDC'
		,REPLACE([Foreign Currency USD],',','')  as 'FCU'
		,REPLACE([Foreign Currrency PESO Equivalent],',','')  as 'FCPE'
		,REPLACE([TOTAL PESO EQUIVALENT],',','')  as 'TPE'
		,GROUPTYPE = (SELECT SUBSTRING((SELECT top 1[FILENAME] FROM #TempTableIC_BS_sub ),1,2))
		,SETINDEX = left([FILENAME], (patindex('%NL_%',[FILENAME])) -2)
		,[QUARTER1] =  SUBSTRING([FILENAME],(patindex('%NL_%',[FILENAME]))+4,1)
		,[QUARTER2] =  SUBSTRING([FILENAME],(patindex('%NL_%',[FILENAME]))+3,1)
		,[YEAR] =  SUBSTRING([FILENAME],(patindex('%NL_%',[FILENAME]))+5,4)
		,[COMPANY] = SUBSTRING([FILENAME],(patindex('%NL_%',[FILENAME]))+10, patindex('%.x%',[FILENAME])-((patindex('%G_%',[FILENAME]))+10))
  INTO #IC_BS_T1
  from #IC_BS
   order by id asc

   --DROP TABLE #GCG_BS_T1
   --SELECT left([FILENAME], 3 )
   --  from #TempTableGCG_BS_sub

-------------6-------------------------------------------IC
SELECT ID
	,TRDATE = [YEAR]+'-'+[QUARTER1]+[QUARTER2]
	,AccountDesc
	,IDC
	,FCU
	,FCPE
	,TPE
	,GROUPTYPE
	,SETINDEX
	--,[QUARTER]
	--,[YEAR]
	,[COMPANY]
INTO #IC_BS_T1_T2
FROM #IC_BS_T1

----------7---------------------------------------------IC
	select ID,
	TRDATE,
	AccountDesc,
	Domestic_Currency = cast([IDC] as numeric(18,0))
	,Foreign_currency_USD = cast([FCU] as numeric(18,0))
	,Foreign_currency_PesoEquivalent = cast([FCPE] as numeric(18,0))
	,Total_Peso_Equivalent = cast([TPE] as numeric(18,0))
	,GROUPTYPE
	--,'SST_TYPE' = 'GCG'
	--,'COMPANY_NAME' = ''
	INTO #IC_BS_T1_T3
	from #IC_BS_T1_T2

----------8---------------------------------------------IC	
	Select
	B.Time_Idx,
	ID,
	AccountDesc,
	TRDATE,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	GROUPTYPE
	INTO #IC_BS_T1_T4
	FROM  #IC_BS_T1_T3 A
	JOIN (SELECT 
     Max(Time_Idx) Time_Idx	,Quarter_Name	
        FROM [DES].[dbo].[Dim_Time]
        GROUP BY Quarter_Name) B
	ON A.TRDATE = B.Quarter_Name

----------9----------------------------------------------IC
	select DISTINCT
	A.ID,
	A.AccountDesc,
	B.[Account Description],
	Time_Idx,
	TRDATE,
	Domestic_Currency,
	Foreign_currency_USD,
	Foreign_currency_PesoEquivalent,
	Total_Peso_Equivalent,
	[Series Code Domestic],
	[Series Code Foreign],
	GROUPTYPE
	INTO #FIN_IC_BS
	FROM  #IC_BS_T1_T4 A
	join [dbo].[S_Dim_SST_OFCS_IC_BS] B
	ON A.AccountDesc = B.[Account Description] and A.ID = B.ID
	order by A.ID asc

	--drop table #FIN_IC_BS

----------------------------------------------------------IC
INSERT INTO [dbo].[S_FACT_SST_IC_BC]
SELECT 
ID,
Time_Idx,
AccountDesc,
Domestic_Currency,
Foreign_currency_USD,
Foreign_currency_PesoEquivalent,
[Series Code Domestic],
[Series Code Foreign],
GROUPTYPE
FROM #FIN_IC_BS 

