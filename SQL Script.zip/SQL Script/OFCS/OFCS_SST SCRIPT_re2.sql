select column4, column5,column6,column7,column8,column9,column10,column11,column12
from [Dump_MFSG_OFCS_SST_GCG_BS]

select * from [dbo].[Dump_MFSG_OFCS_SST_GCG_BS]

--drop table #Temp_BS_GCG

--select * from SSIS_Properties where ReportName = 'OFCS'

select ROW_NUMBER() OVER(ORDER BY (SELECT  null)) AS ID, * 
--into #Temp_BS_GCG
from [Dump_MFSG_OFCS_SST_GCG_BS]


select ROW_NUMBER() OVER(ORDER BY (SELECT  null)) AS ID, * 
--into #Temp_BS_GCG
from [Dump_MFSG_OFCS_SST_GCG_BS]


select  
'AccountDesc' = CONCAT(column4, column5,column6,column7,column8,column9,column10,column11), 
--into #Temp_BS_GCG
'DomesticCurrency' = column12,
'ForeignCurrencyUSD' = column13,
'ForeignCurrrencyPESO_EQ' = column14,
'TOTAL PESO EQUIVALENT' = column15,
ID
from [Dump_MFSG_OFCS_SST_GCG_BS]
order by ID




select  
'AccountDesc' = CONCAT(column4, column5,column6,column7,column8,column9,column10,column11), 
'DomesticCurrency' = column12,
'ForeignCurrencyUSD' = column13,
'ForeignCurrrencyPESO_EQ' = column14,
'TOTAL PESO EQUIVALENT' = column15,
ID = ID - 6
--into #Temp_BS_GCG1
from [Dump_MFSG_OFCS_SST_GCG_BS]
where ID > 6
order by ID 




select ROW_NUMBER() OVER(ORDER BY (SELECT ID)) AS ID2, 
'AccountDesc' = CONCAT(column4, column5,column6,column7,column8,column9,column10,column11),
'DomesticCurrency' = column12,
'ForeignCurrencyUSD' = column13,
'ForeignCurrrencyPESO_EQ' = column14,
'TOTAL PESO EQUIVALENT' = column15
--into #Temp_BS_GCG2
from #Temp_BS_GCG
where ID > 7
order by ID asc

select * from #Temp_BS_GCG
order by ID asc

SELECT  
--CAST(GETDATE() AS DATE) AS Created_Date,
'AccountDesc' = CONCAT(column4, column5,column6,column7,column8,column9,column10,column11), 
'DomesticCurrency' = column12,
'ForeignCurrencyUSD' = column13,
'ForeignCurrrencyPESO_EQ' = column14,
'TOTAL PESO EQUIVALENT' = column15
--into #TempTableGCG_BS_sub
FROM #Temp_BS_GCG
where ID > 7
order by ID asc
, 
--AccountDesc OFFSET 7 ROWS



-----------------------------------------------------------

select ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS ID,* 
--into #TempTableGCG_BS
from #TempTableGCG_BS_sub
order by ID asc


select * from #TempTableGCG_BS
--where AccountDesc = 'Other Financial Corporations'
order by ID asc