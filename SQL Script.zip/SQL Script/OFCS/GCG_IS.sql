/****** Script for SelectTopNRows command from SSMS  ******/
SELECT *
 FROM [DES_Staging].[dbo].[Dump_MFSG_OFCS_SST_GCG_IS]


--1-----------------------------------------------------------------------------------
 SELECT  CONCAT(column1, column2,column3) AS Account_Desc, Column6,
 ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS ID
 into #GCGTemp_Table
  FROM [DES_Staging].[dbo].[Dump_MFSG_OFCS_SST_GCG_IS]
--------------------------------------------------------------------------------------
 --SELECT  CONCAT(column1, column2,column3) AS Account_Desc, Column6,
 --ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS ID
 --into #GCGTemp_Table
 -- FROM [DES_Staging].[dbo].[Dump_MFSG_OFCS_SST_GCG_IS]

  select *  FROM #GCGTemp_Table

--2-----------------------------------------------------------------------------------
SELECT Account_Desc,
INCOME_EXPENSE = Column6
into #GCGTemp_Table2
FROM #GCGTemp_Table
--where column15 <> ''
order by ID asc, Account_Desc OFFSET 11 ROWS

--3----------------------------------------------------------------------------------

--DROP TABLE #GCGTemp_Table3
SELECT Account_Desc,
case
when  LTRIM(RTRIM(INCOME_EXPENSE)) = '-' then NULL
	--WHEN ISNUMERIC([DomesticCurrency]) = 1 THEN [DomesticCurrency]  		
		ELSE INCOME_EXPENSE
		end as  'INCOME_EXPENSE'--,
INTO #GCGTemp_Table3
FROM #GCGTemp_Table2
WHERE Account_Desc <> ''

--4-----------------------------------------------------------------------------------

SELECT Account_Desc,
INCOME_EXPENSE = CAST(INCOME_EXPENSE AS INT)
INTO #GCGTEMP_IS
FROM #GCGTemp_Table3



